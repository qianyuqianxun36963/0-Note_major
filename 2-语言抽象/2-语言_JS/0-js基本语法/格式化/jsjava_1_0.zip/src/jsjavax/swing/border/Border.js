/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Border class references to javax.swing.border.Border of J2SE1.4 */
 
/**
 * constructor
 * param width
 * param color
 * param style
 */
function Border(width,color,style){
	this.jsjava_class="jsjavax.swing.border.Border";
    this.width=width;
    this.color=color;
    this.style=style;
}

/**
 * return the border width
 */
Border.prototype.getWidth=function(){
    return this.width;	
};

/**
 * set the border width
 * param width
 */
Border.prototype.setWidth=function(width){
    return this.width;	
};

/**
 * return the border color
 */
Border.prototype.getColor=function(){
    return this.color;	
};

/**
 * set the border color
 * param color
 */
Border.prototype.setColor=function(color){
    return this.color;	
};

/**
 * return the border style
 * param value
 */
Border.prototype.getStyle=function(){
    return this.style;	
};

/**
 * set the border style
 * param style
 */
Border.prototype.setStyle=function(style){
    return this.style;	
};