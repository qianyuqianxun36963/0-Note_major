/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The JTextField class references to javax.swing.JTextField of J2SE1.4 */
 
/**
 * constructor
 * param text
 */
function JTextField(text){
	this.jsjava_class="jsjavax.swing.JTextField";
    this.text=text;    
    this.invisible=true;
}

/**
 * return the text
 */
JTextField.prototype.getText=function(){
    return this.text;	
};

/**
 * set the text
 * param text
 */
JTextField.prototype.setText=function(text){
    this.text=text;	
};

/**
 * set the font
 * param font
 */
JTextField.prototype.setFont=function(font){
    this.font=font;	
};

/**
 * return the font
 */
JTextField.prototype.getFont=function(){
    return this.font;	
};

/**
 * set the foreground colore
 * param foreground
 */
JTextField.prototype.setForeground=function(foreground){
    this.foreground=foreground;	
};

/**
 * return the foreground color
 */
JTextField.prototype.getForeground=function(){
    return this.foreground;	
};

/**
 * set the border
 * param border
 */
JTextField.prototype.setBorder=function(border){
    this.border=border;	
};

/**
 * return the border
 */
JTextField.prototype.getBorder=function(){
    return this.border;	
};

/**
 * set the background colore
 * param background
 */
JTextField.prototype.setBackground=function(background){
    this.background=background;	
};

/**
 * return the background colore
 */
JTextField.prototype.getBackground=function(){
    return this.background;	
};

/**
 * set the insets
 * param insets
 */
JTextField.prototype.setInsets=function(insets){
    this.insets=insets;	
};

/**
 * return the insets
 */
JTextField.prototype.getInsets=function(){
    return this.insets;	
};

/**
 * set the invisibility
 * param invisible
 */
JTextField.prototype.setInvisible=function(invisible){
    this.invisible=invisible;	
};

/**
 * return the invisibility
 */
JTextField.prototype.getInvisible=function(){
    return this.invisible;	
};

/**
 * return the display content HTML
 */
JTextField.prototype.show=function(){
    var border=this.getBorder();
    var font=this.getFont();
    var foreground=this.getForeground();
    var background=this.getBackground();
    var insets=this.getInsets();
    var invisible=this.getInvisible();
    var display="inline";
    if(!invisible){
        display="none";	
    }
    var str="";
    str+="<input style='border-width:";
    str+=border.getWidth();
    str+=";border-color:";
    str+=border.getColor();
    str+=";border-style:";
    str+=border.getStyle();
    str+=";color:";
    str+=foreground.getHex();
    str+=";font-family:";
    str+=font.getFamily();
    str+=";font-size:";
    str+=font.getSize();
    str+=";background-color:";
    str+=background.getHex();
    str+=";padding:";
    str+=insets.getTop()+" "+insets.getRight()+" "+insets.getBottom()+" "+insets.getLeft();
    str+=";display:";
    str+=display;
    str+=";'";
    str+="value='"+this.getText()+"'";
    str+="/>";
    document.writeln(str);
};