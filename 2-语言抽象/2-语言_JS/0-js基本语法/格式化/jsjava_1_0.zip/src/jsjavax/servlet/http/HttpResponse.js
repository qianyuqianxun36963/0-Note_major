/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The HttpResponse class references to javax.servlet.http.HttpServletResponse of J2EE1.4 */
 
/**
 * constructor
 */
function HttpResponse(){     
	this.jsjava_class="jsjavax.servlet.http.HttpResponse";
}

/**
 * add a cookie by items
 * param name
 * param value
 * param expires
 * param path
 * param domain
 * param secure
 */
HttpResponse.prototype.addCookieByItems=function (name, value, expires, path, domain, secure){
    var curCookie = name + "=" + escape(value) +
      ((expires) ? "; expires=" + expires.toGMTString() : "") +
      ((path) ? "; path=" + path : "") +
      ((domain) ? "; domain=" + domain : "") +
      ((secure) ? "; secure" : "");
    document.cookie = curCookie;
};

/**
 * add a cookie by object
 * param cookie
 */
HttpResponse.prototype.addCookie=function (cookie){
    if(cookie==null||cookie==undefined||cookie==""){
        return;
    }
    var cName=cookie.getName();
    var cValue=cookie.getValue();
    var cExpires=cookie.getMaxAge();
    var cPath=cookie.getPath();
    var cDomain=cookie.getDomain();
    var cSecure=cookie.getSecure();
    this.addCookieByItems(cName,cValue,cExpires,cPath,cDomain,cSecure);
};