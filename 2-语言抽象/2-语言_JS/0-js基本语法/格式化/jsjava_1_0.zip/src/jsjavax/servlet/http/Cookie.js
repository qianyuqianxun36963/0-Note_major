/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Cookie class references to javax.servlet.http.Cookie of J2EE1.4 */
 
/**
 * constructor
 * param name
 * param value
 */
function Cookie(name,value){
	this.jsjava_class="jsjavax.servlet.http.Cookie";
    this.name=name;
    this.value=value;	
    this.secure=false;
    this.maxAge=0;
}

/**
 * clone a new Cookie
 */
Cookie.prototype.clone=function(){
    var clonedCookie=new cookie(this.getName(),this.getValue());
    clonedCookie.setComment(this.getComment());
    clonedCookie.setDomain(this.getDomain());
    clonedCookie.setMaxAge(this.getMaxAge());
    clonedCookie.setPath(this.getPath());
    clonedCookie.setSecure(this.getSecure());
    clonedCookie.setVersion(this.getVersion());
    return clonedCookie;
};

/**
 * return the cookie comment
 */
Cookie.prototype.getComment=function(){
    return this.comment;
};

/**
 * set the cookie comment
 * param comment
 */
Cookie.prototype.setComment=function(comment){
    this.comment=comment;
};

/**
 * return the cookie domain
 */
Cookie.prototype.getDomain=function(){
    return this.domain;
};

/**
 * set the cookie domain
 * param domain
 */
Cookie.prototype.setDomain=function(domain){
    this.domain=domain;
};

/**
 * return the cookie max age
 */
Cookie.prototype.getMaxAge=function(){
    return this.maxAge;
};

/**
 * set the cookie max age
 * param maxAge
 */
Cookie.prototype.setMaxAge=function(maxAge){
    this.maxAge=maxAge;
};

/**
 * return the cookie name
 */
Cookie.prototype.getName=function(){
    return this.name;
};

/**
 * return the cookie path
 */
Cookie.prototype.getPath=function(){
    return this.path;
};

/**
 * set the cookie path
 * param path
 */
Cookie.prototype.setPath=function(path){
    this.path=path;
};

/**
 * return the cookie secure
 */
Cookie.prototype.getSecure=function(){
    return this.secure;
};

/**
 * set the cookie secure
 * param secure
 */
Cookie.prototype.setSecure=function(secure){
    this.secure=secure;
};

/**
 * return the cookie value
 */
Cookie.prototype.getValue=function(){
    return this.value;
};

/**
 * set the cookie value
 * param value
 */
Cookie.prototype.setValue=function(value){
    this.value=value;
};

/**
 * return the cookie version
 */
Cookie.prototype.getVersion=function(){
    return this.version;
};

/**
 * set the cookie version
 * param version
 */
Cookie.prototype.setVersion=function(version){
    this.version=version;
};