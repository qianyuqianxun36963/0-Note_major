/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The HttpRequest class references to javax.servlet.http.HttpServletRequest of J2EE1.4 */
 
/**
 * constructor
 * param url
 */
   function HttpRequest(url){
   	  this.jsjava_class="jsjavax.servlet.http.HttpRequest";
      this.url=url;
      if(!url||url==""){
          this.url=location.href;
      }
      this.pos=url.indexOf("?");    
      this.length=url.length;
      this.method="GET";
      this.queryString=this.url.substring(this.pos+1,this.length);
      this.parameterEntries=this.queryString.split("&");
   }
   
/**
 * return the value of the parameter named paramName
 * param paramName
 */
   HttpRequest.prototype.getParameter=function (paramName){
       if(!this.hasQuery){
           return null;
       }
       for(var i=0;i<this.parameterEntries.length;i++){
           var param=this.parameterEntries[i];
           var paramNameValue=param.split("=");
           if(paramNameValue[0]==paramName){
              return paramNameValue[1];
           }
       }
       return null;
   };
   
/**
 * return the values of the parameter named paramName
 * param paramName
 */
   HttpRequest.prototype.getParameterValues=function (paramName){
       if(!this.hasQuery){
           return null;
       }
       var paramNameCounter=0;
       for(var i=0;i<this.parameterEntries.length;i++){
           var param=this.parameterEntries[i];
           var paramNameValue=param.split("=");
           if(paramNameValue[0]==paramName){
               paramNameCounter++;
           }
       }
       var paramValues=new Array(paramNameCounter);
       paramValueCounter=0;
       for(var i=0;i<this.parameterEntries.length;i++){
           var param=this.parameterEntries[i];
           var paramNameValue=param.split("=");
           if(paramNameValue[0]==paramName){
              paramValues[paramValueCounter++]=paramNameValue[1];
           }
       }
       if(paramValueCounter==0){
           return null;
       }
       return paramValues;
   };
   
/**
 * judge wheter the request url has query
 */
   HttpRequest.prototype.hasQuery=function (){
       return this.pos!=-1
   };
   
/**
 * return the query string
 */
   HttpRequest.prototype.queryString=function (){
       return this.queryString;
   };
   
/**
 * return the request method
 */
   HttpRequest.prototype.getMethod=function (){
       return this.method;
   };

/**
 * return the request url
 */
   HttpRequest.prototype.getRequestURL=function (){
       return this.url; 
   };
   
/**
 * return the request uri
 */
   HttpRequest.prototype.getRequestURI=function (){
       var pos=this.url.indexOf("://");
       var uriPos=this.url.indexOf("/",pos+3);
       return this.url.substring(uriPos,this.pos);
   };
   
/**
 * return the context path
 */
   HttpRequest.prototype.getContextPath=function (){
       var pos=this.url.indexOf("://");
       var uriPos=this.url.indexOf("/",pos+3);
       var contextPathEndPos=this.url.indexOf("/",uriPos+1);
       return this.url.substring(uriPos,contextPathEndPos);
   };
   
/**
 * return the context name
 */
   HttpRequest.prototype.getContextName=function (){
       var contextPath=this.getContextPath();
       return contextPath.substring(1);
   };
   
/**
 * return all document cookies
 */
   HttpRequest.prototype.getCookies=function (){
       var cookies=document.cookie.split(";");
       return cookies; 
   };
   
/**
 * return the cookie value
 * param name
 */
   HttpRequest.prototype.getCookie=function(name){
       var dc = document.cookie;
       var prefix = name + "=";
       var begin = dc.indexOf("; " + prefix);
       if (begin == -1) {
	   begin = dc.indexOf(prefix);
	   if (begin != 0) {
	       return null;
	   }
       } else {
	   begin += 2;
       }
       var end = document.cookie.indexOf(";", begin);
       if (end == -1) {
	   end = dc.length;
       }
       return unescape(dc.substring(begin + prefix.length, end));	
   };
   
/**
 * remove a cookie
 * param name
 * param path
 * path domain
 */
   HttpRequest.prototype.removeCookie=function(name,path,domain){
       if (this.getCookie(name)) {
           document.cookie = name + "=" +
           ((path) ? "; path=" + path : "") +
           ((domain) ? "; domain=" + domain : "") +
           "; expires=Thu, 01-Jan-70 00:00:01 GMT";
       }
   };
   