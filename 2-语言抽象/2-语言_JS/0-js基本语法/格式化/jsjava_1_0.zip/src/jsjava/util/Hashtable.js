/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Hashtable class references to java.util.Hashtable of J2SE1.4 */
 
/**
 * constructor
 */
function Hashtable(){
	this.jsjava_class="jsjava.util.Hashtable";
    this.capacity=50;
    this.size=0;
    this.span=10;
    this.elements=new Array(this.capacity);
}

/**
 * Increases the capacity of and internally reorganizes this 
 * hashtable, in order to accommodate and access its entries 
 * more efficiently.
 */
Hashtable.prototype.recapacity=function(){
    if(this.capacity-this.size<10){
     this.capacity+=this.span;
     var oldElements=this.elements;
        this.elements=new Array(this.capacity); 
        for(var i=0;i<this.size;i++){
            this.elements[i]=oldElements[i]; 
        }
    }
};

/**
 * Removes all mappings from this map 
 */
Hashtable.prototype.clear=function(){
    this.capacity=50;
    this.size=0;
    this.elements=new Array(this.capacity); 
};

/**
 * Associates the specified value with the specified key in this map 
 * param pname
 * param pvalue 
 */
Hashtable.prototype.put=function (pname,pvalue){
    this.recapacity();
    if(this.containsKey(pname)){
        for(var i=0;i<this.size;i++){
            var elem=this.elements[i];
            if(elem[0].equals(pname)){
                elem[1]=pvalue;
                return;
            } 
        } 
    }
    this.elements[this.size++]=[pname,pvalue];
   
};

/**
 * Returns the value to which this map maps the specified key. 
 * param pname
 */
Hashtable.prototype.get=function (pname){
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        if(elem[0].equals(pname)){
            return elem[1]; 
        } 
    }
};

/**
 * Returns true if this map contains a mapping for the specified key.
 * param pname
 */
Hashtable.prototype.containsKey=function(pname){
    if(this.get(pname)==undefined){
        return false; 
    }
    return true;
};

/**
 * Returns true if this map maps one or more keys to the specified value.
 * param pname
 */
Hashtable.prototype.containsValue=function (pvalue){
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        if(elem[1].equals(pvalue)){
            return true;
        } 
    }
    return false;
};

/**
 * Returns a array view of the values contained in this map.
 */
Hashtable.prototype.values=function (){
    var values=new Array(this.size);
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        values[i]=elem[1]; 
    } 
    return values;
};

/**
 * Returns a set view of the mappings contained in this map.
 */
Hashtable.prototype.entrySet=function (){
    return this.elements; 
};

/**
 * Returns true if this map contains no key-value mappings.
 */
Hashtable.prototype.isEmpty=function (){
    return this.size==0; 
};

/**
 * Returns an array of the keys in this hashtable.
 */
Hashtable.prototype.keys=function (){
    var keys=new Array(this.size);
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        keys[i]=elem[0]; 
    } 
    return keys;
};

/**
 * Returns an array of the keys in this hashtable.
 */
Hashtable.prototype.keySet=function (){
    var set=new Set();
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        set.add(elem[0]); 
    } 
    return set;
};

/**
 * Returns the number of keys in this hashtable.
 */
Hashtable.prototype.getSize=function (){
    return this.size; 
};

/**
 * Removes the key (and its corresponding value) from this hashtable.
 * param key
 */
Hashtable.prototype.remove=function (key){
    if(this.containsKey(key)){
        var oldElems=this.elements;
        var oldSize=this.size;
        this.elements=new Array(this.capacity);
        this.size=0;
        for(var i=0;i<oldSize;i++){
            var oldElem=oldElems[i];
            if(!oldElem[0].equals(key)){
                this.put(oldElem[0],oldElem[1]); 
            } 
        } 
    }
};

/**
 * add a array to the hash
 * param arr
 */
Hashtable.prototype.addArray=function (arr){
    if(arr!=null&&arr.length>0){
        for(var i=0;i<arr.length;i++){
            this.put(arr[i][0],arr[i][1]); 
        } 
    } 
};

/**
 * add a hash to the hash
 * param hash
 */
Hashtable.prototype.addHashtable=function (hash){
    if(hash!=null&&hash.size()>0){
        var keys=hash.keys();
        for(var i=0;i<keys.length;i++){
            this.put(keys[i],hash.get(keys[i])); 
        } 
    } 
};

/**
 * Returns a string representation of this Hashtable 
 * object in the form of a set of entries, enclosed 
 * in braces and separated by the ASCII characters ", " 
 * (comma and space).
 */
Hashtable.prototype.toString=function (){
    return this.elements.toString(); 
};
