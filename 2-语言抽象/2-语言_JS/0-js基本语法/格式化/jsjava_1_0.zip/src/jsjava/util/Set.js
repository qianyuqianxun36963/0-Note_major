/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Set class references to java.util.Set of J2SE1.4 */
 
/**
 * constructor
 */
function Set(){
	this.jsjava_class="jsjava.util.Set";
    this.capacity=50;
    this.size=0;
    this.span=10;
    this.elements=new Array(this.capacity);
}

/**
 * Increases the capacity of and internally reorganizes this 
 * set, in order to accommodate and access its entries 
 * more efficiently.
 */
Set.prototype.recapacity=function (){
    if(this.capacity-this.size<10){
     this.capacity+=this.span;
     var oldElements=this.elements;
        this.elements=new Array(this.capacity); 
        for(var i=0;i<this.size;i++){
            this.elements[i]=oldElements[i]; 
        }
    }
};

/**
 * Adds the specified element to this set if it is not already present
 */
Set.prototype.add=function (pvalue){
    if(this.contains(pvalue)){
    	return;
    }
    this.recapacity();
    this.elements[this.size++]=pvalue;    
};

/**
 * Inserts the specified element at the specified position in this set
 * if it is not already present
 * param index
 * param pvalue
 */
Set.prototype.addIndexOf=function (index,pvalue){
    if(this.contains(pvalue)){
    	return;
    }
    this.recapacity();
    if(index>=this.size){
        this.elements[this.size]=pvalue;
        return; 
    }
    this.size++;      
    for(var i=this.size-1;i>index;i--){
     this.elements[i]=this.elements[i-1];
    } 
    this.elements[index]=pvalue;
};

/**
 * Removes all of the elements from this set.
 */
Set.prototype.clear=function (){
    this.elements=new Array(this.capacity); 
};

/**
 * Returns true if this set contains the specified element.
 * param pvalue
 */
Set.prototype.contains=function (pvalue){
    for(var i=0;i<this.size;i++){
     var elem=this.elements[i]
        if(elem.equals(pvalue)){
            return true; 
        } 
    } 
    return false;
};

/**
 * Returns the element at the specified position in this set.
 * param index
 */
Set.prototype.get=function (index){
    return this.elements[index];
};

/**
 * Returns the index in this set of the first occurrence of the 
 * specified element, or -1 if this list does not contain this element.
 * param pvalue
 */
Set.prototype.indexOf=function (pvalue){
    for(var i=0;i<this.size;i++){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return i; 
        } 
    } 
    return -1;
};

/**
 * Returns true if this set contains no elements.
 */
Set.prototype.isEmpty=function (){
    return this.size==0;
};

/**
 * Returns an iterator over the elements in this set in proper sequence.
 */
Set.prototype.iterator=function (){
    return new Iterator(this);
};

/**
 * Returns the index in this set of the last occurrence of the specified 
 * element, or -1 if this set does not contain this
 */
Set.prototype.lastIndexOf=function (pvalue){
    for(var i=this.size-1;i>=0;i--){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return i; 
        } 
    } 
    return -1;
};

/**
 * Removes the element at the specified position in this set
 * param index
 */
Set.prototype.removeIndexOf=function (index){
    if(index>-1&&index<this.size){
     var oldElems=this.elements;
     this.elements=new Array(this.capacity);
     this.size--;
     for(var i=0;i<this.size;i++){
         if(i<index){
             this.elements[i]=oldElems[i]; 
         }else{
             this.elements[i]=oldElems[i+1];
         } 
        
     }
    }
};

/**
 * Removes the first occurrence in this set of the specified element
 * param pvalue
 */
Set.prototype.remove=function (pvalue){
    this.removeIndexOf(this.indexOf(pvalue));
};

/**
 * Replaces the element at the specified position in this set with the 
 * specified element
 * param index
 * param pvalue
 *
Set.prototype.set=function (index,pvalue){
    if(this.contains(pvalue)){
    	return;
    }
    this.elements[index]=pvalue;
};

/**
 * Returns a view of the portion of this set between the specified 
 * fromIndex, inclusive, and toIndex, exclusive.
 * param index1
 * param index2
 */
Set.prototype.subSet=function (index1,index2){
    var l=new Set();
    for(var i=index1;i<index2;i++){
        l.add(this.elements[i]); 
    }
    return l;
};

/**
 * Appends all of the elements in the specified array to the end of 
 * this set
 * param arr
 */
Set.prototype.addArray=function (arr){
    if(arr==undefined||arr.length==undefined){
        return; 
    } 
    for(var i=0;i<arr.length;i++){
    	if(this.contains(arr[i])){
    	    continue;
        }
        this.add(arr[i]); 
    }
};

/**
 * Appends all of the elements in the specified set to the end of 
 * this set
 * param set
 */
Set.prototype.addSet=function (Set){
    if(Set==undefined||Set.size<=0){
        return; 
    }
    this.addArray(Set.elements);
};

/**
 * Returns the number of elements in this set. 
 */
Set.prototype.getSize=function (){
    return this.size;
};

/**
 * Returns an array containing all of the elements 
 * in this set in proper sequence. 
 */
Set.prototype.toArray=function (){
    var arr=new Array(this.size);
    for(var i=0;i<this.size;i++){
        arr[i]=this.elements[i]; 
    } 
    return arr;
};

/**
 * Returns a string representation of this Set object
 */
Set.prototype.toString=function (){
    return this.toArray().toString(); 
};
