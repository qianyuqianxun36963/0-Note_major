/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Properties class references to java.util.Properties of J2SE1.4 */
 
/**
 * constructor
 */
function Properties(){
	this.jsjava_class="jsjava.util.Properties";
    this.capacity=50;
    this.size=0;
    this.span=10;
    this.elements=new Array(this.capacity);
}

/**
 * Increases the capacity of and internally reorganizes this 
 * properties, in order to accommodate and access its entries 
 * more efficiently.
 */
Properties.prototype.recapacity=function(){
    if(this.capacity-this.size<10){
     this.capacity+=this.span;
     var oldElements=this.elements;
        this.elements=new Array(this.capacity); 
        for(var i=0;i<this.size;i++){
            this.elements[i]=oldElements[i]; 
        }
    }
};

/**
 * Removes all of the elements from this properties
 */
Properties.prototype.clear=function(){
    this.capacity=50;
    this.size=0;
    this.elements=new Array(this.capacity); 
};

/**
 * Replaces the element at the specified position in this properties with the 
 * specified element
 * param index
 * param pvalue
 */
Properties.prototype.set=function (pname,pvalue){
    this.recapacity();
    if(this.containsKey(pname)){
        for(var i=0;i<this.size;i++){
            var elem=this.elements[i];
            if(elem[0].equals(pname)){
                elem[1]=pvalue;
                return;
            } 
        } 
    }
    this.elements[this.size++]=[pname,pvalue];
   
};

/**
 * Associates the specified value with the specified key in this properties 
 * param pname
 * param pvalue 
 */
Properties.prototype.setProperty=function(pname,pvalue){
    if(typeof(pname)=="string"&&typeof(pvalue)=="string"){
        this.set(pname,pvalue);	
    }
};

/**
 * Returns the value to which this properties maps the specified key. 
 * param pname
 */
Properties.prototype.get=function (pname){
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        if(elem[0].equals(pname)){
            return elem[1]; 
        } 
    }
};

/**
 * Searches for the property with the specified key in this property list.
 */
Properties.prototype.getProperty=function (pname){
    var pvalue= this.get(pname);
    if(typeof(pvalue)=="string"){
    	return pvalue;
    }
    return null;
};

/**
 * Returns true if this properties contains a mapping for the specified key.
 * param pname
 */
Properties.prototype.containsKey=function(pname){
    if(this.get(pname)==undefined){
        return false; 
    }
    return true;
};

/**
 * Returns true if this properties maps one or more keys to the specified value.
 * param pname
 */
Properties.prototype.containsValue=function (pvalue){
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        if(elem[1].equals(pvalue)){
            return true;
        } 
    }
    return false;
};

/**
 * Returns a array view of the values contained in this properties.
 */
Properties.prototype.values=function (){
    var values=new Array(this.size);
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        values[i]=elem[1]; 
    } 
    return values;
};

/**
 * Returns a set view of the mappings contained in this properties.
 */
Properties.prototype.entrySet=function (){
    return this.elements; 
};

/**
 * Returns true if this properties contains no key-value mappings.
 */
Properties.prototype.isEmpty=function (){
    return this.size==0; 
};

/**
 * Returns an array of the keys in this properties.
 */
Properties.prototype.keys=function (){
    var keys=new Array(this.size);
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        keys[i]=elem[0]; 
    } 
    return keys;
};

/**
 * Returns the number of keys in this properties.
 */
Properties.prototype.getSize=function (){
    return this.size; 
};

/**
 * Removes the key (and its corresponding value) from this properties.
 * param key
 */
Properties.prototype.remove=function (key){
    if(this.containsKey(key)){
        var oldElems=this.elements;
        var oldSize=this.size;
        this.elements=new Array(this.capacity);
        this.size=0;
        for(var i=0;i<oldSize;i++){
            var oldElem=oldElems[i];
            if(!oldElem[0].equals(key)){
                this.put(oldElem[0],oldElem[1]); 
            } 
        } 
    }
};

/**
 * add a array to the properties
 * param arr
 */
Properties.prototype.addArray=function (arr){
    if(arr!=null&&arr.length>0){
        for(var i=0;i<arr.length;i++){
            this.put(arr[i][0],arr[i][1]); 
        } 
    } 
};

/**
 * add a hash to the properties
 * param hash
 */
Properties.prototype.addProperties=function (hash){
    if(hash!=null&&hash.size()>0){
        var keys=hash.keys();
        for(var i=0;i<keys.length;i++){
            this.put(keys[i],hash.get(keys[i])); 
        } 
    } 
};

/**
 * Returns a string representation of this Properties object
 */
Properties.prototype.toString=function (){
    return this.elements.toString(); 
};
