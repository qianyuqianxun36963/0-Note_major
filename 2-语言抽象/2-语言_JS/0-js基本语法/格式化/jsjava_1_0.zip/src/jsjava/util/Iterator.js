/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Iterator class references to java.util.Iterator of J2SE1.4 */
 
/**
 * constructor
 * param list a List object
 */
function Iterator(list){
	this.jsjava_class="jsjava.util.Iterator";
    this.list=list;
    this.nextIndex=0;
    this.size=list.getSize();
}

/**
 * Returns true if the iteration has more elements.
 */
Iterator.prototype.hasNext=function(){
    return this.nextIndex<this.size;
};

/**
 * Returns the next element in the iteration.
 */
Iterator.prototype.next=function(){
    var nextObj;
    if(this.nextIndex<this.size){
        nextObj=this.list.get(this.nextIndex);
        this.nextIndex++;
        return nextObj;
    }
    return null;
};

/**
 * Move the opertion position to the specified index
 */
Iterator.prototype.moveTo=function(index){
    this.nextIndex=index;	
};