/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The BooleanUtils class references to org.apache.commons.lang.BooleanUtils */
 
function BooleanUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.BooleanUtils";
}

/**
 * Is a Boolean value false
 * param value
 */
BooleanUtils.isFalse=function(value){
	var type=typeof(value);
	if(type=="boolean"){
		if(!value){
			return true;
		}
	}
	if(type=="string"){
	    if(value=="false"){
	    	return true;
	    }
	}
	if(type=="object"){
	    if(value.booleanValue()==false||value.booleanValue()=="false"){
	    	return true;
	    }
	}
	return false;
};

/**
 * Is a Boolean value true
 * param value
 */
BooleanUtils.isTrue=function(value){
	var type=typeof(value);
	if(type=="boolean"){
		if(value){
			return true;
		}
	}
	if(type=="string"){
	    if(value=="true"){
	    	return true;
	    }
	}
	if(type=="object"){
	    if(value.booleanValue()==true||value.booleanValue()=="true"){
	    	return true;
	    }
	}
	return false;
};

/**
 * Negates the specified boolean.
 * param value
 */
BooleanUtils.negate=function(value){
	var type=typeof(value);
	if(type=="boolean"){
		return !value;
	}
	if(type=="string"){
	    if(value=="true"){
	    	return "false";
	    }
	    if(value=="false"){
	    	return "true";
	    }
	}
	if(type=="object"){
		var ovalue=value.booleanValue();
	    if(ovalue=="true"){
	    	return new Boolean("false");
	    }
	    if(ovalue=="false"){
	    	return new Boolean("true");
	    }
	    if(ovalue==true){
	    	return new Boolean(false);
	    }
	    if(ovalue==false){
	    	return new Boolean(true);
	    }
	}
	return null;
};

/**
 * Converts a Boolean to a boolean
 * param value
 */
BooleanUtils.toBoolean=function(value){
	var type=typeof(value);
	if(type=="boolean"){
		return value;
	}
	if(type=="string"){
		if(value=="true"){
			return true;
		}else{
			return false;
		}
	}
	if(type=="object"){
		return value.booleanValue();
	}
	if(type=="number"){
		if(value==0){
			return false;
		}else{
			return true;
		}
	}
	return false;
};

/**
 * Converts a Boolean to a boolean handling null.
 * param value
 * param defaultValue
 */
BooleanUtils.toBooleanDefaultIfNull=function(value,defaultValue){
	if(value==null||value==undefined){
		return defaultValue;	
	}
	return BooleanUtils.toBoolean(value);
};

/**
 * Converts an object to a Boolean using the convention.
 * param value
 */
BooleanUtils.toBooleanObject=function(value){
	return new Boolean(BooleanUtils.toBoolean(value));
};

/**
 *  Converts a boolean to an int specifying the conversion values.
 * param value
 * param trueValue
 * param falseValue
 * param nullValue
 */
BooleanUtils.toInteger=function(value,trueValue,falseValue,nullValue){
	if(value==null||value==undefined){
		return nullValue;	
	}
	if(BooleanUtils.toBoolean(value)){
		return trueValue;
	}
	return falseValue;
};

/**
 * Converts a Boolean to an Integer specifying the conversion values.
 * param value
 * param trueValue
 * param falseValue
 * param nullValue
 */
BooleanUtils.toIntegerObject=function(value,trueValue,falseValue,nullValue){
	if(value==null||value==undefined){
		return nullValue;	
	}
	if(BooleanUtils.toBoolean(value)){
		return trueValue;
	}
	return falseValue;
};

/**
 * Converts a Boolean to a String returning one of the input Strings.
 * param value
 * param trueString
 * param falseString
 * param nullString
 */
BooleanUtils.toString=function(value,trueString,falseString,nullString){
	if(value==null||value==undefined){
		return nullString;	
	}
	if(BooleanUtils.toBoolean(value)){
		return trueString;
	}
	return falseString;
};

/**
 * Converts a boolean to a String returning 'on' or 'off'.
 * param value
 */
BooleanUtils.toStringOnOff=function(value){
	if(value==null||value==undefined){
		return "off";	
	}
	if(BooleanUtils.toBoolean(value)){
		return "on";
	}
	return "off";
};

/**
 * Converts a Boolean to a String returning 'on', 'off'
 * param value
 */
BooleanUtils.toStringTrueFalse=function(value){
	if(value==null||value==undefined){
		return "false";	
	}
	if(BooleanUtils.toBoolean(value)){
		return "true";
	}
	return "false";
};

/**
 * Converts a boolean to a String returning 'yes' or 'no'.
 * param value
 */
BooleanUtils.toStringYesNo=function(value){
	if(value==null||value==undefined){
		return "no";	
	}
	if(BooleanUtils.toBoolean(value)){
		return "yes";
	}
	return "no";
};

/**
 * Performs an xor on a set of booleans.
 * param arr
 */
BooleanUtils.xor=function(arr){
	var narr=new Array(arr.length);
	for(var i=0;i<arr.length;i++){
		narr[i]=BooleanUtils.toBoolean(arr[i]);
	}
	var xvalue=narr[0];
	for(var i=1;i<arr.length;i++){
		xvalue=xvalue^narr[i];
	}
	return BooleanUtils.toBoolean(xvalue);
};