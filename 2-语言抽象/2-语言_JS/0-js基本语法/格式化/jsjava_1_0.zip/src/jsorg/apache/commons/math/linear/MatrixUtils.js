/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The MatrixUtils class references to org.apache.commons.math.linear.MatrixUtils */
 
function MatrixUtils(){
	this.jsjava_class="jsorg.apache.commons.math.linear.MatrixUtils";
}

MatrixUtils.createRowRealMatrix=function(rowData){
	var nCols = rowData.length;
    var data=new Array(1);
    for(var i=0;i<1;i++){
    	data[i]=new Array(nCols);
    }
    for(var j=0;j<nCols;j++){
    	data[0][j]=rowData[j];
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(data);
};

MatrixUtils.createColumnRealMatrix=function(columnData){
	var nRows = columnData.length;
    var data=new Array(nRows);
    for(var i=0;i<nRows;i++){
    	data[i]=new Array(1);
    }
    for (var row = 0; row < nRows; row++) {
        data[row][0] = columnData[row];
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(data);
};


MatrixUtils.createRealIdentityMatrix=function(dimension){
	var out = new RealMatrixImpl(dimension, dimension);
    var d = out.getDataRef();
    for (var row = 0; row < dimension; row++) {
        for (var col = 0; col < dimension; col++) {
            d[row][col] = row == col ? 1 : 0;
        }
    }
    return out;
};