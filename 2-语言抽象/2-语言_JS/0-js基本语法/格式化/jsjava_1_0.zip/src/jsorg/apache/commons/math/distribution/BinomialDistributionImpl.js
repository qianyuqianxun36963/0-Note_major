/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The BinomialDistributionImpl class references to org.apache.commons.math.distribution.BinomialDistributionImpl */

function BinomialDistributionImpl(trials,p){
	this.jsjava_class="org.apache.commons.math.distribution.BinomialDistributionImpl";	
	if (trials < 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"number of trials must be non-negative.");
    }
    this.numberOfTrials = trials;
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"probability of success must be between 0.0 and 1.0, inclusive.");
    }
    this.probabilityOfSuccess = p;
}

/**
 * For this distribution, X, this method returns P(X �� x).
 * param x
 */
BinomialDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
	var sx=new String(x);
	if(sx.indexOf(".")!=-1){
		x=Math.floor(x);
	}
    if (x < 0) {
        ret = 0.0;
    } else if (x >= this.getNumberOfTrials()) {
        ret = 1.0;
    } else {    	
        ret =
            1.0 - Beta.regularizedBeta(
                    this.getProbabilityOfSuccess(),
                    x + 1.0,
                    this.getNumberOfTrials() - x);
    }
    return ret;
};

/**
 * For a random variable X whose values are distributed according
 * to this distribution, this method returns P(x0 &le; X &le; x1).
 * @param x0 the inclusive, lower bound
 * @param x1 the inclusive, upper bound
 */
BinomialDistributionImpl.prototype.cumulativeProbability2=function(x0,x1){
	if (x0 > x1) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"lower endpoint must be less than or equal to upper endpoint");
    }
    return this.cumulativeProbability(x1) - this.cumulativeProbability(x0 - 1);
};

/**
 * Access the domain value lower bound, based on p, used to bracket a PDF root.
 * param d
 */
BinomialDistributionImpl.prototype.getDomainLowerBound=function(d){
	return -1;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a PDF root.
 * param p
 */
BinomialDistributionImpl.prototype.getDomainUpperBound=function(p){
	return this.getNumberOfTrials();
};

/**
 * Access the number of trials for this distribution.
 */
BinomialDistributionImpl.prototype.getNumberOfTrials=function(){
	return this.numberOfTrials;
};

/**
 * Access the probability of success for this distribution.
 */
BinomialDistributionImpl.prototype.getProbabilityOfSuccess=function(){
	return this.probabilityOfSuccess;
};

/**
 * For this distribution, X, this method returns the largest x, such that P(X �� x) �� p.
 * param p
 */
BinomialDistributionImpl.prototype.inverseCumulativeProbability=function(p){
	// handle extreme values explicitly
    if (p == 0) {
        return -1;
    } 
    if (p == 1) {
        return Integer.MAX_VALUE; 
    }
    
    // use default bisection impl
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException(
            "p must be between 0 and 1.0 (inclusive)");
    }
    
    // by default, do simple bisection.
    // subclasses can override if there is a better method.
    var x0 = this.getDomainLowerBound(p);
    var x1 = this.getDomainUpperBound(p);
    var pm;
    while (x0 < x1) {
        var xm = x0 + Math.floor((x1 - x0) / 2);
        pm = this.cumulativeProbability(xm);
        if (pm > p) {
            // update x1
            if (xm == x1) {
                // this can happen with integer division
                // simply decrement x1
                --x1;
            } else {
                // update x1 normally
                x1 = xm;
            }
        } else {
            // update x0
            if (xm == x0) {
                // this can happen with integer division
                // simply increment x0
                ++x0;
            } else {
                // update x0 normally
                x0 = xm;
            }
        }
    }
    
    // insure x0 is the correct critical point
    pm = this.cumulativeProbability(x0);
    while (pm > p) {
    	--x0;
        pm = this.cumulativeProbability(x0);
    }

    return x0;
};

/**
 * For this disbution, X, this method returns P(X = x).
 * param x
 */
BinomialDistributionImpl.prototype.probability=function(x){
	var ret;
    if (x < 0 || x > this.getNumberOfTrials()) {
        ret = 0.0;
    } else {
    	var sx=new String(x);
    	if(sx.indexOf(".")!=-1){
    		var fl = Math.floor(x);
		    if (fl == x) {
		        return this.probability(f1);
		    } else {
		        return 0;
		    }
    	}
        ret = MathUtils.binomialCoefficientDouble(
                this.getNumberOfTrials(), x) *
              Math.pow(this.getProbabilityOfSuccess(), x) *
              Math.pow(1.0 - this.getProbabilityOfSuccess(),
                    this.getNumberOfTrials() - x);
    }
    return ret;
};