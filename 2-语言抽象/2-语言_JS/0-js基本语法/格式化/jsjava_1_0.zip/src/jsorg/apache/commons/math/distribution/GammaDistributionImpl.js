/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The GammaDistributionImpl class references to org.apache.commons.math.distribution.GammaDistributionImpl */

function GammaDistributionImpl(alpha,beta){
	this.jsjava_class="org.apache.commons.math.distribution.GammaDistributionImpl";		
	if (alpha <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"alpha must be positive");
    }
    this.alpha = alpha;
    if (beta <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"beta must be positive");
    }
    this.beta = beta;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
GammaDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    
    if (x <= 0.0) {
        ret = 0.0;
    } else {
        ret = Gamma.regularizedGammaP(this.getAlpha(), x / this.getBeta());
    }

    return ret;
};

/**
 * Access the shape parameter, alpha
 */
GammaDistributionImpl.prototype.getAlpha=function(){
	return this.alpha;
};

/**
 * Access the scale parameter, beta
 */
GammaDistributionImpl.prototype.getBeta=function(){
	return this.beta;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
GammaDistributionImpl.prototype.getDomainLowerBound=function(p){
	return Double.MIN_VALUE;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
GammaDistributionImpl.prototype.getDomainUpperBound=function(p){
	var ret;

    if (p < .5) {
        // use mean
        ret = this.getAlpha() * this.getBeta();
    } else {
        // use max value
        ret = Double.MAX_VALUE;
    }
    
    return ret;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
GammaDistributionImpl.prototype.getInitialDomain=function(p){
	var ret;

    if (p < .5) {
        // use 1/2 mean
        ret = this.getAlpha() * this.getBeta() * .5;
    } else {
        // use mean
        ret = this.getAlpha() * this.getBeta();
    }
    
    return ret;
};

/**
 * Modify the shape parameter, alpha.
 * param alpha
 */
GammaDistributionImpl.prototype.setAlpha=function(alpha){
	if (alpha <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"alpha must be positive");
    }
    this.alpha = alpha;
};

/**
 * Modify the scale parameter, beta.
 * param beta
 */
GammaDistributionImpl.prototype.setBeta=function(beta){
	if (beta <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"beta must be positive");
    }
    this.beta = beta;
};