/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The DistributionFactoryImpl class references to org.apache.commons.math.distribution.DistributionFactoryImpl */

function DistributionFactoryImpl(){
	this.jsjava_class="org.apache.commons.math.distribution.DistributionFactoryImpl";	
}

DistributionFactoryImpl.newInstance=function(){
	return new DistributionFactoryImpl();
};

/**
 * Create a binomial distribution with the given number of trials and probability of success.
 * param numberOfTrials
 * param probabilityOfSuccess
 */
DistributionFactoryImpl.prototype.createBinomialDistribution=function(numberOfTrials,probabilityOfSuccess){
	return new BinomialDistributionImpl(numberOfTrials,
            probabilityOfSuccess);
};

/**
 * Create a new chi-square distribution with the given degrees of freedom.
 * param degreesOfFreedom
 */
DistributionFactoryImpl.prototype.createChiSquareDistribution=function(degreesOfFreedom){
	return new ChiSquaredDistributionImpl(degreesOfFreedom);
};

/**
 * Create a new exponential distribution with the given degrees of freedom.
 * param mean
 */
DistributionFactoryImpl.prototype.createExponentialDistribution=function(mean){
	return new ExponentialDistributionImpl(mean);
};

/**
 * Create a new F-distribution with the given degrees of freedom.
 * param numeratorDegreesOfFreedom
 * param denominatorDegreesOfFreedom
 */
DistributionFactoryImpl.prototype.createFDistribution=function(numeratorDegreesOfFreedom,denominatorDegreesOfFreedom){
	return new FDistributionImpl(numeratorDegreesOfFreedom,
            denominatorDegreesOfFreedom);
};

/**
 * 
 * param
 * param
 */
DistributionFactoryImpl.prototype.createGammaDistribution=function(alpha,beta){
	return new GammaDistributionImpl(alpha, beta);
};

/**
 * Create a new gamma distribution the given shape and scale parameters.
 * param populationSize
 * param numberOfSuccesses
 * param sampleSize
 */
DistributionFactoryImpl.prototype.createHypergeometricDistribution=function(populationSize,numberOfSuccesses,sampleSize){
	return new HypergeometricDistributionImpl(populationSize,
            numberOfSuccesses, sampleSize);
};

/**
 * Create a new normal distribution with the given mean and standard deviation.
 * param mean
 * param sd
 */
DistributionFactoryImpl.prototype.createNormalDistribution=function(mean,sd){
	return new NormalDistributionImpl(mean, sd);
};

/**
 * Create a new Poisson distribution with poisson parameter lambda.
 * param lambda
 */
DistributionFactoryImpl.prototype.createPoissonDistribution=function(lambda){
	return new PoissonDistributionImpl(lambda);
};

/**
 * Create a new t distribution with the given degrees of freedom.
 * param degreesOfFreedom
 */
DistributionFactoryImpl.prototype.createTDistribution=function(degreesOfFreedom){
	return new TDistributionImpl(degreesOfFreedom);
};