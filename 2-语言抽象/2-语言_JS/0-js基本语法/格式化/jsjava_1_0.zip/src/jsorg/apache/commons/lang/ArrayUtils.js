/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The ArrayUtils class references to org.apache.commons.lang.ArrayUtils */
 
function ArrayUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.ArrayUtils";
}

/**
 * Copies the given array and adds the given element at the end of the new array.
 * param arr
 * param value
 */
ArrayUtils.add=function(arr,value){
	var narr=new Array(arr.length+1);
	for(var i=0;i<arr.length;i++){
		narr[i]=arr[i];
	}
	narr[arr.length]=value;
	return narr;
};

/**
 * Inserts the specified element at the specified position in the array.
 * param arr
 * param index
 * param value
 */
ArrayUtils.addIndexOf=function(arr,index,value){
	if(index>arr.length||index<0){
	    return arr;
	}
	var narr=new Array(arr.length+1);
	for(var i=0;i<narr.length;i++){
	    if(i<index){
	    	narr[i]=arr[i];
	    }else if(i==index){
	    	narr[i]=value;
	    }else{
	    	narr[i]=arr[i-1];
	    }
	} 
	return narr;
};

/**
 * Adds all the elements of the given arrays into a new array.
 * param toArr
 * param fromArr
 */
ArrayUtils.addAll=function(toArr,fromArr){
	var toArrLength=toArr.length;
	var fromArrLength=fromArr.length;
	var narr=new Array(toArrLength+fromArrLength);
	var j=0;
	for(var i=0;i<narr.length;i++){
		if(j==toArrLength){
			j=0;
		}
		if(i<toArrLength){
		    narr[i]=toArr[j];		    
		}else{
			narr[i]=fromArr[j];
		}
		j++;
	}
	return narr;
};

/**
 * Clones an array returning a typecast result.
 * param arr
 */
ArrayUtils.clone=function(arr){
	var narr=new Array(arr.length);
	for(var i=0;i<arr.length;i++){
		narr[i]=arr[i];
	}
	return narr;
};

/**
 * Checks if the value is in the given array.
 * param arr
 * param value
 */
ArrayUtils.contains=function(arr,value){
	for(var i=0;i<arr.length;i++){
		if(arr[i]==value){
			return true;
		}
	}
	return false;
};

/**
 * Checks if the value is in the given array.This method need each object 
 * to initialize the eqeuals method.
 * param arr
 * param value
 */
ArrayUtils.containsEqual=function(arr,value){
	for(var i=0;i<arr.length;i++){
		if(arr[i].equals(value)){
			return true;
		}
	}
	return false;
};

/**
 * Returns the length of the specified array.
 * param arr
 */
ArrayUtils.getLength=function(arr){
	return arr.length;
};

/**
 * Finds the index of the given value in the array.
 * param arr
 * param value
 */
ArrayUtils.indexOf=function(arr,value){
	for(var i=0;i<arr.length;i++){
		if(arr[i]==value){
			return i;
		}
	}
	return -1;
};

/**
 * Checks if an array of primitive booleans is empty or undefined
 * param arr
 */
ArrayUtils.isEmpty=function(arr){
	if(arr==undefined||arr.length==0){
		return true;
	}
	return false;
};

/**
 * Compares two arrays, using equals().
 * param arr1
 * param arr2
 */
ArrayUtils.isEquals=function(arr1,arr2){
	var arr1Length=arr1.length;
	var arr2Length=arr2.length;
	if(arr1Length!=arr2Length){
		return false;
	}	
	for(var i=0;i<arr1Length;i++){
		if(arr1[i]!=arr2[i]){
			return false;
		}
	}
	return true;
};

/**
 * Checks whether two arrays are the same length.
 * param arr1
 * param arr2
 */
ArrayUtils.isSameLength=function(arr1,arr2){
	var arr1Length=arr1.length;
	var arr2Length=arr2.length;
	if(arr1Length!=arr2Length){
		return false;
	}	
	return true;
};

/**
 * Finds the last index of the given value within the array.
 * param arr
 * value
 */
ArrayUtils.lastIndexOf=function(arr,value){
	for(var i=arr.length-1;i>=0;i--){
		if(arr[i]==value){
			return i;
		}
	}
	return -1;
};

/**
 * Removes the element at the specified position from the specified array.
 * param arr
 * param index
 */
ArrayUtils.remove=function(arr,index){
	if(index>arr.length-1||index<0){
		return arr;
	}
	var narr=new Array(arr.length-1);
	for(var i=0;i<narr.length;i++){
		if(i<index){
			narr[i]=arr[i];
		}else{
			narr[i]=arr[i+1];
		}
	}
	return narr;
};

/** 
 * Removes the first occurrence of the specified element from the specified array.
 * param arr
 * param value
 */
ArrayUtils.removeElement=function(arr,value){
	var index=ArrayUtils.indexOf(arr,value);
	if(index==-1){
		return arr;
	}
	return ArrayUtils.remove(arr,index);
};

/**
 * Reverses the order of the given array.
 * param arr
 */
ArrayUtils.reverse=function(arr){
	return arr.reverse();
};

/**
 * Produces a new boolean array containing the elements between the start and end indices.
 * param arr
 * param startIndexInclusive
 * param endIndexExclusive
 */
ArrayUtils.subarray=function(arr,startIndexInclusive,endIndexExclusive){
	if(startIndexInclusive<=endIndexExclusive&&startIndexInclusive>=0&&endIndexExclusive<=arr.length){
		var narr=new Array(endIndexExclusive-startIndexInclusive);
		for(var i=startIndexInclusive;i<endIndexExclusive;i++){
			narr[i]=arr[i];
		}
		return narr;
	}
	return null;
};

/**
 * Outputs an array as a String, treating null as an empty array.
 * param arr
 */
ArrayUtils.toString=function(arr){
	return arr.toString();
};

/**
 * Outputs an array as a String handling nulls.
 * param arr
 * param defaultValue
 */
ArrayUtils.toStringIfNull=function(arr,defaultValue){
	var narr=ArrayUtils.clone(arr);
	for(var i=0;i<narr.length;i++){
		if(narr[i]==undefined||narr[i]==null){
			narr[i]=defaultValue;
		}
	}
	return narr.toString();
};