/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The TDistributionImpl class references to org.apache.commons.math.distribution.TDistributionImpl */

function TDistributionImpl(degreesOfFreedom){
	this.jsjava_class="org.apache.commons.math.distribution.TDistributionImpl";	
	if (degreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.degreesOfFreedom = degreesOfFreedom;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
TDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    if (x == 0.0) {
        ret = 0.5;
    } else {
        var t =
            Beta.regularizedBeta(
                this.getDegreesOfFreedom() / (this.getDegreesOfFreedom() + (x * x)),
                0.5 * this.getDegreesOfFreedom(),
                0.5);
        if (x < 0.0) {
            ret = 0.5 * t;
        } else {
            ret = 1.0 - 0.5 * t;
        }
    }

    return ret;
};

/**
 * Access the degrees of freedom.
 */
TDistributionImpl.prototype.getDegreesOfFreedom=function(){
	return this.degreesOfFreedom;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
TDistributionImpl.prototype.getDomainLowerBound=function(p){
	return -Double.MAX_VALUE;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
TDistributionImpl.prototype.getDomainUpperBound=function(p){
	return Double.MAX_VALUE;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
TDistributionImpl.prototype.getInitialDomain=function(p){
	return 0.0;
};

/**
 * Modify the degrees of freedom.
 * param degreesOfFreedom
 */
TDistributionImpl.prototype.setDegreesOfFreedom=function(degreesOfFreedom){
	if (degreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.degreesOfFreedom = degreesOfFreedom;
};