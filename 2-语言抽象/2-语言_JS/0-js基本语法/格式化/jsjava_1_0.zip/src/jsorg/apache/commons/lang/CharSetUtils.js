/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The CharSetUtils class references to org.apache.commons.lang.CharSetUtils */
 
function CharSetUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.CharSetUtils";
}

/**
 * Takes an argument in set-syntax, returns the number of characters present in the specified string.
 * param str String to count characters in, may be null
 * param arr String set of characters to count, may be null
 */
CharSetUtils.count=function(str,set){
	if(str==null||str==""||set==null||set==""){
		return 0;
	}
	var count=0;
	for(var i=0;i<str.length;i++){
		if(set.indexOf(str.charAt(i))!=-1){
			count++;
		}
	}
	return count;
};

/**
 * Takes an argument in set-syntax, see evaluateSet, and deletes any of characters present 
 * in the specified string.
 * param str String to delete characters from, may be null
 * param set String set of characters to delete, may be null 
 */
CharSetUtils.remove=function(str,set){
	if(str==null){
		return null;
	}
	if(str==""){
		return "";
	}
	if(set==null||set==""){
		return str;
	}
	var nstr="";
	for(var i=0;i<str.length;i++){
		var ch=str.charAt(i);
		if(set.indexOf(ch)==-1){
			nstr+=ch;
		}
	}
	return nstr;
};

/**
 * Takes an argument in set-syntax, see evaluateSet, and keeps any of characters present in the specified string.
 * param str String to keep characters from, may be null
 * param set String set of characters to keep, may be null
 */
CharSetUtils.keep=function(str,set){
	if(str==null){
		return null;
	}
	if(str==""||set==null||set==""){
		return "";
	}
	var nstr="";
	for(var i=0;i<str.length;i++){
		var ch=str.charAt(i);
		if(set.indexOf(ch)!=-1){
			nstr+=ch;
		}
	}
	return nstr;
};

/**
 * Squeezes any repetitions of a character that is mentioned in the supplied set.
 * param str the string to squeeze, may be null
 * param set the character set to use for manipulation, may be null
 */
CharSetUtils.squeeze=function(str,set){
	if(str==null||str==""){
		return str;
	}
	if(set==null||set==""){
		return str;
	}
	for(var i=0;i<set.length;i++){
		var ch=set.charAt(i);
		str=str.replace(new RegExp(ch+"{2,}","g"),ch);
	}
	return str;
};