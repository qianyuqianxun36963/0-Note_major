/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The HypergeometricDistributionImpl class references to org.apache.commons.math.distribution.HypergeometricDistributionImpl */

function HypergeometricDistributionImpl(populationSize,numberOfSuccesses,sampleSize){
	this.jsjava_class="org.apache.commons.math.distribution.HypergeometricDistributionImpl";	
	if (numberOfSuccesses > populationSize) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"number of successes must be less than or equal to " +
            "population size");
    }
    if (sampleSize > populationSize) {
        throw new IllegalArgumentException(
        IllegalArgumentException.ERROR,"sample size must be less than or equal to population size");
    }
    if(populationSize <= 0){
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"population size must be positive.");
    }
    this.populationSize = populationSize;
    if (sampleSize < 0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"sample size must be non-negative.");
    }    
    this.sampleSize = sampleSize;
    if(numberOfSuccesses < 0){
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"number of successes must be non-negative.");
    }
    this.numberOfSuccesses = numberOfSuccesses;
}

/**
 * For this disbution, X, this method returns P(X �� x).
 * param x
 */
HypergeometricDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    var sx=new String(x);
	if(sx.indexOf(".")!=-1){
		x=Math.floor(x);
	}    
    var n = this.getPopulationSize();
    var m = this.getNumberOfSuccesses();
    var k = this.getSampleSize();

    var domain = this.getDomain(n, m, k);
    if (x < domain[0]) {
        ret = 0.0;
    } else if(x >= domain[1]) {
        ret = 1.0;
    } else {
        ret = this.innerCumulativeProbability(domain[0], x, 1, n, m, k);
    }
    
    return ret;
};

/**
 * Return the domain for the given hypergeometric distribution parameters.
 * param n
 * param m
 * param k
 */
HypergeometricDistributionImpl.prototype.getDomain=function(n,m,k){
	var arr=new Array(2);
	arr[0]=this.getLowerDomain(n, m, k);
	arr[1]=this.getUpperDomain(m, k);
	return arr;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a PDF root.
 * param p
 */
HypergeometricDistributionImpl.prototype.getDomainLowerBound=function(p){
	return this.getLowerDomain(this.getPopulationSize(), this.getNumberOfSuccesses(),
            this.getSampleSize());
};

/**
 * Access the domain value upper bound, based on p, used to bracket a PDF root.
 * param p
 */
HypergeometricDistributionImpl.prototype.getDomainUpperBound=function(p){
	return this.getUpperDomain(this.getSampleSize(), this.getNumberOfSuccesses());
};

/**
 * Return the lowest domain value for the given hypergeometric distribution parameters.
 * param n
 * param m
 * param k
 */
HypergeometricDistributionImpl.prototype.getLowerDomain=function(n,m,k){
	return Math.max(0, m - (n - k));
};

/**
 * Access the number of successes.
 */
HypergeometricDistributionImpl.prototype.getNumberOfSuccesses=function(){
	return this.numberOfSuccesses;
};

/**
 * Access the population size.
 */
HypergeometricDistributionImpl.prototype.getPopulationSize=function(){
	return this.populationSize;
};

/**
 * Access the sample size.
 */
HypergeometricDistributionImpl.prototype.getSampleSize=function(){
	return this.sampleSize;
};

/**
 * Return the highest domain value for the given hypergeometric distribution parameters.
 * param m
 * param k
 */
HypergeometricDistributionImpl.prototype.getUpperDomain=function(m,k){
	return Math.min(k, m);
};

/**
 * For this disbution, X, this method returns P(X = x).
 * param x
 */
HypergeometricDistributionImpl.prototype.probability=function(x){
	var ret;       
    var n = this.getPopulationSize();
    var m = this.getNumberOfSuccesses();
    var k = this.getSampleSize();
	var domain = this.getDomain(n, m, k);
    if(x < domain[0] || x > domain[1]){
        ret = 0.0;
    } else {
        ret = this.probability2(n, m, k, x);
    }
    
    return ret;
};

/**
 * For the disbution, X, defined by the given hypergeometric distribution
 * parameters, this method returns P(X = x).
 * param n
 * param m
 * param k
 * param x
 */
HypergeometricDistributionImpl.prototype.probability2=function(n, m, k, x){
	return Math.exp(MathUtils.binomialCoefficientLog(m, x) +
            MathUtils.binomialCoefficientLog(n - m, k - x) -
            MathUtils.binomialCoefficientLog(n, k));
};

/**
 * Modify the number of successes.
 * param num
 */
HypergeometricDistributionImpl.prototype.setNumberOfSuccesses=function(num){
	if(num < 0){
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"number of successes must be non-negative.");
    }
    this.numberOfSuccesses = num;
};

/**
 * Modify the population size.
 * param size
 */
HypergeometricDistributionImpl.prototype.setPopulationSize=function(size){
	if(size <= 0){
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"population size must be positive.");
    }
    this.populationSize = size;
};

/**
 * Modify the sample size.
 * param size
 */
HypergeometricDistributionImpl.prototype.setSampleSize=function(size){
	if (size < 0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"sample size must be non-negative.");
    }    
    this.sampleSize = size;
};

/**
 * For this disbution, X, this method returns P(X �� x).
 * param x
 */
HypergeometricDistributionImpl.prototype.upperCumulativeProbability=function(x){
	var ret;
    var sx=new String(x);
	if(sx.indexOf(".")!=-1){
		x=Math.floor(x);
	}     
    var n = this.getPopulationSize();
    var m = this.getNumberOfSuccesses();
    var k = this.getSampleSize();

    var domain = this.getDomain(n, m, k);
    if (x < domain[0]) {
        ret = 1.0;
    } else if(x > domain[1]) {
        ret = 0.0;
    } else {
        ret = this.innerCumulativeProbability(domain[1], x, -1, n, m, k);
    }
    
    return ret;
};

/**
 * For this disbution, X, this method returns P(X �� x).
 * param x
 */
HypergeometricDistributionImpl.prototype.innerCumulativeProbability=function(
	x0, x1, dx, n, m, k){
	var ret = this.probability2(n, m, k, x0);
    while (x0 != x1) {
        x0 += dx;
        ret += this.probability2(n, m, k, x0);
    }
    return ret;
};