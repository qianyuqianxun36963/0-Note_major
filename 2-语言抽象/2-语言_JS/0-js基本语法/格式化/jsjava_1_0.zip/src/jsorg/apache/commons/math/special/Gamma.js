/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Gamma class references to org.apache.commons.math.special.Gamma */

function Gamma(){
	this.jsjava_class="org.apache.commons.math.special.Erf";
}

Gamma.DEFAULT_EPSILON = 10e-9;

Gamma.lanczos =
    [
        0.99999999999999709182,
        57.156235665862923517,
        -59.597960355475491248,
        14.136097974741747174,
        -0.49191381609762019978,
        .33994649984811888699e-4,
        .46523628927048575665e-4,
        -.98374475304879564677e-4,
        .15808870322491248884e-3,
        -.21026444172410488319e-3,
        .21743961811521264320e-3,
        -.16431810653676389022e-3,
        .84418223983852743293e-4,
        -.26190838401581408670e-4,
        .36899182659531622704e-5
    ];
    
Gamma.HALF_LOG_2_PI = 0.5 * Math.log(2.0 * Math.PI);

/**
 * Returns the natural logarithm of the gamma function ��(x).
 * param x - the value.
 */
Gamma.logGamma=function(x){
	var ret;
    if (Double.isNaN(x) || (x <= 0.0)) {
        ret = Double.NaN;
    } else {
        var g = 607.0 / 128.0;        
        var sum = 0.0;
        for (var i = Gamma.lanczos.length - 1; i > 0; --i) {
        	sum = sum + (Gamma.lanczos[i] / (x + i));
        }
        sum = sum + Gamma.lanczos[0];
        var tmp = x + g + .5;
        ret = ((x + .5) * Math.log(tmp)) - tmp +
            Gamma.HALF_LOG_2_PI + Math.log(sum / x);
            
    }

    return ret;Gamma.js
};

/**
 * Returns the regularized gamma function P(a, x).
 * param a - the a parameter.
 * param x - the value.
 */
Gamma.regularizedGammaP=function(a,x){
	return Gamma.regularizedGammaP2(a, x, Gamma.DEFAULT_EPSILON, Integer.MAX_VALUE);
};

/**
 * Returns the regularized gamma function P(a, x).
 * param a - the a parameter.
 * param x - the value.
 * param epsilon - When the absolute value of the nth item in the series is less 
 * than epsilon the approximation ceases to calculate further elements in the series. 
 * param maxIterations - Maximum number of "iterations" to complete.
 */
Gamma.regularizedGammaP2=function(a,x,epsilon,maxIterations){
	var ret;
    if (Double.isNaN(a) || Double.isNaN(x) || (a <= 0.0) || (x < 0.0)) {
        ret = Double.NaN;
    } else if (x == 0.0) {
        ret = 0.0;
    } else if (a >= 1.0 && x > a) {
        // use regularizedGammaQ because it should converge faster in this
        // case.
        ret = 1.0 - Gamma.regularizedGammaQ2(a, x, epsilon, maxIterations);
    } else {
        // calculate series
        var n = 0.0; // current element index
        var an = 1.0 / a; // n-th element in the series
        var sum = an; // partial sum
        while (Math.abs(an) > epsilon && n < maxIterations) {
            // compute next element in the series
            n = n + 1.0;
            an = an * (x / (a + n));

            // update partial sum
            sum = sum + an;
        }
        if (n >= maxIterations) {
            throw new ConvergenceException(ConvergenceException.ERROR,
                "maximum number of iterations reached");
        } else {
            ret = Math.exp(-x + (a * Math.log(x)) - Gamma.logGamma(a)) * sum;
        }
    }

    return ret;
};

/**
 * Returns the regularized gamma function Q(a, x) = 1 - P(a, x).
 * param a - the a parameter.
 * param x - the value.
 */
Gamma.regularizedGammaQ=function(a,x){
	return Gamma.regularizedGammaQ2(a, x, Gamma.DEFAULT_EPSILON, Integer.MAX_VALUE);
};

/**
 * Returns the regularized gamma function Q(a, x) = 1 - P(a, x).
 * param a - the a parameter.
 * param x - the value.
 * param epsilon - When the absolute value of the nth item in the series is less than 
 * epsilon the approximation ceases to calculate further elements in the series.
 * param maxIterations - Maximum number of "iterations" to complete. 
 */
Gamma.regularizedGammaQ2=function(a,x,epsilon,maxIterations){
	function ContinuedFraction(){
		
	}
	ContinuedFraction.DEFAULT_EPSILON = 10e-9;
	ContinuedFraction.prototype.evaluate=function(x){
		return this.evaluate(x, ContinuedFraction.DEFAULT_EPSILON, Integer.MAX_VALUE);
	};
	ContinuedFraction.prototype.evaluate2=function(x,epsilon){
		return this.evaluate(x, epsilon, Integer.MAX_VALUE);
	};
	ContinuedFraction.prototype.evaluate3=function(x,maxIterations){
		return this.evaluate(x, ContinuedFraction.DEFAULT_EPSILON, maxIterations);
	};
	ContinuedFraction.prototype.evaluate4=function(x,epsilon,maxIterations){
		var p0 = 1.0;
        var p1 = this.getA(0, x);
        var q0 = 0.0;
        var q1 = 1.0;
        var c = p1 / q1;
        var n = 0;
        var relativeError = Double.MAX_VALUE;
        while (n < maxIterations && relativeError > epsilon) {
            ++n;
            var a = this.getA(n, x);
            var b = this.getB(n, x);
            var p2 = a * p1 + b * p0;
            var q2 = a * q1 + b * q0;
            if (Double.isInfinite(p2) || Double.isInfinite(q2)) {
                // need to scale
                if (a != 0.0) {
                    p2 = p1 + (b / a * p0);
                    q2 = q1 + (b / a * q0);
                } else if (b != 0) {
                    p2 = (a / b * p1) + p0;
                    q2 = (a / b * q1) + q0;
                } else {
                    // can not scale an convergent is unbounded.
                    throw new ConvergenceException(ConvergenceException.ERROR,
                        "Continued fraction convergents diverged to +/- " +
                        "infinity.");
                }
            }
            var r = p2 / q2;
            relativeError = Math.abs(r / c - 1.0);
                
            // prepare for next iteration
            c = p2 / q2;
            p0 = p1;
            p1 = p2;
            q0 = q1;
            q1 = q2;
        }

        if (n >= maxIterations) {
            throw new ConvergenceException(ConvergenceException.ERROR,
                "Continued fraction convergents failed to converge.");
        }

        return c;
	};
	ContinuedFraction.prototype.getA=function(n,x){
		return ((2.0 * n) + 1.0) - a + x;
	};
	ContinuedFraction.prototype.getB=function(n,x){
		return n * (a - n);
	};
	var ret;
    if (Double.isNaN(a) || Double.isNaN(x) || (a <= 0.0) || (x < 0.0)) {
        ret = Double.NaN;
    } else if (x == 0.0) {
        ret = 1.0;
    } else if (x < a || a < 1.0) {
        // use regularizedGammaP because it should converge faster in this
        // case.
        ret = 1.0 - Gamma.regularizedGammaP2(a, x, epsilon, maxIterations);
    } else {
        // create continued fraction
        var cf = new ContinuedFraction();        
        ret = 1.0 / cf.evaluate4(x, epsilon, maxIterations);
        ret = Math.exp(-x + (a * Math.log(x)) - Gamma.logGamma(a)) * ret;
    }    
    return ret;
};