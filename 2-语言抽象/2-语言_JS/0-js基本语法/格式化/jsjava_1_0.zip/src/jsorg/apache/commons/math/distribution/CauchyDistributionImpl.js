/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The CauchyDistributionImpl class references to org.apache.commons.math.distribution.CauchyDistributionImpl */

function CauchyDistributionImpl(median, s){
	this.jsjava_class="org.apache.commons.math.distribution.CauchyDistributionImpl";	
	this.median = median;
    if (s <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Scale must be positive.");
    }       
    this.scale = s;
}
/**
 * For this disbution, X, this method returns P(X < x). 
 */
CauchyDistributionImpl.prototype.cumulativeProbability=function(x){
	return 0.5 + (Math.atan((x - this.median) / this.scale) / Math.PI);
};          
          
/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root. 
 */
CauchyDistributionImpl.prototype.getDomainLowerBound=function(p) {
	var ret;

    if (p < .5) {
        ret = -Double.MAX_VALUE;
    } else {
        ret = this.getMedian();
    }
    
    return ret;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.  
 */        
CauchyDistributionImpl.prototype.getDomainUpperBound=function(p) {
	var ret;

    if (p < .5) {
        ret = this.getMedian();
    } else {
        ret = Double.MAX_VALUE;
    }
    
    return ret;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.   
 */        
CauchyDistributionImpl.prototype.getInitialDomain=function(p) {
	var ret;

    if (p < .5) {
        ret = this.getMedian() - this.getScale();
    } else if (p > .5) {
        ret = this.getMedian() + this.getScale();
    } else {
        ret = this.getMedian();
    }
    
    return ret;
};

/**
 * Access the median.
 */       
CauchyDistributionImpl.prototype.getMedian=function() {
	return this.median;
};

/**
 * Access the scale parameter. 
 */          
CauchyDistributionImpl.prototype.getScale=function() {
	return this.scale;
};

/**
 * For this distribution, X, this method returns the critical point x, such that P(X < x) = p. 
 */       
CauchyDistributionImpl.prototype.inverseCumulativeProbability=function(p) {
	var ret;
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"probability argument must be between 0 and 1 (inclusive)");
    } else if (p == 0) {
        ret = Double.NEGATIVE_INFINITY;
    } else  if (p == 1) {
        ret = Double.POSITIVE_INFINITY;
    } else {
        ret = this.median + this.scale * Math.tan(Math.PI * (p - .5));
    }
    return ret;
};

/**
 * Modify the median.
 */          
CauchyDistributionImpl.prototype.setMedian=function(median) {
	this.median = median;
};

/**
 * Modify the scale parameter.
 */           
CauchyDistributionImpl.prototype.setScale=function(s) {
	if (s <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Scale must be positive.");
    }       
    this.scale = s;
};