/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The LocaleUtils class references to org.apache.commons.lang.LocaleUtils */
 
function LocaleUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.LocaleUtils";
}

/**
 * Obtains an unmodifiable list of installed locales.
 */
LocaleUtils.availableLocaleList=function(){
	var list=new List();
	list.addArray(Locale.getAvailableLocales());
	return list;
};

/**
 * Obtains an unmodifiable set of installed locales.
 */
LocaleUtils.availableLocaleSet=function(){
	var set=new Set();
	set.addArray(Locale.getAvailableLocales());
	return set;
};

/**
 * Obtains the list of countries supported for a given language.
 * param language
 */
LocaleUtils.countriesByLanguage=function(language){
	var larr=Locale.getAvailableLocales();
	var length=larr.length;
	var list=new List();
	for(var i=0;i<length;i++){
		var locale=larr[i];
		if(locale.getLanguage()==language){
			list.add(locale);
		}
	}
	return list;
};

/**
 * Checks if the locale specified is in the list of available locales.
 * param locale
 */
LocaleUtils.isAvailableLocale=function(locale){
	var larr=Locale.getAvailableLocales();
	var length=larr.length;
	for(var i=0;i<length;i++){
		var clocale=larr[i];
		if(clocale.equals(locale)){
			return true;
		}
	}
	return false;
};

/**
 * Obtains the list of languages supported for a given country.
 * param country
 */
LocaleUtils.languagesByCountry=function(country){
	var larr=Locale.getAvailableLocales();
	var length=larr.length;
	var list=new List();
	for(var i=0;i<length;i++){
		var locale=larr[i];
		if(locale.getCountry()==country){
			list.add(locale);
		}
	}
	return list;
};

/**
 * Converts a String to a Locale.
 * param str
 */
LocaleUtils.toLocale=function(str){
	var arr=str.split("_");
	var length=arr.length;
	var language="";
	var country="";
	var variant="";
	if(length>=1){
		language=arr[0];
	}
	if(length>=2){
		country=arr[1];
	}
	if(length>=3){
		variant=arr[2];
	}
	var locale=new Locale(language,country,variant);
	if(LocaleUtils.isAvailableLocale(locale)){
		return locale;
	}
	return null;
};