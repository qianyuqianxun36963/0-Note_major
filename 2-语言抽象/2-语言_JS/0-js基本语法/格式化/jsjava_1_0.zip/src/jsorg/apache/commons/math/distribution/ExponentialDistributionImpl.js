/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The ExponentialDistributionImpl class references to org.apache.commons.math.distribution.ExponentialDistributionImpl */

function ExponentialDistributionImpl(mean){
	this.jsjava_class="org.apache.commons.math.distribution.ExponentialDistributionImpl";	
	if (mean <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"mean must be positive.");
    }
    this.mean = mean;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
ExponentialDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    if (x <= 0.0) {
        ret = 0.0;
    } else {
        ret = 1.0 - Math.exp(-x / this.getMean());
    }
    return ret;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
ExponentialDistributionImpl.prototype.getDomainLowerBound=function(p){
	return 0;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
ExponentialDistributionImpl.prototype.getDomainUpperBound=function(p){
	// NOTE: exponential is skewed to the left
    // NOTE: therefore, P(X < &mu;) > .5

    if (p < .5) {
        // use mean
        return this.getMean();
    } else {
        // use max
        return Double.MAX_VALUE;
    }
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
ExponentialDistributionImpl.prototype.getInitialDomain=function(p){
	// Exponential is skewed to the left, therefore, P(X < &mu;) > .5
    if (p < .5) {
        // use 1/2 mean
        return this.getMean() * .5;
    } else {
        // use mean
        return this.getMean();
    }
};

/**
 * Access the mean.
 */
ExponentialDistributionImpl.prototype.getMean=function(){
	return this.mean;
};

/**
 * For this distribution, X, this method returns the critical point x, such that P(X < x) = p.
 * param p
 */
ExponentialDistributionImpl.prototype.inverseCumulativeProbability=function(p){
	var ret;
        
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"probability argument must be between 0 and 1 (inclusive)");
    } else if (p == 1.0) {
        ret = Double.POSITIVE_INFINITY;
    } else {
        ret = -this.getMean() * Math.log(1.0 - p);
    }
    
    return ret;
};

/**
 * Modify the mean.
 * param mean
 */
ExponentialDistributionImpl.prototype.setMean=function(mean){
	if (mean <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"mean must be positive.");
    }
    this.mean = mean;
};