/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The StringUtils class references to org.apache.commons.lang.StringUtils */
 
function StringUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.StringUtils";	
}

/**
 * Abbreviates a String using ellipses.
 * param str the String to check, may be null
 * param offset left edge of source String
 * param maxWidth maximum length of result String, must be at least 4
 */
StringUtils.abbreviate=function(str,offset,maxWidth){
	if (str == null) {
        return null;
    }
    if (maxWidth < 4) {
        maxWidth==4;
    }
    if (str.length <= maxWidth) {
        return str;
    }
    if (offset > str.length) {
        offset = str.length;
    }
    if ((str.length - offset) < (maxWidth - 3)) {
        offset = str.length - (maxWidth - 3);
    }
    if (offset <= 4) {
        return str.substring(0, maxWidth - 3) + "...";
    }
    if (maxWidth < 7) {
        maxWidth=7;
    }
    if ((offset + (maxWidth - 3)) < str.length) {
        return "..." + StringUtils.abbreviate(str.substring(offset),0, maxWidth - 3);
    }
    return "..." + str.substring(str.length - (maxWidth - 3));
};

/**
 * Capitalizes a String changing the first letter to title case.
 * param str
 */
StringUtils.capitalize=function(str){
	if(str==null||str==""){
		return str;
	}
	if(str.length==1){
		return str.toUpperCase();
	}
	var nstr=str.charAt(0).toUpperCase()+str.substring(1);
	return nstr;
};

/**
 * Checks if a String is empty ("") or null.
 * param str
 */
StringUtils.isEmpty=function(str){
	if(str==undefined||str==""||str==null){
		return true;
	}
	return false;
};

/**
 * Checks if a String is not empty ("") and not null.
 * param str
 */
StringUtils.isNotEmpty=function(str){
	return !StringUtils.isEmpty(str);
};

/**
 * Checks if a String is whitespace, empty ("") or null.
 * param str
 */
StringUtils.isBlank=function(str){
	if(str==undefined||str==""||str==null||/^\s*/.test(str)){
		return true;
	}
	return false;
};

/**
 * Checks if a String is not empty (""), not null and not whitespace only.
 * param str
 */
StringUtils.isNotBlank=function(str){
	return !StringUtils.isBlank(str);
};

/**
 * Checks if the String contains only unicode letters.
 * param str
 */
StringUtils.isAlpha=function(str){
	return /^[A-Za-z]+$/.test(str);
};

/**
 * Checks if the String contains only unicode letters or digits.
 * param str
 */
StringUtils.isAlphanumeric=function(str){
	return /^[A-Za-z0-9]+$/.test(str);
};

/**
 * Checks if the String contains only unicode letters, digits or space (' ').
 * param str
 */
StringUtils.isAlphanumericSpace=function(str){
	if(str==""){
		return true;
	}
	return /^[A-Za-z0-9\s]+$/.test(str);
};

/**
 * Checks if the String contains only unicode letters and space (' ').
 * param str
 */
StringUtils.isAlphaSpace=function(str){
	if(str==""){
		return true;
	}
	return /^[A-Za-z\s]+$/.test(str);
};

/**
 * Checks if the string contains only ASCII printable characters.
 * param str
 */
StringUtils.isAsciiPrintable=function(str){
	if (str == null) {
        return false;
    }
    var length = str.length();
    for (var i = 0; i < length; i++) {
        var ch=str.charAt(i);
        ch=ch.charCodeAt(0);
        if(ch < 32 && ch >= 127){
        	return false;
        }
    }
    return true;
};

/**
 * Checks if the String contains only unicode digits.
 * param str
 */
StringUtils.isNumeric=function(str){
	return /^[0-9]+$/.test(str);
};

/**
 * Checks if the String contains only unicode digits or space (' ').
 * param str
 */
StringUtils.isNumericSpace=function(str){
	return /^[0-9\s]+$/.test(str);
};

/**
 * Checks if the String contains only whitespace.
 * param str
 */
StringUtils.isWhitespace=function(str){
	return /^[\s]+$/.test(str);
};

/**
 * Joins the elements of the provided array into a single String containing the provided list of elements.
 * param arr
 * param separtor
 */
StringUtils.joinArray=function(arr,separator){
	if(StringUtils.isEmpty(separator)){
		return arr.join("");
	}
	return arr.join(separator);
};

/**
 * Joins the elements of the provided list into a single String containing the provided list of elements.
 * param list
 * param separator
 */
StringUtils.joinList=function(list,separator){
	if(!list||!list.jsjava_class||list.jsjava_class!="jsjava.util.List"){
		return null;
	}
	if(StringUtils.isEmpty(separator)){
		separator="";
	}
	var arr=list.toArray();
	return arr.join(separator);
};

/**
 * Joins the elements of the provided iterator into a single String containing the provided list of elements.
 * param iterator
 * param separator
 */
StringUtils.joinIterator=function(iterator,separator){
	if(!iterator||!iterator.jsjava_class||iterator.jsjava_class!="jsjava.util.Iterator"){
		return null;
	}
	if(StringUtils.isEmpty(separator)){
		separator="";
	}
	iterator.moveTo(0);
	var list=new List();
	while(iterator.hasNext()){
		list.add(iterator.next());
	}
	var arr=list.toArray();
	return arr.join(separator);
};

/**
 * Removes control characters (char <= 32) from both ends of this String, handling null by returning null.
 * param str
 */
StringUtils.trim=function(str){
	if(StringUtils.isEmpty(str)){
		return str;
	}
	return str.replace(/(^\s*)|(\s*$)/g, ""); 
};