/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The StopWatch class references to org.apache.commons.lang.StopWatch */
 
function StopWatch(){
	this.jsjava_class="jsorg.apache.commons.lang.StopWatch";
	this.startTime=0;
	this.endTime=0;
}

/**
 * Start the stopwatch.
 */
StopWatch.prototype.start=function(){
	this.startTime=new Date().getTime();
};

/**
 * Stop the stopwatch.
 */
StopWatch.prototype.stop=function(){
	this.endTime=new Date().getTime();
};

/**
 * Get the milliseconds on the stopwatch.
 */
StopWatch.prototype.getTime=function(){
	return this.endTime-this.startTime;
};

/**
 * Get the milliseconds on the stopwatch.
 */
StopWatch.prototype.getMilliSeconds=function(){
	return this.getTime();
};

/**
 * Get the seconds on the stopwatch.
 */
StopWatch.prototype.getSeconds=function(){
	return this.getTime()/1000;
};

/**
 * Get the minutes on the stopwatch.
 */
StopWatch.prototype.getMinutes=function(){
	return this.getTime()/(1000*60);
};

/**
 * Get the hours on the stopwatch.
 */
StopWatch.prototype.getHours=function(){
	return this.getTime()/(1000*3600);
};