/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The CharUtils class references to org.apache.commons.lang.CharUtils */
 
function CharUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.CharUtils";
}

/**
 * check whether the input value is a char value
 * param c
 */
CharUtils.checkValid=function(c){
    var type=typeof(c);
    if(type=="string"&&c.length==1){
    	return true;
    }
    return false;
};

/**
 * Checks whether the character is ASCII 7 bit.
 * param ch
 */
CharUtils.isAscii=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch < 128;
};

/**
 * Checks whether the character is ASCII 7 bit alphabetic.
 * param ch
 */
CharUtils.isAsciiAlpha=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return (ch >= 'A'.charCodeAt(0) && ch <= 'Z'.charCodeAt(0)) || (ch >= 'a'.charCodeAt(0) && ch <= 'z'.charCodeAt(0));
};

/**
 * Checks whether the character is ASCII 7 bit alphabetic lower case.
 * param ch
 */
CharUtils.isAsciiAlphaLower=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch >= 'a'.charCodeAt(0) && ch <= 'z'.charCodeAt(0);
};

/**
 * Checks whether the character is ASCII 7 bit numeric.
 * param ch
 */
CharUtils.isAsciiAlphanumeric=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return (ch >= 'A'.charCodeAt(0) && ch <= 'Z'.charCodeAt(0)) || (ch >= 'a'.charCodeAt(0) && ch <= 'z'.charCodeAt(0)) || (ch >= '0'.charCodeAt(0) && ch <= '9'.charCodeAt(0));
};

/**
 * Checks whether the character is ASCII 7 bit alphabetic upper case.
 * param ch
 */
CharUtils.isAsciiAlphaUpper=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch >= 'A'.charCodeAt(0) && ch <= 'Z'.charCodeAt(0);
};

/**
 * Checks whether the character is ASCII 7 bit control.
 * param ch
 */
CharUtils.isAsciiControl=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch < 32 || ch == 127;
};

/**
 * Checks whether the character is ASCII 7 bit numeric.
 * param ch
 */
CharUtils.isAsciiNumeric=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch >= '0'.charCodeAt(0) && ch <= '9'.charCodeAt(0);
};

/**
 * Checks whether the character is ASCII 7 bit printable.
 * param ch
 */
CharUtils.isAsciiPrintable=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch >= 32 && ch < 127;
};

/**
 * Converts the Character to a char handling null.
 * param chobj
 * param defaultValue
 */
CharUtils.toChar=function(chobj,defaultValue){
	if(chobj==null){
		return defaultValue;
	}
	if(typeof(chobj=="object")){
		return chobj.charValue();
	}
	return;
};

/**
 * Converts the character to the Integer it represents, throwing an exception if the character is not numeric.
 * param ch
 * param defaultValue
 */
CharUtils.toIntValue=function(ch,defaultValue){	
	if(defaultValue!=undefined){
		if(isNaN(defaultValue)){
			return;
		}
	}
	if(ch==null){
		return defaultValue;
	}
	if(isNaN(ch)){
		return;
	}
	if(CharUtils.checkValid(ch)){
		return parseInt(ch);
	}
};

/**
 * Converts the character to a Character.
 * param ch
 */
CharUtils.toCharacterObject=function(ch){
	return new Character(ch);
};

CharUtils.toString=function(ch){
	return ch;
};