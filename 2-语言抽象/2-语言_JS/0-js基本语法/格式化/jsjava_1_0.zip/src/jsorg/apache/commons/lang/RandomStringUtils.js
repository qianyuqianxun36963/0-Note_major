/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The RandomStringUtils class references to org.apache.commons.lang.RandomStringUtils */
 
function RandomStringUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.RandomStringUtils";
}

/**
 * Creates a random string whose length is the number of characters specified.
 * param count - the length of random string to create
 * param letters(boolean) - if true, generated string will include alphabetic characters
 * param numbers(boolean) - if true, generated string will include numeric characters 
 */
RandomStringUtils.random=function(count,letters,numbers){
	if(isNaN(count)){
		return;
	}
	if(count<0){
		return;
	}
	if(count==0){
		return "";
	}
	var minAlpha="a".charCodeAt(0);
	var maxAlpha="z".charCodeAt(0);
	var alphas=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"];
	var digits=["0","1","2","3","4","5","6","7","8","9"];
	if(!letters&&numbers){
		var str="";
		for(var i=0;i<count;i++){
			str+=digits[Math.floor(Math.random()*10)];
		}
		return str;
	}
	if(letters&&!numbers){
		var str="";
		for(var i=0;i<count;i++){
			str+=alphas[Math.floor(Math.random()*26)];
		}
		return str;
	}
	if(letters&&numbers||!letters&&!numbers){
		var str="";
		for(var i=0;i<count;i++){
			var r=Math.floor(Math.random()*2);
			if(r==0){
				str+=alphas[Math.floor(Math.random()*26)];
			}else if(r==1){
				str+=digits[Math.floor(Math.random()*10)];
			}
		}
		return str;
	}
	return "";
};

/**
 * Creates a random string whose length is the number of characters specified.
 * param count
 */
RandomStringUtils.randomAlphabetic=function(count){
	return RandomStringUtils.random(count,true,false);
};

/**
 * Creates a random string whose length is the number of characters specified.
 * param count
 */
RandomStringUtils.randomAlphanumeric=function(count){
	return RandomStringUtils.random(count,true,true);
};

/**
 * Creates a random string whose length is the number of characters specified.
 * param count
 */
RandomStringUtils.randomNumeric=function(count){
	return RandomStringUtils.random(count,false,true);
};