/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The CharSet class references to org.apache.commons.lang.CharSet */
 
function CharSet(str){
	this.jsjava_class="jsorg.apache.commons.lang.CharSet";
	if(str==undefined){
		str="";
	}
	this.str=str;
}

/**
 * check whether the input value is a char value
 * param c
 */
CharSet.checkValid=function(c){
    var type=typeof(c);
    if(type=="string"&&c.length==1){
    	return true;
    }
    return false;
};

/**
 * Does the CharSet contain the specified character ch.
 * param ch
 */
CharSet.prototype.contains=function(ch){
	if(!CharSet.checkValid(ch)){
		return false;
	}
	for(var i=0;i<this.str.length;i++){
		if(this.str.charAt(i)==ch){
			return true;
		}
	}
	return false;
};

/**
 * Get CharRange object from the CharSet
 */
CharSet.prototype.getCharRange=function(){
	var arr=new Array(this.str.length);
	for(var i=0;i<this.str.length;i++){
		arr[i]=this.str.charAt(i);
	}
	arr.sort();
	return new CharRange(arr[0],arr[arr.length-1],false);
};

/**
 * Gets a string representation of the set.
 */
CharSet.prototype.toString=function(){
	return this.str;
};

/**
 * Compares two CharSet objects
 */
CharSet.prototype.equals=function(o){
	if(o.str=this.str){
		return true;
	}
	return false;
};