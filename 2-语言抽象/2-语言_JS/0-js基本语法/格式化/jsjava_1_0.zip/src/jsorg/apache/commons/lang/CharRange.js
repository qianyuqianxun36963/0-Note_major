/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The CharRange class references to org.apache.commons.lang.CharRange */
 
/**
 * Constructs a CharRange over a set of characters, optionally negating the range.
 * param start
 * param end
 * param negated
 */
function CharRange(start,end,negated){
	this.jsjava_class="jsorg.apache.commons.lang.CharRange";
	if(CharRange.checkValid(start)){
		this.start=start;
		this.end=end;
	}
	this.negated=false;//nothing to do in this version
}

/**
 * check whether the input value is a char value
 * param c
 */
CharRange.checkValid=function(c){
    var type=typeof(c);
    if(type=="string"&&c.length==1){
    	return true;
    }
    return false;
};

/**
 * Is the character specified contained in this range.
 * param ch
 */
CharRange.prototype.contains=function(ch){
	if(!CharRange.checkValid(ch)){
		return false;
	}
	if(ch>=this.start&&ch<=this.end){
		return true;
	}
	return false;
};

/**
 * Are all the characters of the passed in range contained in this range.
 * param range
 */
CharRange.prototype.containsRange=function(range){
	if(range.start>=this.start&&range.end<=this.end){
		return true;
	}
	return false;
};

/**
 * Gets the start character for this character range.
 */
CharRange.prototype.getStart=function(){
	return this.start;
};

/**
 * Gets the end character for this character range.
 */
CharRange.prototype.getEnd=function(){
	return this.end;
};

/**
 * Is this CharRange negated.
 */
CharRange.prototype.isNegated=function(){
	return this.negated;
};

/**
 * Gets a string representation of the character range.
 */
CharRange.prototype.toString=function(){
	return "["+this.start+","+this.end+"]";
};

/**
 * Compares two CharRange objects
 * param o
 */
CharRange.prototype.equals=function(o){
	if(o.start==this.start&&this.end==this.end){
		return true;
	}
	return false;
};