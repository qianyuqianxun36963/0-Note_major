/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The FDistributionImpl class references to org.apache.commons.math.distribution.FDistributionImpl */

function FDistributionImpl(numeratorDegreesOfFreedom,denominatorDegreesOfFreedom){
	this.jsjava_class="org.apache.commons.math.distribution.FDistributionImpl";
	if (numeratorDegreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.numeratorDegreesOfFreedom = numeratorDegreesOfFreedom;	
    if (denominatorDegreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.denominatorDegreesOfFreedom = denominatorDegreesOfFreedom;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
FDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    if (x <= 0.0) {
        ret = 0.0;
    } else {
        var n = this.getNumeratorDegreesOfFreedom();
        var m = this.getDenominatorDegreesOfFreedom();
        
        ret = Beta.regularizedBeta((n * x) / (m + n * x),
            0.5 * n,
            0.5 * m);
    }
    return ret;
};

/**
 * Access the denominator degrees of freedom.
 */
FDistributionImpl.prototype.getDenominatorDegreesOfFreedom=function(){
	return this.denominatorDegreesOfFreedom;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
FDistributionImpl.prototype.getDomainLowerBound=function(p){
	return 0.0;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
FDistributionImpl.prototype.getDomainUpperBound=function(p){
	return Double.MAX_VALUE;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
FDistributionImpl.prototype.getInitialDomain=function(p){
	return this.getDenominatorDegreesOfFreedom() /
            (this.getDenominatorDegreesOfFreedom() - 2.0);
};

/**
 * Access the numerator degrees of freedom.
 */
FDistributionImpl.prototype.getNumeratorDegreesOfFreedom=function(){
	return this.numeratorDegreesOfFreedom;
};

/**
 * Modify the denominator degrees of freedom.
 * param degreesOfFreedom
 */
FDistributionImpl.prototype.setDenominatorDegreesOfFreedom=function(degreesOfFreedom){
	if (degreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.denominatorDegreesOfFreedom = degreesOfFreedom;
};

/**
 * Modify the numerator degrees of freedom.
 * param degreesOfFreedom
 */
FDistributionImpl.prototype.setNumeratorDegreesOfFreedom=function(degreesOfFreedom){
	if (degreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.numeratorDegreesOfFreedom = degreesOfFreedom;
};