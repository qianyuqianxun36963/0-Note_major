/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The ChiSquaredDistributionImpl class references to org.apache.commons.math.distribution.ChiSquaredDistributionImpl */

function ChiSquaredDistributionImpl(degreesOfFreedom){
	this.jsjava_class="org.apache.commons.math.distribution.ChiSquaredDistributionImpl";	
	this.gamma=	DistributionFactoryImpl.newInstance().createGammaDistribution(
            degreesOfFreedom / 2.0, 2.0);
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
ChiSquaredDistributionImpl.prototype.cumulativeProbability=function(x){
	return this.gamma.cumulativeProbability(x);
};

/**
 * Access the degrees of freedom.
 */
ChiSquaredDistributionImpl.prototype.getDegreesOfFreedom=function(){
	return this.gamma.getAlpha() * 2.0;
};

/**
 * Modify the degrees of freedom.
 * param degreesOfFreedom
 */
ChiSquaredDistributionImpl.prototype.setDegreesOfFreedom=function(degreesOfFreedom){
	this.gamma.setAlpha(this.degreesOfFreedom / 2.0);
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
ChiSquaredDistributionImpl.prototype.getDomainLowerBound=function(p){
	return Double.MIN_VALUE * this.getGamma().getBeta();
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
ChiSquaredDistributionImpl.prototype.getDomainUpperBound=function(p){
	var ret;

    if (p < .5) {
        // use mean
        ret = this.getDegreesOfFreedom();
    } else {
        // use max
        ret = Double.MAX_VALUE;
    }
    
    return ret;
};

/** 
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
ChiSquaredDistributionImpl.prototype.getInitialDomain=function(p){
	var ret;

    if (p < .5) {
        // use 1/2 mean
        ret = this.getDegreesOfFreedom() * .5;
    } else {
        // use mean
        ret = this.getDegreesOfFreedom();
    }
    
    return ret;
};

/**
 * Access the Gamma distribution.
 */
ChiSquaredDistributionImpl.prototype.getGamma=function(){
	return this.gamma;
};