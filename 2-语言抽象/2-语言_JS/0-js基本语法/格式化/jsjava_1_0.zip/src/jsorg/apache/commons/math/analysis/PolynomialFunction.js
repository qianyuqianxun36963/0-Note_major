/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The PolynomialFunction class references to org.apache.commons.math.analysis.PolynomialFunction */
 
function PolynomialFunction(arr){
	this.jsjava_class="jsorg.apache.commons.math.analysis.PolynomialFunction";
	if (arr.length < 1) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Polynomial coefficient array must have postive length.");
    }
    this.coefficients = new Array(arr.length);
    for(var i=0;i<arr.length;i++){
    	this.coefficients[i]=arr[i];
    }
}

/**
 * Returns the degree of the polynomial
 */
PolynomialFunction.prototype.degree=function(){
	return this.coefficients.length - 1;
};

/**
 * Returns the derivative as a UnivariateRealFunction
 */
PolynomialFunction.prototype.derivative=function(){
	return this.polynomialDerivative();
};

/**
 * Returns a copy of the coefficients array.
 */
PolynomialFunction.prototype.getCoefficients=function(){
	var out = new Array(this.coefficients.length);
	for(var i=0;i<this.coefficients.length;i++){
    	out[i]=this.coefficients[i];
    }
    return out;
};

/**
 * Returns the derivative as a PolynomialRealFunction
 */
PolynomialFunction.prototype.polynomialDerivative=function(){
	return new PolynomialFunction(PolynomialFunction.differentiate(this.coefficients));
};

/**
 * Compute the value of the function for the given argument.
 */
PolynomialFunction.prototype.value=function(x){
	return PolynomialFunction.evaluate(this.coefficients, x);
};

/**
 * Returns the coefficients of the derivative of the polynomial with the given coefficients.
 * 
 * @param coefficients  the coefficients of the polynomial to differentiate
 * @return the coefficients of the derivative or null if coefficients has length 1.
 * @throws IllegalArgumentException if coefficients is empty
 * @throws NullPointerException if coefficients is null
 */
PolynomialFunction.differentiate=function(coefficients){
	var n = coefficients.length;
    if (n < 1) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Coefficient array must have positive length for differentiation");
    }
    if (n == 1) {
        return [0];
    }
    var result = new Array(n - 1);
    for (var i = n - 1; i  > 0; i--) {
        result[i - 1] = i * coefficients[i];
    }
    return result;
};

/**
 * Uses Horner's Method to evaluate the polynomial with the given coefficients at
 * the argument.
 * 
 * @param coefficients  the coefficients of the polynomial to evaluate
 * @param argument  the input value
 * @return  the value of the polynomial 
 * @throws IllegalArgumentException if coefficients is empty
 * @throws NullPointerException if coefficients is null
 */
PolynomialFunction.evaluate=function(coefficients,argument){
	var n = coefficients.length;
    if (n < 1) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Coefficient array must have positive length for evaluation");
    }
    var result = coefficients[n - 1];
    for (var j = n -2; j >=0; j--) {
        result = argument * result + coefficients[j];
    }
    return result;
};