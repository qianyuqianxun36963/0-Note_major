/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The WeibullDistributionImpl class references to org.apache.commons.math.distribution.WeibullDistributionImpl */

function WeibullDistributionImpl(alpha,beta){
	this.jsjava_class="org.apache.commons.math.distribution.WeibullDistributionImpl";	
	if (alpha <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Shape must be positive.");
    }       
    this.alpha = alpha;
    if (beta <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Scale must be positive.");
    }       
    this.beta = beta;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
WeibullDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    if (x <= 0.0) {
        ret = 0.0;
    } else {
        ret = 1.0 - Math.exp(-Math.pow(x / this.getScale(), this.getShape()));
    }
    return ret;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
WeibullDistributionImpl.prototype.getDomainLowerBound=function(p){
	return 0.0;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
WeibullDistributionImpl.prototype.getDomainUpperBound=function(p){
	return Double.MAX_VALUE;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
WeibullDistributionImpl.prototype.getInitialDomain=function(p){
	return Math.pow(this.getScale() * Math.log(2.0), 1.0 / this.getShape());
};

/**
 * Access the scale parameter.
 */
WeibullDistributionImpl.prototype.getScale=function(){
	return this.beta;
};

/**
 * Access the shape parameter.
 */
WeibullDistributionImpl.prototype.getShape=function(){
	return this.alpha;
};

/**
 * For this distribution, X, this method returns the critical point x, such that P(X < x) = p.
 * param p
 */
WeibullDistributionImpl.prototype.inverseCumulativeProbability=function(p){
	var ret;
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"probability argument must be between 0 and 1 (inclusive)");
    } else if (p == 0) {
        ret = 0.0;
    } else  if (p == 1) {
        ret = Double.POSITIVE_INFINITY;
    } else {
        ret = this.getScale() * Math.pow(-Math.log(1.0 - p), 1.0 / this.getShape());
    }
    return ret;
};

/**
 * Modify the scale parameter.
 * param beta
 */
WeibullDistributionImpl.prototype.setScale=function(beta){
	if (beta <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Scale must be positive.");
    }       
    this.beta = beta;
};

/**
 * Modify the shape parameter.
 * param alpha
 */
WeibullDistributionImpl.prototype.setShape=function(alpha){
	if (alpha <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Shape must be positive.");
    }       
    this.alpha = alpha;
};