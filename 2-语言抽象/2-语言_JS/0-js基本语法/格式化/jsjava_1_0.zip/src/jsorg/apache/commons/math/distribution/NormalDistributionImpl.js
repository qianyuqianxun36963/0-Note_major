/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The NormalDistributionImpl class references to org.apache.commons.math.distribution.NormalDistributionImpl */

function NormalDistributionImpl(mean,sd){
	this.jsjava_class="org.apache.commons.math.distribution.NormalDistributionImpl";	
	this.mean = mean;
    if (sd <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Standard deviation must be positive.");
    }       
    this.standardDeviation = sd;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
NormalDistributionImpl.prototype.cumulativeProbability=function(x){
	return 0.5 * (1.0 + Erf.erf((x - this.mean) /
            (this.standardDeviation * Math.sqrt(2.0))));
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
NormalDistributionImpl.prototype.getDomainLowerBound=function(p){
	var ret;

    if (p < .5) {
        ret = -Double.MAX_VALUE;
    } else {
        ret = this.getMean();
    }
    
    return ret;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
NormalDistributionImpl.prototype.getDomainUpperBound=function(p){
	var ret;

    if (p < .5) {
        ret = this.getMean();
    } else {
        ret = Double.MAX_VALUE;
    }
    
    return ret;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
NormalDistributionImpl.prototype.getInitialDomain=function(p){
	var ret;

    if (p < .5) {
        ret = this.getMean() - this.getStandardDeviation();
    } else if (p > .5) {
        ret = this.getMean() + this.getStandardDeviation();
    } else {
        ret = this.getMean();
    }
    
    return ret;
};

/**
 * Access the mean.
 */
NormalDistributionImpl.prototype.getMean=function(){
	return this.mean;
};

/**
 * Access the standard deviation.
 */
NormalDistributionImpl.prototype.getStandardDeviation=function(){
	return this.standardDeviation;
};

/**
 * Modify the mean.
 * param mean
 */
NormalDistributionImpl.prototype.setMean=function(mean){
	this.mean = mean;
};

/**
 * Modify the standard deviation.
 * param sd
 */
NormalDistributionImpl.prototype.setStandardDeviation=function(sd){
	if (sd <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Standard deviation must be positive.");
    }       
    this.standardDeviation = sd;
};