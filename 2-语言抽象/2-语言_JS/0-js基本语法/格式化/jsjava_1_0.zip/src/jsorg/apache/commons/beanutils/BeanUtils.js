/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The BeanUtils class references to org.apache.commons.lang.BeanUtils */
 
function BeanUtils(){
	this.jsjava_class="jsorg.apache.commons.beanutils.BeanUtils";
}

/**
 * Return the value of the specified property of the specified bean, no matter which property reference format is used, as a String.
 * param bean
 * param name
 */
BeanUtils.getProperty=function(bean,name){
    if(!bean||typeof(bean)!="object"||!name||typeof(name)!="string"){
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"bean and property can not be null!");
    }
    var capitalName=name.charAt(0).toUpperCase()+name.substring(1);
    var str="bean.get"+capitalName+"()";
    var value=eval(str);
	return value;
};

/**
 * Return the value of the specified simple property of the specified bean, converted to a String.
 * param bean
 * param name
 */
BeanUtils.getSimpleProperty=function(bean,name){
    if(!bean||typeof(bean)!="object"||!name||typeof(name)!="string"){
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"bean and property can not be null!");
    }
    var capitalName=name.charAt(0).toUpperCase()+name.substring(1);
    var str="bean.get"+capitalName+"()";
    var value=eval(str);
	return value;
};

/**
 * Return the value of the specified indexed property of the specified bean, as a String.
 * param bean
 * param name
 * param index
 */
BeanUtils.getIndexedProperty=function(bean,name,index){
	if(!bean||typeof(bean)!="object"||!name||typeof(name)!="string"||isNaN(index)||index<0){
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,
              "bean and property and can not be null and index can not be smaller than 0!");
    }
    var capitalName=name.charAt(0).toUpperCase()+name.substring(1);
    var str="bean.get"+capitalName+"("+index+")";
    var value=eval(str);
	return value;
};

/**
 * Return the value of the specified mapped property of the specified bean, as a String.
 * param bean
 * param name
 * param key
 */
BeanUtils.getMappedProperty=function(bean,name,key){
	if(!bean||typeof(bean)!="object"||!name||typeof(name)!="string"||!key||typeof(key)!="string"){
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,
              "bean and property and key can not be null!");
    }
    var capitalName=name.charAt(0).toUpperCase()+name.substring(1);
    var str="bean.get"+capitalName+"('"+key+"')";
    var value=eval(str);
	return value;
};

/**
 * Set the specified property value, performing type conversions as required to conform to the type of the destination property.
 * param bean
 * param name
 * param value
 */
BeanUtils.setProperty=function(bean,name,value){
    if(!bean||typeof(bean)!="object"||!name||typeof(name)!="string"){
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"bean and property can not be null!");
    }
    var capitalName=name.charAt(0).toUpperCase()+name.substring(1);
    var str="bean.set"+capitalName+"('"+value+"')";
    var value=eval(str);
	return value;
};

/**
 * Copy the specified property value to the specified destination bean, performing any type conversion that is required.
 * param bean
 * param name
 * param value
 */
BeanUtils.copyProperty=function(bean,name,value){
    if(!bean||typeof(bean)!="object"||!name||typeof(name)!="string"){
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"bean and property can not be null!");
    }
    var capitalName=name.charAt(0).toUpperCase()+name.substring(1);
    var str="bean.set"+capitalName+"('"+value+"')";
    var value=eval(str);
	return value;
};

/**
 * Populate the JavaBeans properties of the specified bean, based on the specified name/value pairs.
 * param bean
 * param properties
 */
BeanUtils.populate=function(bean,properties){
	if(!bean||typeof(bean)!="object"||!properties||!properties.jsjava_class||properties.jsjava_class!="jsjava.util.Hashtable"){
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,
             "bean and properties can not be null and properties must be an instance of jsjava.util.Hashtable");
    }
    var keys=properties.keySet().iterator();
    while(keys.hasNext()){
    	var key=keys.next();
    	var value=properties.get(key);
    	BeanUtils.setProperty(bean,key,value);
    }
};