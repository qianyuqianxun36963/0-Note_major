/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function EventUtils(){
	this.jsjava_class="jsorg.eob.event.EventUtils";
}

/**
 * Add event to given dom object
 * @param domObj - object in document model
 * @param eventName - event name such as onclick
 * @param funcName - javascript function
 * @param isBroadcase
 */
EventUtils.addDomEvent=function(domObj, eventName, funcName, isBroadcast){
	if(eventName.indexOf("on")==0){
		eventName=eventName.substring(2);
	}
	if (domObj.addEventListener) {
����		domObj.addEventListener(eventName, funcName, isBroadcast);
����		return true;
����	} else if (domObj.attachEvent) {
����		return domObj.attachEvent("on" + eventName, funcName);
����	}
����	else {
����		element['on' + eventName] = funcName;
����	}	
};

/**
 * remove event from given dom object
 * @param domObj - object in document model
 * @param eventName - event name such as onclick
 * @param funcName - javascript function
 * @param isBroadcase
 */
EventUtils.removeDomEvent=function(domObj, eventName, funcName,isBroadcast){
	if(eventName.indexOf("on")==0){
		eventName=eventName.substring(2);
	}
	if (domObj.removeEventListener) {
����		domObj.removeEventListener(eventName, funcName,isBroadcast);
����		return true;
����	} else if (domObj.detachEvent) {
����		return domObj.detachEvent("on" + eventName, funcName);
����	}
����	else {
����		element['on' + eventName] = null;
����	}	
};

/**
 * Check whether the current mouse click is left click
 * @param event - the current window event
 */
EventUtils.isLeftClick=function(event){
	return event.which==1||event.button==0;
};

/**
 * Get the event soruce object
 * @param event - the current window event
 */
EventUtils.getEventSource=function(event){
	return event.srcElement||event.target;
};