/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function EmailValidator(){
	this.jsjava_class="jsorg.eob.validator.EmailValidator";
}

EmailValidator.defaultPattern=/^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;

/**
 * Check whether the given email is valid
 * param str - the given email
 * param pattern - the email pattern
 */
EmailValidator.validate=function(str,pattern){
	if(str==undefined||str==""){
	    return false;
	}
	if(pattern==undefined||pattern==""){
	    return EmailValidator.defaultPattern.test(str);
	}
	if(typeof(pattern)=="string"){
	    pattern=new RegExp(pattern);
	}
	return pattern.test(str);
};