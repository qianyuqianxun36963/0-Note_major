/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function DoubleValidator(){
	this.jsjava_class="jsorg.eob.validator.DoubleValidator";
}

DoubleValidator.POSITIVE_INFINITY=1.0/0.0;
DoubleValidator.NEGATIVE_INFINITY=-1.0/0.0;

/**
 * Check whether the given value is double
 * param str - the given value
 */
DoubleValidator.validate=function(str){
	return Double.checkValid(str);
};

/**
 * Check whether the given value is double
 * param d - the given value
 */
DoubleValidator.validate2=function(d){
	if(isNaN(d)){
		return false;
	}
	d=parseFloat(d);
	if(d<DoubleValidator.POSITIVE_INFINITY&&d>DoubleValidator.NEGATIVE_INFINITY){
        return true;
    }
    return false;
};