/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function IntegerValidator(){
	this.jsjava_class="jsorg.eob.validator.IntegerValidator";
}

IntegerValidator.MIN=-Math.pow(2,31);
IntegerValidator.MAX=Math.pow(2,31)-1;

/**
 * Check whether the given value is int
 * param str - the given value
 */
IntegerValidator.validate=function(str){
	return Integer.checkValid(str);
};

/**
 * Check whether the given value is int
 * param i - the given value
 */
IntegerValidator.validate2=function(i){
	if(isNaN(i)){
		return false;
	}
	if(typeof(i)=="number"){
		if(Math.floor(i)!=i){
			return false;
		}
	}else{
		if(i.indexOf(".")!=-1){
			return false;
		}
	}
	i=parseInt(i);
	if(i<=IntegerValidator.MAX&&i>=IntegerValidator.MIN){
    	return true;
    }
    return false;
};