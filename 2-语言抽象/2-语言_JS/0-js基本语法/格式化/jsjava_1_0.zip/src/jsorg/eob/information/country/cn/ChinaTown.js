/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function ChinaTown(){
	this.jsjava_class="jsorg.eob.information.country.cn.ChinaTown";
	this.villages=new List();
}

ChinaTown.TYPE_TOWN=0;
ChinaTown.TYPE_TOWNSHIP=1;
ChinaTown.TYPE_ETHNIC_TOWNSHIP=2;
ChinaTown.TYPE_SUB_DISTRICT=3;

/**
 * Set the town id
 * param id - town id
 */
ChinaTown.prototype.setId=function(id){
	this.id=id;
};

/**
 * Get the town id
 */
ChinaTown.prototype.getId=function(){
	return this.id;
};

/**
 * Set the town name
 * param name - town name
 */
ChinaTown.prototype.setName=function(name){
	this.name=name;
};

/**
 * Get the town name
 */
ChinaTown.prototype.getName=function(){
	return this.name;
};

/**
 * Set the town type
 * param type - town type
 */
ChinaTown.prototype.setType=function(type){
	this.type=type;
};

/**
 * Get the town type
 */
ChinaTown.prototype.getType=function(){
	return this.type;
};

/**
 * Check whether the town is general town
 */
ChinaTown.prototype.isTown=function(){
	return this.type==ChinaTown.TYPE_TOWN;
};

/**
 * Check whether the town is township
 */
ChinaTown.prototype.isTownship=function(){
	return this.type==ChinaTown.TYPE_TOWNSHIP;
};

/**
 * Check whether the town is ethnic township
 */
ChinaTown.prototype.isEthnicTownship=function(){
	return this.type==ChinaTown.TYPE_ETHNIC_TOWNSHIP;
};

/**
 * Check whether the town is sub district
 */
ChinaTown.prototype.isSubDistrict=function(){
	return this.type==ChinaTown.TYPE_SUB_DISTRICT;
};

/**
 * Set the county belonged to
 * param county - the county belonged to
 */
ChinaTown.prototype.setCounty=function(county){
	this.county=county;
};

/**
 * Get the county belonged to
 */
ChinaTown.prototype.getCounty=function(){
	return this.county;
};

/**
 * Add village
 * param village
 */
ChinaTown.prototype.addVillage=function(village){
	this.villages.add(village);
};

/**
 * Get village by city id
 * param villageId
 */
ChinaTown.prototype.getVillageById=function(villageId){
	var it=this.iterator();
	while(it.hasNext()){
		var village=it.next();
		if(village.getId()==villageId){
			return village;
		}
	}
};

/**
 * Get village by city name
 * param villageName
 */
ChinaTown.prototype.getVillageByName=function(villageName){
	var it=this.iterator();
	while(it.hasNext()){
		var village=it.next();
		if(village.getName()==villageName){
			return village;
		}
	}
};

/**
 * Convert to iterator object
 */
ChinaTown.prototype.iterator=function(){
	return this.villages.iterator();
};

/**
 * Get all villages belonged to the town
 */
ChinaTown.prototype.getVillages=function(){
	return this.villages;
};

/**
 * Get number of villages
 */
ChinaTown.prototype.getSize=function(){
	return this.villages.getSize();
};

/**
 * Get the town description
 */
ChinaTown.prototype.toString=function(){
	var str="["+this.id+","+this.name+"]";
	return str;
};