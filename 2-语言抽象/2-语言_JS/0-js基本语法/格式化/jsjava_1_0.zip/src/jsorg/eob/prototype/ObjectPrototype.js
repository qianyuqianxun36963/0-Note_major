/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**
 * Constructor
 */ 
function ObjectPrototype(){
	this.jsjava_class="jsorg.eob.prototype.ObjectPrototype";
}

/**
 * Load the extended Object prototype
 */
ObjectPrototype.load=function(){
	Object.prototype.jsjava_class="Object";
	
	Object.prototype.equals=function(o){
		if(this==o){
			return true;
		}		
		if(this.toString()==o.toString()){
			return true;
		}
		return false;
	};
	
	Object.prototype.clone=function(){
		throw new CloneNotSupportedException(CloneNotSupportedException.ERROR,"The object,which calls the clone method,need implement the clone method by itself");
	};
	
	Object.prototype.getClass=function(){
		if(this.jsjava_class){
			return this.jsjava_class;
		}
		if(this instanceof Array){
			return "Array";
		}
		if(this instanceof Boolean){
			return "Boolean";
		}
		if(this instanceof Date){
			return "Date";
		}
		if(this instanceof Function){
			return "Function";
		}
		if(this instanceof Number){
			return "Number";
		}
		if(this instanceof RegExp){
			return "RegExp";
		}
		if(this instanceof String){
			return "String";
		}
	};
};

ObjectPrototype.load();