/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */
function ChinaProvince(){
	this.jsjava_class="jsorg.eob.information.country.cn.ChinaProvince";
	this.cities=new List();
}

ChinaProvince.TYPE_PROVINCE=0;
ChinaProvince.TYPE_AUTONOMOUS_REGION=1;
ChinaProvince.TYPE_MUNICIPALITY=2;
ChinaProvince.TYPE_SAR=3;

/**
 * Set the province id
 * param id - province id
 */
ChinaProvince.prototype.setId=function(id){
	this.id=id;
};

/**
 * Get the province id
 */
ChinaProvince.prototype.getId=function(){
	return this.id;
};

/**
 * Set the province name
 * param name - province name
 */
ChinaProvince.prototype.setName=function(name){
	this.name=name;
};

/**
 * Get the province name
 */
ChinaProvince.prototype.getName=function(){
	return this.name;
};

/**
 * Set the province type
 * param type - county type
 */
ChinaProvince.prototype.setType=function(type){
	this.type=type;
};

/**
 * Get the province type
 */
ChinaProvince.prototype.getType=function(){
	return this.type;
};

/**
 * Set the province short name
 * param shortName - province short name
 */
ChinaProvince.prototype.setShortName=function(shortName){
	this.shortName=shortName;
};

/**
 * Get the province short name
 */
ChinaProvince.prototype.getShortName=function(){
	return this.shortName;
};

/**
 * Set the province abbreviate name
 * param shortName - province abbreviate name
 */
ChinaProvince.prototype.setAbbreviate=function(abbreviate){
	this.abbreviate=abbreviate;
};

/**
 * Get the province abbreviate name
 */
ChinaProvince.prototype.getAbbreviate=function(){
	return this.abbreviate;
};

/**
 * Check whether the province is general level
 */
ChinaProvince.prototype.isProvince=function(){
	return this.type==ChinaProvince.TYPE_PROVINCE;
};

/**
 * Check whether the province is autonomous region
 */
ChinaProvince.prototype.isAutonomousRegion=function(){
	return this.type==ChinaProvince.TYPE_AUTONOMOUS_REGION;
};

/**
 * Check whether the province is municipality
 */
ChinaProvince.prototype.isMunicipality=function(){
	return this.type==ChinaProvince.TYPE_MUNICIPALITY;
};

/**
 * Check whether the province is SAR
 */
ChinaProvince.prototype.isSAR=function(){
	return this.type==ChinaProvince.TYPE_SAR;
};

/**
 * Set the country belonged to
 * param country - the country belonged to
 */
ChinaProvince.prototype.setCountry=function(country){
	this.country=country; 
};

/**
 * Get the country belonged to
 */
ChinaProvince.prototype.getCountry=function(){
	return this.country;
};

/**
 * Set the province region code
 * param regionCode - the province region code
 */
ChinaProvince.prototype.setRegionCode=function(regionCode){
	this.regionCode=regionCode; 
};

/**
 * Get the province region code
 */
ChinaProvince.prototype.getRegionCode=function(){
	return this.regionCode;
};

/**
 * Add city
 * param city
 */
ChinaProvince.prototype.addCity=function(city){
	this.cities.add(city);
};

/**
 * Get city by city id
 * param cityId
 */
ChinaProvince.prototype.getCityById=function(cityId){
	var it=this.iterator();
	while(it.hasNext()){
		var city=it.next();
		if(city.getId()==cityId){
			return city;
		}
	}
};

/**
 * Get city by city name
 * param cityName
 */
ChinaProvince.prototype.getCityByName=function(cityName){
	var it=this.iterator();
	while(it.hasNext()){
		var city=it.next();
		if(city.getName()==cityName){
			return city;
		}
	}
};

/**
 * Convert to iterator object
 */
ChinaProvince.prototype.iterator=function(){
	return this.cities.iterator();
};

/**
 * Get all cities belonged to the province
 */
ChinaProvince.prototype.getCities=function(){
	return this.cities;
};

/**
 * Get number of cities
 */
ChinaProvince.prototype.getSize=function(){
	return this.cities.getSize();
};

/**
 * Get the province description
 */
ChinaProvince.prototype.toString=function(){
	var str="["+this.id+","+this.abbreviate+","+this.name+","+this.shortName+","+this.type+"]";
	return str;
};