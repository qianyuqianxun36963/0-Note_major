/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function NumberScaleValidator(){
	this.jsjava_class="jsorg.eob.validator.NumberScaleValidator";
}

/**
 * validate whether a number n is between n1 and n2
 * param n
 * param n1
 * param n2
 */
NumberScaleValidator.validateBetween=function(n,n1,n2){
	if(isNaN(n)||isNaN(n1)||isNaN(n2)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
	n=parseInt(n);
	n1=parseInt(n1);
	n2=parseInt(n2);
	if(n>=n1&&n<=n2){
    	return true;
    }
    return false;
};

/**
 * validate whether a number is larger than n1
 * param n
 * param n1
 */
NumberScaleValidator.validateLargerThan=function(n,n1){
	if(isNaN(n)||isNaN(n1)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
	n=parseInt(n);
	n1=parseInt(n1);
	if(n>=n1){
    	return true;
    }
    return false;
};

/**
 * validate whether a number is less than n1
 * param n
 * param n1
 */
NumberScaleValidator.validateLessThan=function(n,n1){
	if(isNaN(n)||isNaN(n1)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
	n=parseInt(n);
	n1=parseInt(n1);
	if(n<=n1){
    	return true;
    }
    return false;
};