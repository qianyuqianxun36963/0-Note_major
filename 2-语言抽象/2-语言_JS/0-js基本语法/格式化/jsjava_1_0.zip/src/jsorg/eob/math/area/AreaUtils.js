/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function AreaUtils(){
	this.jsjava_class="jsorg.eob.math.area.AreaUtils";
}

/**
 * Calculate the area of square
 * param a - the side length of the square
 */
AreaUtils.countSquare=function(a){
	if(a<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"side must be equal or larger than zero!");
	}
	return a*a;
};

/**
 * Calculate the area of rectangle
 * param a - the one side length of the rectangle
 * param b - the ajacent side length of the rectangle
 */
AreaUtils.countRectangle=function(a,b){
	if(a<0||b<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}
	return a*a;
};

/**
 * Calculate the area of circle
 * param r - the radius of circle
 */
AreaUtils.countCircle=function(r){
	if(r<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"radius must be equal or larger than zero!");
	}	
	return  Math.PI*r*r;
};

/**
 * Calculate the area of circle
 * param d - the diameter of circle
 */
AreaUtils.countCircle2=function(d){
	if(d<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"diameter must be equal or larger than zero!");
	}	
	return  Math.PI*d*d/4;
};

/**
 * Calculate the area of equilateral triangle
 * param a - the side length
 */
AreaUtils.countEquilateralTriangle=function(a){
	return  AreaUtils.countTriangle(a,a,Math.PI/3);
};

/**
 * Calculate the area of triangle
 * param a - the side length
 * param h - the height of the side
 */
AreaUtils.countTriangle=function(a,h){
	if(a<0||h<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and height must be equal or larger than zero!");
	}	
	return  0.5*a*h;
};

/**
 * Calculate the area of triangle
 * param a - the one side length
 * param b - the other side length
 * param angleC - the angle between the tow sides
 */
AreaUtils.countTriangle2=function(a,b,angleC){
	if(a<0||b<0||angleC<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  0.5*a*b*Math.sin(angleC);
};

/**
 * Calculate the area of triangle
 * param a - the one side length
 * param b - the second side length
 * param c - the third side length
 */
AreaUtils.countTriangle3=function(a,b,c){
	if(a<0||b<0||c<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}	
	var s=(a+b+c)/2;
	return  Math.sqrt(s*(s-a)*(s-b)*(s-c));
};

/**
 * Calculate the area of triangle
 * param a - the one side length
 * param angleA - the angle A
 * param angleB - the angle B
 * param angleC - the angle C
 */
AreaUtils.countTriangle4=function(a,angleA,angleB,angleC){
	if(a<0||angleA<0||angleB<0||angleC<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  a*a*Math.sin(angleB)*Math.sin(angleC)/(2*Math.sin(angleA));
};

/**
 * Calculate the area of trapezia
 * param a - the top side length
 * param b - the bottom side length
 * param h - the height of trapezia
 */
AreaUtils.countTrapezia=function(a,b,h){
	if(a<0||b<0||h<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and height must be equal or larger than zero!");
	}	
	return  0.5*(a+b)*h;
};

/**
 * Calculate the area of trapezia
 * param m - the middle line length
 * param h - the height of trapezia
 */
AreaUtils.countTrapezia2=function(m,h){
	if(m<0||h<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and height must be equal or larger than zero!");
	}	
	return  m*h;
};

/**
 * Calculate the area of quadrangle
 * param d - the length of one diagonal
 * param D - the length of the other diagonal
 * param angleA - the angle between two diagonals
 */
AreaUtils.countQuadrangle=function(d,D,angleA){
	if(d<0||D<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  d*D/2*Math.sin(DegreeTransform.toRadian(angleA));
};

/**
 * Calculate the area of parallelogram
 * param a - the length of one diagonal
 * param h - the length of the other diagonal
 */
AreaUtils.countParallelogram=function(a,h){
	if(a<0||h<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}	
	return  a*h;
};

/**
 * Calculate the area of parallelogram
 * param a - the length of one diagonal
 * param b - the length of the other diagonal
 * param angleA - the angle between two diagonals
 */
AreaUtils.countParallelogram2=function(a,b,angleA){
	if(a<0||b<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  a*b*Math.sin(DegreeTransform.toRadian(angleA));
};

/**
 * Calculate the area of diamond
 * param a - the length of one diagonal
 * param D - the length of the other diagonal
 */
AreaUtils.countDiamond=function(d,D){
	if(d<0||D<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}	
	return  d*D/2;
};

/**
 * Calculate the area of diamond
 * param a - the side length
 * param angleA - the angle of two ajacent side
 */
AreaUtils.countDiamond2=function(a,angleA){
	if(a<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  a*a*Math.sin(DegreeTransform.toRadian(angleA));
};

/**
 * Calculate the area of sector
 * param r - the radius of sector
 * param angleA - the central angle
 */
AreaUtils.countSector=function(r,angleA){
	if(r<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  Math.PI*r*r*angleA/360;
};

/**
 * Calculate the area of arc
 * param r - the radius of arc
 * param angleA - the central angle
 */
AreaUtils.countArc=function(r,angleA){
	if(r<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  r*r/2*(DegreeTransform.toRadian(angleA)-Math.sin(DegreeTransform.toRadian(angleA)));
};

/**
 * Calculate the area of annulus
 * param r - the radius of inner circle
 * param R - the radius of outer circle
 */
AreaUtils.countAnnulus=function(r,R){
	if(r<0||R<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"radius must be equal or larger than zero!");
	}	
	if(r>R){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"R must be equal or larger than r!");
	}
	return  Math.PI*(R*R-r*r);
};

/**
 * Calculate the area of ellipse
 * param d - the length of short axis
 * param D - the length of long axis
 */
AreaUtils.countEllipse=function(d,D){
	if(d<0||D<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}	
	return  Math.PI*D*d/4;
};
