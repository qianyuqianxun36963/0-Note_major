/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function ChinaCountry(){
	this.jsjava_class="jsorg.eob.information.country.cn.ChinaCountry";
	this.provinces=new List();
	this.id="china";
	this.name="\u4E2D\u56FD";
}

/**
 * Get the country id
 */
ChinaCountry.prototype.getId=function(){
	return "china";
};

/**
 * Get the country name
 */
ChinaCountry.prototype.getName=function(){
	return "\u4E2D\u56FD";
};

/**
 * Add province
 * param province
 */
ChinaCountry.prototype.addProvince=function(province){
	this.provinces.add(province);
};

/**
 * Get province by its id
 * param provinceId
 */
ChinaCountry.prototype.getProvinceById=function(provinceId){
	var it=this.iterator();
	while(it.hasNext()){
		var province=it.next();
		if(province.getId()==provinceId){
			return province;
		}
	}
};

/**
 * Get province by its name
 * param provinceName
 */
ChinaCountry.prototype.getProvinceByName=function(provinceName){
	var it=this.iterator();
	while(it.hasNext()){
		var province=it.next();
		if(province.getName()==provinceName){
			return province;
		}
	}
};

/**
 * Convert to iterator object
 */
ChinaCountry.prototype.iterator=function(){
	return this.provinces.iterator();
};

/**
 * Get all provinces
 */
ChinaCountry.prototype.getprovinces=function(){
	return this.provinces;
};

/**
 * Get number of provinces
 */
ChinaCountry.prototype.getSize=function(){
	return this.provinces.getSize();
};

/**
 * Get the description
 */
ChinaCountry.prototype.toString=function(){
	var str="["+this.id+","+this.name+"]";
	return str;
};