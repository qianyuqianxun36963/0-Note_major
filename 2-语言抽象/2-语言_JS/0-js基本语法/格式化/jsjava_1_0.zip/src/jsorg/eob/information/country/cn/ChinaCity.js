/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function ChinaCity(){
	this.jsjava_class="jsorg.eob.information.country.cn.ChinaCity";
	this.counties=new List();
}

ChinaCity.TYPE_PROVINCE=0;
ChinaCity.TYPE_CITY=1;
ChinaCity.TYPE_AUTONOMOUS_PREFECTURE=2;
ChinaCity.TYPE_PREFECTURE_MENG=3;
ChinaCity.TYPE_PREFECTURE_DIQU=4;

/**
 * Set the city id
 * param id - city id
 */
ChinaCity.prototype.setId=function(id){
	this.id=id;
};

/**
 * Get the city id
 */
ChinaCity.prototype.getId=function(){
	return this.id;
};

/**
 * Set the city name
 * param name - city name
 */
ChinaCity.prototype.setName=function(name){
	this.name=name;
};

/**
 * Get the city name
 */
ChinaCity.prototype.getName=function(){
	return this.name;
};

/**
 * Set the city type
 * param type - city type
 */
ChinaCity.prototype.setType=function(type){
	this.type=type;
};

/**
 * Get the city type
 */
ChinaCity.prototype.getType=function(){
	return this.type;
};

/**
 * Set the city short name
 * param shortName - city short name
 */
ChinaCity.prototype.setShortName=function(shortName){
	this.shortName=shortName;
};

/**
 * Get the city short name
 */
ChinaCity.prototype.getShortName=function(){
	return this.shortName;
};

/**
 * Check whether the city is province level
 */
ChinaCity.prototype.isProvince=function(){
	return this.type==ChinaCity.TYPE_PROVINCE;
};

/**
 * Check whether the city is city level
 */
ChinaCity.prototype.isCity=function(){
	return this.type==ChinaCity.TYPE_CITY;
};

/**
 * Check whether the city is autonomous prefecture
 */
ChinaCity.prototype.isAutonomousPrefecture=function(){
	return this.type==ChinaCity.TYPE_AUTONOMOUS_PREFECTURE;
};

/**
 * Check whether the city is prefecture
 */
ChinaCity.prototype.isPrefectureMeng=function(){
	return this.type==ChinaCity.TYPE_PREFECTURE_MENG;
};

/**
 * Check whether the city is prefecture
 */
ChinaCity.prototype.isPrefectureDiqu=function(){
	return this.type==ChinaCity.TYPE_PREFECTURE_DIQU;
};

/**
 * Set the province belonged to
 * param province - the province belonged to
 */
ChinaCity.prototype.setProvince=function(province){
	this.province=province;
};

/**
 * Get the province belonged to
 */
ChinaCity.prototype.getProvince=function(){
	return this.province;
};

/**
 * Set the city postcode
 * param postcode - the city postcode
 */
ChinaCity.prototype.setPostcode=function(postcode){
	this.postcode=postcode;
};

/**
 * Get the city postcode
 */
ChinaCity.prototype.getPostcode=function(){
	return this.postcode;
};

/**
 * Set the city phone area code
 * param phoneAreaCode - the city phone area code
 */
ChinaCity.prototype.setPhoneAreaCode=function(phoneAreaCode){
	this.phoneAreaCode=phoneAreaCode;
};

/**
 * Get the city phone area code
 */
ChinaCity.prototype.getPhoneAreaCode=function(){
	return this.phoneAreaCode;
};

/**
 * Set the city region code
 * param regionCode - the city region code
 */
ChinaCity.prototype.setRegionCode=function(regionCode){
	this.regionCode=regionCode; 
};

/**
 * Get the city region code
 */
ChinaCity.prototype.getRegionCode=function(){
	return this.regionCode;
};

/**
 * Add county
 * param county
 */
ChinaCity.prototype.addCounty=function(county){
	this.counties.add(county);
};

/**
 * Get county by county id
 * param countyId
 */
ChinaCity.prototype.getCountyById=function(countyId){
	var it=this.iterator();
	while(it.hasNext()){
		var county=it.next();
		if(county.getId()==countyId){
			return county;
		}
	}
};

/**
 * Get county by county name
 * param countyName
 */
ChinaCity.prototype.getCountyByName=function(countyName){
	var it=this.iterator();
	while(it.hasNext()){
		var county=it.next();
		if(county.getName()==countyName){
			return county;
		}
	}
};

/**
 * Convert to iterator object
 */
ChinaCity.prototype.iterator=function(){
	return this.counties.iterator();
};

/**
 * Get all counties belonged to the city
 */
ChinaCity.prototype.getCounties=function(){
	return this.counties;
};

/**
 * Get number of counties
 */
ChinaCity.prototype.getSize=function(){
	return this.counties.getSize();
};

/**
 * Get the city description
 */
ChinaCity.prototype.toString=function(){
	var str="["+this.id+","+this.name+","+this.postcode+","+this.phoneAreaCode+","+this.regionCode+"]";
	return str;
};