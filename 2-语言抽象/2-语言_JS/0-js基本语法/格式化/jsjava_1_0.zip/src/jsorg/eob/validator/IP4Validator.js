/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function IP4Validator(){
	this.jsjava_class="jsorg.eob.validator.IP4Validator";
}

/**
 * Check whether the given value is valid IP address
 * param str - the given value
 * param strict - boolean flag
 */
IP4Validator.validate=function(str,strict){
	if(strict != null  && strict == ""){
		if (str == "0.0.0.0")
			return false;
		else if (str == "255.255.255.255")
			return false;
	};
	theName = "IPaddress";
	var ipPattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
	var ipArray = str.match(ipPattern);
	if (ipArray == null){
		return false;
	}else {
		for (i = 1; i < 5; i++){
			thisSegment = parseInt(ipArray[i]);
			if (thisSegment > 255) {
				return false;
			}
			if (i == 1 && parseInt(ipArray[1]) == 0 ) {
				return false ;
			}
		}
	}
	return true; 
};