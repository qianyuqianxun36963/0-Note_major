/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**  The ConditionTrigger class not references to any class of J2SE1.4 
 *  This is a class used to condition assert.
 */
 
/**
 * constructor
 * param components
 * param conditionNumber
 */ 
function ConditionTrigger(components,conditionNumber){
	this.jsjava_class="jsorg.eob.component.trigger.ConditionTrigger";
    this.components=components;
    this.conditions=new Array(conditionNumber);
    this.size=0;
}

/**
 * add a condition expression
 * param condition
 */
ConditionTrigger.prototype.addCondition=function(condition){
    this.conditions[this.size++]=condition;
    
};

/**
 * triggered according to the given conditionSeed
 * param conditionSeed
 */
ConditionTrigger.prototype.trigger=function(conditionSeed){
    var triggerCondition="ConditionTrigger_NULL";
    var conditions=this.conditions;
    for(var i=0;i<conditions.length;i++){
        if(conditions[i].conditionSeed==conditionSeed){
            triggerCondition=conditions[i];
        }
    }
    if(triggerCondition=="ConditionTrigger_NULL"){
        return;	
    }
    var visibles;
    if(triggerCondition!=null){
        visibles=triggerCondition.visibles;	
    }
    if(visibles!=null){
        for(var i=0;i<visibles.length;i++){
            this.show(visibles[i]);
        }
    }
    var invisibles=this.getDiff(this.components,visibles);
    for(var i=0;i<invisibles.length;i++){
        this.hide(invisibles[i]);
    }
};

/**
 * display the component identified by id
 * param id
 */
ConditionTrigger.prototype.show=function(id){
    document.getElementById(id).style.display="block";
};

/**
 * hide the component identified by id
 * param id
 */
ConditionTrigger.prototype.hide=function(id){
    document.getElementById(id).style.display="none";
};

/**
 * return the different components between collections and parts 
 * param collections all components
 * param parts
 */
ConditionTrigger.prototype.getDiff=function(collection,parts){
	if(parts==null){
	    return collection;	
	}
    var res=new Array(collection.length-parts.length);
    var resCount=0;
    for(var i=0;i<collection.length;i++){
        if(!this.contains(parts,collection[i])){
            res[resCount]=collection[i];
            resCount++;
        }
    }
    return res;
};

/**
 * return the boolean value whether parts contains part
 * param parts
 * param part
 */
ConditionTrigger.prototype.contains=function(parts,part){
    for(var i=0;i<parts.length;i++){
        if(parts[i]==part){
            return true;
        }
    }
    return false;
};    
    