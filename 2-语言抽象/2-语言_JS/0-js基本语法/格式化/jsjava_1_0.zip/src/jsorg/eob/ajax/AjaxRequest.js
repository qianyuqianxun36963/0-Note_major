/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function AjaxRequest(){
	this.jsjava_class="jsorg.eob.ajax.AjaxRequest";
	this.request=AjaxUtils.getXMLHTTPRequest();		
	this.headers=new Hashtable();
};

/**
 * Set the method triggered on ajax request success
 * param jsFunc - javascript function
 * param args - an arguments array
 */
AjaxRequest.prototype.setMethodOnSuccess=function(jsFunc,args){
	this.jsFunctionOnSuccess=jsFunc;
	this.jsFunctionArgsOnSuccess=args;
};

/**
 * Get the method triggered on ajax request success
 */
AjaxRequest.prototype.getMethodOnSuccess=function(){
	return this.jsFunctionOnSuccess;
};

/**
 * Get ready state
 */
AjaxRequest.prototype.getReadyState=function(){
	return this.request.readyState;
};

/**
 * Get response data
 */
AjaxRequest.prototype.getResponseBody=function(){
	return this.request.responseBody;
};

/**
 * Get response stream
 */
AjaxRequest.prototype.getResponseStream=function(){
	return this.request.responseStream;
};

/**
 * Get response text
 */
AjaxRequest.prototype.getResponseText=function(){
	return this.request.responseText;
};

/**
 * Get response xml object
 */
AjaxRequest.prototype.getResponseXML=function(){
	return this.request.responseXML;
};

/**
 * Get response status
 */
AjaxRequest.prototype.getStatus=function(){
	return this.request.status;
};

/**
 * Get response text
 */
AjaxRequest.prototype.getStatusText=function(){
	return this.request.statusText;
};

/**
 * Abort the current ajax request
 */
AjaxRequest.prototype.abort=function(){
	return this.request.abort();
};

/**
 * Set the request method
 * param reqMethod - the request method
 */
AjaxRequest.prototype.setRequestMethod=function(reqMethod){
	this.requestMethod=reqMethod;
};

/**
 * Set the request url
 * param reqURL - the request url
 */
AjaxRequest.prototype.setRequestURL=function(reqURL){
	this.requestURL=reqURL;
};

/**
 * Set whether the request is asynchoronized
 * param isAsync - boolean flag
 */
AjaxRequest.prototype.setAsync=function(isAsync){
	this.isAsynchronous=isAsync;
};

/**
 * Set the request authentication that is required on some web servers
 * param auth - the authenction object which contains username and password
 */
AjaxRequest.prototype.setAuthentication=function(auth){
	this.authentication=auth;
};

/**
 * Send the ajax request
 */
AjaxRequest.prototype.send=function(){	
	var ajaxRequest=this;
	var authUserName="";
	var authPassword="";
	if(this.authentication){
		authUserName=this.authentication.getUserName();
		authPassword=this.authentication.getPassword();
	}
	this.request.open(this.requestMethod,this.requestURL,this.isAsynchronous,authUserName,authPassword);
	var headerNames=this.headers.keys();
	for(var i=0;i<headerNames.length;i++){
		var headerName=headerNames[i];
		var headerValue=this.headers.get(headerName);
		this.request.setRequestHeader(headerName,headerValue);
	}
	this.request.onreadystatechange=function(){
		if(ajaxRequest.request.readyState==4){
			if(ajaxRequest.request.status==200){
				var args=ajaxRequest.jsFunctionArgsOnSuccess;
				var argStr="";
				if(args!=undefined&&args.length){
					for(var i=0;i<args.length;i++){
						argStr+="args["+i+"],";
					}
				}
				if(argStr.indexOf(",")==argStr.length-1){
					argStr=argStr.substring(0,argStr.length-1);
				}
				var newStr = "ajaxRequest.jsFunctionOnSuccess("+ argStr+")"; 
				eval(newStr);
			}
		};
	};
	this.request.send(null);
};

/**
 * Set ajax request header
 * param headerName
 * param headerValue
 */
AjaxRequest.prototype.setRequestHeader=function(headerName,headerValue){
	this.headers.put(headerName,headerValue);
};

/**
 * Set ajax request headers
 * param headersArray
 */
AjaxRequest.prototype.setRequestHeaders=function(headersArray){
	for(var i=0;i<headersArray.length;i++){
		var header=headersArray[i];
		var headerName=header.getName();
		var headerValue=header.getValue();
		this.headers.put(headerName,headerValue);
	}	
};

/**
 * Get ajax response header value
 * param headerName
 */
AjaxRequest.prototype.getResponseHeaderValue=function(headerName){
	this.request.getResponseHeader(headerName);
};

/**
 * Get all ajax response headers
 */
AjaxRequest.prototype.getAllResponseHeaders=function(){
	this.request.getAllResponseHeaders();
};