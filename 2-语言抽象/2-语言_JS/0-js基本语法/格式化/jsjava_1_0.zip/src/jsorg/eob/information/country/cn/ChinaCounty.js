/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */
function ChinaCounty(){
	this.jsjava_class="jsorg.eob.information.country.cn.ChinaCounty";
	this.towns=new List();
}

ChinaCounty.TYPE_COUNTY=0;
ChinaCounty.TYPE_AUTONOMOUS_COUNTY=1;
ChinaCounty.TYPE_CITY=2;
ChinaCounty.TYPE_DISTRICT=3;

/**
 * Set the county id
 * param id - county id
 */
ChinaCounty.prototype.setId=function(id){
	this.id=id;
};

/**
 * Get the county id
 */
ChinaCounty.prototype.getId=function(){
	return this.id;
};

/**
 * Set the county name
 * param name - county name
 */
ChinaCounty.prototype.setName=function(name){
	this.name=name;
};

/**
 * Get the county name
 */
ChinaCounty.prototype.getName=function(){
	return this.name;
};

/**
 * Set the county type
 * param type - county type
 */
ChinaCounty.prototype.setType=function(type){
	this.type=type;
};

/**
 * Get the county type
 */
ChinaCounty.prototype.getType=function(){
	return this.type;
};

/**
 * Check whether the city is county
 */
ChinaCounty.prototype.isCounty=function(){
	return this.type==ChinaCounty.TYPE_COUNTY;
};

/**
 * Check whether the county is autonomous county
 */
ChinaCounty.prototype.isAutonomousCounty=function(){
	return this.type==ChinaCounty.TYPE_AUTONOMOUS_COUNTY;
};

/**
 * Check whether the county is city
 */
ChinaCounty.prototype.isCity=function(){
	return this.type==ChinaCounty.TYPE_CITY;
};

/**
 * Check whether the county is district
 */
ChinaCounty.prototype.isDistrict=function(){
	return this.type==ChinaCounty.TYPE_DISTRICT;
};

/**
 * Set the city belonged to
 */
ChinaCounty.prototype.setCity=function(city){
	this.city=city;
};

/**
 * Set the city belonged to
 */
ChinaCounty.prototype.setCity=function(city){
	this.city=city;
};


/**
 * Set the city belonged to
 * param city
 */
ChinaCounty.prototype.setCity=function(city){
	this.city=city;
};

/**
 * Get the city belonged to
 */
ChinaCounty.prototype.getCity=function(){
	return this.city;
};

/**
 * Add town
 * param town
 */
ChinaCounty.prototype.addTown=function(town){
	this.towns.add(town);
};

/**
 * Get town by id
 * param townId
 */
ChinaCounty.prototype.getTownById=function(townId){
	var it=this.iterator();
	while(it.hasNext()){
		var town=it.next();
		if(town.getId()==townId){
			return town;
		}
	}
};

/**
 * Get town by name
 * param townName
 */
ChinaCounty.prototype.getTownByName=function(townName){
	var it=this.iterator();
	while(it.hasNext()){
		var town=it.next();
		if(town.getName()==townName){
			return town;
		}
	}
};

/**
 * Convert to iterator object
 */
ChinaCounty.prototype.iterator=function(){
	return this.towns.iterator();
};

/**
 * Get all counties belonged to the county
 */
ChinaCounty.prototype.getTowns=function(){
	return this.towns;
};

/**
 * Get number of towns
 */
ChinaCounty.prototype.getSize=function(){
	return this.towns.getSize();
};

/**
 * Get the county description
 */
ChinaCounty.prototype.toString=function(){
	var str="["+this.id+","+this.name+"]";
	return str;
};