/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**
 * constructor
 */
function ChinaLunarCalendar(){
	this.jsjava_class="jsorg.eob.calendar.country.cn.ChinaLunarCalendar";
	this.calendarData=[0x41A95,0xD4A,0xDA5,0x20B55,0x56A,0x7155B,0x25D,0x92D,0x5192B,0xA95,0xB4A,0x416AA,0xAD5,0x90AB5,0x4BA,0xA5B,0x60A57,0x52B,0xA93,0x40E95];
	this.madd=[0,31,59,90,120,151,181,212,243,273,304,334];
	this.date=new Date();
	this.tgString="\u7532\u4e59\u4e19\u4e01\u620a\u5df1\u5e9a\u8f9b\u58ec\u7678";
	this.dzString="\u5b50\u4e11\u5bc5\u536f\u8fb0\u5df3\u5348\u672a\u7533\u9149\u620c\u4ea5";
	this.numString="\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341";
	this.monString="\u6b63\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341\u51ac\u814a";
	this.weekString="\u65e5\u4e00\u4e8c\u4e09\u56db\u4e94\u516d";
	this.sxString="\u9f20\u725b\u864e\u5154\u9f99\u86c7\u9a6c\u7f8a\u7334\u9e21\u72d7\u732a";
	this.cYear;
	this.cMonth;
	this.cDate;
	this.cDay;
	this.cHour;
	this.tiangan;
	this.dizhi;
	this.shengxiao;
	this.convert();	
}

ChinaLunarCalendar.jia=0;
ChinaLunarCalendar.yi=1;
ChinaLunarCalendar.bing=2;
ChinaLunarCalendar.ding=3;
ChinaLunarCalendar.wu=4;
ChinaLunarCalendar.ji=5;
ChinaLunarCalendar.geng=6;
ChinaLunarCalendar.xin=7;
ChinaLunarCalendar.ren=8;
ChinaLunarCalendar.gui=9;

ChinaLunarCalendar.zi=0;
ChinaLunarCalendar.chou=1;
ChinaLunarCalendar.yin=2;
ChinaLunarCalendar.mao=3;
ChinaLunarCalendar.chen=4;
ChinaLunarCalendar.si=5;
ChinaLunarCalendar.wu=6;
ChinaLunarCalendar.wei=7;
ChinaLunarCalendar.shen=8;
ChinaLunarCalendar.you=9;
ChinaLunarCalendar.xu=10;
ChinaLunarCalendar.hai=11;

ChinaLunarCalendar.shu=0;
ChinaLunarCalendar.niu=1;
ChinaLunarCalendar.hu=2;
ChinaLunarCalendar.tu=3;
ChinaLunarCalendar.lon=4;
ChinaLunarCalendar.she=5;
ChinaLunarCalendar.ma=6;
ChinaLunarCalendar.yang=7;
ChinaLunarCalendar.hou=8;
ChinaLunarCalendar.ji=9;
ChinaLunarCalendar.gou=10;
ChinaLunarCalendar.zhu=11;

ChinaLunarCalendar.DISPLAY_NIAN="\u5e74";
ChinaLunarCalendar.DISPLAY_YUE="\u6708";
ChinaLunarCalendar.DISPLAY_RI="\u65e5";
ChinaLunarCalendar.DISPLAY_SHI="\u65f6";
ChinaLunarCalendar.DISPLAY_FEN="\u5206";
ChinaLunarCalendar.DISPLAY_MIAO="\u79d2";
ChinaLunarCalendar.DISPLAY_HAOMIAO="\u6beb\u79d2";
ChinaLunarCalendar.DISPLAY_ZHOU="\u5468";
ChinaLunarCalendar.DISPLAY_XINGQI="\u661f\u671f";
ChinaLunarCalendar.DISPLAY_RUN="\u95f0";
ChinaLunarCalendar.DISPLAY_CHU="\u521d";
ChinaLunarCalendar.DISPLAY_SHI="\u5341";
ChinaLunarCalendar.DISPLAY_ERSHI="\u5eff";
ChinaLunarCalendar.DISPLAY_SANSHI="\u5345";

/**
 * Convert to lunar calendar
 */
ChinaLunarCalendar.prototype.convert=function(){
	var total,m,n,k;
	var isEnd=false;
	var tmp=this.date.getYear();
	if (tmp<1900){ 
		tmp+=1900;
	}
	total=(tmp-2001)*365+Math.floor((tmp-2001)/4)+this.madd[this.date.getMonth()]+this.date.getDate()-23;
	if (this.date.getYear()%4==0&&this.date.getMonth()>1){
		total++;
	}
	for(m=0;;m++){
		k=(this.calendarData[m]<0xfff)?11:12;
		for(n=k;n>=0;n--){
			if(total<=29+((this.calendarData[m]>>n)&1)){
				isEnd=true;
				break;
			}
			total=total-29-((this.calendarData[m]>>n)&1);
		}
		if(isEnd){
		    break;
		}
	}
	this.cYear=2001 + m;
	this.cMonth=k-n+1;
	this.cDate=total;
	this.cDay=this.date.getDay();
	if(k==12){
		if(this.cMonth==Math.floor(this.calendarData[m]/0x10000)+1){
			this.cMonth=1-this.cMonth;
		}
		if(this.cMonth>Math.floor(this.calendarData[m]/0x10000)+1){
			this.cMonth--;
		}
	}
	this.cHour=Math.floor((this.date.getHours()+3)/2);
	this.tiangan=(this.cYear-4)%10;
	this.dizhi=(this.cYear-4)%12;
	this.shengxiao=(this.cYear-4)%12;
};

/**
 * Get the tiangan of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getTianGan=function(){
	return this.tiangan;
};

/**
 * Get the dizhi of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDiZhi=function(){
	return this.dizhi;
};

/**
 * Get the shengxiao of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getShengXiao=function(){
	return this.shengxiao;
};

/**
 * Get the year of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getYear=function(){
	return this.cYear;
};

/**
 * Get the month of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getMonth=function(){
	return this.cMonth;
};

/**
 * Get the date of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDate=function(){
	return this.cDate;
};

/**
 * Get the day of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDay=function(){
	return this.cDay;
};

/**
 * Get the hours of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getHours=function(){
	return this.cHour;
};

/**
 * Get the tiangan title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfTianGan=function(){
	return this.tgString.charAt(this.tiangan);
};

/**
 * Get the dizhi title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfDiZhi=function(){
	return this.dzString.charAt(this.dizhi);
};

/**
 * Get the shengxiao title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfShengXiao=function(){
	return this.sxString.charAt(this.shengxiao);
};

/**
 * Get the year title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfYear=function(){
	return this.getDescOfTianGan()+this.getDescOfDiZhi()+ChinaLunarCalendar.DISPLAY_NIAN;
};

/**
 * Get the month title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfMonth=function(){
    var monthdes="";
	if(this.cMonth<1){
		monthdes+=ChinaLunarCalendar.DISPLAY_RUN;
		monthdes+=this.monString.charAt(-this.cMonth-1);
	}else{
		monthdes+=this.monString.charAt(this.cMonth-1);
	}
	monthdes+=ChinaLunarCalendar.DISPLAY_YUE;
	return monthdes;
};

/**
 * Get the date title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfDate=function(){
    var datedes="";
	datedes+=(this.cDate<11)?ChinaLunarCalendar.DISPLAY_CHU:((this.cDate<20)?ChinaLunarCalendar.DISPLAY_SHI:((this.cDate<30)?ChinaLunarCalendar.DISPLAY_ERSHI:ChinaLunarCalendar.DISPLAY_SANSHI));
	if(this.cDate%10!=0||this.cDate==10){
		datedes+=this.numString.charAt((this.cDate-1)%10);
	}
	return datedes;
};

/**
 * Get the day title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfDay=function(){
	return ChinaLunarCalendar.DISPLAY_XINGQI+this.weekString.charAt(this.cDay);
};

/**
 * Get the hours title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfHours=function(){
	return this.dzString.charAt((this.cHour-1)%12)+ChinaLunarCalendar.DISPLAY_SHI;
};

/**
 * Set the time with date object
 */
ChinaLunarCalendar.prototype.setTime=function(date){
	this.date=date;
	this.convert();
};