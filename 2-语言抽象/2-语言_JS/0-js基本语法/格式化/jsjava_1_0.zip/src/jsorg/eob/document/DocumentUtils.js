/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function DocumentUtils(){
	this.jsjava_class="jsorg.eob.document.DocumentUtils";
}

/**
 * Get elements by classname of HTML tags
 * @param domObj - object in document model
 * @param tagName - HTML tag name
 * @param className - css class name
 */
DocumentUtils.getElementsByClassName=function(domObj,tagName,className){
	var elems=new List();
	var tagElems=domObj.getElementsByTagName(tagName.toUpperCase());
	for(var i=0;i<tagElems.length;i++){
		var tagElem=tagElems[i];
		if(tagElem.className==className){
		    elems.add(tagElem);
		}
	}
	return elems.toArray();
};

/**
 * Get frame sub window object
 * @param winObj - the object of the window where the frame is on
 * @param frameName - the name of the frame
 */
DocumentUtils.getFrameWindowObjectByName=function(winObj,frameName){
    var frameObj=eval("winObj."+frameName);
    return frameObj.window;
};

/**
 * Get frame sub window object
 * @param winObj - the object of the window where the frame is on
 * @param frameId - the id of the frame
 */
DocumentUtils.getFrameWindowObjectById=function(winObj,frameId){
    var frameTagObj=DocumentUtils.getFrameTagObjectById(winObj,frameId);
    return frameTagObj.contentWindow;
};

/**
 * Get frame tag object
 * @param winObj - the object of the window where the frame is on
 * @param frameId - the id of the frame
 */
DocumentUtils.getFrameTagObjectById=function(winObj,frameId){
	return winObj.document.getElementById(frameId);
};

/**
 * Get frame tag object
 * @param winObj - the object of the window where the frame is on
 * @param frameId - the id of the frame
 */
DocumentUtils.getFrameTagObjectByName=function(winObj,frameName){
	var elems=winObj.document.getElementsByName(frameName);
	return elems[0];
};

/**
 * Get the top window of the current window
 */
DocumentUtils.getTopWindowObjectOfCurrent=function(){
	return window.top;
};

/**
 * Get the parent window of the current window
 */
DocumentUtils.getParentWindowObjectOfCurrent=function(){
	return window.parent;
};

/**
 * Get the operner window from where the current window is opened
 */
DocumentUtils.getOpenerWindowObjectOfCurrent=function(){
    return window.opener;
};