/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 */

/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The MathUtils class references to org.apache.commons.math.util.MathUtils */
 
function MathUtils(){
	this.jsjava_class="jsorg.apache.commons.math.util.MathUtils";
}

/**
 * Returns an exact representation of the Binomial Coefficient, "n choose k", the 
 * number of k-element subsets that can be selected from an n-element set.
 * param n
 * param k
 */
MathUtils.binomialCoefficient=function(n,k){
	if (n < k) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"must have n >= k for binomial coefficient (n,k)");
    }
    if (n < 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"must have n >= 0 for binomial coefficient (n,k)");
    }
    if ((n == k) || (k == 0)) {
        return 1;
    }
    if ((k == 1) || (k == n - 1)) {
        return n;
    }
    var result = Math.round(MathUtils.binomialCoefficientDouble(n, k));
    if (result == Long.MAX) {
        throw new ArithmeticException(ArithmeticException.ERROR,"result too large to represent in a long integer");
    }
    return result;
};

/**
 * Returns an double representation of the Binomial Coefficient, "n choose k", the 
 * number of k-element subsets that can be selected from an n-element set.
 * param n
 * param k
 */
MathUtils.binomialCoefficientDouble=function(n,k){
	return Math.floor(Math.exp(MathUtils.binomialCoefficientLog(n, k)) + 0.5);
};

/**
 * Returns the natural log of the Binomial Coefficient, "n choose k", the 
 * number of k-element subsets that can be selected from an n-element set.
 * param n
 * param k
 */
MathUtils.binomialCoefficientLog=function(n,k){
	if (n < k) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"must have n >= k for binomial coefficient (n,k)");
    }
    if (n < 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"must have n >= 0 for binomial coefficient (n,k)");
    }
    if ((n == k) || (k == 0)) {
        return 0;
    }
    if ((k == 1) || (k == n - 1)) {
        return Math.log(n);
    }
    var logSum = 0;

    // n!/k!
    for (var i = k + 1; i <= n; i++) {
        logSum += Math.log(i);
    }

    // divide by (n-k)!
    for (var i = 2; i <= n - k; i++) {
        logSum -= Math.log(i);
    }

    return logSum;
};

/**
 * Returns the hyperbolic cosine of x.
 * param x
 */
MathUtils.cosh=function(x){
	return (Math.exp(x) + Math.exp(-x)) / 2.0;
};

/**
 * Returns n!.
 * param n
 */
MathUtils.factorial=function(n){
	var result = Math.round(MathUtils.factorialDouble(n));
    if (result == Long.MAX) {
        throw new ArithmeticException(ArithmeticException.ERROR,"result too large to represent in a long integer");
    }
    return result;
};

/**
 * Returns n!.
 * param n
 */
MathUtils.factorialDouble=function(n){
	if (n < 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"must have n >= 0 for n!");
    }
    return Math.floor(Math.exp(MathUtils.factorialLog(n)) + 0.5);
};

/**
 * Returns n!.
 * param n
 */
MathUtils.factorialLog=function(n){
	if (n < 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"must have n > 0 for n!");
    }
    var logSum = 0;
    for (var i = 2; i <= n; i++) {
        logSum += Math.log(i);
    }
    return logSum;
};

/**
 * Gets the greatest common divisor of 
 * the absolute value of two numbers, using the "binary gcd" method which avoids division and modulo operations.
 * param u
 * param v
 */
MathUtils.gcd=function(u,v){
	if (u * v == 0) {
        return (Math.abs(u) + Math.abs(v));
    }
    // keep u and v negative, as negative integers range down to
    // -2^31, while positive numbers can only be as large as 2^31-1
    // (i.e. we can't necessarily negate a negative number without
    // overflow)
    /** assert u!=0 && v!=0; */
    if (u > 0) {
        u = -u;
    } // make u negative
    if (v > 0) {
        v = -v;
    } // make v negative
    // B1. [Find power of 2]
    var k = 0;
    while ((u & 1) == 0 && (v & 1) == 0 && k < 31) { // while u and v are
                                                        // both even...
        u /= 2;
        v /= 2;
        k++; // cast out twos.
    }
    if (k == 31) {
        throw new ArithmeticException(ArithmeticException.ERROR,"overflow: gcd is 2^31");
    }
    // B2. Initialize: u and v have been divided by 2^k and at least
    // one is odd.
    var t = ((u & 1) == 1) ? v : -(u / 2)/** B3 */;
    // t negative: u was odd, v may be even (t replaces v)
    // t positive: u was even, v is odd (t replaces u)
    do {
        /** assert u<0 && v<0; */
        // B4/B3: cast out twos from t.
        while ((t & 1) == 0) { // while t is even..
            t /= 2; // cast out twos
        }
        // B5 [reset max(u,v)]
        if (t > 0) {
            u = -t;
        } else {
            v = t;
        }
        // B6/B3. at this point both u and v should be odd.
        t = (v - u) / 2;
        // |u| larger: t positive (replace u)
        // |v| larger: t negative (replace v)
    } while (t != 0);
    return -u * (1 << k); // gcd is u*2^k
};

/**
 * For a value x, this method returns +1 if x >= 0 and -1 if x < 0.
 * param x
 */
MathUtils.indicator=function(x){
	return (x >= 0) ? 1 : -1;
};

/**
 * Returns the least common multiple between two integer values.
 * param a
 * param b
 */
MathUtils.lcm=function(a,b){
 	var x=a/MathUtils.gcd(a,b);
 	var y=b;
	var m =x*y;
	return Math.abs(m);
};

/**
 * Returns the sign for value x.
 * param x
 */
MathUtils.sign=function(x){
	return (x == 0) ? 0 : (x > 0) ? 1 : -1;
};

/**
 * Returns the hyperbolic sine of x.
 * param x
 */
MathUtils.sinh=function(x){
	return (Math.exp(x) - Math.exp(-x)) / 2.0;

};

/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function AreaUtils(){
	this.jsjava_class="jsorg.eob.math.area.AreaUtils";
}

/**
 * Calculate the area of square
 * param a - the side length of the square
 */
AreaUtils.countSquare=function(a){
	if(a<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"side must be equal or larger than zero!");
	}
	return a*a;
};

/**
 * Calculate the area of rectangle
 * param a - the one side length of the rectangle
 * param b - the ajacent side length of the rectangle
 */
AreaUtils.countRectangle=function(a,b){
	if(a<0||b<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}
	return a*a;
};

/**
 * Calculate the area of circle
 * param r - the radius of circle
 */
AreaUtils.countCircle=function(r){
	if(r<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"radius must be equal or larger than zero!");
	}	
	return  Math.PI*r*r;
};

/**
 * Calculate the area of circle
 * param d - the diameter of circle
 */
AreaUtils.countCircle2=function(d){
	if(d<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"diameter must be equal or larger than zero!");
	}	
	return  Math.PI*d*d/4;
};

/**
 * Calculate the area of equilateral triangle
 * param a - the side length
 */
AreaUtils.countEquilateralTriangle=function(a){
	return  AreaUtils.countTriangle(a,a,Math.PI/3);
};

/**
 * Calculate the area of triangle
 * param a - the side length
 * param h - the height of the side
 */
AreaUtils.countTriangle=function(a,h){
	if(a<0||h<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and height must be equal or larger than zero!");
	}	
	return  0.5*a*h;
};

/**
 * Calculate the area of triangle
 * param a - the one side length
 * param b - the other side length
 * param angleC - the angle between the tow sides
 */
AreaUtils.countTriangle2=function(a,b,angleC){
	if(a<0||b<0||angleC<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  0.5*a*b*Math.sin(angleC);
};

/**
 * Calculate the area of triangle
 * param a - the one side length
 * param b - the second side length
 * param c - the third side length
 */
AreaUtils.countTriangle3=function(a,b,c){
	if(a<0||b<0||c<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}	
	var s=(a+b+c)/2;
	return  Math.sqrt(s*(s-a)*(s-b)*(s-c));
};

/**
 * Calculate the area of triangle
 * param a - the one side length
 * param angleA - the angle A
 * param angleB - the angle B
 * param angleC - the angle C
 */
AreaUtils.countTriangle4=function(a,angleA,angleB,angleC){
	if(a<0||angleA<0||angleB<0||angleC<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  a*a*Math.sin(angleB)*Math.sin(angleC)/(2*Math.sin(angleA));
};

/**
 * Calculate the area of trapezia
 * param a - the top side length
 * param b - the bottom side length
 * param h - the height of trapezia
 */
AreaUtils.countTrapezia=function(a,b,h){
	if(a<0||b<0||h<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and height must be equal or larger than zero!");
	}	
	return  0.5*(a+b)*h;
};

/**
 * Calculate the area of trapezia
 * param m - the middle line length
 * param h - the height of trapezia
 */
AreaUtils.countTrapezia2=function(m,h){
	if(m<0||h<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and height must be equal or larger than zero!");
	}	
	return  m*h;
};

/**
 * Calculate the area of quadrangle
 * param d - the length of one diagonal
 * param D - the length of the other diagonal
 * param angleA - the angle between two diagonals
 */
AreaUtils.countQuadrangle=function(d,D,angleA){
	if(d<0||D<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  d*D/2*Math.sin(DegreeTransform.toRadian(angleA));
};

/**
 * Calculate the area of parallelogram
 * param a - the length of one diagonal
 * param h - the length of the other diagonal
 */
AreaUtils.countParallelogram=function(a,h){
	if(a<0||h<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}	
	return  a*h;
};

/**
 * Calculate the area of parallelogram
 * param a - the length of one diagonal
 * param b - the length of the other diagonal
 * param angleA - the angle between two diagonals
 */
AreaUtils.countParallelogram2=function(a,b,angleA){
	if(a<0||b<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  a*b*Math.sin(DegreeTransform.toRadian(angleA));
};

/**
 * Calculate the area of diamond
 * param a - the length of one diagonal
 * param D - the length of the other diagonal
 */
AreaUtils.countDiamond=function(d,D){
	if(d<0||D<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}	
	return  d*D/2;
};

/**
 * Calculate the area of diamond
 * param a - the side length
 * param angleA - the angle of two ajacent side
 */
AreaUtils.countDiamond2=function(a,angleA){
	if(a<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  a*a*Math.sin(DegreeTransform.toRadian(angleA));
};

/**
 * Calculate the area of sector
 * param r - the radius of sector
 * param angleA - the central angle
 */
AreaUtils.countSector=function(r,angleA){
	if(r<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  Math.PI*r*r*angleA/360;
};

/**
 * Calculate the area of arc
 * param r - the radius of arc
 * param angleA - the central angle
 */
AreaUtils.countArc=function(r,angleA){
	if(r<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  r*r/2*(DegreeTransform.toRadian(angleA)-Math.sin(DegreeTransform.toRadian(angleA)));
};

/**
 * Calculate the area of annulus
 * param r - the radius of inner circle
 * param R - the radius of outer circle
 */
AreaUtils.countAnnulus=function(r,R){
	if(r<0||R<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"radius must be equal or larger than zero!");
	}	
	if(r>R){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"R must be equal or larger than r!");
	}
	return  Math.PI*(R*R-r*r);
};

/**
 * Calculate the area of ellipse
 * param d - the length of short axis
 * param D - the length of long axis
 */
AreaUtils.countEllipse=function(d,D){
	if(d<0||D<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}	
	return  Math.PI*D*d/4;
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Gamma class references to org.apache.commons.math.special.Beta */

function Beta(){
	this.jsjava_class="org.apache.commons.math.special.Beta";
}

Beta.DEFAULT_EPSILON = 10e-9;

/**
 * Returns the regularized beta function I(x, a, b).
 * param x - the value
 * param a - the a parameter.
 * param b - the b parameter.
 */
Beta.regularizedBeta=function(x,a,b){
	return Beta.regularizedBeta4(x, a, b, Beta.DEFAULT_EPSILON, Integer.MAX_VALUE);
};

/**
 * Returns the regularized beta function I(x, a, b).
 * param x - the value
 * param a - the a parameter.
 * param b - the b parameter.
 * param epsilon - When the absolute value of the nth item in the series is less than 
 * epsilon the approximation ceases to calculate further elements in the series. 
 */
Beta.regularizedBeta2=function(x,a,b,epsilon){
	return Beta.regularizedBeta4(x, a, b, epsilon, Integer.MAX_VALUE);
};

/**
 * Returns the regularized beta function I(x, a, b).
 * param x - the value
 * param a - the a parameter.
 * param b - the b parameter.
 * param maxIterations - Maximum number of "iterations" to complete.
 */
Beta.regularizedBeta3=function(x,a,b,maxIterations){
	return Beta.regularizedBeta4(x, a, b, Beta.DEFAULT_EPSILON, maxIterations);
};

/**
 * Returns the regularized beta function I(x, a, b).
 * param x - the value
 * param a - the a parameter.
 * param b - the b parameter.
 * param epsilon - When the absolute value of the nth item in the series is less than 
 * epsilon the approximation ceases to calculate further elements in the series.
 * param maxIterations - Maximum number of "iterations" to complete.
 */
Beta.regularizedBeta4=function(x,a,b,epsilon,maxIterations){
	function ContinuedFraction(){
		
	}
	ContinuedFraction.DEFAULT_EPSILON = 10e-9;
	ContinuedFraction.prototype.evaluate=function(x){
		return this.evaluate(x, ContinuedFraction.DEFAULT_EPSILON, Integer.MAX_VALUE);
	};
	ContinuedFraction.prototype.evaluate2=function(x,epsilon){
		return this.evaluate(x, epsilon, Integer.MAX_VALUE);
	};
	ContinuedFraction.prototype.evaluate3=function(x,maxIterations){
		return this.evaluate(x, ContinuedFraction.DEFAULT_EPSILON, maxIterations);
	};
	ContinuedFraction.prototype.evaluate4=function(x,epsilon,maxIterations){
		var p0 = 1.0;
        var p1 = this.getA(0, x);
        var q0 = 0.0;
        var q1 = 1.0;
        var c = p1 / q1;
        var n = 0;
        var relativeError = Double.MAX_VALUE;
        while (n < maxIterations && relativeError > epsilon) {
            ++n;
            var a = this.getA(n, x);
            var b = this.getB(n, x);
            var p2 = a * p1 + b * p0;
            var q2 = a * q1 + b * q0;
            if (Double.isInfinite(p2) || Double.isInfinite(q2)) {
                // need to scale
                if (a != 0.0) {
                    p2 = p1 + (b / a * p0);
                    q2 = q1 + (b / a * q0);
                } else if (b != 0) {
                    p2 = (a / b * p1) + p0;
                    q2 = (a / b * q1) + q0;
                } else {
                    // can not scale an convergent is unbounded.
                    throw new ConvergenceException(ConvergenceException.ERROR,
                        "Continued fraction convergents diverged to +/- " +
                        "infinity.");
                }
            }
            var r = p2 / q2;
            relativeError = Math.abs(r / c - 1.0);
                
            // prepare for next iteration
            c = p2 / q2;
            p0 = p1;
            p1 = p2;
            q0 = q1;
            q1 = q2;
        }

        if (n >= maxIterations) {
            throw new ConvergenceException(ConvergenceException.ERROR,
                "Continued fraction convergents failed to converge.");
        }

        return c;
	};
	ContinuedFraction.prototype.getA=function(n,x){
		return 1.0;
	};
	ContinuedFraction.prototype.getB=function(n,x){
		var ret;
        var m;
        if (n % 2 == 0) { // even
            m = n / 2.0;
            ret = (m * (b - m) * x) /
                ((a + (2 * m) - 1) * (a + (2 * m)));
        } else {
            m = (n - 1.0) / 2.0;
            ret = -((a + m) * (a + b + m) * x) /
                    ((a + (2 * m)) * (a + (2 * m) + 1.0));
        }
        return ret;
	};
	var ret;
    if (Double.isNaN(x) || Double.isNaN(a) || Double.isNaN(b) || (x < 0) ||
        (x > 1) || (a <= 0.0) || (b <= 0.0)) {
        ret = Double.NaN;
    } else if (x > (a + 1.0) / (a + b + 2.0)) {
        ret = 1.0 - Beta.regularizedBeta4(1.0 - x, b, a, epsilon, maxIterations);
    } else {
        var fraction = new ContinuedFraction();
        ret = Math.exp((a * Math.log(x)) + (b * Math.log(1.0 - x)) -
                Math.log(a) - Beta.logBeta2(a, b, epsilon, maxIterations)) *
                1.0 / fraction.evaluate4(x, epsilon, maxIterations);
    }
	return ret;
};

/**
 * Returns the natural logarithm of the beta function B(a, b).
 * param a - the a parameter.
 * param b - the b parameter.
 */
Beta.logBeta=function(a,b){
	return Beta.logBeta2(a, b, Beta.DEFAULT_EPSILON, Integer.MAX_VALUE);
};

/**
 * Returns the natural logarithm of the beta function B(a, b).
 * param a - the a parameter.
 * param b - the b parameter.
 * param epsilon - When the absolute value of the nth item in the series is less 
 * than epsilon the approximation ceases to calculate further elements in the series. 
 * param maxIterations - Maximum number of "iterations" to complete. 
 */
Beta.logBeta2=function(a,b,epsilon,maxIterations){
	var ret;
	if (Double.isNaN(a) || Double.isNaN(b) || (a <= 0.0) || (b <= 0.0)) {
        ret = Double.NaN;
    } else {
        ret = Gamma.logGamma(a) + Gamma.logGamma(b) -
            Gamma.logGamma(a + b);
    }
	
    return ret;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The BinomialDistributionImpl class references to org.apache.commons.math.distribution.BinomialDistributionImpl */

function BinomialDistributionImpl(trials,p){
	this.jsjava_class="org.apache.commons.math.distribution.BinomialDistributionImpl";	
	if (trials < 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"number of trials must be non-negative.");
    }
    this.numberOfTrials = trials;
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"probability of success must be between 0.0 and 1.0, inclusive.");
    }
    this.probabilityOfSuccess = p;
}

/**
 * For this distribution, X, this method returns P(X �� x).
 * param x
 */
BinomialDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
	var sx=new String(x);
	if(sx.indexOf(".")!=-1){
		x=Math.floor(x);
	}
    if (x < 0) {
        ret = 0.0;
    } else if (x >= this.getNumberOfTrials()) {
        ret = 1.0;
    } else {    	
        ret =
            1.0 - Beta.regularizedBeta(
                    this.getProbabilityOfSuccess(),
                    x + 1.0,
                    this.getNumberOfTrials() - x);
    }
    return ret;
};

/**
 * For a random variable X whose values are distributed according
 * to this distribution, this method returns P(x0 &le; X &le; x1).
 * @param x0 the inclusive, lower bound
 * @param x1 the inclusive, upper bound
 */
BinomialDistributionImpl.prototype.cumulativeProbability2=function(x0,x1){
	if (x0 > x1) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"lower endpoint must be less than or equal to upper endpoint");
    }
    return this.cumulativeProbability(x1) - this.cumulativeProbability(x0 - 1);
};

/**
 * Access the domain value lower bound, based on p, used to bracket a PDF root.
 * param d
 */
BinomialDistributionImpl.prototype.getDomainLowerBound=function(d){
	return -1;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a PDF root.
 * param p
 */
BinomialDistributionImpl.prototype.getDomainUpperBound=function(p){
	return this.getNumberOfTrials();
};

/**
 * Access the number of trials for this distribution.
 */
BinomialDistributionImpl.prototype.getNumberOfTrials=function(){
	return this.numberOfTrials;
};

/**
 * Access the probability of success for this distribution.
 */
BinomialDistributionImpl.prototype.getProbabilityOfSuccess=function(){
	return this.probabilityOfSuccess;
};

/**
 * For this distribution, X, this method returns the largest x, such that P(X �� x) �� p.
 * param p
 */
BinomialDistributionImpl.prototype.inverseCumulativeProbability=function(p){
	// handle extreme values explicitly
    if (p == 0) {
        return -1;
    } 
    if (p == 1) {
        return Integer.MAX_VALUE; 
    }
    
    // use default bisection impl
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException(
            "p must be between 0 and 1.0 (inclusive)");
    }
    
    // by default, do simple bisection.
    // subclasses can override if there is a better method.
    var x0 = this.getDomainLowerBound(p);
    var x1 = this.getDomainUpperBound(p);
    var pm;
    while (x0 < x1) {
        var xm = x0 + Math.floor((x1 - x0) / 2);
        pm = this.cumulativeProbability(xm);
        if (pm > p) {
            // update x1
            if (xm == x1) {
                // this can happen with integer division
                // simply decrement x1
                --x1;
            } else {
                // update x1 normally
                x1 = xm;
            }
        } else {
            // update x0
            if (xm == x0) {
                // this can happen with integer division
                // simply increment x0
                ++x0;
            } else {
                // update x0 normally
                x0 = xm;
            }
        }
    }
    
    // insure x0 is the correct critical point
    pm = this.cumulativeProbability(x0);
    while (pm > p) {
    	--x0;
        pm = this.cumulativeProbability(x0);
    }

    return x0;
};

/**
 * For this disbution, X, this method returns P(X = x).
 * param x
 */
BinomialDistributionImpl.prototype.probability=function(x){
	var ret;
    if (x < 0 || x > this.getNumberOfTrials()) {
        ret = 0.0;
    } else {
    	var sx=new String(x);
    	if(sx.indexOf(".")!=-1){
    		var fl = Math.floor(x);
		    if (fl == x) {
		        return this.probability(f1);
		    } else {
		        return 0;
		    }
    	}
        ret = MathUtils.binomialCoefficientDouble(
                this.getNumberOfTrials(), x) *
              Math.pow(this.getProbabilityOfSuccess(), x) *
              Math.pow(1.0 - this.getProbabilityOfSuccess(),
                    this.getNumberOfTrials() - x);
    }
    return ret;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The CauchyDistributionImpl class references to org.apache.commons.math.distribution.CauchyDistributionImpl */

function CauchyDistributionImpl(median, s){
	this.jsjava_class="org.apache.commons.math.distribution.CauchyDistributionImpl";	
	this.median = median;
    if (s <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Scale must be positive.");
    }       
    this.scale = s;
}
/**
 * For this disbution, X, this method returns P(X < x). 
 */
CauchyDistributionImpl.prototype.cumulativeProbability=function(x){
	return 0.5 + (Math.atan((x - this.median) / this.scale) / Math.PI);
};          
          
/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root. 
 */
CauchyDistributionImpl.prototype.getDomainLowerBound=function(p) {
	var ret;

    if (p < .5) {
        ret = -Double.MAX_VALUE;
    } else {
        ret = this.getMedian();
    }
    
    return ret;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.  
 */        
CauchyDistributionImpl.prototype.getDomainUpperBound=function(p) {
	var ret;

    if (p < .5) {
        ret = this.getMedian();
    } else {
        ret = Double.MAX_VALUE;
    }
    
    return ret;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.   
 */        
CauchyDistributionImpl.prototype.getInitialDomain=function(p) {
	var ret;

    if (p < .5) {
        ret = this.getMedian() - this.getScale();
    } else if (p > .5) {
        ret = this.getMedian() + this.getScale();
    } else {
        ret = this.getMedian();
    }
    
    return ret;
};

/**
 * Access the median.
 */       
CauchyDistributionImpl.prototype.getMedian=function() {
	return this.median;
};

/**
 * Access the scale parameter. 
 */          
CauchyDistributionImpl.prototype.getScale=function() {
	return this.scale;
};

/**
 * For this distribution, X, this method returns the critical point x, such that P(X < x) = p. 
 */       
CauchyDistributionImpl.prototype.inverseCumulativeProbability=function(p) {
	var ret;
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"probability argument must be between 0 and 1 (inclusive)");
    } else if (p == 0) {
        ret = Double.NEGATIVE_INFINITY;
    } else  if (p == 1) {
        ret = Double.POSITIVE_INFINITY;
    } else {
        ret = this.median + this.scale * Math.tan(Math.PI * (p - .5));
    }
    return ret;
};

/**
 * Modify the median.
 */          
CauchyDistributionImpl.prototype.setMedian=function(median) {
	this.median = median;
};

/**
 * Modify the scale parameter.
 */           
CauchyDistributionImpl.prototype.setScale=function(s) {
	if (s <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Scale must be positive.");
    }       
    this.scale = s;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The ChiSquaredDistributionImpl class references to org.apache.commons.math.distribution.ChiSquaredDistributionImpl */

function ChiSquaredDistributionImpl(degreesOfFreedom){
	this.jsjava_class="org.apache.commons.math.distribution.ChiSquaredDistributionImpl";	
	this.gamma=	DistributionFactoryImpl.newInstance().createGammaDistribution(
            degreesOfFreedom / 2.0, 2.0);
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
ChiSquaredDistributionImpl.prototype.cumulativeProbability=function(x){
	return this.gamma.cumulativeProbability(x);
};

/**
 * Access the degrees of freedom.
 */
ChiSquaredDistributionImpl.prototype.getDegreesOfFreedom=function(){
	return this.gamma.getAlpha() * 2.0;
};

/**
 * Modify the degrees of freedom.
 * param degreesOfFreedom
 */
ChiSquaredDistributionImpl.prototype.setDegreesOfFreedom=function(degreesOfFreedom){
	this.gamma.setAlpha(this.degreesOfFreedom / 2.0);
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
ChiSquaredDistributionImpl.prototype.getDomainLowerBound=function(p){
	return Double.MIN_VALUE * this.getGamma().getBeta();
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
ChiSquaredDistributionImpl.prototype.getDomainUpperBound=function(p){
	var ret;

    if (p < .5) {
        // use mean
        ret = this.getDegreesOfFreedom();
    } else {
        // use max
        ret = Double.MAX_VALUE;
    }
    
    return ret;
};

/** 
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
ChiSquaredDistributionImpl.prototype.getInitialDomain=function(p){
	var ret;

    if (p < .5) {
        // use 1/2 mean
        ret = this.getDegreesOfFreedom() * .5;
    } else {
        // use mean
        ret = this.getDegreesOfFreedom();
    }
    
    return ret;
};

/**
 * Access the Gamma distribution.
 */
ChiSquaredDistributionImpl.prototype.getGamma=function(){
	return this.gamma;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Complex class references to org.apache.commons.math.complex.Complex */

function Complex(real,imaginary){
	this.jsjava_class="org.apache.commons.math.complex.Complex";
	this.real=real;
	this.imaginary=imaginary;
}

/*** The square root of -1. A number representing "0.0 + 1.0i" */
Complex.I = new Complex(0.0, 1.0);
    
/*** A complex number representing "NaN + NaNi" */
Complex.NaN = new Complex(Double.NaN, Double.NaN);

/*** A complex number representing "1.0 + 0.0i" */    
Complex.ONE = new Complex(1.0, 0.0);

/*** A complex number representing "0.0 + 0.0i" */    
Complex.ZERO = new Complex(0.0, 0.0);

/**
 * Return the absolute value of this complex number.
 */
Complex.prototype.abs=function(){
	if (this.isNaN()) {
        return Double.NaN;
    }
    
    if (this.isInfinite()) {
        return Double.POSITIVE_INFINITY;
    }
    var real=this.real;
    var imaginary=this.imaginary;
    if (Math.abs(real) < Math.abs(imaginary)) {
        if (imaginary == 0.0) {
            return Math.abs(real);
        }
        var q = real / imaginary;
        return (Math.abs(imaginary) * Math.sqrt(1 + q*q));
    } else {
        if (real == 0.0) {
            return Math.abs(imaginary);
        }
        var q = imaginary / real;
        return (Math.abs(real) * Math.sqrt(1 + q*q));
    }
};

/**
 * Return the sum of this complex number and the given complex number.
 * param rsh - the other complex number 
 */
Complex.prototype.add=function(rhs){
	return new Complex(this.real + rhs.getReal(),this.imaginary + rhs.getImaginary());
};

/**
 * the conjugate of this Complex object
 */
Complex.prototype.conjugate=function(){
	if (this.isNaN()) {
        return Complex.NaN;
    }   
    return new Complex(this.real, -this.imaginary);
};

/**
 * Return the quotient of this complex number and the given complex number. 
 * param rhs - the other complex number 
 */
Complex.prototype.divide=function(rhs){
	if (this.isNaN() || rhs.isNaN()) {
        return Complext.NaN;
    }
    var real=this.real;
    var imaginary=this.imaginary;
    var c = rhs.getReal();
    var d = rhs.getImaginary();
    if (c == 0.0 && d == 0.0) {
        return Complex.NaN;
    }
    
    if (rhs.isInfinite() && !this.isInfinite()) {
        return Complex.ZERO;
    }

    if (Math.abs(c) < Math.abs(d)) {
        if (d == 0.0) {
            return new Complex(real/c, imaginary/c);
        }
        var q = c / d;
        var denominator = c * q + d;
        return new Complex((real * q + imaginary) / denominator,(imaginary * q - real) / denominator);
    } else {
        if (c == 0.0) {
            return new Complex(imaginary/d, -real/c);
        }
        var q = d / c;
        var denominator = d * q + c;
        return new Complex((imaginary * q + real) / denominator,(imaginary - real * q) / denominator);
    }
};

/**
 * Test for the equality of two Complex objects.
 * param o
 */
Complex.prototype.equals=function(o){
	if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="org.apache.commons.math.complex.Complex"){
        return this.real==o.real&&this.imaginary==o.imaginary;
    }
    return false;
};

/**
 * Access the imaginary part. 
 */
Complex.prototype.getImaginary=function(){
	return this.imaginary;
};

/**
 * Access the real part. 
 */
Complex.prototype.getReal=function(){
	return this.real;
};

/**
 * Access the real part.
 */
Complex.prototype.isInfinite=function(){
	return !this.isNaN() && (Double.isInfinite(this.real) || Double.isInfinite(this.imaginary));   
};

/**
 * Returns true if either or both parts of this complex number is NaN; false otherwise
 */
Complex.prototype.isNaN=function(){
	return Double.isNaN(this.real) || Double.isNaN(this.imaginary); 
};

/**
 * Return the product of this complex number and the given complex number. 
 * param rhs - the other complex number 
 */
Complex.prototype.multiply=function(rhs){
	if (this.isNaN() || rhs.isNaN()) {
        return Complex.NaN;
    }
    return new Complex(this.real * rhs.real - this.imaginary * rhs.imaginary,
            this.real * rhs.imaginary + this.imaginary * rhs.real);
};

/**
 * Return the additive inverse of this complex number. 
 */
Complex.prototype.negate=function(){
	if (this.isNaN()) {
        return Complex.NaN;
    }    
    return new Complex(-this.real, -this.imaginary);
};

/**
 * Return the difference between this complex number and the given complex number. 
 * param rhs - the other complex number 
 */
Complex.prototype.subtract=function(rhs){
	if (this.isNaN() || rhs.isNaN()) {
        return Complex.NaN;
    }
    
    return new Complex(this.real - rhs.getReal(),
        this.imaginary - rhs.getImaginary());
};

/**
 * return a string description
 */
Complex.prototype.toString=function(){
	var str=this.real;
	if(this.imaginary>=0){
		str+="+";
	}
	str+=this.imaginary+"i";
	return str;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Complex class references to org.apache.commons.math.complex.ComplexUtils */

function ComplexUtils(){
	this.jsjava_class="org.apache.commons.math.complex.ComplexUtils";
}

/**
 * Compute the inverse cosine for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.acos=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }

    return Complex.I.negate().multiply(ComplexUtils.log(z.add(
        Complex.I.multiply(ComplexUtils.sqrt1z(z))))); 
};

/**
 * Compute the inverse sine for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.asin=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }

    return Complex.I.negate().multiply(ComplexUtils.log(ComplexUtils.sqrt1z(z).add(
        Complex.I.multiply(z))));
};

/**
 * Compute the inverse tangent for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.atan=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    return Complex.I.multiply(
        ComplexUtils.log(Complex.I.add(z).divide(Complex.I.subtract(z))))
        .divide(new Complex(2.0, 0.0));
};

/**
 * Compute the cosine for the given complex argument.
 * param z - a complex number 
 */
ComplexUtils.cos=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var a = z.getReal();
    var b = z.getImaginary();
    
    return new Complex(Math.cos(a) * MathUtils.cosh(b),
        -Math.sin(a) * MathUtils.sinh(b));
};

/**
 * Compute the hyperbolic cosine for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.cosh=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var a = z.getReal();
    var b = z.getImaginary();
    
    return new Complex(MathUtils.cosh(a) * Math.cos(b),
        MathUtils.sinh(a) * Math.sin(b));
};

/**
 * Compute the exponential function for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.exp=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var b = z.getImaginary();
    var expA = Math.exp(z.getReal());
    return new Complex(expA *  Math.cos(b), expA * Math.sin(b));
};

/**
 * Compute the natural logarithm for the given complex argument. 
 * param z - a complex number
 */
ComplexUtils.log=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }

    return new Complex(Math.log(z.abs()),
        Math.atan2(z.getImaginary(), z.getReal())); 
};

/**
 * Creates a complex number from the given polar representation.
 * param r - the modulus of the complex number to create
 * param theta - the argument of the complex number to create
 */
ComplexUtils.polar2Complex=function(r,theta){
	if (r < 0) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"Complex modulus must not be negative");
    }
    return new Complex(r * Math.cos(theta), r * Math.sin(theta));
};

/**
 * Returns of value of y raised to the power of x.
 * param y - a complex number
 * param x - a complex number
 */
ComplexUtils.pow=function(y,x){
	return ComplexUtils.exp(x.multiply(ComplexUtils.log(y)));
};

/**
 * Compute the sine for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.sin=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var a = z.getReal();
    var b = z.getImaginary();
    
    return new Complex(Math.sin(a) * MathUtils.cosh(b),
        Math.cos(a) * MathUtils.sinh(b));
};

/**
 * Compute the hyperbolic sine for the given complex argument.
 * param z - a complex number 
 */
ComplexUtils.sinh=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var a = z.getReal();
    var b = z.getImaginary();
    
    return new Complex(MathUtils.sinh(a) * Math.cos(b),
        MathUtils.cosh(a) * Math.sin(b));
};

/**
 * Compute the square root for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.sqrt=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var a = z.getReal();
    var b = z.getImaginary();
    
    var t = Math.sqrt((Math.abs(a) + z.abs()) / 2.0);
    if (a >= 0.0) {
        return new Complex(t, b / (2.0 * t));
    } else {
        return new Complex(Math.abs(b) / (2.0 * t),
            MathUtils.indicator(b) * t);
    }
};

/**
 * Compute the square root of 1 - z2 for the given complex argument.
 * param z - a complex number 
 */
ComplexUtils.sqrt1z=function(z){
	return ComplexUtils.sqrt(Complex.ONE.subtract(z.multiply(z)));
};

/**
 * Compute the tangent for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.tan=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var a2 = 2.0 * z.getReal();
    var b2 = 2.0 * z.getImaginary();
    var d = Math.cos(a2) + MathUtils.cosh(b2);
    
    return new Complex(Math.sin(a2) / d, MathUtils.sinh(b2) / d);
};

/**
 * Compute the hyperbolic tangent for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.tanh=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var a2 = 2.0 * z.getReal();
    var b2 = 2.0 * z.getImaginary();
    var d = MathUtils.cosh(a2) + Math.cos(b2);
    
    return new Complex(MathUtils.sinh(a2) / d, Math.sin(b2) / d);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The ConvergenceException class references to org.apache.commons.math.ConvergenceException */

ConvergenceException.prototype=new Error();
ConvergenceException.prototype.constructor=ConvergenceException;

ConvergenceException.ERROR=0;

/**
 * param code - error code
 * param message - error message
 */
function ConvergenceException(code,message){
	this.jsjava_class="org.apache.commons.math.ConvergenceException";
	this.code=code;
    this.message=message;
    this.name="org.apache.commons.math.ConvergenceException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function DegreeTransform(){
	this.jsjava_class="jsorg.eob.math.transform.DegreeTransform";
}

/**
 * Get the degree of the given radian
 * param radian
 */
DegreeTransform.toDegree=function(radian){
	if(isNaN(radian)){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"radian must be a number!");
	}
	return 180*radian/Math.PI;
};

/**
 * Get the radian of the given degree
 * param degree
 */
DegreeTransform.toRadian=function(degree){
	if(isNaN(degree)){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"degree must be a number!");
	}
	return Math.PI*degree/180;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The DistributionFactoryImpl class references to org.apache.commons.math.distribution.DistributionFactoryImpl */

function DistributionFactoryImpl(){
	this.jsjava_class="org.apache.commons.math.distribution.DistributionFactoryImpl";	
}

DistributionFactoryImpl.newInstance=function(){
	return new DistributionFactoryImpl();
};

/**
 * Create a binomial distribution with the given number of trials and probability of success.
 * param numberOfTrials
 * param probabilityOfSuccess
 */
DistributionFactoryImpl.prototype.createBinomialDistribution=function(numberOfTrials,probabilityOfSuccess){
	return new BinomialDistributionImpl(numberOfTrials,
            probabilityOfSuccess);
};

/**
 * Create a new chi-square distribution with the given degrees of freedom.
 * param degreesOfFreedom
 */
DistributionFactoryImpl.prototype.createChiSquareDistribution=function(degreesOfFreedom){
	return new ChiSquaredDistributionImpl(degreesOfFreedom);
};

/**
 * Create a new exponential distribution with the given degrees of freedom.
 * param mean
 */
DistributionFactoryImpl.prototype.createExponentialDistribution=function(mean){
	return new ExponentialDistributionImpl(mean);
};

/**
 * Create a new F-distribution with the given degrees of freedom.
 * param numeratorDegreesOfFreedom
 * param denominatorDegreesOfFreedom
 */
DistributionFactoryImpl.prototype.createFDistribution=function(numeratorDegreesOfFreedom,denominatorDegreesOfFreedom){
	return new FDistributionImpl(numeratorDegreesOfFreedom,
            denominatorDegreesOfFreedom);
};

/**
 * 
 * param
 * param
 */
DistributionFactoryImpl.prototype.createGammaDistribution=function(alpha,beta){
	return new GammaDistributionImpl(alpha, beta);
};

/**
 * Create a new gamma distribution the given shape and scale parameters.
 * param populationSize
 * param numberOfSuccesses
 * param sampleSize
 */
DistributionFactoryImpl.prototype.createHypergeometricDistribution=function(populationSize,numberOfSuccesses,sampleSize){
	return new HypergeometricDistributionImpl(populationSize,
            numberOfSuccesses, sampleSize);
};

/**
 * Create a new normal distribution with the given mean and standard deviation.
 * param mean
 * param sd
 */
DistributionFactoryImpl.prototype.createNormalDistribution=function(mean,sd){
	return new NormalDistributionImpl(mean, sd);
};

/**
 * Create a new Poisson distribution with poisson parameter lambda.
 * param lambda
 */
DistributionFactoryImpl.prototype.createPoissonDistribution=function(lambda){
	return new PoissonDistributionImpl(lambda);
};

/**
 * Create a new t distribution with the given degrees of freedom.
 * param degreesOfFreedom
 */
DistributionFactoryImpl.prototype.createTDistribution=function(degreesOfFreedom){
	return new TDistributionImpl(degreesOfFreedom);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Gamma class references to org.apache.commons.math.special.Beta */

function Erf(){
	this.jsjava_class="org.apache.commons.math.special.Erf";
}

/**
 * Returns the error function erf(x).
 * param x - the value.
 */
Erf.erf=function(x){
	var ret = Gamma.regularizedGammaP2(0.5, x * x, 1.0e-15, 10000);
    if (x < 0) {
        ret = -ret;
    }
    return ret;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The ExponentialDistributionImpl class references to org.apache.commons.math.distribution.ExponentialDistributionImpl */

function ExponentialDistributionImpl(mean){
	this.jsjava_class="org.apache.commons.math.distribution.ExponentialDistributionImpl";	
	if (mean <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"mean must be positive.");
    }
    this.mean = mean;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
ExponentialDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    if (x <= 0.0) {
        ret = 0.0;
    } else {
        ret = 1.0 - Math.exp(-x / this.getMean());
    }
    return ret;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
ExponentialDistributionImpl.prototype.getDomainLowerBound=function(p){
	return 0;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
ExponentialDistributionImpl.prototype.getDomainUpperBound=function(p){
	// NOTE: exponential is skewed to the left
    // NOTE: therefore, P(X < &mu;) > .5

    if (p < .5) {
        // use mean
        return this.getMean();
    } else {
        // use max
        return Double.MAX_VALUE;
    }
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
ExponentialDistributionImpl.prototype.getInitialDomain=function(p){
	// Exponential is skewed to the left, therefore, P(X < &mu;) > .5
    if (p < .5) {
        // use 1/2 mean
        return this.getMean() * .5;
    } else {
        // use mean
        return this.getMean();
    }
};

/**
 * Access the mean.
 */
ExponentialDistributionImpl.prototype.getMean=function(){
	return this.mean;
};

/**
 * For this distribution, X, this method returns the critical point x, such that P(X < x) = p.
 * param p
 */
ExponentialDistributionImpl.prototype.inverseCumulativeProbability=function(p){
	var ret;
        
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"probability argument must be between 0 and 1 (inclusive)");
    } else if (p == 1.0) {
        ret = Double.POSITIVE_INFINITY;
    } else {
        ret = -this.getMean() * Math.log(1.0 - p);
    }
    
    return ret;
};

/**
 * Modify the mean.
 * param mean
 */
ExponentialDistributionImpl.prototype.setMean=function(mean){
	if (mean <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"mean must be positive.");
    }
    this.mean = mean;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The FDistributionImpl class references to org.apache.commons.math.distribution.FDistributionImpl */

function FDistributionImpl(numeratorDegreesOfFreedom,denominatorDegreesOfFreedom){
	this.jsjava_class="org.apache.commons.math.distribution.FDistributionImpl";
	if (numeratorDegreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.numeratorDegreesOfFreedom = numeratorDegreesOfFreedom;	
    if (denominatorDegreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.denominatorDegreesOfFreedom = denominatorDegreesOfFreedom;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
FDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    if (x <= 0.0) {
        ret = 0.0;
    } else {
        var n = this.getNumeratorDegreesOfFreedom();
        var m = this.getDenominatorDegreesOfFreedom();
        
        ret = Beta.regularizedBeta((n * x) / (m + n * x),
            0.5 * n,
            0.5 * m);
    }
    return ret;
};

/**
 * Access the denominator degrees of freedom.
 */
FDistributionImpl.prototype.getDenominatorDegreesOfFreedom=function(){
	return this.denominatorDegreesOfFreedom;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
FDistributionImpl.prototype.getDomainLowerBound=function(p){
	return 0.0;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
FDistributionImpl.prototype.getDomainUpperBound=function(p){
	return Double.MAX_VALUE;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
FDistributionImpl.prototype.getInitialDomain=function(p){
	return this.getDenominatorDegreesOfFreedom() /
            (this.getDenominatorDegreesOfFreedom() - 2.0);
};

/**
 * Access the numerator degrees of freedom.
 */
FDistributionImpl.prototype.getNumeratorDegreesOfFreedom=function(){
	return this.numeratorDegreesOfFreedom;
};

/**
 * Modify the denominator degrees of freedom.
 * param degreesOfFreedom
 */
FDistributionImpl.prototype.setDenominatorDegreesOfFreedom=function(degreesOfFreedom){
	if (degreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.denominatorDegreesOfFreedom = degreesOfFreedom;
};

/**
 * Modify the numerator degrees of freedom.
 * param degreesOfFreedom
 */
FDistributionImpl.prototype.setNumeratorDegreesOfFreedom=function(degreesOfFreedom){
	if (degreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.numeratorDegreesOfFreedom = degreesOfFreedom;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Fraction class references to org.apache.commons.math.fraction.Fraction */

/**
 * Create a fraction given the numerator and denominator.
 * param num
 * param den
 */
function Fraction(num,den){
	this.jsjava_class="org.apache.commons.math.fraction.Fraction";
	if (den == 0) {
        throw new ArithmeticException(ArithmeticException.ERROR,"The denominator must not be zero");
    }
    if (den < 0) {
        if (num == Integer.MIN_VALUE ||
                den == Integer.MIN_VALUE) {
            throw new ArithmeticException(ArithmeticException.ERROR,"overflow: can't negate");
        }
        num = -num;
        den = -den;
    }
    this.numerator = num;
    this.denominator = den;
    var d = MathUtils.gcd(this.numerator, this.denominator);
    if (d > 1) {
        this.numerator /= d;
        this.denominator /= d;
    }
    // move sign to numerator.
    if (this.denominator < 0) {
        this.numerator *= -1;
        this.denominator *= -1;
    }
}

Fraction.ONE = new Fraction(1, 1);
Fraction.ZERO = new Fraction(0, 1);

/**
 * Returns the absolute value of this fraction.
 */
Fraction.prototype.abs=function(){
	var ret;
    if (this.numerator >= 0) {
        ret = this;
    } else {
        ret = this.negate();
    }
    return ret;
};

/**
 * Compares this object to another based on size.
 * param o
 */
Fraction.prototype.compareTo=function(o){
	if(!o||!o.jsjava_class||o.jsjava_class!="org.apache.commons.math.fraction.Fraction"){
		return -1;
	}
	var ret = 0;   
    var first = this.doubleValue();
    var second = o.doubleValue();    
    if (first < second) {
        ret = -1;
    } else if (first > second) {
        ret = 1;
    }
    return ret;
};

/**
 * Gets the fraction as a double.
 */
Fraction.prototype.doubleValue=function(){
	return this.numerator / this.denominator;
};

/**
 * Test for the equality of two fractions.
 * param o
 */
Fraction.prototype.equals=function(o){
	if(!o||!o.jsjava_class||o.jsjava_class!="org.apache.commons.math.fraction.Fraction"){
		return false;
	}
	if(this.numerator==o.numerator&&this.denominator==o.denominator){
		return true;
	}
	return false;
};

/** 
 * Gets the fraction as a float.
 */
Fraction.prototype.floatValue=function(){
	return this.doubleValue();
};

/**
 * Access the denominator.
 */
Fraction.prototype.getDenominator=function(){
	return this.denominator;
};

/**
 * Access the numerator.
 */
Fraction.prototype.getNumerator=function(){
	return this.numerator;
};

/**
 * Gets the fraction as an int.
 */
Fraction.prototype.intValue=function(){
	return Math.round(this.doubleValue());
};

/**
 * Gets the fraction as a long.
 */
Fraction.prototype.longValue=function(){
	return Math.round(this.doubleValue());
};

/**
 * Return the additive inverse of this fraction.
 */
Fraction.prototype.negate=function(){
	if (this.numerator==Integer.MIN_VALUE) {
        throw new ArithmeticException(ArithmeticException.ERROR,"overflow: too large to negate");
    }
    return new Fraction(-this.numerator, this.denominator);
};

/**
 * Return the multiplicative inverse of this fraction.
 */
Fraction.prototype.reciprocal=function(){
	return new Fraction(this.denominator, this.numerator);
};

/**
 * Adds the value of this fraction to another, returning the result in reduced form.
 * param fraction
 */
Fraction.prototype.add=function(fraction){
	return this.addSub(fraction, true);
};

/**
 * Subtracts the value of another fraction from the value of this one, returning the result in reduced form.
 * param fraction
 */
Fraction.prototype.subtract=function(fraction){
	return this.addSub(fraction, false);
};

/**
 * Implement add and subtract using algorithm described in Knuth 4.5.1.
 * param fraction
 * param isAdd
 */
Fraction.prototype.addSub=function(fraction,isAdd){
	if (fraction == null) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"The fraction must not be null");
    }
    // zero is identity for addition.
    if (this.numerator == 0) {
        return isAdd ? fraction : fraction.negate();
    }
    if (fraction.numerator == 0) {
        return this;
    }     
    // if denominators are randomly distributed, d1 will be 1 about 61%
    // of the time.
    var d1 = MathUtils.gcd(this.denominator, fraction.denominator);
    if (d1==1) {
        // result is ( (u*v' +/- u'v) / u'v')
        var uvp = this.numerator*fraction.denominator;
        var upv = fraction.numerator*this.denominator;
        return new Fraction
            (isAdd ? (uvp+upv) : (uvp-upv),this.denominator*fraction.denominator);
    }
    // the quantity 't' requires 65 bits of precision; see knuth 4.5.1
    // exercise 7.  we're going to use a BigInteger.
    // t = u(v'/d1) +/- v(u'/d1)
    var uvp = this.numerator*fraction.denominator/d1;
    var upv = fraction.numerator*this.denominator/d1;
    var t = isAdd ? (uvp+upv) : (uvp-upv);
    // but d2 doesn't need extra precision because
    // d2 = gcd(t,d1) = gcd(t mod d1, d1)
    var tmodd1 = t%d1;
    var d2 = (tmodd1==0)?d1:MathUtils.gcd(tmodd1, d1);

    // result is (t/d2) / (u'/d1)(v'/d2)
    var w = t/d2;
    return new Fraction (w, this.denominator/d1*fraction.denominator/d2);
};

/**
 * Multiplies the value of this fraction by another, returning the result in reduced form.
 * param fraction
 */
Fraction.prototype.multiply=function(fraction){
	if (fraction == null) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"The fraction must not be null");
    }
    if (this.numerator == 0 || fraction.numerator == 0) {
        return Fraction.ZERO;
    }
    // knuth 4.5.1
    // make sure we don't overflow unless the result *must* overflow.
    var d1 = MathUtils.gcd(this.numerator, fraction.denominator);
    var d2 = MathUtils.gcd(fraction.numerator, this.denominator);
    return Fraction.getReducedFraction
    (this.numerator/d1*fraction.numerator/d2,
            this.denominator/d2*fraction.denominator/d1);
};

/**
 * Divide the value of this fraction by another.
 * param divide
 */
Fraction.prototype.divide=function(fraction){
	if (fraction==undefined||fraction == null) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"The fraction must not be null");
    }
    if (fraction.numerator == 0) {
        throw new ArithmeticException(IllegalArgumentException.ERROR,"The fraction to divide by must not be zero");
    }
    return this.multiply(fraction.reciprocal());
};

/**
 * Creates a Fraction instance with the 2 parts of a fraction Y/Z.
 * param numerator
 * param denominator
 */
Fraction.getReducedFraction=function(numerator,denominator){
	if (denominator == 0) {
        throw new ArithmeticException(ArithmeticException.ERROR,"The denominator must not be zero");
    }
    if (numerator==0) {
        return Fraction.ZERO; // normalize zero.
    }
    // allow 2^k/-2^31 as a valid fraction (where k>0)
    if (denominator==Integer.MIN_VALUE && (numerator&1)==0) {
        numerator/=2; denominator/=2;
    }
    if (denominator < 0) {
        if (numerator==Integer.MIN_VALUE ||
                denominator==Integer.MIN_VALUE) {
            throw new ArithmeticException(ArithmeticException.ERROR,"overflow: can't negate");
        }
        numerator = -numerator;
        denominator = -denominator;
    }
    // simplify fraction.
    var gcd = MathUtils.gcd(numerator, denominator);
    numerator /= gcd;
    denominator /= gcd;
    return new Fraction(numerator, denominator);
};

/**
 * return a string description
 */
Fraction.prototype.toString=function(){
	return this.numerator+"/"+this.denominator;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The FunctionEvaluationException class references to org.apache.commons.math.FunctionEvaluationException */

FunctionEvaluationException.prototype=new Error();
FunctionEvaluationException.prototype.constructor=FunctionEvaluationException;

FunctionEvaluationException.ERROR=0;

/**
 * param code - error code
 * param message - error message
 */
function FunctionEvaluationException(code,message){
	this.jsjava_class="org.apache.commons.math.FunctionEvaluationException";
	this.code=code;
    this.message=message;
    this.name="org.apache.commons.math.FunctionEvaluationException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Gamma class references to org.apache.commons.math.special.Gamma */

function Gamma(){
	this.jsjava_class="org.apache.commons.math.special.Erf";
}

Gamma.DEFAULT_EPSILON = 10e-9;

Gamma.lanczos =
    [
        0.99999999999999709182,
        57.156235665862923517,
        -59.597960355475491248,
        14.136097974741747174,
        -0.49191381609762019978,
        .33994649984811888699e-4,
        .46523628927048575665e-4,
        -.98374475304879564677e-4,
        .15808870322491248884e-3,
        -.21026444172410488319e-3,
        .21743961811521264320e-3,
        -.16431810653676389022e-3,
        .84418223983852743293e-4,
        -.26190838401581408670e-4,
        .36899182659531622704e-5
    ];
    
Gamma.HALF_LOG_2_PI = 0.5 * Math.log(2.0 * Math.PI);

/**
 * Returns the natural logarithm of the gamma function ��(x).
 * param x - the value.
 */
Gamma.logGamma=function(x){
	var ret;
    if (Double.isNaN(x) || (x <= 0.0)) {
        ret = Double.NaN;
    } else {
        var g = 607.0 / 128.0;        
        var sum = 0.0;
        for (var i = Gamma.lanczos.length - 1; i > 0; --i) {
        	sum = sum + (Gamma.lanczos[i] / (x + i));
        }
        sum = sum + Gamma.lanczos[0];
        var tmp = x + g + .5;
        ret = ((x + .5) * Math.log(tmp)) - tmp +
            Gamma.HALF_LOG_2_PI + Math.log(sum / x);
            
    }

    return ret;Gamma.js
};

/**
 * Returns the regularized gamma function P(a, x).
 * param a - the a parameter.
 * param x - the value.
 */
Gamma.regularizedGammaP=function(a,x){
	return Gamma.regularizedGammaP2(a, x, Gamma.DEFAULT_EPSILON, Integer.MAX_VALUE);
};

/**
 * Returns the regularized gamma function P(a, x).
 * param a - the a parameter.
 * param x - the value.
 * param epsilon - When the absolute value of the nth item in the series is less 
 * than epsilon the approximation ceases to calculate further elements in the series. 
 * param maxIterations - Maximum number of "iterations" to complete.
 */
Gamma.regularizedGammaP2=function(a,x,epsilon,maxIterations){
	var ret;
    if (Double.isNaN(a) || Double.isNaN(x) || (a <= 0.0) || (x < 0.0)) {
        ret = Double.NaN;
    } else if (x == 0.0) {
        ret = 0.0;
    } else if (a >= 1.0 && x > a) {
        // use regularizedGammaQ because it should converge faster in this
        // case.
        ret = 1.0 - Gamma.regularizedGammaQ2(a, x, epsilon, maxIterations);
    } else {
        // calculate series
        var n = 0.0; // current element index
        var an = 1.0 / a; // n-th element in the series
        var sum = an; // partial sum
        while (Math.abs(an) > epsilon && n < maxIterations) {
            // compute next element in the series
            n = n + 1.0;
            an = an * (x / (a + n));

            // update partial sum
            sum = sum + an;
        }
        if (n >= maxIterations) {
            throw new ConvergenceException(ConvergenceException.ERROR,
                "maximum number of iterations reached");
        } else {
            ret = Math.exp(-x + (a * Math.log(x)) - Gamma.logGamma(a)) * sum;
        }
    }

    return ret;
};

/**
 * Returns the regularized gamma function Q(a, x) = 1 - P(a, x).
 * param a - the a parameter.
 * param x - the value.
 */
Gamma.regularizedGammaQ=function(a,x){
	return Gamma.regularizedGammaQ2(a, x, Gamma.DEFAULT_EPSILON, Integer.MAX_VALUE);
};

/**
 * Returns the regularized gamma function Q(a, x) = 1 - P(a, x).
 * param a - the a parameter.
 * param x - the value.
 * param epsilon - When the absolute value of the nth item in the series is less than 
 * epsilon the approximation ceases to calculate further elements in the series.
 * param maxIterations - Maximum number of "iterations" to complete. 
 */
Gamma.regularizedGammaQ2=function(a,x,epsilon,maxIterations){
	function ContinuedFraction(){
		
	}
	ContinuedFraction.DEFAULT_EPSILON = 10e-9;
	ContinuedFraction.prototype.evaluate=function(x){
		return this.evaluate(x, ContinuedFraction.DEFAULT_EPSILON, Integer.MAX_VALUE);
	};
	ContinuedFraction.prototype.evaluate2=function(x,epsilon){
		return this.evaluate(x, epsilon, Integer.MAX_VALUE);
	};
	ContinuedFraction.prototype.evaluate3=function(x,maxIterations){
		return this.evaluate(x, ContinuedFraction.DEFAULT_EPSILON, maxIterations);
	};
	ContinuedFraction.prototype.evaluate4=function(x,epsilon,maxIterations){
		var p0 = 1.0;
        var p1 = this.getA(0, x);
        var q0 = 0.0;
        var q1 = 1.0;
        var c = p1 / q1;
        var n = 0;
        var relativeError = Double.MAX_VALUE;
        while (n < maxIterations && relativeError > epsilon) {
            ++n;
            var a = this.getA(n, x);
            var b = this.getB(n, x);
            var p2 = a * p1 + b * p0;
            var q2 = a * q1 + b * q0;
            if (Double.isInfinite(p2) || Double.isInfinite(q2)) {
                // need to scale
                if (a != 0.0) {
                    p2 = p1 + (b / a * p0);
                    q2 = q1 + (b / a * q0);
                } else if (b != 0) {
                    p2 = (a / b * p1) + p0;
                    q2 = (a / b * q1) + q0;
                } else {
                    // can not scale an convergent is unbounded.
                    throw new ConvergenceException(ConvergenceException.ERROR,
                        "Continued fraction convergents diverged to +/- " +
                        "infinity.");
                }
            }
            var r = p2 / q2;
            relativeError = Math.abs(r / c - 1.0);
                
            // prepare for next iteration
            c = p2 / q2;
            p0 = p1;
            p1 = p2;
            q0 = q1;
            q1 = q2;
        }

        if (n >= maxIterations) {
            throw new ConvergenceException(ConvergenceException.ERROR,
                "Continued fraction convergents failed to converge.");
        }

        return c;
	};
	ContinuedFraction.prototype.getA=function(n,x){
		return ((2.0 * n) + 1.0) - a + x;
	};
	ContinuedFraction.prototype.getB=function(n,x){
		return n * (a - n);
	};
	var ret;
    if (Double.isNaN(a) || Double.isNaN(x) || (a <= 0.0) || (x < 0.0)) {
        ret = Double.NaN;
    } else if (x == 0.0) {
        ret = 1.0;
    } else if (x < a || a < 1.0) {
        // use regularizedGammaP because it should converge faster in this
        // case.
        ret = 1.0 - Gamma.regularizedGammaP2(a, x, epsilon, maxIterations);
    } else {
        // create continued fraction
        var cf = new ContinuedFraction();        
        ret = 1.0 / cf.evaluate4(x, epsilon, maxIterations);
        ret = Math.exp(-x + (a * Math.log(x)) - Gamma.logGamma(a)) * ret;
    }    
    return ret;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The GammaDistributionImpl class references to org.apache.commons.math.distribution.GammaDistributionImpl */

function GammaDistributionImpl(alpha,beta){
	this.jsjava_class="org.apache.commons.math.distribution.GammaDistributionImpl";		
	if (alpha <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"alpha must be positive");
    }
    this.alpha = alpha;
    if (beta <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"beta must be positive");
    }
    this.beta = beta;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
GammaDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    
    if (x <= 0.0) {
        ret = 0.0;
    } else {
        ret = Gamma.regularizedGammaP(this.getAlpha(), x / this.getBeta());
    }

    return ret;
};

/**
 * Access the shape parameter, alpha
 */
GammaDistributionImpl.prototype.getAlpha=function(){
	return this.alpha;
};

/**
 * Access the scale parameter, beta
 */
GammaDistributionImpl.prototype.getBeta=function(){
	return this.beta;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
GammaDistributionImpl.prototype.getDomainLowerBound=function(p){
	return Double.MIN_VALUE;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
GammaDistributionImpl.prototype.getDomainUpperBound=function(p){
	var ret;

    if (p < .5) {
        // use mean
        ret = this.getAlpha() * this.getBeta();
    } else {
        // use max value
        ret = Double.MAX_VALUE;
    }
    
    return ret;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
GammaDistributionImpl.prototype.getInitialDomain=function(p){
	var ret;

    if (p < .5) {
        // use 1/2 mean
        ret = this.getAlpha() * this.getBeta() * .5;
    } else {
        // use mean
        ret = this.getAlpha() * this.getBeta();
    }
    
    return ret;
};

/**
 * Modify the shape parameter, alpha.
 * param alpha
 */
GammaDistributionImpl.prototype.setAlpha=function(alpha){
	if (alpha <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"alpha must be positive");
    }
    this.alpha = alpha;
};

/**
 * Modify the scale parameter, beta.
 * param beta
 */
GammaDistributionImpl.prototype.setBeta=function(beta){
	if (beta <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"beta must be positive");
    }
    this.beta = beta;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The HypergeometricDistributionImpl class references to org.apache.commons.math.distribution.HypergeometricDistributionImpl */

function HypergeometricDistributionImpl(populationSize,numberOfSuccesses,sampleSize){
	this.jsjava_class="org.apache.commons.math.distribution.HypergeometricDistributionImpl";	
	if (numberOfSuccesses > populationSize) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"number of successes must be less than or equal to " +
            "population size");
    }
    if (sampleSize > populationSize) {
        throw new IllegalArgumentException(
        IllegalArgumentException.ERROR,"sample size must be less than or equal to population size");
    }
    if(populationSize <= 0){
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"population size must be positive.");
    }
    this.populationSize = populationSize;
    if (sampleSize < 0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"sample size must be non-negative.");
    }    
    this.sampleSize = sampleSize;
    if(numberOfSuccesses < 0){
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"number of successes must be non-negative.");
    }
    this.numberOfSuccesses = numberOfSuccesses;
}

/**
 * For this disbution, X, this method returns P(X �� x).
 * param x
 */
HypergeometricDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    var sx=new String(x);
	if(sx.indexOf(".")!=-1){
		x=Math.floor(x);
	}    
    var n = this.getPopulationSize();
    var m = this.getNumberOfSuccesses();
    var k = this.getSampleSize();

    var domain = this.getDomain(n, m, k);
    if (x < domain[0]) {
        ret = 0.0;
    } else if(x >= domain[1]) {
        ret = 1.0;
    } else {
        ret = this.innerCumulativeProbability(domain[0], x, 1, n, m, k);
    }
    
    return ret;
};

/**
 * Return the domain for the given hypergeometric distribution parameters.
 * param n
 * param m
 * param k
 */
HypergeometricDistributionImpl.prototype.getDomain=function(n,m,k){
	var arr=new Array(2);
	arr[0]=this.getLowerDomain(n, m, k);
	arr[1]=this.getUpperDomain(m, k);
	return arr;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a PDF root.
 * param p
 */
HypergeometricDistributionImpl.prototype.getDomainLowerBound=function(p){
	return this.getLowerDomain(this.getPopulationSize(), this.getNumberOfSuccesses(),
            this.getSampleSize());
};

/**
 * Access the domain value upper bound, based on p, used to bracket a PDF root.
 * param p
 */
HypergeometricDistributionImpl.prototype.getDomainUpperBound=function(p){
	return this.getUpperDomain(this.getSampleSize(), this.getNumberOfSuccesses());
};

/**
 * Return the lowest domain value for the given hypergeometric distribution parameters.
 * param n
 * param m
 * param k
 */
HypergeometricDistributionImpl.prototype.getLowerDomain=function(n,m,k){
	return Math.max(0, m - (n - k));
};

/**
 * Access the number of successes.
 */
HypergeometricDistributionImpl.prototype.getNumberOfSuccesses=function(){
	return this.numberOfSuccesses;
};

/**
 * Access the population size.
 */
HypergeometricDistributionImpl.prototype.getPopulationSize=function(){
	return this.populationSize;
};

/**
 * Access the sample size.
 */
HypergeometricDistributionImpl.prototype.getSampleSize=function(){
	return this.sampleSize;
};

/**
 * Return the highest domain value for the given hypergeometric distribution parameters.
 * param m
 * param k
 */
HypergeometricDistributionImpl.prototype.getUpperDomain=function(m,k){
	return Math.min(k, m);
};

/**
 * For this disbution, X, this method returns P(X = x).
 * param x
 */
HypergeometricDistributionImpl.prototype.probability=function(x){
	var ret;       
    var n = this.getPopulationSize();
    var m = this.getNumberOfSuccesses();
    var k = this.getSampleSize();
	var domain = this.getDomain(n, m, k);
    if(x < domain[0] || x > domain[1]){
        ret = 0.0;
    } else {
        ret = this.probability2(n, m, k, x);
    }
    
    return ret;
};

/**
 * For the disbution, X, defined by the given hypergeometric distribution
 * parameters, this method returns P(X = x).
 * param n
 * param m
 * param k
 * param x
 */
HypergeometricDistributionImpl.prototype.probability2=function(n, m, k, x){
	return Math.exp(MathUtils.binomialCoefficientLog(m, x) +
            MathUtils.binomialCoefficientLog(n - m, k - x) -
            MathUtils.binomialCoefficientLog(n, k));
};

/**
 * Modify the number of successes.
 * param num
 */
HypergeometricDistributionImpl.prototype.setNumberOfSuccesses=function(num){
	if(num < 0){
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"number of successes must be non-negative.");
    }
    this.numberOfSuccesses = num;
};

/**
 * Modify the population size.
 * param size
 */
HypergeometricDistributionImpl.prototype.setPopulationSize=function(size){
	if(size <= 0){
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"population size must be positive.");
    }
    this.populationSize = size;
};

/**
 * Modify the sample size.
 * param size
 */
HypergeometricDistributionImpl.prototype.setSampleSize=function(size){
	if (size < 0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"sample size must be non-negative.");
    }    
    this.sampleSize = size;
};

/**
 * For this disbution, X, this method returns P(X �� x).
 * param x
 */
HypergeometricDistributionImpl.prototype.upperCumulativeProbability=function(x){
	var ret;
    var sx=new String(x);
	if(sx.indexOf(".")!=-1){
		x=Math.floor(x);
	}     
    var n = this.getPopulationSize();
    var m = this.getNumberOfSuccesses();
    var k = this.getSampleSize();

    var domain = this.getDomain(n, m, k);
    if (x < domain[0]) {
        ret = 1.0;
    } else if(x > domain[1]) {
        ret = 0.0;
    } else {
        ret = this.innerCumulativeProbability(domain[1], x, -1, n, m, k);
    }
    
    return ret;
};

/**
 * For this disbution, X, this method returns P(X �� x).
 * param x
 */
HypergeometricDistributionImpl.prototype.innerCumulativeProbability=function(
	x0, x1, dx, n, m, k){
	var ret = this.probability2(n, m, k, x0);
    while (x0 != x1) {
        x0 += dx;
        ret += this.probability2(n, m, k, x0);
    }
    return ret;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The MatrixIndexException class references to org.apache.commons.math.linear.InvalidMatrixException */

InvalidMatrixException.prototype=new Error();
InvalidMatrixException.prototype.constructor=InvalidMatrixException;

InvalidMatrixException.ERROR=0;

/**
 * constructor
 * param msg
 */
function InvalidMatrixException(code,message){
	this.jsjava_class="org.apache.commons.math.linear.InvalidMatrixException";
	this.code=code;
    this.message=message;
    this.name="org.apache.commons.math.linear.InvalidMatrixException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The MathException class references to org.apache.commons.math.MathException */

MathException.prototype=new Error();
MathException.prototype.constructor=MathException;

MathException.ERROR=0;

/**
 * param code - error code
 * param message - error message
 */
function MathException(code,message){
	this.jsjava_class="org.apache.commons.math.MathException";
	this.code=code;
    this.message=message;
    this.name="org.apache.commons.math.MathException";

}

/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The MatrixIndexException class references to org.apache.commons.math.linear.MatrixIndexException */

MatrixIndexException.prototype=new Error();
MatrixIndexException.prototype.constructor=MatrixIndexException;

MatrixIndexException.ERROR=0;

/**
 * constructor
 * param msg
 */
function MatrixIndexException(code,message){
	this.jsjava_class="org.apache.commons.math.linear.MatrixIndexException";
	this.code=code;
    this.message=message;
    this.name="org.apache.commons.math.linear.MatrixIndexException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The MatrixUtils class references to org.apache.commons.math.linear.MatrixUtils */
 
function MatrixUtils(){
	this.jsjava_class="jsorg.apache.commons.math.linear.MatrixUtils";
}

MatrixUtils.createRowRealMatrix=function(rowData){
	var nCols = rowData.length;
    var data=new Array(1);
    for(var i=0;i<1;i++){
    	data[i]=new Array(nCols);
    }
    for(var j=0;j<nCols;j++){
    	data[0][j]=rowData[j];
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(data);
};

MatrixUtils.createColumnRealMatrix=function(columnData){
	var nRows = columnData.length;
    var data=new Array(nRows);
    for(var i=0;i<nRows;i++){
    	data[i]=new Array(1);
    }
    for (var row = 0; row < nRows; row++) {
        data[row][0] = columnData[row];
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(data);
};


MatrixUtils.createRealIdentityMatrix=function(dimension){
	var out = new RealMatrixImpl(dimension, dimension);
    var d = out.getDataRef();
    for (var row = 0; row < dimension; row++) {
        for (var col = 0; col < dimension; col++) {
            d[row][col] = row == col ? 1 : 0;
        }
    }
    return out;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The NormalDistributionImpl class references to org.apache.commons.math.distribution.NormalDistributionImpl */

function NormalDistributionImpl(mean,sd){
	this.jsjava_class="org.apache.commons.math.distribution.NormalDistributionImpl";	
	this.mean = mean;
    if (sd <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Standard deviation must be positive.");
    }       
    this.standardDeviation = sd;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
NormalDistributionImpl.prototype.cumulativeProbability=function(x){
	return 0.5 * (1.0 + Erf.erf((x - this.mean) /
            (this.standardDeviation * Math.sqrt(2.0))));
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
NormalDistributionImpl.prototype.getDomainLowerBound=function(p){
	var ret;

    if (p < .5) {
        ret = -Double.MAX_VALUE;
    } else {
        ret = this.getMean();
    }
    
    return ret;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
NormalDistributionImpl.prototype.getDomainUpperBound=function(p){
	var ret;

    if (p < .5) {
        ret = this.getMean();
    } else {
        ret = Double.MAX_VALUE;
    }
    
    return ret;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
NormalDistributionImpl.prototype.getInitialDomain=function(p){
	var ret;

    if (p < .5) {
        ret = this.getMean() - this.getStandardDeviation();
    } else if (p > .5) {
        ret = this.getMean() + this.getStandardDeviation();
    } else {
        ret = this.getMean();
    }
    
    return ret;
};

/**
 * Access the mean.
 */
NormalDistributionImpl.prototype.getMean=function(){
	return this.mean;
};

/**
 * Access the standard deviation.
 */
NormalDistributionImpl.prototype.getStandardDeviation=function(){
	return this.standardDeviation;
};

/**
 * Modify the mean.
 * param mean
 */
NormalDistributionImpl.prototype.setMean=function(mean){
	this.mean = mean;
};

/**
 * Modify the standard deviation.
 * param sd
 */
NormalDistributionImpl.prototype.setStandardDeviation=function(sd){
	if (sd <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Standard deviation must be positive.");
    }       
    this.standardDeviation = sd;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The PoissonDistributionImpl class references to org.apache.commons.math.distribution.PoissonDistributionImpl */

function PoissonDistributionImpl(p){
	this.jsjava_class="org.apache.commons.math.distribution.PoissonDistributionImpl";	
	if (p <= 0) {
        throw new IllegalArgumentException(
                IllegalArgumentException.ERROR,"The Poisson mean must be positive");
    }
    this.mean = p;
}

/**
 * The probability distribution function P(X <= x) for a Poisson distribution.
 * param x
 */
PoissonDistributionImpl.prototype.cumulativeProbability=function(x){
	if (x < 0) {
        return 0;
    }
    if (x == Integer.MAX_VALUE) {
        return 1;
    }
    var sx=new String(x);
	if(sx.indexOf(".")!=-1){
		x=Math.floor(x);
	}
    return Gamma.regularizedGammaQ2(x + 1, this.mean, 
            1E-12, Integer.MAX_VALUE);
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
PoissonDistributionImpl.prototype.getDomainLowerBound=function(p){
	return 0;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
PoissonDistributionImpl.prototype.getDomainUpperBound=function(p){
	return Integer.MAX_VALUE;
};

/**
 * Get the Poisson mean for the distribution.
 */
PoissonDistributionImpl.prototype.getMean=function(){
	return this.mean;
};

/**
 * Calculates the Poisson distribution function using a normal approximation.
 * param x
 */
PoissonDistributionImpl.prototype.normalApproximateProbability=function(x){
	var normal = DistributionFactoryImpl.newInstance()
            .createNormalDistribution(this.getMean(),
                    Math.sqrt(this.getMean()));

    // calculate the probability using half-correction
    return normal.cumulativeProbability(x + 0.5);
};

/**
 * The probability mass function P(X = x) for a Poisson distribution.
 * param x
 */
PoissonDistributionImpl.prototype.probability=function(x){
	if (x < 0 || x == Integer.MAX_VALUE) {
        return 0;
    }
    return Math.pow(this.getMean(), x) / 
        MathUtils.factorialDouble(x) * Math.exp(-this.mean);
};

/**
 * Set the Poisson mean for the distribution.
 * param p
 */
PoissonDistributionImpl.prototype.setMean=function(p){
	if (p <= 0) {
        throw new IllegalArgumentException(
                IllegalArgumentException.ERROR,"The Poisson mean must be positive");
    }
    this.mean = p;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The PolynomialFunction class references to org.apache.commons.math.analysis.PolynomialFunction */
 
function PolynomialFunction(arr){
	this.jsjava_class="jsorg.apache.commons.math.analysis.PolynomialFunction";
	if (arr.length < 1) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Polynomial coefficient array must have postive length.");
    }
    this.coefficients = new Array(arr.length);
    for(var i=0;i<arr.length;i++){
    	this.coefficients[i]=arr[i];
    }
}

/**
 * Returns the degree of the polynomial
 */
PolynomialFunction.prototype.degree=function(){
	return this.coefficients.length - 1;
};

/**
 * Returns the derivative as a UnivariateRealFunction
 */
PolynomialFunction.prototype.derivative=function(){
	return this.polynomialDerivative();
};

/**
 * Returns a copy of the coefficients array.
 */
PolynomialFunction.prototype.getCoefficients=function(){
	var out = new Array(this.coefficients.length);
	for(var i=0;i<this.coefficients.length;i++){
    	out[i]=this.coefficients[i];
    }
    return out;
};

/**
 * Returns the derivative as a PolynomialRealFunction
 */
PolynomialFunction.prototype.polynomialDerivative=function(){
	return new PolynomialFunction(PolynomialFunction.differentiate(this.coefficients));
};

/**
 * Compute the value of the function for the given argument.
 */
PolynomialFunction.prototype.value=function(x){
	return PolynomialFunction.evaluate(this.coefficients, x);
};

/**
 * Returns the coefficients of the derivative of the polynomial with the given coefficients.
 * 
 * @param coefficients  the coefficients of the polynomial to differentiate
 * @return the coefficients of the derivative or null if coefficients has length 1.
 * @throws IllegalArgumentException if coefficients is empty
 * @throws NullPointerException if coefficients is null
 */
PolynomialFunction.differentiate=function(coefficients){
	var n = coefficients.length;
    if (n < 1) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Coefficient array must have positive length for differentiation");
    }
    if (n == 1) {
        return [0];
    }
    var result = new Array(n - 1);
    for (var i = n - 1; i  > 0; i--) {
        result[i - 1] = i * coefficients[i];
    }
    return result;
};

/**
 * Uses Horner's Method to evaluate the polynomial with the given coefficients at
 * the argument.
 * 
 * @param coefficients  the coefficients of the polynomial to evaluate
 * @param argument  the input value
 * @return  the value of the polynomial 
 * @throws IllegalArgumentException if coefficients is empty
 * @throws NullPointerException if coefficients is null
 */
PolynomialFunction.evaluate=function(coefficients,argument){
	var n = coefficients.length;
    if (n < 1) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Coefficient array must have positive length for evaluation");
    }
    var result = coefficients[n - 1];
    for (var j = n -2; j >=0; j--) {
        result = argument * result + coefficients[j];
    }
    return result;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The PolynomialSplineFunction class references to org.apache.commons.math.analysis.PolynomialSplineFunction */
 
/**
 * Construct a polynomial spline function with the given segment delimiters
 * and interpolating polynomials.
 * <p>
 * The constructor copies both arrays and assigns the copies to the knots
 * and polynomials properties, respectively.
 * 
 * @param knots spline segment interval delimiters
 * @param polynomials polynomial functions that make up the spline
 * @throws NullPointerException if either of the input arrays is null
 * @throws IllegalArgumentException if knots has length less than 2,  
 * <code>polynomials.length != knots.length - 1 </code>, or the knots array
 * is not strictly increasing.
 * 
 */
function PolynomialSplineFunction(knots,polynomials){
	this.jsjava_class="jsorg.apache.commons.math.analysis.PolynomialSplineFunction";
	if (knots.length < 2) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"Not enough knot values -- spline partition must have at least 2 points.");
    }
    if (knots.length - 1 != polynomials.length) {
        throw new IllegalArgumentException 
        (IllegalArgumentException.ERROR,"Number of polynomial interpolants must match the number of segments.");
    }
    if (!PolynomialSplineFunction.isStrictlyIncreasing(knots)) {
        throw new IllegalArgumentException 
            (IllegalArgumentException.ERROR,"Knot values must be strictly increasing.");
    }
    
    this.n = knots.length -1;
    this.knots = new Array(this.n + 1);
    for(var i=0;i<knots.length;i++){
    	this.knots[i]=knots[i];
    }
    this.polynomials = new Array(this.n);
    for(var i=0;i<polynomials.length;i++){
    	this.polynomials[i]=polynomials[i];
    }
}

/**
 * Returns the derivative of the polynomial spline function as a UnivariateRealFunction
 */
PolynomialSplineFunction.prototype.derivative=function(){
	return this.polynomialSplineDerivative();
};

/**
 * Returns an array copy of the knot points.
 */
PolynomialSplineFunction.prototype.getKnots=function(){
	var out = new Array(this.n + 1);
    for(var i=0;i<out.length;i++){
    	out[i]=this.knots[i];
    }
    return out;
};

/**
 *  Returns a copy of the interpolating polynomials array.
 */
PolynomialSplineFunction.prototype.getPolynomials=function(){
	var p = new Array(this.n);
    for(var i=0;i<p.length;i++){
    	p[i]=this.polynomials[i];
    }
    return p;
};

/**
 * Returns the derivative of the polynomial spline function as a PolynomialSplineFunction
 */
PolynomialSplineFunction.prototype.polynomialSplineDerivative=function(){
	var derivativePolynomials = new Array(this.n);
    for (var i = 0; i < this.n; i++) {
        derivativePolynomials[i] = this.polynomials[i].polynomialDerivative();
    }
    return new PolynomialSplineFunction(this.knots, derivativePolynomials);
};

/**
 * Compute the value for the function.
 */
PolynomialSplineFunction.prototype.value=function(v){
	if (v < this.knots[0] || v > this.knots[this.n]) {
        throw new FunctionEvaluationException(FunctionEvaluationException.ERROR,"Argument outside domain");
    }
    var i=-1;
    for(var m=0;m<this.knots.length;m++){
    	if(v==this.knots[m]){
    		i=m;
    		break;
    	}
    }
    if (i < 0) {
        i = -i - 2;
    }
    //This will handle the case where v is the last knot value
    //There are only n-1 polynomials, so if v is the last knot
    //then we will use the last polynomial to calculate the value.
    if ( i >= this.polynomials.length ) {
        i--;
    }
    return this.polynomials[i].value(v - this.knots[i]);
};

/**
 * Determines if the given array is ordered in a strictly increasing
 * fashion.
 * 
 * @param x the array to examine.
 * @return <code>true</code> if the elements in <code>x</code> are ordered
 * in a stricly increasing manner.  <code>false</code>, otherwise.
 */
PolynomialSplineFunction.isStrictlyIncreasing=function(arr) {
    for (var i = 1; i < arr.length; ++i) {
        if (arr[i - 1] >= arr[i]) {
            return false;
        }
    }
    return true;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The RealMatrixImpl class references to org.apache.commons.math.linear.RealMatrixImpl */

function RealMatrixImpl(rowDimension,columnDimension){
	this.jsjava_class="org.apache.commons.math.linear.RealMatrixImpl";
	if(rowDimension==undefined||columnDimension==undefined){
	
	}else{
		if (rowDimension <= 0 || columnDimension <= 0) {
		    throw new IllegalArgumentException(
		            IllegalArgumentException.ERROR,"row and column dimensions must be postive");
		}
		this.data = new Array(rowDimension);
		for(var i=0;i<rowDimension;i++){
			this.data[i]=new Array(columnDimension);
		}
		this.lu = null;
    }
    this.parity=1;
}

RealMatrixImpl.TOO_SMALL= 10E-12;

RealMatrixImpl.CreateBlankRealMatrixImpl=function(){
	return new RealMatrixImpl();
};

RealMatrixImpl.CreateRealMatrixImplByFullArray=function(d){
	var row=0;
	var column=0;
	if ((row < 0) || (column < 0)){
        throw new MatrixIndexException
            (MatrixIndexException.ERROR,"invalid row or column index selection");          
    }
    var subMatrix=d;
    var nRows = subMatrix.length;
    if (nRows == 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,
        "Matrix must have at least one row."); 
    }
    var nCols = subMatrix[0].length;
    if (nCols == 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,
        "Matrix must have at least one column."); 
    }    
    var matrix=new RealMatrixImpl(nRows,nCols);
    for (var r = 1; r < nRows; r++) {
        if (subMatrix[r].length != nCols) {
            throw new IllegalArgumentException(IllegalArgumentException.ERROR,
            "All input rows must have the same length.");
        }
    }        
    if ((row > 0)||(column > 0)) {
    	throw new MatrixIndexException(MatrixIndexException.ERROR,"matrix must be initialized to perfom this method");
    }
    matrix.data = new Array(nRows);
    for(var i=0;i<nRows;i++){
		matrix.data[i]=new Array(nCols);
	}
    for(var i=0;i<nRows;i++){
    	for(var j=0;j<nCols;j++){
    		matrix.data[i][j]=subMatrix[i][j];
    	}
    }     
    if (((nRows + row) > matrix.getRowDimension()) ||(nCols + column > matrix.getColumnDimension())){
        throw new MatrixIndexException(MatrixIndexException.ERROR,"invalid row or column index selection");  
    }                 
    for (var i = 0; i < nRows; i++) {
        for(var j=0;j<nCols;j++){
        	matrix.data[row + i][j]=subMatrix[i][j];
        }
    } 
    matrix.lu = null;
    return matrix;
};

RealMatrixImpl.prototype.copy=function(){
	return RealMatrixImpl.CreateRealMatrixImplByFullArray(this.copyOut());
};

RealMatrixImpl.prototype.add=function(m){
	if (this.getColumnDimension() != m.getColumnDimension() ||
            this.getRowDimension() != m.getRowDimension()) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"matrix dimension mismatch");
    }
    var rowCount = this.getRowDimension();
    var columnCount = this.getColumnDimension();
    var outData = new Array(rowCount);
    for(var i=0;i<rowCount;i++){
    	outData[i]=new Array(columnCount);
    }
    for (var row = 0; row < rowCount; row++) {
        for (var col = 0; col < columnCount; col++) {
            outData[row][col] = this.data[row][col] + m.getEntry(row, col);
        }  
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(outData);
};

RealMatrixImpl.prototype.subtract=function(m){
	if (this.getColumnDimension() != m.getColumnDimension() ||
            this.getRowDimension() != m.getRowDimension()) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"matrix dimension mismatch");
    }
    var rowCount = this.getRowDimension();
    var columnCount = this.getColumnDimension();
    var outData = new Array(rowCount);
    for(var i=0;i<rowCount;i++){
    	outData[i]=new Array(columnCount);
    }
    for (var row = 0; row < rowCount; row++) {
        for (var col = 0; col < columnCount; col++) {
            outData[row][col] = this.data[row][col] - m.getEntry(row, col);
        }
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(outData);
};

RealMatrixImpl.prototype.scalarAdd=function(d){
	var rowCount = this.getRowDimension();
    var columnCount = this.getColumnDimension();
    var outData = new Array(rowCount);
    for(var i=0;i<rowCount;i++){
    	outData[i]=new Array(columnCount);
    }
    for (var row = 0; row < rowCount; row++) {
        for (var col = 0; col < columnCount; col++) {
            outData[row][col] = this.data[row][col] + d;
        }
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(outData);
};

RealMatrixImpl.prototype.scalarMultiply=function(d){
	var rowCount = this.getRowDimension();
    var columnCount = this.getColumnDimension();
    var outData = new Array(rowCount);
    for(var i=0;i<rowCount;i++){
    	outData[i]=new Array(columnCount);
    }
    for (var row = 0; row < rowCount; row++) {
        for (var col = 0; col < columnCount; col++) {
            outData[row][col] = this.data[row][col] * d;
        }
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(outData);
};

RealMatrixImpl.prototype.multiply=function(m){
	if (this.getColumnDimension() != m.getRowDimension()) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Matrices are not multiplication compatible.");
    }
    var nRows = this.getRowDimension();
    var nCols = m.getColumnDimension();
    var nSum = this.getColumnDimension();
    var outData = new Array(nRows);
    for(var i=0;i<nRows;i++){
    	outData[i]=new Array(nCols);
    }
    var sum = 0;
    for (var row = 0; row < nRows; row++) {
        for (var col = 0; col < nCols; col++) {
            sum = 0;
            for (var i = 0; i < nSum; i++) {
                sum += this.data[row][i] * m.getEntry(i, col);
            }
            outData[row][col] = sum;
        }
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(outData);
};

RealMatrixImpl.prototype.preMultiply=function(m){
	return m.multiply(this);
};

RealMatrixImpl.prototype.getData=function(){
	return this.copyOut();
};

RealMatrixImpl.prototype.getDataRef=function(){
	return this.data;
};

RealMatrixImpl.prototype.getNorm=function(){
	var maxColSum = 0;
    for (var col = 0; col < this.getColumnDimension(); col++) {
        var sum = 0;
        for (var row = 0; row < this.getRowDimension(); row++) {
            sum += Math.abs(this.data[row][col]);
        }
        maxColSum = Math.max(maxColSum, sum);
    }
    return maxColSum;
};

RealMatrixImpl.prototype.getSubMatrix=function(startRow,endRow,startColumn,endColumn){
	if (startRow < 0 || startRow > endRow || endRow > this.data.length ||
         startColumn < 0 || startColumn > endColumn ||
         endColumn > this.data[0].length ) {
        throw new MatrixIndexException(MatrixIndexException.ERROR,
                "invalid row or column index selection");
    }
    var subMatrix = new RealMatrixImpl(endRow - startRow+1,
            endColumn - startColumn+1);
    var subMatrixData = subMatrix.getDataRef();
    for (var i = startRow; i <= endRow; i++) {
        for (var j = startColumn; j <= endColumn; j++) {
                subMatrixData[i - startRow][j - startColumn] = this.data[i][j];
            }
        }
    return subMatrix;
};

RealMatrixImpl.prototype.getSubMatrix2=function(selectedRows,selectedColumns){
	if (selectedRows.length * selectedColumns.length == 0) {
        throw new MatrixIndexException(MatrixIndexException.ERROR,
                "selected row and column index arrays must be non-empty");
    }
    var subMatrix = new RealMatrixImpl(selectedRows.length,
            selectedColumns.length);
    var subMatrixData = subMatrix.getDataRef();
    try  {
        for (var i = 0; i < selectedRows.length; i++) {
            for (var j = 0; j < selectedColumns.length; j++) {
                subMatrixData[i][j] = this.data[selectedRows[i]][selectedColumns[j]];
            }
        }
    } catch (e) {
        throw new MatrixIndexException(MatrixIndexException.ERROR,"matrix dimension mismatch");
    }
    return subMatrix;
};

RealMatrixImpl.prototype.setSubMatrix=function(subMatrix,row,column){
	if ((row < 0) || (column < 0)){
        throw new MatrixIndexException
            (MatrixIndexException.ERROR,"invalid row or column index selection");          
    }
    var nRows = subMatrix.length;
    if (nRows == 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,
        "Matrix must have at least one row."); 
    }
    var nCols = subMatrix[0].length;
    if (nCols == 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,
        "Matrix must have at least one column."); 
    }
    for (var r = 1; r < nRows; r++) {
        if (subMatrix[r].length != nCols) {
            throw new IllegalArgumentException(IllegalArgumentException.ERROR,
            "All input rows must have the same length.");
        }
    }       
    if (this.data == null) {
        if ((row > 0)||(column > 0)) throw new MatrixIndexException
            (MatrixIndexException.ERROR,"matrix must be initialized to perfom this method");
        this.data = new Array(nRows);		    
		for(var i=0;i<nRows;i++){
			outData[i]=new Array(nCols);
		}
        var values=subMatrix.getData();
        for (var i = 0; i < nRows; i++) {
		    for (var j = 0; j < nCols; j++) {
		        this.data[i][j]=values[i][j];
		    }
		}   
    }   
    if (((nRows + row) > this.getRowDimension()) ||
        (nCols + column > this.getColumnDimension()))
        throw new MatrixIndexException(MatrixIndexException.ERROR,
                "invalid row or column index selection");                   
    for (var i = 0; i < nRows; i++) {
        for(var j=0;j<nCols;j++){
        	this.data[row + i][j]=subMatrix[i][j];
        }
    } 
    this.lu = null;
};

RealMatrixImpl.prototype.getRowMatrix=function(row){
	if ( !this.isValidCoordinate( row, 0)) {
        throw new MatrixIndexException(MatrixIndexException.ERROR,"illegal row argument");
    }
    var ncols = this.getColumnDimension();
    var out=new Array(row);
    for(var i=0;i<row;i++){
    	out[i]=new Array(1);
    }
    for(var j=0;j<ncols;j++){
    	out[0][j]=this.data[row][j];
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(out);
};

RealMatrixImpl.prototype.getColumnMatrix=function(column){
	if ( !this.isValidCoordinate( 0, column)) {
        throw new MatrixIndexException("illegal column argument");
    }
    var nRows = this.getRowDimension();
    var out=new Array(nRows);
    for(var i=0;i<nRows;i++){
    	out[i]=new Array(1);
    }
    for (var i = 0; i < nRows; i++) {
        out[i][0] = this.data[i][column];
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(out);
};

RealMatrixImpl.prototype.getRow=function(row){
	if ( !this.isValidCoordinate( row, 0 ) ) {
        throw new MatrixIndexException(MatrixIndexException.ERROR,"illegal row argument");
    }
    var ncols = this.getColumnDimension();
    var out = new Array(ncols);
    for(var j=0;j<ncols;j++){
    	out[j]=this.data[row][j];
    }
    return out;
};

RealMatrixImpl.prototype.getColumn=function(col){
	if ( !this.isValidCoordinate(0, col) ) {
        throw new MatrixIndexException(MatrixIndexException.ERROR,"illegal column argument");
    }
    var nRows = this.getRowDimension();
    var out = new Array(nRows);
    for (var i = 0; i < nRows; i++) {
        out[i] = this.data[i][col];
    }
    return out;
};

RealMatrixImpl.prototype.getEntry=function(row,column){
	if (!this.isValidCoordinate(row,column)) {
        throw new MatrixIndexException(MatrixIndexException.ERROR,"matrix entry does not exist");
    }
    return this.data[row][column];
};

RealMatrixImpl.prototype.transpose=function(){
	var nRows = this.getRowDimension();
    var nCols = this.getColumnDimension();
    var out = new RealMatrixImpl(nCols, nRows);
    var outData = out.getDataRef();
    for (var row = 0; row < nRows; row++) {
        for (var col = 0; col < nCols; col++) {
            outData[col][row] = this.data[row][col];
        }
    }
    return out;
};

RealMatrixImpl.prototype.inverse=function(){
	return this.solveMatrix(MatrixUtils.createRealIdentityMatrix
            (this.getRowDimension()));
};

RealMatrixImpl.prototype.getDeterminant=function(){
	if (!this.isSquare()) {
        throw new InvalidMatrixException(InvalidMatrixException.ERROR,"matrix is not square");
    }
    if (this.isSingular()) {   // note: this has side effect of attempting LU decomp if lu == null
        return 0;
    } else {
        var det = this.parity;
        for (var i = 0; i < this.getRowDimension(); i++) {
            det *= this.lu[i][i];
        }
        return det;
    }
};

RealMatrixImpl.prototype.isSquare=function(){
	return (this.getColumnDimension() == this.getRowDimension());
};

RealMatrixImpl.prototype.isSingular=function(){
	if (this.lu == undefined||this.lu==null) {
        try {
            this.luDecompose();
            return false;
        } catch (ex) {
            return true;
        }
    } else { // LU decomp must have been successfully performed
        return false; // so the matrix is not singular
    }
};

RealMatrixImpl.prototype.getRowDimension=function(){
	return this.data.length;
};

RealMatrixImpl.prototype.getColumnDimension=function(){
	return this.data[0].length;
};

RealMatrixImpl.prototype.getTrace=function(){
	if (!this.isSquare()) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"matrix is not square");
    }
    var trace = this.data[0][0];
    for (var i = 1; i < this.getRowDimension(); i++) {
        trace += this.data[i][i];
    }
    return trace;
};

RealMatrixImpl.prototype.operate=function(v){
	if (v.length != this.getColumnDimension()) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"vector has wrong length");
    }
    var nRows = this.getRowDimension();
    var nCols = this.getColumnDimension();
    var out = new Array(v.length);
    for (var row = 0; row < nRows; row++) {
        var sum = 0;
        for (var i = 0; i < nCols; i++) {
            sum += this.data[row][i] * v[i];
        }
        out[row] = sum;
    }
    return out;
};

RealMatrixImpl.prototype.preMultiplyArray=function(v){
	var nRows = this.getRowDimension();
    if (v.length != nRows) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"vector has wrong length");
    }
    var nCols = this.getColumnDimension();
    var out = new Array(nCols);
    for (var col = 0; col < nCols; col++) {
        var sum = 0;
        for (var i = 0; i < nRows; i++) {
            sum += this.data[i][col] * v[i];
        }
        out[col] = sum;
    }
    return out;
};

RealMatrixImpl.prototype.solve=function(b){	
	var nRows = this.getRowDimension();
	if (b.length != nRows) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"constant vector has wrong length");
    }
    var bMatrix = RealMatrixImpl.CreateRealMatrixImplByFullArray(b);
    var solution =  this.solveMatrix(bMatrix).getDataRef();
    var out = new Array(nRows);
    for (var row = 0; row < nRows; row++) {
        out[row] = solution[row][0];
    }
    return out;
};

RealMatrixImpl.prototype.solveMatrix=function(b){
	if (b.getRowDimension() != this.getRowDimension()) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Incorrect row dimension");
    }
    if (!this.isSquare()) {
        throw new InvalidMatrixException(InvalidMatrixException.ERROR,"coefficient matrix is not square");
    }
    if (this.isSingular()) { // side effect: compute LU decomp
        throw new InvalidMatrixException(InvalidMatrixException.ERROR,"Matrix is singular.");
    }

    var nCol = this.getColumnDimension();
    var nColB = b.getColumnDimension();
    var nRowB = b.getRowDimension();

    // Apply permutations to b
    var bp=new Array(nRowB);
    for(var i=0;i<nRowB;i++){
    	bp[i]=new Array(nColB);
    }
    for (var row = 0; row < nRowB; row++) {
        for (var col = 0; col < nColB; col++) {
            bp[row][col] = b.getEntry(this.permutation[row], col);
        }
    }

    // Solve LY = b
    for (var col = 0; col < nCol; col++) {
        for (var i = col + 1; i < nCol; i++) {
            for (var j = 0; j < nColB; j++) {
                bp[i][j] -= bp[col][j] * this.lu[i][col];
            }
        }
    }

    // Solve UX = Y
    for (var col = nCol - 1; col >= 0; col--) {
        for (var j = 0; j < nColB; j++) {
            bp[col][j] /= this.lu[col][col];
        }
        for (var i = 0; i < col; i++) {
            for (var j = 0; j < nColB; j++) {
                bp[i][j] -= bp[col][j] * this.lu[i][col];
            }
        }
    }

    var outMat = RealMatrixImpl.CreateRealMatrixImplByFullArray(bp);
    return outMat;
};

RealMatrixImpl.prototype.luDecompose=function(){
	var nRows = this.getRowDimension();
    var nCols = this.getColumnDimension();
    if (nRows != nCols) {
        throw new InvalidMatrixException(InvalidMatrixException.ERROR,"LU decomposition requires that the matrix be square.");
    }
    this.lu = this.getData();

    // Initialize permutation array and parity
    this.permutation = new Array(nRows);
    for (var row = 0; row < nRows; row++) {
        this.permutation[row] = row;
    }
    this.parity = 1;

    // Loop over columns
    for (var col = 0; col < nCols; col++) {

        var sum = 0;

        // upper
        for (var row = 0; row < col; row++) {
            sum = this.lu[row][col];
            for (var i = 0; i < row; i++) {
                sum -= this.lu[row][i] * this.lu[i][col];
            }
            this.lu[row][col] = sum;
        }

        // lower
        var max = col; // permutation row
        var largest = 0;
        for (var row = col; row < nRows; row++) {
            sum = this.lu[row][col];
            for (var i = 0; i < col; i++) {
                sum -= this.lu[row][i] * this.lu[i][col];
            }
            this.lu[row][col] = sum;

            // maintain best permutation choice
            if (Math.abs(sum) > largest) {
                largest = Math.abs(sum);
                max = row;
            }
        }

        // Singularity check
        if (Math.abs(this.lu[max][col]) < RealMatrixImpl.TOO_SMALL) {
            this.lu = null;
            throw new InvalidMatrixException(InvalidMatrixException.ERROR,"matrix is singular");
        }

        // Pivot if necessary
        if (max != col) {
            var tmp = 0;
            for (var i = 0; i < nCols; i++) {
                tmp = this.lu[max][i];
                this.lu[max][i] = this.lu[col][i];
                this.lu[col][i] = tmp;
            }
            var temp = this.permutation[max];
            this.permutation[max] = this.permutation[col];
            this.permutation[col] = temp;
            this.parity = -this.parity;
        }

        //Divide the lower elements by the "winning" diagonal elt.
        for (var row = col + 1; row < nRows; row++) {
            this.lu[row][col] /= this.lu[col][col];
        }
    }
};

RealMatrixImpl.prototype.toString=function(){
	var res = new StringBuffer();
    res.append("RealMatrixImpl{");
    if (this.data != null) {
        for (var i = 0; i < this.data.length; i++) {
            if (i > 0)
                res.append(",");
            res.append("{");
            for (var j = 0; j < this.data[0].length; j++) {
                if (j > 0)
                    res.append(",");
                res.append(this.data[i][j]);
            } 
            res.append("}");
        } 
    }
    res.append("}");
    return res.toString();
};

RealMatrixImpl.prototype.equals=function(o){
	if(!o||!o.jsjava_class||o.jsjava_class!="org.apache.commons.math.linear.RealMatrixImpl"){
		return false;
	}
	var nRows = this.getRowDimension();
    var nCols = this.getColumnDimension();
    if (o.getColumnDimension() != nCols || o.getRowDimension() != nRows) {
        return false;
    }
    for (var row = 0; row < nRows; row++) {
        for (var col = 0; col < nCols; col++) {
            if (this.data[row][col] != o.getEntry(row, col)) {
                return false;
            }
        }
    }
    return true;
};

RealMatrixImpl.prototype.getLUMatrix=function(){
	if (this.lu == null) {
        this.luDecompose();
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(this.lu);
};

RealMatrixImpl.prototype.getPermutation=function(){
	var out = new Array(this.permutation.length);
	for(var i=0;i<this.permutation.length;i++){
		out[i]=this.permutation[i];
	}
    return out;
};

RealMatrixImpl.prototype.copyOut=function(){
	var nRows = this.getRowDimension();
	var nCols=this.getColumnDimension();
    var out=new Array(nRows);
    for(var i=0;i<nRows;i++){
    	out[i]=new Array(nCols);
    }
    // can't copy 2-d array in one shot, otherwise get row references
    for (var i = 0; i < nRows; i++) {
        for(var j=0;j<nCols;j++){
        	out[i][j]=this.data[i][j];
        }
    }
    return out;
};

RealMatrixImpl.prototype.copyIn=function(ins){
	this.setSubMatrix(ins,0,0);
};

RealMatrixImpl.prototype.isValidCoordinate=function(row,col){
	var nRows = this.getRowDimension();
    var nCols = this.getColumnDimension();
    return !(row < 0 || row > nRows - 1 || col < 0 || col > nCols -1);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The SplineInterpolator class references to org.apache.commons.math.analysis.SplineInterpolator */
 
function SplineInterpolator(){
	this.jsjava_class="jsorg.apache.commons.math.analysis.SplineInterpolator";
}

/**
 * Computes an interpolating function for the data set.
 * param arrx - the arguments for the varerpolation povars
 * param arry - the values for the varerpolation povars
 */
SplineInterpolator.prototype.interpolate=function(arrx,arry){
	if (arrx.length != arry.length) {
            throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Dataset arrays must have same length.");
        }
        
        if (arrx.length < 3) {
            throw new IllegalArgumentException
                (IllegalArgumentException.ERROR,"At least 3 datapovars are required to compute a spline varerpolant");
        }
        
        // Number of varervals.  The number of data povars is n + 1.
        var n = arrx.length - 1;   
        
        for (var i = 0; i < n; i++) {
            if (arrx[i]  >= arrx[i + 1]) {
                throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Dataset arrx values must be strictly increasing.");
            }
        }
        
        // Differences between knot povars
        var h = new Array(n);
        for (var i = 0; i < n; i++) {
            h[i] = arrx[i + 1] - arrx[i];
        }
        
        var mu = new Array(n);
        var z = new Array(n + 1);
        mu[0] = 0;
        z[0] = 0;
        var g = 0;
        for (var i = 1; i < n; i++) {
            g = 2 * (arrx[i+1]  - arrx[i - 1]) - h[i - 1] * mu[i -1];
            mu[i] = h[i] / g;
            z[i] = (3 * (arry[i + 1] * h[i - 1] - arry[i] * (arrx[i + 1] - arrx[i - 1])+ arry[i - 1] * h[i]) /
                    (h[i - 1] * h[i]) - h[i - 1] * z[i - 1]) / g;
        }
       
        // cubic spline coefficients --  b is linear, c quadratic, d is cubic (original arry's are constants)
        var b = new Array(n);
        var c = new Array(n+1);
        var d = new Array(n);
        
        z[n] = 0;
        c[n] = 0;
        
        for (var j = n -1; j >=0; j--) {
            c[j] = z[j] - mu[j] * c[j + 1];
            b[j] = (arry[j + 1] - arry[j]) / h[j] - h[j] * (c[j + 1] + 2 * c[j]) / 3;
            d[j] = (c[j + 1] - c[j]) / (3 * h[j]);
        }
        
        var polynomials = new Array(n);
        var coefficients = new Array(4);
        for (var i = 0; i < n; i++) {
            coefficients[0] = arry[i];
            coefficients[1] = b[i];
            coefficients[2] = c[i];
            coefficients[3] = d[i];
            polynomials[i] = new PolynomialFunction(coefficients);
        }
        
        return new PolynomialSplineFunction(arrx, polynomials);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The StatUtils class references to org.apache.commons.math.stat.StatUtils */

function StatUtils(){
	this.jsjava_class="org.apache.commons.math.stat.StatUtils";
}

/**
 * Returns the geometric mean of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.geometricMean=function(values){
	return Math.pow(StatUtils.product(values),1/values.length);
};

/**
 * Returns the maximum of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.max=function(values){
	var max=Double.MIN_VALUE;
	for(var i=0;i<values.length;i++){
		var value=values[i];
		if(value>max){
			max=value;
		}
	}
	return max;
};

/**
 * Returns the arithmetic mean of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.mean=function(values){
	return StatUtils.sum(values)/values.length;
};

/**
 * Returns the mean of the (signed) differences between corresponding elements of the input arrays -- i.e., 
 * sum(sample1[i] - sample2[i]) / sample1.length.
 * param sample1
 * param sample2
 */
StatUtils.meanDifference=function(sample1,sample2){
	var length1=sample1.length;
	var length2=sample2.length;
	if(!length1||!length2||length1!=length2){
		return new IllegalArgumentException ("Input arrays must have the same (positive) length.");
	}
	var sample=new Array(length1);
	for(var i=0;i<length1;i++){
		sample[i]=sample1[i]-sample2[i];
	}
	return StatUtils.mean(sample);
};

/**
 * Returns the minimum of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.min=function(values){
	var min=Double.MAX_VALUE;
	for(var i=0;i<values.length;i++){
		var value=values[i];
		if(value<min){
			min=value;
		}
	}
	return min;
};

/**
 * Returns an estimate of the pth percentile of the values in the values array.
 * param values
 * p
 */
StatUtils.percentile=function(values,p){
	if ((p > 100) || (p <= 0)) {
        throw new IllegalArgumentException("invalid quantile value: " + p);
    }
    var length=values.length;
    if (length == 0) {
        return Double.NaN;
    }
    if (length == 1) {
        return values[0]; // always return single value for n = 1
    }
    var n =  length;
    var pos = p * (n + 1) / 100;
    var fpos = Math.floor(pos);
    var intPos =  fpos;
    var dif = pos - fpos;
    var sorted = new Array(length);
    for(var i=0;i<length;i++){
    	sorted[i]=values[i];
    }
    sorted.sort();
    if (pos < 1) {
        return sorted[0];
    }
    if (pos >= n) {
        return sorted[length - 1];
    }
    var lower = sorted[intPos - 1];
    var upper = sorted[intPos];
    return lower + dif * (upper - lower);
};

/**
 * Returns the product of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.product=function(values){
	var value=1;
	for(var i=0;i<values.length;i++){
		value*=values[i];
	}
	return value;
};

/**
 * Returns the sum of the values in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.sum=function(values){
	var sum=0;
	for(var i=0;i<values.length;i++){
		sum+=values[i];
	}
	return sum;
};

/**
 * Returns the sum of the (signed) differences between corresponding 
 * elements of the input arrays -- i.e., sum(sample1[i] - sample2[i]).
 * param sample1
 * param sample2
 */
StatUtils.sumDifference=function(sample1,sample2){
	var length1=sample1.length;
	var length2=sample2.length;
	if(!length1||!length2||length1!=length2){
		return new IllegalArgumentException ("Input arrays must have the same (positive) length.");
	}
    var result = 0;
    for (var i = 0; i < length1; i++) {
        result += sample1[i] - sample2[i];
    }
    return result;
};

/**
 * Returns the sum of the natural logs of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.sumLog=function(values){
	var sumLog=0;
	for(var i=0;i<values.length;i++){
		sumLog+=Math.log(values[i]);
	}
	return sumLog;
};

/**
 * Returns the sum of the squares of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.sumSq=function(values){
	var sumLog=0;
	for(var i=0;i<values.length;i++){
		sumLog+=values[i]*values[i];
	}
	return sumLog;
};

/**
 * Returns the variance of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.variance=function(values){
	var v;
	var length=values.length;
	if(length==1){
		return 0.0;
	}
	var mean=StatUtils.mean(values);
	var accum = 0.0;
    var accum2 = 0.0;
    for (var i = 0; i < length; i++) {
        accum += Math.pow((values[i] - mean), 2.0);
        accum2 += (values[i] - mean);
    }
    v=(accum - (Math.pow(accum2, 2) / (length))) /(length - 1);    
    return v;
};

/**
 * Returns the variance of the (signed) differences between corresponding elements of the input 
 * arrays -- i.e., var(sample1[i] - sample2[i]).
 * param sample1
 * param sample2
 * param meanDifference
 */
StatUtils.varianceDifference=function(sample1,sample2,meanDifference){
	var sum1 = 0;
    var sum2 = 0;
    var diff = 0;
    var length1=sample1.length;
	var length2=sample2.length;
	if(!length1||!length2||length1!=length2){
		return new IllegalArgumentException ("Input arrays must have the same (positive) length.");
	}
    for (var i = 0; i < length1; i++) {
        diff = sample1[i] - sample2[i];
        sum1 += (diff - meanDifference) *(diff - meanDifference);
        sum2 += diff - meanDifference;
    }
    return (sum1 - (sum2 * sum2 / length1)) / (length1 - 1);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The TDistributionImpl class references to org.apache.commons.math.distribution.TDistributionImpl */

function TDistributionImpl(degreesOfFreedom){
	this.jsjava_class="org.apache.commons.math.distribution.TDistributionImpl";	
	if (degreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.degreesOfFreedom = degreesOfFreedom;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
TDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    if (x == 0.0) {
        ret = 0.5;
    } else {
        var t =
            Beta.regularizedBeta(
                this.getDegreesOfFreedom() / (this.getDegreesOfFreedom() + (x * x)),
                0.5 * this.getDegreesOfFreedom(),
                0.5);
        if (x < 0.0) {
            ret = 0.5 * t;
        } else {
            ret = 1.0 - 0.5 * t;
        }
    }

    return ret;
};

/**
 * Access the degrees of freedom.
 */
TDistributionImpl.prototype.getDegreesOfFreedom=function(){
	return this.degreesOfFreedom;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
TDistributionImpl.prototype.getDomainLowerBound=function(p){
	return -Double.MAX_VALUE;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
TDistributionImpl.prototype.getDomainUpperBound=function(p){
	return Double.MAX_VALUE;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
TDistributionImpl.prototype.getInitialDomain=function(p){
	return 0.0;
};

/**
 * Modify the degrees of freedom.
 * param degreesOfFreedom
 */
TDistributionImpl.prototype.setDegreesOfFreedom=function(degreesOfFreedom){
	if (degreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.degreesOfFreedom = degreesOfFreedom;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The WeibullDistributionImpl class references to org.apache.commons.math.distribution.WeibullDistributionImpl */

function WeibullDistributionImpl(alpha,beta){
	this.jsjava_class="org.apache.commons.math.distribution.WeibullDistributionImpl";	
	if (alpha <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Shape must be positive.");
    }       
    this.alpha = alpha;
    if (beta <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Scale must be positive.");
    }       
    this.beta = beta;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
WeibullDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    if (x <= 0.0) {
        ret = 0.0;
    } else {
        ret = 1.0 - Math.exp(-Math.pow(x / this.getScale(), this.getShape()));
    }
    return ret;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
WeibullDistributionImpl.prototype.getDomainLowerBound=function(p){
	return 0.0;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
WeibullDistributionImpl.prototype.getDomainUpperBound=function(p){
	return Double.MAX_VALUE;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
WeibullDistributionImpl.prototype.getInitialDomain=function(p){
	return Math.pow(this.getScale() * Math.log(2.0), 1.0 / this.getShape());
};

/**
 * Access the scale parameter.
 */
WeibullDistributionImpl.prototype.getScale=function(){
	return this.beta;
};

/**
 * Access the shape parameter.
 */
WeibullDistributionImpl.prototype.getShape=function(){
	return this.alpha;
};

/**
 * For this distribution, X, this method returns the critical point x, such that P(X < x) = p.
 * param p
 */
WeibullDistributionImpl.prototype.inverseCumulativeProbability=function(p){
	var ret;
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"probability argument must be between 0 and 1 (inclusive)");
    } else if (p == 0) {
        ret = 0.0;
    } else  if (p == 1) {
        ret = Double.POSITIVE_INFINITY;
    } else {
        ret = this.getScale() * Math.pow(-Math.log(1.0 - p), 1.0 / this.getShape());
    }
    return ret;
};

/**
 * Modify the scale parameter.
 * param beta
 */
WeibullDistributionImpl.prototype.setScale=function(beta){
	if (beta <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Scale must be positive.");
    }       
    this.beta = beta;
};

/**
 * Modify the shape parameter.
 * param alpha
 */
WeibullDistributionImpl.prototype.setShape=function(alpha){
	if (alpha <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Shape must be positive.");
    }       
    this.alpha = alpha;
};
