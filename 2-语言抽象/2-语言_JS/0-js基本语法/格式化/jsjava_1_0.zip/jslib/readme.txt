Here are some Javascript libraries built by JsJava.
1) jsjava-1.0.js : include all jsjava classes
2) jsjava-ajax-1.0.js : include jsjava ajax classes
3) jsjava-animation-1.0.js : include jsjava animation classes
4) jsjava-collections-1.0.js : include jsjava collections classes
5) jsjava-lang-1.0.js : include jsjava language classes
6) jsjava-math-1.0.js : include jsjava math classes
7) jsjava-prototype-1.0.js : include jsjava prototype classes
8) jsjava-validator-1.0.js : include jsjava validator classes
9) jsjava-xml-1.0.js : include jsjava xml classes

2)+3)+4)+5)+6)+7)+8)+9) is part of 1),because there are many other classes which 
are not included from 2) to 9).

Notes:

1)jsjava-collections-1.0.js depends on jsjava-lang-1.0.js,jsjava-prototype-1.0.js
2)jsjava-math-1.0.js depends on jsjava-lang-1.0.js
3)jsjava-validator-1.0.js depends on jsjava-lang-1.0.js
4)jsjava-animation-1.0.js depends on jsjava-xml-1.0.js,jsjava-collections-1.0.js