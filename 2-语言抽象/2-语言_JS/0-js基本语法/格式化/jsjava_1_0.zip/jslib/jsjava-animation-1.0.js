/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 */

/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function Animation(){
	this.jsjava_class="jsorg.eob.animation.Animation";
	this.scenes=new List();
};

/**
 * add scene to animation
 * @param scene
 */
Animation.prototype.addScene=function(scene){
    this.scenes.add(scene);
};

/**
 * return animation scenes
 */
Animation.prototype.getScenes=function(){
    return this.scenes.toArray();
};

/**
 * return the indexed scene
 * @param index
 */
Animation.prototype.getScene=function(index){
    return this.scenes.get(index);
};

/**
 * return the max number of scene
 */
Animation.prototype.getMaxSceneNumber=function(){
    return this.scenes.toArray().length;
};

/**
 * clone a new animation object
 */
Animation.prototype.clone=function(){
	var animation=new Animation();
	animation.scenes=this.scenes;
	return animation;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function AnimationFrame(){
	this.jsjava_class="jsorg.eob.animation.AnimationFrame";
};

/**
 * set frame status
 * @param status
 */
AnimationFrame.prototype.setStatus=function(status){
    this.status=status;	
};

/**
 * return frame status
 */
AnimationFrame.prototype.getStatus=function(){
    return this.status;	
};

/**
 * set the user-defined model of the frame
 */
AnimationFrame.prototype.setModel=function(model){
    this.model=model;	
};

/**
 * return the user-defined model of the frame
 */
AnimationFrame.prototype.getModel=function(){
    return this.model;	

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function AnimationFrameModel(){
	this.jsjava_class="jsorg.eob.animation.AnimationFrameModel";
	this.id=null;
    this.name=null;
    this.title=null;
    this.type=null;
};

/**
 * set frame model id
 * @param id
 */
AnimationFrameModel.prototype.setId=function(id){
    this.id=id;	
};

/**
 * return frame model id
 */
AnimationFrameModel.prototype.getId=function(){
    return this.id;	
};

/**
 * set frame model name
 * @param id
 */
AnimationFrameModel.prototype.setName=function(name){
    this.name=name;	
};

/**
 * return frame model name
 */
AnimationFrameModel.prototype.getName=function(){
    return this.name;	
};

/**
 * set frame model title
 * @param title
 */
AnimationFrameModel.prototype.setTitle=function(title){
    this.title=title;	
};

/**
 * set frame model title
 */
AnimationFrameModel.prototype.getTitle=function(){
    return this.title;	
};

/**
 * set frame model type
 * @param type
 */
AnimationFrameModel.prototype.setType=function(type){
    this.type=type;	
};

/**
 * set frame model type
 */
AnimationFrameModel.prototype.getType=function(){
    return this.type;	

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function AnimationScene(){
	this.jsjava_class="jsorg.eob.animation.AnimationScene";
	this.frames=new List();
};

/**
 * set scene sequence
 * @param sequence
 */
AnimationScene.prototype.setSequence=function(sequence){
    this.sequence=sequence;	
};

/**
 * return scene sequence
 */
AnimationScene.prototype.getSequence=function(){
    return this.sequence;	
};

/**
 * add frame to the scene
 * @param frame
 */
AnimationScene.prototype.addFrame=function(frame){
    this.frames.add(frame);
};

/**
 * return the frames of the scene
 */
AnimationScene.prototype.getFrames=function(){
    return this.frames.toArray();

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function AnimationStudio(){
	this.jsjava_class="jsorg.eob.animation.AnimationStudio";
	this.animation=null;
	this.timer=null;
	this.sceneNumber=0;
	this.maxSceneNumber=0;
	this.instanceName=null;
};

/**
 * set the instance of current processing animation studio object
 * @param instanceName
 */
AnimationStudio.prototype.setInstanceName=function(instanceName){
    this.instanceName=instanceName;
};

/**
 * load animation into studio from xml string
 * @param aXml
 */
AnimationStudio.prototype.loadFromXml=function(aXml){
	var parser=new XmlBrowserParser();
	parser.loadXml(aXml);
	var xmldom=parser.toDocument();
    var rootElem=xmldom.documentElement;
    var sceneElems=rootElem.getElementsByTagName("graph-scene");
    var scenesSize=sceneElems.length;
    this.maxSceneNumber=scenesSize;
    var animation=new Animation();
    for(var i=0;i<scenesSize;i++){
        var sceneElem=sceneElems[i];
        var scene=new AnimationScene();
        var sceneSequenceElem=sceneElem.getElementsByTagName("graph-scene-sequence")[0];
        var sceneSequence=sceneSequenceElem.firstChild.nodeValue;
        scene.setSequence(sceneSequence);
        var frameElems=sceneElem.getElementsByTagName("graph-frame");
        var framesSize=frameElems.length;
        for(var j=0;j<framesSize;j++){
            var frameElem=frameElems[j];
            var frame=new AnimationFrame();
            var statusElem=frameElem.getElementsByTagName("graph-frame-status")[0];
            var status=statusElem.firstChild.nodeValue;
            frame.setStatus(status);
            var model=new AnimationFrameModel();
            var modelElem=frameElem.getElementsByTagName("graph-object")[0];
            var typeElem=modelElem.getElementsByTagName("graph-type")[0];
            var type=typeElem.firstChild.nodeValue;
            var metaElem=modelElem.getElementsByTagName("graph-meta-info")[0];
            var id=metaElem.getElementsByTagName("graph-object-id")[0].firstChild.nodeValue;
            var name=metaElem.getElementsByTagName("graph-object-name")[0].firstChild.nodeValue;
            var title=metaElem.getElementsByTagName("graph-object-label")[0].firstChild.nodeValue;
            model.setId(id);
            model.setName(name);
            model.setTitle(title);
            model.setType(type);
            frame.setModel(model);
            scene.addFrame(frame);
        }
        animation.addScene(scene);
    }
    this.animation=animation;
};

/**
 * load animation into studio from animation object
 * @param animation
 */
AnimationStudio.prototype.load=function(animation){
	this.animation=animation;
};

/**
 * set the interval between the frames
 * @param interval
 */
AnimationStudio.prototype.setInterval=function(interval){
	this.interval=interval;
};

/**
 * return the interval between the frames
 */
AnimationStudio.prototype.getInterval=function(){
	return this.interval;
};

/**
 * set the user-defined function for animation
 * @param action
 */
AnimationStudio.prototype.setAction=function(action){
	this.action=action;
};

/**
 * return the user-defined function for animation
 */
AnimationStudio.prototype.getAction=function(){
	return this.action;
};

/**
 * set the user-defined start function for animation
 * @param action
 */
AnimationStudio.prototype.setStartAction=function(action){
	this.startAction=action;
};

/**
 * return the user-defined start function for animation
 */
AnimationStudio.prototype.getStartAction=function(){
	return this.startAction;
};

/**
 * set the user-defined render function for animation
 * @param render
 */
AnimationStudio.prototype.setRender=function(render){
	this.render=render;
};

/**
 * return the user-defined render function for animation
 */
AnimationStudio.prototype.getRender=function(){
	return this.render;
};

/**
 * set the user-defined end function for animation
 * @param action
 */
AnimationStudio.prototype.setEndAction=function(action){
	this.endAction=action;
};

/**
 * return the user-defined end function for animation
 */
AnimationStudio.prototype.getEndAction=function(){
	return this.endAction;
};

/**
 * start to play animation
 */
AnimationStudio.prototype.play=function(){
	var action=this.getAction();
	var startAction=this.getStartAction();
	if(typeof(startAction)=="function"){
		startAction();
	}else{
		eval("window."+startAction+"()");
	}
	if(action){
		if(typeof(action)=="function"){
	    	this.timer=setInterval(action(),this.getInterval());  
	    }else{
	    	this.timer=setInterval(action+"()",this.getInterval()); 
	    }
	}else{
	    this.timer=setInterval("jsjava_play_animation('"+this.instanceName+"')",this.getInterval()); 
	}
};

/**
 * suspend to play animation
 */
AnimationStudio.prototype.suspend=function(){
	clearInterval(this.timer);
};

/**
 * restore to play animation
 */
AnimationStudio.prototype.restore=function(){
	this.play();
};

/**
 * stop to play animation
 */
AnimationStudio.prototype.stop=function(){	
	var endAction=studio.getEndAction();
    if(endAction){
    	if(typeof(endAction)=="function"){
    		endAction();
    	}else{
    		eval("window."+endAction+"()");
    	}
    }
    if(this.timer&&this.timer!=null){
    	clearInterval(this.timer);
    }
    this.sceneNumber=0;
};

/**
 * the execution action if no user-defined action
 */
function jsjava_play_animation(studioInstanceName){
    var studio=eval("window."+studioInstanceName);
    studio.sceneNumber++;
	if(studio.sceneNumber>=studio.maxSceneNumber){
	    studio.stop();
	    return;
	}	
	var render=studio.getRender();
	var currentScene=studio.animation.getScene(studio.sceneNumber);	
    var frames=currentScene.getFrames();
    for(var i=0;i<frames.length;i++){
        var frame=frames[i];
        var status=frame.getStatus();
        var model=frame.getModel();
        var type=model.getType();
        var id=model.getId();
        var title=model.getTitle(); 
        eval("window."+render+"('"+id+"','"+type+"','"+status+"','"+title+"')");
    }
};
