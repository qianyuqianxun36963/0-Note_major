/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 */

/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 * param username
 * param password
 */
function AjaxAuthentication(username,password){
	this.jsjava_class="jsorg.eob.ajax.AjaxAuthentication";	
	this.username=username;
	this.password=password;
};

/**
 * Get the username
 */
AjaxAuthentication.prototype.getUserName=function(){
	return this.username;
};

/**
 * Get the password
 */
AjaxAuthentication.prototype.getPassword=function(){
	return this.password;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 * param name - header name
 * param value - header value
 */ 
function AjaxHeader(name,value){
	this.jsjava_class="jsorg.eob.ajax.AjaxHeader";	
	this.name=name;
	this.value=value;
};

/**
 * Get the header name
 */
AjaxHeader.prototype.getName=function(){
	return this.name;
};

/**
 * Get the header value
 */
AjaxHeader.prototype.getValue=function(){
	return this.value;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function AjaxRequest(){
	this.jsjava_class="jsorg.eob.ajax.AjaxRequest";
	this.request=AjaxUtils.getXMLHTTPRequest();		
	this.headers=new Hashtable();
};

/**
 * Set the method triggered on ajax request success
 * param jsFunc - javascript function
 * param args - an arguments array
 */
AjaxRequest.prototype.setMethodOnSuccess=function(jsFunc,args){
	this.jsFunctionOnSuccess=jsFunc;
	this.jsFunctionArgsOnSuccess=args;
};

/**
 * Get the method triggered on ajax request success
 */
AjaxRequest.prototype.getMethodOnSuccess=function(){
	return this.jsFunctionOnSuccess;
};

/**
 * Get ready state
 */
AjaxRequest.prototype.getReadyState=function(){
	return this.request.readyState;
};

/**
 * Get response data
 */
AjaxRequest.prototype.getResponseBody=function(){
	return this.request.responseBody;
};

/**
 * Get response stream
 */
AjaxRequest.prototype.getResponseStream=function(){
	return this.request.responseStream;
};

/**
 * Get response text
 */
AjaxRequest.prototype.getResponseText=function(){
	return this.request.responseText;
};

/**
 * Get response xml object
 */
AjaxRequest.prototype.getResponseXML=function(){
	return this.request.responseXML;
};

/**
 * Get response status
 */
AjaxRequest.prototype.getStatus=function(){
	return this.request.status;
};

/**
 * Get response text
 */
AjaxRequest.prototype.getStatusText=function(){
	return this.request.statusText;
};

/**
 * Abort the current ajax request
 */
AjaxRequest.prototype.abort=function(){
	return this.request.abort();
};

/**
 * Set the request method
 * param reqMethod - the request method
 */
AjaxRequest.prototype.setRequestMethod=function(reqMethod){
	this.requestMethod=reqMethod;
};

/**
 * Set the request url
 * param reqURL - the request url
 */
AjaxRequest.prototype.setRequestURL=function(reqURL){
	this.requestURL=reqURL;
};

/**
 * Set whether the request is asynchoronized
 * param isAsync - boolean flag
 */
AjaxRequest.prototype.setAsync=function(isAsync){
	this.isAsynchronous=isAsync;
};

/**
 * Set the request authentication that is required on some web servers
 * param auth - the authenction object which contains username and password
 */
AjaxRequest.prototype.setAuthentication=function(auth){
	this.authentication=auth;
};

/**
 * Send the ajax request
 */
AjaxRequest.prototype.send=function(){	
	var ajaxRequest=this;
	var authUserName="";
	var authPassword="";
	if(this.authentication){
		authUserName=this.authentication.getUserName();
		authPassword=this.authentication.getPassword();
	}
	this.request.open(this.requestMethod,this.requestURL,this.isAsynchronous,authUserName,authPassword);
	var headerNames=this.headers.keys();
	for(var i=0;i<headerNames.length;i++){
		var headerName=headerNames[i];
		var headerValue=this.headers.get(headerName);
		this.request.setRequestHeader(headerName,headerValue);
	}
	this.request.onreadystatechange=function(){
		if(ajaxRequest.request.readyState==4){
			if(ajaxRequest.request.status==200){
				var args=ajaxRequest.jsFunctionArgsOnSuccess;
				var argStr="";
				if(args!=undefined&&args.length){
					for(var i=0;i<args.length;i++){
						argStr+="args["+i+"],";
					}
				}
				if(argStr.indexOf(",")==argStr.length-1){
					argStr=argStr.substring(0,argStr.length-1);
				}
				var newStr = "ajaxRequest.jsFunctionOnSuccess("+ argStr+")"; 
				eval(newStr);
			}
		};
	};
	this.request.send(null);
};

/**
 * Set ajax request header
 * param headerName
 * param headerValue
 */
AjaxRequest.prototype.setRequestHeader=function(headerName,headerValue){
	this.headers.put(headerName,headerValue);
};

/**
 * Set ajax request headers
 * param headersArray
 */
AjaxRequest.prototype.setRequestHeaders=function(headersArray){
	for(var i=0;i<headersArray.length;i++){
		var header=headersArray[i];
		var headerName=header.getName();
		var headerValue=header.getValue();
		this.headers.put(headerName,headerValue);
	}	
};

/**
 * Get ajax response header value
 * param headerName
 */
AjaxRequest.prototype.getResponseHeaderValue=function(headerName){
	this.request.getResponseHeader(headerName);
};

/**
 * Get all ajax response headers
 */
AjaxRequest.prototype.getAllResponseHeaders=function(){
	this.request.getAllResponseHeaders();

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function AjaxUtils(){
	this.jsjava_class="jsorg.eob.ajax.AjaxUtils";	
};

/**
 * Get xmlhttp request object
 */
AjaxUtils.getXMLHTTPRequest=function(){
	var xmlHttpReq;
	if(BrowserUtils.isIE()){
		var arr = ["MSXML2.XMLHTTP.5.0", "Microsoft.XMLHTTP", "MSXML2.XMLHTTP.4.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP"];
		for(var i=0;i<arr.length;i++){
	        try{
	            xmlHttpReq = new ActiveXObject(arr[i]);
	            break;
	        }catch(e){ 
	        	                   
	        }
        }
		
	}else{
		xmlHttpReq = new XMLHttpRequest();
	}
	return xmlHttpReq;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function Animation(){
	this.jsjava_class="jsorg.eob.animation.Animation";
	this.scenes=new List();
};

/**
 * add scene to animation
 * @param scene
 */
Animation.prototype.addScene=function(scene){
    this.scenes.add(scene);
};

/**
 * return animation scenes
 */
Animation.prototype.getScenes=function(){
    return this.scenes.toArray();
};

/**
 * return the indexed scene
 * @param index
 */
Animation.prototype.getScene=function(index){
    return this.scenes.get(index);
};

/**
 * return the max number of scene
 */
Animation.prototype.getMaxSceneNumber=function(){
    return this.scenes.toArray().length;
};

/**
 * clone a new animation object
 */
Animation.prototype.clone=function(){
	var animation=new Animation();
	animation.scenes=this.scenes;
	return animation;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function AnimationFrame(){
	this.jsjava_class="jsorg.eob.animation.AnimationFrame";
};

/**
 * set frame status
 * @param status
 */
AnimationFrame.prototype.setStatus=function(status){
    this.status=status;	
};

/**
 * return frame status
 */
AnimationFrame.prototype.getStatus=function(){
    return this.status;	
};

/**
 * set the user-defined model of the frame
 */
AnimationFrame.prototype.setModel=function(model){
    this.model=model;	
};

/**
 * return the user-defined model of the frame
 */
AnimationFrame.prototype.getModel=function(){
    return this.model;	

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function AnimationFrameModel(){
	this.jsjava_class="jsorg.eob.animation.AnimationFrameModel";
	this.id=null;
    this.name=null;
    this.title=null;
    this.type=null;
};

/**
 * set frame model id
 * @param id
 */
AnimationFrameModel.prototype.setId=function(id){
    this.id=id;	
};

/**
 * return frame model id
 */
AnimationFrameModel.prototype.getId=function(){
    return this.id;	
};

/**
 * set frame model name
 * @param id
 */
AnimationFrameModel.prototype.setName=function(name){
    this.name=name;	
};

/**
 * return frame model name
 */
AnimationFrameModel.prototype.getName=function(){
    return this.name;	
};

/**
 * set frame model title
 * @param title
 */
AnimationFrameModel.prototype.setTitle=function(title){
    this.title=title;	
};

/**
 * set frame model title
 */
AnimationFrameModel.prototype.getTitle=function(){
    return this.title;	
};

/**
 * set frame model type
 * @param type
 */
AnimationFrameModel.prototype.setType=function(type){
    this.type=type;	
};

/**
 * set frame model type
 */
AnimationFrameModel.prototype.getType=function(){
    return this.type;	

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function AnimationScene(){
	this.jsjava_class="jsorg.eob.animation.AnimationScene";
	this.frames=new List();
};

/**
 * set scene sequence
 * @param sequence
 */
AnimationScene.prototype.setSequence=function(sequence){
    this.sequence=sequence;	
};

/**
 * return scene sequence
 */
AnimationScene.prototype.getSequence=function(){
    return this.sequence;	
};

/**
 * add frame to the scene
 * @param frame
 */
AnimationScene.prototype.addFrame=function(frame){
    this.frames.add(frame);
};

/**
 * return the frames of the scene
 */
AnimationScene.prototype.getFrames=function(){
    return this.frames.toArray();

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function AnimationStudio(){
	this.jsjava_class="jsorg.eob.animation.AnimationStudio";
	this.animation=null;
	this.timer=null;
	this.sceneNumber=0;
	this.maxSceneNumber=0;
	this.instanceName=null;
};

/**
 * set the instance of current processing animation studio object
 * @param instanceName
 */
AnimationStudio.prototype.setInstanceName=function(instanceName){
    this.instanceName=instanceName;
};

/**
 * load animation into studio from xml string
 * @param aXml
 */
AnimationStudio.prototype.loadFromXml=function(aXml){
	var parser=new XmlBrowserParser();
	parser.loadXml(aXml);
	var xmldom=parser.toDocument();
    var rootElem=xmldom.documentElement;
    var sceneElems=rootElem.getElementsByTagName("graph-scene");
    var scenesSize=sceneElems.length;
    this.maxSceneNumber=scenesSize;
    var animation=new Animation();
    for(var i=0;i<scenesSize;i++){
        var sceneElem=sceneElems[i];
        var scene=new AnimationScene();
        var sceneSequenceElem=sceneElem.getElementsByTagName("graph-scene-sequence")[0];
        var sceneSequence=sceneSequenceElem.firstChild.nodeValue;
        scene.setSequence(sceneSequence);
        var frameElems=sceneElem.getElementsByTagName("graph-frame");
        var framesSize=frameElems.length;
        for(var j=0;j<framesSize;j++){
            var frameElem=frameElems[j];
            var frame=new AnimationFrame();
            var statusElem=frameElem.getElementsByTagName("graph-frame-status")[0];
            var status=statusElem.firstChild.nodeValue;
            frame.setStatus(status);
            var model=new AnimationFrameModel();
            var modelElem=frameElem.getElementsByTagName("graph-object")[0];
            var typeElem=modelElem.getElementsByTagName("graph-type")[0];
            var type=typeElem.firstChild.nodeValue;
            var metaElem=modelElem.getElementsByTagName("graph-meta-info")[0];
            var id=metaElem.getElementsByTagName("graph-object-id")[0].firstChild.nodeValue;
            var name=metaElem.getElementsByTagName("graph-object-name")[0].firstChild.nodeValue;
            var title=metaElem.getElementsByTagName("graph-object-label")[0].firstChild.nodeValue;
            model.setId(id);
            model.setName(name);
            model.setTitle(title);
            model.setType(type);
            frame.setModel(model);
            scene.addFrame(frame);
        }
        animation.addScene(scene);
    }
    this.animation=animation;
};

/**
 * load animation into studio from animation object
 * @param animation
 */
AnimationStudio.prototype.load=function(animation){
	this.animation=animation;
};

/**
 * set the interval between the frames
 * @param interval
 */
AnimationStudio.prototype.setInterval=function(interval){
	this.interval=interval;
};

/**
 * return the interval between the frames
 */
AnimationStudio.prototype.getInterval=function(){
	return this.interval;
};

/**
 * set the user-defined function for animation
 * @param action
 */
AnimationStudio.prototype.setAction=function(action){
	this.action=action;
};

/**
 * return the user-defined function for animation
 */
AnimationStudio.prototype.getAction=function(){
	return this.action;
};

/**
 * set the user-defined start function for animation
 * @param action
 */
AnimationStudio.prototype.setStartAction=function(action){
	this.startAction=action;
};

/**
 * return the user-defined start function for animation
 */
AnimationStudio.prototype.getStartAction=function(){
	return this.startAction;
};

/**
 * set the user-defined render function for animation
 * @param render
 */
AnimationStudio.prototype.setRender=function(render){
	this.render=render;
};

/**
 * return the user-defined render function for animation
 */
AnimationStudio.prototype.getRender=function(){
	return this.render;
};

/**
 * set the user-defined end function for animation
 * @param action
 */
AnimationStudio.prototype.setEndAction=function(action){
	this.endAction=action;
};

/**
 * return the user-defined end function for animation
 */
AnimationStudio.prototype.getEndAction=function(){
	return this.endAction;
};

/**
 * start to play animation
 */
AnimationStudio.prototype.play=function(){
	var action=this.getAction();
	var startAction=this.getStartAction();
	if(typeof(startAction)=="function"){
		startAction();
	}else{
		eval("window."+startAction+"()");
	}
	if(action){
		if(typeof(action)=="function"){
	    	this.timer=setInterval(action(),this.getInterval());  
	    }else{
	    	this.timer=setInterval(action+"()",this.getInterval()); 
	    }
	}else{
	    this.timer=setInterval("jsjava_play_animation('"+this.instanceName+"')",this.getInterval()); 
	}
};

/**
 * suspend to play animation
 */
AnimationStudio.prototype.suspend=function(){
	clearInterval(this.timer);
};

/**
 * restore to play animation
 */
AnimationStudio.prototype.restore=function(){
	this.play();
};

/**
 * stop to play animation
 */
AnimationStudio.prototype.stop=function(){	
	var endAction=studio.getEndAction();
    if(endAction){
    	if(typeof(endAction)=="function"){
    		endAction();
    	}else{
    		eval("window."+endAction+"()");
    	}
    }
    if(this.timer&&this.timer!=null){
    	clearInterval(this.timer);
    }
    this.sceneNumber=0;
};

/**
 * the execution action if no user-defined action
 */
function jsjava_play_animation(studioInstanceName){
    var studio=eval("window."+studioInstanceName);
    studio.sceneNumber++;
	if(studio.sceneNumber>=studio.maxSceneNumber){
	    studio.stop();
	    return;
	}	
	var render=studio.getRender();
	var currentScene=studio.animation.getScene(studio.sceneNumber);	
    var frames=currentScene.getFrames();
    for(var i=0;i<frames.length;i++){
        var frame=frames[i];
        var status=frame.getStatus();
        var model=frame.getModel();
        var type=model.getType();
        var id=model.getId();
        var title=model.getTitle(); 
        eval("window."+render+"('"+id+"','"+type+"','"+status+"','"+title+"')");
    }
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function AreaUtils(){
	this.jsjava_class="jsorg.eob.math.area.AreaUtils";
}

/**
 * Calculate the area of square
 * param a - the side length of the square
 */
AreaUtils.countSquare=function(a){
	if(a<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"side must be equal or larger than zero!");
	}
	return a*a;
};

/**
 * Calculate the area of rectangle
 * param a - the one side length of the rectangle
 * param b - the ajacent side length of the rectangle
 */
AreaUtils.countRectangle=function(a,b){
	if(a<0||b<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}
	return a*a;
};

/**
 * Calculate the area of circle
 * param r - the radius of circle
 */
AreaUtils.countCircle=function(r){
	if(r<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"radius must be equal or larger than zero!");
	}	
	return  Math.PI*r*r;
};

/**
 * Calculate the area of circle
 * param d - the diameter of circle
 */
AreaUtils.countCircle2=function(d){
	if(d<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"diameter must be equal or larger than zero!");
	}	
	return  Math.PI*d*d/4;
};

/**
 * Calculate the area of equilateral triangle
 * param a - the side length
 */
AreaUtils.countEquilateralTriangle=function(a){
	return  AreaUtils.countTriangle(a,a,Math.PI/3);
};

/**
 * Calculate the area of triangle
 * param a - the side length
 * param h - the height of the side
 */
AreaUtils.countTriangle=function(a,h){
	if(a<0||h<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and height must be equal or larger than zero!");
	}	
	return  0.5*a*h;
};

/**
 * Calculate the area of triangle
 * param a - the one side length
 * param b - the other side length
 * param angleC - the angle between the tow sides
 */
AreaUtils.countTriangle2=function(a,b,angleC){
	if(a<0||b<0||angleC<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  0.5*a*b*Math.sin(angleC);
};

/**
 * Calculate the area of triangle
 * param a - the one side length
 * param b - the second side length
 * param c - the third side length
 */
AreaUtils.countTriangle3=function(a,b,c){
	if(a<0||b<0||c<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}	
	var s=(a+b+c)/2;
	return  Math.sqrt(s*(s-a)*(s-b)*(s-c));
};

/**
 * Calculate the area of triangle
 * param a - the one side length
 * param angleA - the angle A
 * param angleB - the angle B
 * param angleC - the angle C
 */
AreaUtils.countTriangle4=function(a,angleA,angleB,angleC){
	if(a<0||angleA<0||angleB<0||angleC<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  a*a*Math.sin(angleB)*Math.sin(angleC)/(2*Math.sin(angleA));
};

/**
 * Calculate the area of trapezia
 * param a - the top side length
 * param b - the bottom side length
 * param h - the height of trapezia
 */
AreaUtils.countTrapezia=function(a,b,h){
	if(a<0||b<0||h<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and height must be equal or larger than zero!");
	}	
	return  0.5*(a+b)*h;
};

/**
 * Calculate the area of trapezia
 * param m - the middle line length
 * param h - the height of trapezia
 */
AreaUtils.countTrapezia2=function(m,h){
	if(m<0||h<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and height must be equal or larger than zero!");
	}	
	return  m*h;
};

/**
 * Calculate the area of quadrangle
 * param d - the length of one diagonal
 * param D - the length of the other diagonal
 * param angleA - the angle between two diagonals
 */
AreaUtils.countQuadrangle=function(d,D,angleA){
	if(d<0||D<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  d*D/2*Math.sin(DegreeTransform.toRadian(angleA));
};

/**
 * Calculate the area of parallelogram
 * param a - the length of one diagonal
 * param h - the length of the other diagonal
 */
AreaUtils.countParallelogram=function(a,h){
	if(a<0||h<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}	
	return  a*h;
};

/**
 * Calculate the area of parallelogram
 * param a - the length of one diagonal
 * param b - the length of the other diagonal
 * param angleA - the angle between two diagonals
 */
AreaUtils.countParallelogram2=function(a,b,angleA){
	if(a<0||b<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  a*b*Math.sin(DegreeTransform.toRadian(angleA));
};

/**
 * Calculate the area of diamond
 * param a - the length of one diagonal
 * param D - the length of the other diagonal
 */
AreaUtils.countDiamond=function(d,D){
	if(d<0||D<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}	
	return  d*D/2;
};

/**
 * Calculate the area of diamond
 * param a - the side length
 * param angleA - the angle of two ajacent side
 */
AreaUtils.countDiamond2=function(a,angleA){
	if(a<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  a*a*Math.sin(DegreeTransform.toRadian(angleA));
};

/**
 * Calculate the area of sector
 * param r - the radius of sector
 * param angleA - the central angle
 */
AreaUtils.countSector=function(r,angleA){
	if(r<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  Math.PI*r*r*angleA/360;
};

/**
 * Calculate the area of arc
 * param r - the radius of arc
 * param angleA - the central angle
 */
AreaUtils.countArc=function(r,angleA){
	if(r<0||angleA<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides and angle must be equal or larger than zero!");
	}	
	return  r*r/2*(DegreeTransform.toRadian(angleA)-Math.sin(DegreeTransform.toRadian(angleA)));
};

/**
 * Calculate the area of annulus
 * param r - the radius of inner circle
 * param R - the radius of outer circle
 */
AreaUtils.countAnnulus=function(r,R){
	if(r<0||R<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"radius must be equal or larger than zero!");
	}	
	if(r>R){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"R must be equal or larger than r!");
	}
	return  Math.PI*(R*R-r*r);
};

/**
 * Calculate the area of ellipse
 * param d - the length of short axis
 * param D - the length of long axis
 */
AreaUtils.countEllipse=function(d,D){
	if(d<0||D<0){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"sides must be equal or larger than zero!");
	}	
	return  Math.PI*D*d/4;
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The ArithmeticException class references to java.lang.ArithmeticException of J2SE1.4 */

ArithmeticException.prototype=new Error();
ArithmeticException.prototype.constructor=ArithmeticException;

ArithmeticException.ERROR=0;

/**
 * constructor
 * param code - error code
 * param message - error message
 */
function ArithmeticException(code,message){
	this.jsjava_class="jsjava.lang.ArithmeticException";
	this.code=code;
    this.message=message;
    this.name="jsjava.lang.ArithmeticException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The ArrayUtils class references to org.apache.commons.lang.ArrayUtils */
 
function ArrayUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.ArrayUtils";
}

/**
 * Copies the given array and adds the given element at the end of the new array.
 * param arr
 * param value
 */
ArrayUtils.add=function(arr,value){
	var narr=new Array(arr.length+1);
	for(var i=0;i<arr.length;i++){
		narr[i]=arr[i];
	}
	narr[arr.length]=value;
	return narr;
};

/**
 * Inserts the specified element at the specified position in the array.
 * param arr
 * param index
 * param value
 */
ArrayUtils.addIndexOf=function(arr,index,value){
	if(index>arr.length||index<0){
	    return arr;
	}
	var narr=new Array(arr.length+1);
	for(var i=0;i<narr.length;i++){
	    if(i<index){
	    	narr[i]=arr[i];
	    }else if(i==index){
	    	narr[i]=value;
	    }else{
	    	narr[i]=arr[i-1];
	    }
	} 
	return narr;
};

/**
 * Adds all the elements of the given arrays into a new array.
 * param toArr
 * param fromArr
 */
ArrayUtils.addAll=function(toArr,fromArr){
	var toArrLength=toArr.length;
	var fromArrLength=fromArr.length;
	var narr=new Array(toArrLength+fromArrLength);
	var j=0;
	for(var i=0;i<narr.length;i++){
		if(j==toArrLength){
			j=0;
		}
		if(i<toArrLength){
		    narr[i]=toArr[j];		    
		}else{
			narr[i]=fromArr[j];
		}
		j++;
	}
	return narr;
};

/**
 * Clones an array returning a typecast result.
 * param arr
 */
ArrayUtils.clone=function(arr){
	var narr=new Array(arr.length);
	for(var i=0;i<arr.length;i++){
		narr[i]=arr[i];
	}
	return narr;
};

/**
 * Checks if the value is in the given array.
 * param arr
 * param value
 */
ArrayUtils.contains=function(arr,value){
	for(var i=0;i<arr.length;i++){
		if(arr[i]==value){
			return true;
		}
	}
	return false;
};

/**
 * Checks if the value is in the given array.This method need each object 
 * to initialize the eqeuals method.
 * param arr
 * param value
 */
ArrayUtils.containsEqual=function(arr,value){
	for(var i=0;i<arr.length;i++){
		if(arr[i].equals(value)){
			return true;
		}
	}
	return false;
};

/**
 * Returns the length of the specified array.
 * param arr
 */
ArrayUtils.getLength=function(arr){
	return arr.length;
};

/**
 * Finds the index of the given value in the array.
 * param arr
 * param value
 */
ArrayUtils.indexOf=function(arr,value){
	for(var i=0;i<arr.length;i++){
		if(arr[i]==value){
			return i;
		}
	}
	return -1;
};

/**
 * Checks if an array of primitive booleans is empty or undefined
 * param arr
 */
ArrayUtils.isEmpty=function(arr){
	if(arr==undefined||arr.length==0){
		return true;
	}
	return false;
};

/**
 * Compares two arrays, using equals().
 * param arr1
 * param arr2
 */
ArrayUtils.isEquals=function(arr1,arr2){
	var arr1Length=arr1.length;
	var arr2Length=arr2.length;
	if(arr1Length!=arr2Length){
		return false;
	}	
	for(var i=0;i<arr1Length;i++){
		if(arr1[i]!=arr2[i]){
			return false;
		}
	}
	return true;
};

/**
 * Checks whether two arrays are the same length.
 * param arr1
 * param arr2
 */
ArrayUtils.isSameLength=function(arr1,arr2){
	var arr1Length=arr1.length;
	var arr2Length=arr2.length;
	if(arr1Length!=arr2Length){
		return false;
	}	
	return true;
};

/**
 * Finds the last index of the given value within the array.
 * param arr
 * value
 */
ArrayUtils.lastIndexOf=function(arr,value){
	for(var i=arr.length-1;i>=0;i--){
		if(arr[i]==value){
			return i;
		}
	}
	return -1;
};

/**
 * Removes the element at the specified position from the specified array.
 * param arr
 * param index
 */
ArrayUtils.remove=function(arr,index){
	if(index>arr.length-1||index<0){
		return arr;
	}
	var narr=new Array(arr.length-1);
	for(var i=0;i<narr.length;i++){
		if(i<index){
			narr[i]=arr[i];
		}else{
			narr[i]=arr[i+1];
		}
	}
	return narr;
};

/** 
 * Removes the first occurrence of the specified element from the specified array.
 * param arr
 * param value
 */
ArrayUtils.removeElement=function(arr,value){
	var index=ArrayUtils.indexOf(arr,value);
	if(index==-1){
		return arr;
	}
	return ArrayUtils.remove(arr,index);
};

/**
 * Reverses the order of the given array.
 * param arr
 */
ArrayUtils.reverse=function(arr){
	return arr.reverse();
};

/**
 * Produces a new boolean array containing the elements between the start and end indices.
 * param arr
 * param startIndexInclusive
 * param endIndexExclusive
 */
ArrayUtils.subarray=function(arr,startIndexInclusive,endIndexExclusive){
	if(startIndexInclusive<=endIndexExclusive&&startIndexInclusive>=0&&endIndexExclusive<=arr.length){
		var narr=new Array(endIndexExclusive-startIndexInclusive);
		for(var i=startIndexInclusive;i<endIndexExclusive;i++){
			narr[i]=arr[i];
		}
		return narr;
	}
	return null;
};

/**
 * Outputs an array as a String, treating null as an empty array.
 * param arr
 */
ArrayUtils.toString=function(arr){
	return arr.toString();
};

/**
 * Outputs an array as a String handling nulls.
 * param arr
 * param defaultValue
 */
ArrayUtils.toStringIfNull=function(arr,defaultValue){
	var narr=ArrayUtils.clone(arr);
	for(var i=0;i<narr.length;i++){
		if(narr[i]==undefined||narr[i]==null){
			narr[i]=defaultValue;
		}
	}
	return narr.toString();

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The BeanUtils class references to org.apache.commons.lang.BeanUtils */
 
function BeanUtils(){
	this.jsjava_class="jsorg.apache.commons.beanutils.BeanUtils";
}

/**
 * Return the value of the specified property of the specified bean, no matter which property reference format is used, as a String.
 * param bean
 * param name
 */
BeanUtils.getProperty=function(bean,name){
    if(!bean||typeof(bean)!="object"||!name||typeof(name)!="string"){
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"bean and property can not be null!");
    }
    var capitalName=name.charAt(0).toUpperCase()+name.substring(1);
    var str="bean.get"+capitalName+"()";
    var value=eval(str);
	return value;
};

/**
 * Return the value of the specified simple property of the specified bean, converted to a String.
 * param bean
 * param name
 */
BeanUtils.getSimpleProperty=function(bean,name){
    if(!bean||typeof(bean)!="object"||!name||typeof(name)!="string"){
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"bean and property can not be null!");
    }
    var capitalName=name.charAt(0).toUpperCase()+name.substring(1);
    var str="bean.get"+capitalName+"()";
    var value=eval(str);
	return value;
};

/**
 * Return the value of the specified indexed property of the specified bean, as a String.
 * param bean
 * param name
 * param index
 */
BeanUtils.getIndexedProperty=function(bean,name,index){
	if(!bean||typeof(bean)!="object"||!name||typeof(name)!="string"||isNaN(index)||index<0){
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,
              "bean and property and can not be null and index can not be smaller than 0!");
    }
    var capitalName=name.charAt(0).toUpperCase()+name.substring(1);
    var str="bean.get"+capitalName+"("+index+")";
    var value=eval(str);
	return value;
};

/**
 * Return the value of the specified mapped property of the specified bean, as a String.
 * param bean
 * param name
 * param key
 */
BeanUtils.getMappedProperty=function(bean,name,key){
	if(!bean||typeof(bean)!="object"||!name||typeof(name)!="string"||!key||typeof(key)!="string"){
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,
              "bean and property and key can not be null!");
    }
    var capitalName=name.charAt(0).toUpperCase()+name.substring(1);
    var str="bean.get"+capitalName+"('"+key+"')";
    var value=eval(str);
	return value;
};

/**
 * Set the specified property value, performing type conversions as required to conform to the type of the destination property.
 * param bean
 * param name
 * param value
 */
BeanUtils.setProperty=function(bean,name,value){
    if(!bean||typeof(bean)!="object"||!name||typeof(name)!="string"){
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"bean and property can not be null!");
    }
    var capitalName=name.charAt(0).toUpperCase()+name.substring(1);
    var str="bean.set"+capitalName+"('"+value+"')";
    var value=eval(str);
	return value;
};

/**
 * Copy the specified property value to the specified destination bean, performing any type conversion that is required.
 * param bean
 * param name
 * param value
 */
BeanUtils.copyProperty=function(bean,name,value){
    if(!bean||typeof(bean)!="object"||!name||typeof(name)!="string"){
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"bean and property can not be null!");
    }
    var capitalName=name.charAt(0).toUpperCase()+name.substring(1);
    var str="bean.set"+capitalName+"('"+value+"')";
    var value=eval(str);
	return value;
};

/**
 * Populate the JavaBeans properties of the specified bean, based on the specified name/value pairs.
 * param bean
 * param properties
 */
BeanUtils.populate=function(bean,properties){
	if(!bean||typeof(bean)!="object"||!properties||!properties.jsjava_class||properties.jsjava_class!="jsjava.util.Hashtable"){
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,
             "bean and properties can not be null and properties must be an instance of jsjava.util.Hashtable");
    }
    var keys=properties.keySet().iterator();
    while(keys.hasNext()){
    	var key=keys.next();
    	var value=properties.get(key);
    	BeanUtils.setProperty(bean,key,value);
    }

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Gamma class references to org.apache.commons.math.special.Beta */

function Beta(){
	this.jsjava_class="org.apache.commons.math.special.Beta";
}

Beta.DEFAULT_EPSILON = 10e-9;

/**
 * Returns the regularized beta function I(x, a, b).
 * param x - the value
 * param a - the a parameter.
 * param b - the b parameter.
 */
Beta.regularizedBeta=function(x,a,b){
	return Beta.regularizedBeta4(x, a, b, Beta.DEFAULT_EPSILON, Integer.MAX_VALUE);
};

/**
 * Returns the regularized beta function I(x, a, b).
 * param x - the value
 * param a - the a parameter.
 * param b - the b parameter.
 * param epsilon - When the absolute value of the nth item in the series is less than 
 * epsilon the approximation ceases to calculate further elements in the series. 
 */
Beta.regularizedBeta2=function(x,a,b,epsilon){
	return Beta.regularizedBeta4(x, a, b, epsilon, Integer.MAX_VALUE);
};

/**
 * Returns the regularized beta function I(x, a, b).
 * param x - the value
 * param a - the a parameter.
 * param b - the b parameter.
 * param maxIterations - Maximum number of "iterations" to complete.
 */
Beta.regularizedBeta3=function(x,a,b,maxIterations){
	return Beta.regularizedBeta4(x, a, b, Beta.DEFAULT_EPSILON, maxIterations);
};

/**
 * Returns the regularized beta function I(x, a, b).
 * param x - the value
 * param a - the a parameter.
 * param b - the b parameter.
 * param epsilon - When the absolute value of the nth item in the series is less than 
 * epsilon the approximation ceases to calculate further elements in the series.
 * param maxIterations - Maximum number of "iterations" to complete.
 */
Beta.regularizedBeta4=function(x,a,b,epsilon,maxIterations){
	function ContinuedFraction(){
		
	}
	ContinuedFraction.DEFAULT_EPSILON = 10e-9;
	ContinuedFraction.prototype.evaluate=function(x){
		return this.evaluate(x, ContinuedFraction.DEFAULT_EPSILON, Integer.MAX_VALUE);
	};
	ContinuedFraction.prototype.evaluate2=function(x,epsilon){
		return this.evaluate(x, epsilon, Integer.MAX_VALUE);
	};
	ContinuedFraction.prototype.evaluate3=function(x,maxIterations){
		return this.evaluate(x, ContinuedFraction.DEFAULT_EPSILON, maxIterations);
	};
	ContinuedFraction.prototype.evaluate4=function(x,epsilon,maxIterations){
		var p0 = 1.0;
        var p1 = this.getA(0, x);
        var q0 = 0.0;
        var q1 = 1.0;
        var c = p1 / q1;
        var n = 0;
        var relativeError = Double.MAX_VALUE;
        while (n < maxIterations && relativeError > epsilon) {
            ++n;
            var a = this.getA(n, x);
            var b = this.getB(n, x);
            var p2 = a * p1 + b * p0;
            var q2 = a * q1 + b * q0;
            if (Double.isInfinite(p2) || Double.isInfinite(q2)) {
                // need to scale
                if (a != 0.0) {
                    p2 = p1 + (b / a * p0);
                    q2 = q1 + (b / a * q0);
                } else if (b != 0) {
                    p2 = (a / b * p1) + p0;
                    q2 = (a / b * q1) + q0;
                } else {
                    // can not scale an convergent is unbounded.
                    throw new ConvergenceException(ConvergenceException.ERROR,
                        "Continued fraction convergents diverged to +/- " +
                        "infinity.");
                }
            }
            var r = p2 / q2;
            relativeError = Math.abs(r / c - 1.0);
                
            // prepare for next iteration
            c = p2 / q2;
            p0 = p1;
            p1 = p2;
            q0 = q1;
            q1 = q2;
        }

        if (n >= maxIterations) {
            throw new ConvergenceException(ConvergenceException.ERROR,
                "Continued fraction convergents failed to converge.");
        }

        return c;
	};
	ContinuedFraction.prototype.getA=function(n,x){
		return 1.0;
	};
	ContinuedFraction.prototype.getB=function(n,x){
		var ret;
        var m;
        if (n % 2 == 0) { // even
            m = n / 2.0;
            ret = (m * (b - m) * x) /
                ((a + (2 * m) - 1) * (a + (2 * m)));
        } else {
            m = (n - 1.0) / 2.0;
            ret = -((a + m) * (a + b + m) * x) /
                    ((a + (2 * m)) * (a + (2 * m) + 1.0));
        }
        return ret;
	};
	var ret;
    if (Double.isNaN(x) || Double.isNaN(a) || Double.isNaN(b) || (x < 0) ||
        (x > 1) || (a <= 0.0) || (b <= 0.0)) {
        ret = Double.NaN;
    } else if (x > (a + 1.0) / (a + b + 2.0)) {
        ret = 1.0 - Beta.regularizedBeta4(1.0 - x, b, a, epsilon, maxIterations);
    } else {
        var fraction = new ContinuedFraction();
        ret = Math.exp((a * Math.log(x)) + (b * Math.log(1.0 - x)) -
                Math.log(a) - Beta.logBeta2(a, b, epsilon, maxIterations)) *
                1.0 / fraction.evaluate4(x, epsilon, maxIterations);
    }
	return ret;
};

/**
 * Returns the natural logarithm of the beta function B(a, b).
 * param a - the a parameter.
 * param b - the b parameter.
 */
Beta.logBeta=function(a,b){
	return Beta.logBeta2(a, b, Beta.DEFAULT_EPSILON, Integer.MAX_VALUE);
};

/**
 * Returns the natural logarithm of the beta function B(a, b).
 * param a - the a parameter.
 * param b - the b parameter.
 * param epsilon - When the absolute value of the nth item in the series is less 
 * than epsilon the approximation ceases to calculate further elements in the series. 
 * param maxIterations - Maximum number of "iterations" to complete. 
 */
Beta.logBeta2=function(a,b,epsilon,maxIterations){
	var ret;
	if (Double.isNaN(a) || Double.isNaN(b) || (a <= 0.0) || (b <= 0.0)) {
        ret = Double.NaN;
    } else {
        ret = Gamma.logGamma(a) + Gamma.logGamma(b) -
            Gamma.logGamma(a + b);
    }
	
    return ret;

};

/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The MathUtils class references to org.apache.commons.math.util.MathUtils */
 
function MathUtils(){
	this.jsjava_class="jsorg.apache.commons.math.util.MathUtils";
}

/**
 * Returns an exact representation of the Binomial Coefficient, "n choose k", the 
 * number of k-element subsets that can be selected from an n-element set.
 * param n
 * param k
 */
MathUtils.binomialCoefficient=function(n,k){
	if (n < k) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"must have n >= k for binomial coefficient (n,k)");
    }
    if (n < 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"must have n >= 0 for binomial coefficient (n,k)");
    }
    if ((n == k) || (k == 0)) {
        return 1;
    }
    if ((k == 1) || (k == n - 1)) {
        return n;
    }
    var result = Math.round(MathUtils.binomialCoefficientDouble(n, k));
    if (result == Long.MAX) {
        throw new ArithmeticException(ArithmeticException.ERROR,"result too large to represent in a long integer");
    }
    return result;
};

/**
 * Returns an double representation of the Binomial Coefficient, "n choose k", the 
 * number of k-element subsets that can be selected from an n-element set.
 * param n
 * param k
 */
MathUtils.binomialCoefficientDouble=function(n,k){
	return Math.floor(Math.exp(MathUtils.binomialCoefficientLog(n, k)) + 0.5);
};

/**
 * Returns the natural log of the Binomial Coefficient, "n choose k", the 
 * number of k-element subsets that can be selected from an n-element set.
 * param n
 * param k
 */
MathUtils.binomialCoefficientLog=function(n,k){
	if (n < k) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"must have n >= k for binomial coefficient (n,k)");
    }
    if (n < 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"must have n >= 0 for binomial coefficient (n,k)");
    }
    if ((n == k) || (k == 0)) {
        return 0;
    }
    if ((k == 1) || (k == n - 1)) {
        return Math.log(n);
    }
    var logSum = 0;

    // n!/k!
    for (var i = k + 1; i <= n; i++) {
        logSum += Math.log(i);
    }

    // divide by (n-k)!
    for (var i = 2; i <= n - k; i++) {
        logSum -= Math.log(i);
    }

    return logSum;
};

/**
 * Returns the hyperbolic cosine of x.
 * param x
 */
MathUtils.cosh=function(x){
	return (Math.exp(x) + Math.exp(-x)) / 2.0;
};

/**
 * Returns n!.
 * param n
 */
MathUtils.factorial=function(n){
	var result = Math.round(MathUtils.factorialDouble(n));
    if (result == Long.MAX) {
        throw new ArithmeticException(ArithmeticException.ERROR,"result too large to represent in a long integer");
    }
    return result;
};

/**
 * Returns n!.
 * param n
 */
MathUtils.factorialDouble=function(n){
	if (n < 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"must have n >= 0 for n!");
    }
    return Math.floor(Math.exp(MathUtils.factorialLog(n)) + 0.5);
};

/**
 * Returns n!.
 * param n
 */
MathUtils.factorialLog=function(n){
	if (n < 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"must have n > 0 for n!");
    }
    var logSum = 0;
    for (var i = 2; i <= n; i++) {
        logSum += Math.log(i);
    }
    return logSum;
};

/**
 * Gets the greatest common divisor of 
 * the absolute value of two numbers, using the "binary gcd" method which avoids division and modulo operations.
 * param u
 * param v
 */
MathUtils.gcd=function(u,v){
	if (u * v == 0) {
        return (Math.abs(u) + Math.abs(v));
    }
    // keep u and v negative, as negative integers range down to
    // -2^31, while positive numbers can only be as large as 2^31-1
    // (i.e. we can't necessarily negate a negative number without
    // overflow)
    /** assert u!=0 && v!=0; */
    if (u > 0) {
        u = -u;
    } // make u negative
    if (v > 0) {
        v = -v;
    } // make v negative
    // B1. [Find power of 2]
    var k = 0;
    while ((u & 1) == 0 && (v & 1) == 0 && k < 31) { // while u and v are
                                                        // both even...
        u /= 2;
        v /= 2;
        k++; // cast out twos.
    }
    if (k == 31) {
        throw new ArithmeticException(ArithmeticException.ERROR,"overflow: gcd is 2^31");
    }
    // B2. Initialize: u and v have been divided by 2^k and at least
    // one is odd.
    var t = ((u & 1) == 1) ? v : -(u / 2)/** B3 */;
    // t negative: u was odd, v may be even (t replaces v)
    // t positive: u was even, v is odd (t replaces u)
    do {
        /** assert u<0 && v<0; */
        // B4/B3: cast out twos from t.
        while ((t & 1) == 0) { // while t is even..
            t /= 2; // cast out twos
        }
        // B5 [reset max(u,v)]
        if (t > 0) {
            u = -t;
        } else {
            v = t;
        }
        // B6/B3. at this point both u and v should be odd.
        t = (v - u) / 2;
        // |u| larger: t positive (replace u)
        // |v| larger: t negative (replace v)
    } while (t != 0);
    return -u * (1 << k); // gcd is u*2^k
};

/**
 * For a value x, this method returns +1 if x >= 0 and -1 if x < 0.
 * param x
 */
MathUtils.indicator=function(x){
	return (x >= 0) ? 1 : -1;
};

/**
 * Returns the least common multiple between two integer values.
 * param a
 * param b
 */
MathUtils.lcm=function(a,b){
 	var x=a/MathUtils.gcd(a,b);
 	var y=b;
	var m =x*y;
	return Math.abs(m);
};

/**
 * Returns the sign for value x.
 * param x
 */
MathUtils.sign=function(x){
	return (x == 0) ? 0 : (x > 0) ? 1 : -1;
};

/**
 * Returns the hyperbolic sine of x.
 * param x
 */
MathUtils.sinh=function(x){
	return (Math.exp(x) - Math.exp(-x)) / 2.0;

};

/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The BinomialDistributionImpl class references to org.apache.commons.math.distribution.BinomialDistributionImpl */

function BinomialDistributionImpl(trials,p){
	this.jsjava_class="org.apache.commons.math.distribution.BinomialDistributionImpl";	
	if (trials < 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"number of trials must be non-negative.");
    }
    this.numberOfTrials = trials;
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"probability of success must be between 0.0 and 1.0, inclusive.");
    }
    this.probabilityOfSuccess = p;
}

/**
 * For this distribution, X, this method returns P(X �� x).
 * param x
 */
BinomialDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
	var sx=new String(x);
	if(sx.indexOf(".")!=-1){
		x=Math.floor(x);
	}
    if (x < 0) {
        ret = 0.0;
    } else if (x >= this.getNumberOfTrials()) {
        ret = 1.0;
    } else {    	
        ret =
            1.0 - Beta.regularizedBeta(
                    this.getProbabilityOfSuccess(),
                    x + 1.0,
                    this.getNumberOfTrials() - x);
    }
    return ret;
};

/**
 * For a random variable X whose values are distributed according
 * to this distribution, this method returns P(x0 &le; X &le; x1).
 * @param x0 the inclusive, lower bound
 * @param x1 the inclusive, upper bound
 */
BinomialDistributionImpl.prototype.cumulativeProbability2=function(x0,x1){
	if (x0 > x1) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"lower endpoint must be less than or equal to upper endpoint");
    }
    return this.cumulativeProbability(x1) - this.cumulativeProbability(x0 - 1);
};

/**
 * Access the domain value lower bound, based on p, used to bracket a PDF root.
 * param d
 */
BinomialDistributionImpl.prototype.getDomainLowerBound=function(d){
	return -1;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a PDF root.
 * param p
 */
BinomialDistributionImpl.prototype.getDomainUpperBound=function(p){
	return this.getNumberOfTrials();
};

/**
 * Access the number of trials for this distribution.
 */
BinomialDistributionImpl.prototype.getNumberOfTrials=function(){
	return this.numberOfTrials;
};

/**
 * Access the probability of success for this distribution.
 */
BinomialDistributionImpl.prototype.getProbabilityOfSuccess=function(){
	return this.probabilityOfSuccess;
};

/**
 * For this distribution, X, this method returns the largest x, such that P(X �� x) �� p.
 * param p
 */
BinomialDistributionImpl.prototype.inverseCumulativeProbability=function(p){
	// handle extreme values explicitly
    if (p == 0) {
        return -1;
    } 
    if (p == 1) {
        return Integer.MAX_VALUE; 
    }
    
    // use default bisection impl
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException(
            "p must be between 0 and 1.0 (inclusive)");
    }
    
    // by default, do simple bisection.
    // subclasses can override if there is a better method.
    var x0 = this.getDomainLowerBound(p);
    var x1 = this.getDomainUpperBound(p);
    var pm;
    while (x0 < x1) {
        var xm = x0 + Math.floor((x1 - x0) / 2);
        pm = this.cumulativeProbability(xm);
        if (pm > p) {
            // update x1
            if (xm == x1) {
                // this can happen with integer division
                // simply decrement x1
                --x1;
            } else {
                // update x1 normally
                x1 = xm;
            }
        } else {
            // update x0
            if (xm == x0) {
                // this can happen with integer division
                // simply increment x0
                ++x0;
            } else {
                // update x0 normally
                x0 = xm;
            }
        }
    }
    
    // insure x0 is the correct critical point
    pm = this.cumulativeProbability(x0);
    while (pm > p) {
    	--x0;
        pm = this.cumulativeProbability(x0);
    }

    return x0;
};

/**
 * For this disbution, X, this method returns P(X = x).
 * param x
 */
BinomialDistributionImpl.prototype.probability=function(x){
	var ret;
    if (x < 0 || x > this.getNumberOfTrials()) {
        ret = 0.0;
    } else {
    	var sx=new String(x);
    	if(sx.indexOf(".")!=-1){
    		var fl = Math.floor(x);
		    if (fl == x) {
		        return this.probability(f1);
		    } else {
		        return 0;
		    }
    	}
        ret = MathUtils.binomialCoefficientDouble(
                this.getNumberOfTrials(), x) *
              Math.pow(this.getProbabilityOfSuccess(), x) *
              Math.pow(1.0 - this.getProbabilityOfSuccess(),
                    this.getNumberOfTrials() - x);
    }
    return ret;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The BitSet class references to java.util.BitSet of J2SE1.4 */
 
/**
 * constructor
 */
 function BitSet(){
 	 this.jsjava_class="jsjava.util.BitSet";
     this.elements=new Array();
 }
 
/**
 * Sets the bit at the specified index to true.
 * param bitIndex
 */
 BitSet.prototype.set=function(bitIndex){
     this.elements[bitIndex]=true;
 };
 
/**
 * Sets the bit at the specified index to the specified value.
 * param bitIndex
 * param value
 */
 BitSet.prototype.setByValue=function(bitIndex,value){
     if(value!=true&&value!=false){
         value=false;	
     }
     this.elements[bitIndex]=value;
 };
 
/**
 * Sets the bits from the specified fromIndex(inclusive) to the 
 * specified toIndex(exclusive) to true.
 * param fromIndex
 * param toIndex
 */
 BitSet.prototype.setBetween=function(fromIndex,toIndex){
     for(var i=fromIndex;i<toIndex;i++){
         this.elements[i]=true;
     }
 };
 
/**
 * Sets the bits from the specified fromIndex(inclusive) to the 
 * specified toIndex(exclusive) to the specified value.
 * param fromIndex
 * param toIndex
 * param value
 */
 BitSet.prototype.setBetweenByValue=function(fromIndex,toIndex,value){
     if(value!=true&&value!=false){
         value=false;	
     }
     for(var i=fromIndex;i<toIndex;i++){
         this.elements[i]=value;
     }
 };
 
/**
 * Returns the value of the bit with the specified index.
 * param bitIndex
 */
 BitSet.prototype.get=function(bitIndex){
     var value=this.elements[bitIndex];
     if(value){
         return value;
     }
     return false;
 };

/**
 * Returns a new BitSet composed of bits from this BitSet from 
 * fromIndex(inclusive) to toIndex(exclusive).
 * param fromIndex
 * param toIndex
 */ 
 BitSet.prototype.getBetween=function(fromIndex,toIndex){
     var bs=new BitSet();
     for(var i=fromIndex;i<toIndex;i++){
         bs.setByValue(i,this.get(i));	
     }
     return bs;
 };

/**
 * Returns a string representation of this bit set. 
 */
 BitSet.prototype.toString=function(){
 	 var elems=new Array();
 	 for(var i=0;i<this.elements.length;i++){
 	     var value=this.elements[i];
 	     if(value){
 	         elems[i]=true;
 	     }else{
 	         elems[i]=false;
 	     }
 	 }
     return elems.toString();	
 };

/**
 * Returns the number of bits of space actually in use by 
 * this BitSet to represent bit values. 
 */ 
 BitSet.prototype.size=function(){
     return this.elements.length;	
 };

/**
 * Returns the "logical size" of this BitSet: the index of the 
 * highest set bit in the BitSet plus one.
 */ 
 BitSet.prototype.length=function(){
     return this.size();	
 };

/**
 * Sets all of the bits in this BitSet to false.
 */ 
 BitSet.prototype.clear=function(){
     for(var i=0;i<this.size();i++){
         this.elements[i]=false;	
     }	
 };

/**
 * Sets the bits from the specified fromIndex(inclusive) to 
 * the specified toIndex(exclusive) to false.
 * param fromIndex
 * param toIndex
 */ 
 BitSet.prototype.clearBetween=function(fromIndex,toIndex){
     for(var i=fromIndex;i<toIndex;i++){
         this.elements[i]=false;	
     }	
 };

/**
 * Returns true if this BitSet contains no bits that are set to true.
 */ 
 BitSet.prototype.isEmpty=function(){
     for(var i=0;i<this.size();i++){
         if(this.get(i)){
             return false;
         }
     }	
     return true;
 };

/**
 * Sets the bit at the specified index to to the complement of its current value.
 * param bitIndex
 */ 
 BitSet.prototype.flip=function(bitIndex){
     var value=this.elements[bitIndex];
     if(value!=true&&value!=false){
         value=false;	
     }
     var rValue=false;
     if(!value){
         rValue=true;	
     }
     this.setByValue(bitIndex,rValue);
 };

/**
 * Sets each bit from the specified fromIndex(inclusive) to the 
 * specified toIndex(exclusive) to the complement of its current value.
 * param fromIndex
 * param toIndex
 */
 BitSet.prototype.flipBetween=function(fromIndex,toIndex){
     for(var i=fromIndex;i<toIndex;i++){
         this.flip(i);	
     }
 };

/**
 * Performs a logical AND of this target bit set with the 
 * argument bit set.
 * param bs a BitSet object
 */ 
 BitSet.prototype.and=function(bs){
     var size1=this.size();
     var size2=bs.size();
     var size=size1>size2?size1:size2;
     for(var i=0;i<size;i++){
         var value1=this.get(i);
         var value2=bs.get(i);
         var value=value1&&value2;
         this.setByValue(i,value);
     }	
 };

/**
 * Performs a logical OR of this bit set with the bit set argument.
 * param bs a BitSet object
 */ 
 BitSet.prototype.or=function(bs){
     var size1=this.size();
     var size2=bs.size();
     var size=size1>size2?size1:size2;
     for(var i=0;i<size;i++){
         var value1=this.get(i);
         var value2=bs.get(i);
         var value=value1||value2;
         this.setByValue(i,value);
     }	
 };

/**
 * Performs a logical XOR of this bit set with the bit set argument.
 * param bs a BitSet object
 */  
 BitSet.prototype.xor=function(bs){
     var size1=this.size();
     var size2=bs.size();
     var size=size1>size2?size1:size2;
     for(var i=0;i<size;i++){
         var value1=this.get(i);
         var value2=bs.get(i);
         var value=value1^value2;
         value=value==1?true:false;
         this.setByValue(i,value);
     }	
 };

/**
 * Clears all of the bits in this BitSet whose corresponding bit is 
 * set in the specified BitSet.
 * param bs a BitSet object
 */ 
 BitSet.prototype.andNot=function(bs){
     var size1=this.size();
     var size2=bs.size();
     var size=size1>size2?size1:size2;
     for(var i=0;i<size;i++){
         var value1=this.get(i);
         var value2=bs.get(i);
         var value=value2==true?false:value1;
         this.setByValue(i,value);
     }	
 };

/**
 * Returns the number of bits set to true in this BitSet.
 */ 
 BitSet.prototype.cardinality=function(){
     var value=0;
     for(var i=0;i<this.size();i++){
         if(this.get(i)){
             value++;	
         }	
     }	
     return value;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**  The Boolean class references to java.lang.Boolean of J2SE1.4 */
 
/**
 * constructor
 * param value true or false
 */
function Boolean(value){
	this.jsjava_class="jsjava.lang.Boolean";
    this.value=value;
}
Boolean.TRUE=true;
Boolean.FALSE=false;

/**
 * check whether the input value is a boolean value
 * param b
 */
Boolean.checkValid=function(b){
    if(b=="true"||b=="false"||b==true||b==false){
        return true;
    }
    return false;
};

/**
 * Returns a Boolean with a value represented by the specified String.
 * param str
 */
Boolean.valueOf=function(str){
	if(Boolean.checkValid(str)){
		return new Boolean(true);
	}
	return new Boolean(false);
};

/**
 * compare whether this object value is equals to input Boolean object value
 * param b input Boolean object
 */
Boolean.prototype.compareTo=function(b){
    if(b==undefined){
        return -1; 
    }
    if(this.value==b.value){
        return 1; 
    }else{
        return -1;  
    }
};

/**
 * return a string description
 */
Boolean.prototype.toString=function(){
    return this.value; 
}

/**
 * return the object's boolean value
 */
Boolean.prototype.booleanValue=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Boolean.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Boolean"){
        return this.value==o.value; 
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The BooleanUtils class references to org.apache.commons.lang.BooleanUtils */
 
function BooleanUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.BooleanUtils";
}

/**
 * Is a Boolean value false
 * param value
 */
BooleanUtils.isFalse=function(value){
	var type=typeof(value);
	if(type=="boolean"){
		if(!value){
			return true;
		}
	}
	if(type=="string"){
	    if(value=="false"){
	    	return true;
	    }
	}
	if(type=="object"){
	    if(value.booleanValue()==false||value.booleanValue()=="false"){
	    	return true;
	    }
	}
	return false;
};

/**
 * Is a Boolean value true
 * param value
 */
BooleanUtils.isTrue=function(value){
	var type=typeof(value);
	if(type=="boolean"){
		if(value){
			return true;
		}
	}
	if(type=="string"){
	    if(value=="true"){
	    	return true;
	    }
	}
	if(type=="object"){
	    if(value.booleanValue()==true||value.booleanValue()=="true"){
	    	return true;
	    }
	}
	return false;
};

/**
 * Negates the specified boolean.
 * param value
 */
BooleanUtils.negate=function(value){
	var type=typeof(value);
	if(type=="boolean"){
		return !value;
	}
	if(type=="string"){
	    if(value=="true"){
	    	return "false";
	    }
	    if(value=="false"){
	    	return "true";
	    }
	}
	if(type=="object"){
		var ovalue=value.booleanValue();
	    if(ovalue=="true"){
	    	return new Boolean("false");
	    }
	    if(ovalue=="false"){
	    	return new Boolean("true");
	    }
	    if(ovalue==true){
	    	return new Boolean(false);
	    }
	    if(ovalue==false){
	    	return new Boolean(true);
	    }
	}
	return null;
};

/**
 * Converts a Boolean to a boolean
 * param value
 */
BooleanUtils.toBoolean=function(value){
	var type=typeof(value);
	if(type=="boolean"){
		return value;
	}
	if(type=="string"){
		if(value=="true"){
			return true;
		}else{
			return false;
		}
	}
	if(type=="object"){
		return value.booleanValue();
	}
	if(type=="number"){
		if(value==0){
			return false;
		}else{
			return true;
		}
	}
	return false;
};

/**
 * Converts a Boolean to a boolean handling null.
 * param value
 * param defaultValue
 */
BooleanUtils.toBooleanDefaultIfNull=function(value,defaultValue){
	if(value==null||value==undefined){
		return defaultValue;	
	}
	return BooleanUtils.toBoolean(value);
};

/**
 * Converts an object to a Boolean using the convention.
 * param value
 */
BooleanUtils.toBooleanObject=function(value){
	return new Boolean(BooleanUtils.toBoolean(value));
};

/**
 *  Converts a boolean to an int specifying the conversion values.
 * param value
 * param trueValue
 * param falseValue
 * param nullValue
 */
BooleanUtils.toInteger=function(value,trueValue,falseValue,nullValue){
	if(value==null||value==undefined){
		return nullValue;	
	}
	if(BooleanUtils.toBoolean(value)){
		return trueValue;
	}
	return falseValue;
};

/**
 * Converts a Boolean to an Integer specifying the conversion values.
 * param value
 * param trueValue
 * param falseValue
 * param nullValue
 */
BooleanUtils.toIntegerObject=function(value,trueValue,falseValue,nullValue){
	if(value==null||value==undefined){
		return nullValue;	
	}
	if(BooleanUtils.toBoolean(value)){
		return trueValue;
	}
	return falseValue;
};

/**
 * Converts a Boolean to a String returning one of the input Strings.
 * param value
 * param trueString
 * param falseString
 * param nullString
 */
BooleanUtils.toString=function(value,trueString,falseString,nullString){
	if(value==null||value==undefined){
		return nullString;	
	}
	if(BooleanUtils.toBoolean(value)){
		return trueString;
	}
	return falseString;
};

/**
 * Converts a boolean to a String returning 'on' or 'off'.
 * param value
 */
BooleanUtils.toStringOnOff=function(value){
	if(value==null||value==undefined){
		return "off";	
	}
	if(BooleanUtils.toBoolean(value)){
		return "on";
	}
	return "off";
};

/**
 * Converts a Boolean to a String returning 'on', 'off'
 * param value
 */
BooleanUtils.toStringTrueFalse=function(value){
	if(value==null||value==undefined){
		return "false";	
	}
	if(BooleanUtils.toBoolean(value)){
		return "true";
	}
	return "false";
};

/**
 * Converts a boolean to a String returning 'yes' or 'no'.
 * param value
 */
BooleanUtils.toStringYesNo=function(value){
	if(value==null||value==undefined){
		return "no";	
	}
	if(BooleanUtils.toBoolean(value)){
		return "yes";
	}
	return "no";
};

/**
 * Performs an xor on a set of booleans.
 * param arr
 */
BooleanUtils.xor=function(arr){
	var narr=new Array(arr.length);
	for(var i=0;i<arr.length;i++){
		narr[i]=BooleanUtils.toBoolean(arr[i]);
	}
	var xvalue=narr[0];
	for(var i=1;i<arr.length;i++){
		xvalue=xvalue^narr[i];
	}
	return BooleanUtils.toBoolean(xvalue);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function BooleanValidator(){
	this.jsjava_class="jsorg.eob.validator.BooleanValidator";
}

/**
 * Check whether the given value is boolean
 * param str - the given value
 */
BooleanValidator.validate=function(str){
	return Boolean.checkValid(str);
};

/**
 * Check whether the given value is boolean
 * param b - the given value
 */
BooleanValidator.validate2=function(b){
    if(b=="true"||b=="false"||b==true||b==false){
        return true;
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Border class references to javax.swing.border.Border of J2SE1.4 */
 
/**
 * constructor
 * param width
 * param color
 * param style
 */
function Border(width,color,style){
	this.jsjava_class="jsjavax.swing.border.Border";
    this.width=width;
    this.color=color;
    this.style=style;
}

/**
 * return the border width
 */
Border.prototype.getWidth=function(){
    return this.width;	
};

/**
 * set the border width
 * param width
 */
Border.prototype.setWidth=function(width){
    return this.width;	
};

/**
 * return the border color
 */
Border.prototype.getColor=function(){
    return this.color;	
};

/**
 * set the border color
 * param color
 */
Border.prototype.setColor=function(color){
    return this.color;	
};

/**
 * return the border style
 * param value
 */
Border.prototype.getStyle=function(){
    return this.style;	
};

/**
 * set the border style
 * param style
 */
Border.prototype.setStyle=function(style){
    return this.style;	

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function BrowserUtils(){
	this.jsjava_class="jsorg.eob.browser.BrowserUtils";
}

/**
 * Check whether the current browser is IE
 */
BrowserUtils.isIE=function(){
	return navigator.userAgent.indexOf("MSIE")!=-1;
};

/**
 * Check whether the current browser is Firefox
 */
BrowserUtils.isFirefox=function(){
	return navigator.userAgent.indexOf("Firefox")!=-1;
};

/**
 * Check whether the current browser is Opera
 */
BrowserUtils.isOpera=function(){
	return navigator.userAgent.indexOf("Opera")!=-1;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Byte class references to java.lang.Byte of J2SE1.4 */
 
/**
 * constructor
 * param value 
 */
function Byte(value){
	this.jsjava_class="jsjava.lang.Byte";
    this.value=value;
}
Byte.MIN=-Math.pow(2,7);
Byte.MAX=Math.pow(2,7)-1;
Byte.MIN_VALUE=-Math.pow(2,7);
Byte.MAX_VALUE=Math.pow(2,7)-1;

/**
 * check whether the input value is a byte value
 * param b
 */
Byte.checkValid=function(b){
	if(isNaN(b)){
		return false;
	}
	b=parseInt(b);
    if(b<=Byte.MAX&&b>=Byte.MIN){
        return true;
    }
    return false;
};

/**
 * create a new Byte object with str
 * param str
 */
Byte.parseByte=function(str){
    if(isNaN(str)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	} 
    var b=parseInt(str);
    if(!Byte.checkValid(b)){
        return;
    }
    return b;
};

/**
 * compare whether this object value is equals to input Boolean object value
 * param b input Byte object
 */
Byte.prototype.compareTo=function(b){
    if(b==undefined){
        return -1; 
    }
    if(this.value>b.value){
        return 1; 
    }else if(this.value==b.value){
        return 0; 
    }else{
        return -1;  
    }
};

/**
 * return the object's byte value
 */
Byte.prototype.byteValue=function(){
    return this.value; 
};

/**
 * return a string description
 */
Byte.prototype.toString=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Byte.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Byte"){
        return this.value==o.value; 
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**
 * Constructor
 */
function ByteValidator(){
	this.jsjava_class="jsorg.eob.validator.ByteValidator";
}

ByteValidator.MIN=-Math.pow(2,7);
ByteValidator.MAX=Math.pow(2,7)-1;

/**
 * Check whether the given value is byte
 * param str - the given value
 */
ByteValidator.validate=function(str){
	return Byte.checkValid(str);
};

/**
 * Check whether the given value is boolean
 * param b - the given value
 */
ByteValidator.validate2=function(b){
	if(isNaN(b)){
		return false;
	}
	b=parseInt(b);
	if(b<=ByteValidator.MAX&&b>=ByteValidator.MIN){
        return true;
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Calendar class references to java.util.Calendar of J2SE1.4 */
 
/**
 * constructor
 */
function Calendar(){
	this.jsjava_class="jsjava.util.Calendar";
	this._date=new Date();
	this.time=this._date.getTime();
	this.year=this._date.getYear();
	this.month=this._date.getMonth();
	this.date=this._date.getDate();
	this.day=this._date.getDay();
	this.hours=this._date.getHours();
	this.minutes=this._date.getMinutes();
	this.seconds=this._date.getSeconds();
}

Calendar.ERA = 0;    
Calendar.YEAR = 1;
Calendar.MONTH = 2;
Calendar.WEEK_OF_YEAR = 3;
Calendar.WEEK_OF_MONTH = 4;
Calendar.DATE = 5;
Calendar.DAY_OF_MONTH = 5;
Calendar.DAY_OF_YEAR = 6;
Calendar.DAY_OF_WEEK = 7;
Calendar.DAY_OF_WEEK_IN_MONTH = 8;
Calendar.AM_PM = 9;
Calendar.HOUR = 10;
Calendar.HOUR_OF_DAY = 11;
Calendar.MINUTE = 12;
Calendar.SECOND = 13;
Calendar.MILLISECOND = 14;
Calendar.ZONE_OFFSET = 15;
Calendar.DST_OFFSET = 16;
Calendar.FIELD_COUNT = 17;
Calendar.SUNDAY = 1;
Calendar.MONDAY = 2;
Calendar.TUESDAY = 3;
Calendar.WEDNESDAY = 4;
Calendar.THURSDAY = 5;
Calendar.FRIDAY = 6;
Calendar.SATURDAY = 7;
Calendar.JANUARY = 0;
Calendar.FEBRUARY = 1;
Calendar.MARCH = 2;
Calendar.APRIL = 3;
Calendar.MAY = 4;
Calendar.JUNE = 5;
Calendar.JULY = 6;
Calendar.AUGUST = 7;
Calendar.SEPTEMBER = 8;
Calendar.OCTOBER = 9;
Calendar.NOVEMBER = 10;
Calendar.DECEMBER = 11;
Calendar.UNDECIMBER = 12;
Calendar.AM = 0;
Calendar.PM = 1;
Calendar.BIG_MONTH_DAYS=31;
Calendar.SMALL_MONTH_DAYS=30;
Calendar.LEAP_YEAR_FEB_DAYS=29;
Calendar.NON_LEAP_YEAR_FEB_DAYS=28;
Calendar.DAYS_OF_WEEK=7;

/**
 * check whether the calendar object is valid
 * @param c - calendar object
 */
Calendar.prototype.checkValid=function(c){
	if(c==undefined||!c.jsjava_class||c.jsjava_class!=this.jsjava_class){
	    throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Invalid arguments!");
	}
};

/**
 * Compares the time field records.
 * @param c - calendar object
 */
Calendar.prototype.after=function(c){
	this.checkValid(c);
	if(this.getTimeInMillis()>c.getTimeInMillis()){
		return true;
	}
	return false;
};

/**
 * Compares the time field records
 * @param c - calendar object
 */
Calendar.prototype.before=function(c){
	this.checkValid(c);
	if(this.getTimeInMillis()<c.getTimeInMillis()){
		return true;
	}
	return false;
};

/**
 * Gets the value for a given time field.
 * @param field - the given time field.
 */
Calendar.prototype.get=function(field){
	if(typeof(field)!="number"){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Invalid arguments!");
	}
	var result=-1;
	switch(field){
		case Calendar.ERA :{
			result=Calendar.ERA+1;
			break;
		};    
		case Calendar.YEAR :{
			result=this.year;
			break;
		};
		case Calendar.MONTH :{
			result=this.month;
			break;
		};
		case Calendar.WEEK_OF_YEAR :{
			var fDate=new Date(this.year,0,1);
			var fDay=fDate.getDay();
			var cDate=this.get(Calendar.DAY_OF_YEAR);
			var n=Math.floor((cDate+fDay-1)/Calendar.DAYS_OF_WEEK)+1;
			result=n;
			break;
		};
		case Calendar.WEEK_OF_MONTH :{
			var fDate=new Date(this.year,this.month,1);
			var fDay=fDate.getDay();
			var cDate=this.date;
			var n=Math.floor((cDate+fDay-1)/Calendar.DAYS_OF_WEEK)+1;
			result=n;
			break;
		};
		case Calendar.DATE :{
			result=this.date;
			break;
		};
		case Calendar.DAY_OF_MONTH :{
			result=this.date;
			break;
		};
		case Calendar.DAY_OF_YEAR :{
			var nDay=0;
			var month=this.month;			
			for(var i=0;i<month;i++){
				nDay+=Calendar.getDaysOfMonth(this.year,i);
			}
			nDay+=this.date;
			result=nDay;
			break;
		};
		case Calendar.DAY_OF_WEEK :{
			result=this.day+1;
			break;
		};
		case Calendar.DAY_OF_WEEK_IN_MONTH :{
			var date=this.date;
			var n=Math.floor((date-1)/Calendar.DAYS_OF_WEEK)+1;
			result=n;
			break;
		};
		case Calendar.AM_PM :{
			if(this.hours>12){
				result=Calendar.PM;
			}else{
				result=Calendar.AM;
			}
			break;
		}
		case Calendar.HOUR :{
			var hours=this.hours;
			if(hours>=12){
				result=hours-12;
			}else{
				result=hours;
			}
			break;
		};
		case Calendar.HOUR_OF_DAY :{
			result=this.hours;
			break;
		};
		case Calendar.MINUTE :{
			result=this.minutes;
			break;
		};
		case Calendar.SECOND :{
			result=this.seconds;
			break;
		};
		case Calendar.MILLISECOND :{
			result=this.time;
			break;
		};
		case Calendar.ZONE_OFFSET :{
			result=this._date.getTimezoneOffset()*60*1000;
			break;
		};
		case Calendar.DST_OFFSET :{
			result=0;
			break;
		};
	}
	return result;
};

/**
 * Gets a calendar using the default time zone and locale.
 */
Calendar.prototype.getInstance=function(){
	return new Calendar();
};

/**
 * Gets this Calendar's current time.
 */
Calendar.prototype.getTime=function(){
	return this._date;
};

/**
 * Gets this Calendar's current time as a long.
 */
Calendar.prototype.getTimeInMillis=function(){
	return this.time;
};

/**
 * check whether the calendar year is a leap year
 */
Calendar.prototype.isLeapYear=function(){
	var year=this.year;
	if(year%100==0){
		if(year%400==0){
			return true;
		}
		return false;
	}
	if(year%4==0){
		return true;
	}
	return false;
};

/**
 * check whether the given year is a leap year
 * @param year - the given year number
 */
Calendar.isLeapYear=function(year){
	if(year%100==0){
		if(year%400==0){
			return true;
		}
		return false;
	}
	if(year%4==0){
		return true;
	}
	return false;
};

/**
 * Sets this Calendar's current time with the given Date.
 * @param date - the given Date.
 */
Calendar.prototype.setTime=function(date){
	this._date=date;
	this.time=this._date.getTime();
	this.year=this._date.getYear();
	this.month=this._date.getMonth();
	this.date=this._date.getDate();
	this.day=this._date.getDay();
	this.hours=this._date.getHours();
	this.minutes=this._date.getMinutes();
	this.seconds=this._date.getSeconds();
};

/**
 * check whether the calendar month is a big month
 */
Calendar.prototype.isBigMonth=function(){
	var bigMonth=",1,3,5,7,8,10,12,";
	if(bigMonth.indexOf(","+(this.month+1)+",")!=-1){
		return true;
	}
	return false;
};

/**
 * check whether the given month is a big month
 * @param month - the given month
 */
Calendar.isBigMonth=function(month){
	var bigMonth=",1,3,5,7,8,10,12,";
	if(bigMonth.indexOf(","+(month+1)+",")!=-1){
		return true;
	}
	return false;
};

/**
 * check whether the calendar month is a small month
 */
Calendar.prototype.isSmallMonth=function(){
	var smallMonth=",4,6,9,11,";
	if(smallMonth.indexOf(","+(this.month+1)+",")!=-1){
		return true;
	}
	return false;
};

/**
 * check whether the given month is a small month
 * @param month - the given month
 */
Calendar.isSmallMonth=function(month){
	var smallMonth=",4,6,9,11,";
	if(smallMonth.indexOf(","+(month+1)+",")!=-1){
		return true;
	}
	return false;
};

/**
 * check whether the given month is February
 */
Calendar.prototype.isSpecialMonth=function(){
	if(this.month==1){
		return true;
	}
	return false;
};

/**
 * check whether the given month is February
 * @param month - the given month
 */
Calendar.isSpecialMonth=function(month){
	if(month==1){
		return true;
	}
	return false;
};

/**
 * Get the number of days of the given month of year
 * @param year - the given year
 * @param month - the given month
 */
Calendar.getDaysOfMonth=function(year,month){
	if(Calendar.isBigMonth(month)){
		return Calendar.BIG_MONTH_DAYS;
	}
	if(Calendar.isSmallMonth(month)){
		return Calendar.SMALL_MONTH_DAYS;
	}
	if(!year){
		year=new Date().getYear();
	}
	if(Calendar.isLeapYear(year)){
		return Calendar.LEAP_YEAR_FEB_DAYS;
	}else{
		return Calendar.NON_LEAP_YEAR_FEB_DAYS;
	}
	

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The CauchyDistributionImpl class references to org.apache.commons.math.distribution.CauchyDistributionImpl */

function CauchyDistributionImpl(median, s){
	this.jsjava_class="org.apache.commons.math.distribution.CauchyDistributionImpl";	
	this.median = median;
    if (s <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Scale must be positive.");
    }       
    this.scale = s;
}
/**
 * For this disbution, X, this method returns P(X < x). 
 */
CauchyDistributionImpl.prototype.cumulativeProbability=function(x){
	return 0.5 + (Math.atan((x - this.median) / this.scale) / Math.PI);
};          
          
/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root. 
 */
CauchyDistributionImpl.prototype.getDomainLowerBound=function(p) {
	var ret;

    if (p < .5) {
        ret = -Double.MAX_VALUE;
    } else {
        ret = this.getMedian();
    }
    
    return ret;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.  
 */        
CauchyDistributionImpl.prototype.getDomainUpperBound=function(p) {
	var ret;

    if (p < .5) {
        ret = this.getMedian();
    } else {
        ret = Double.MAX_VALUE;
    }
    
    return ret;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.   
 */        
CauchyDistributionImpl.prototype.getInitialDomain=function(p) {
	var ret;

    if (p < .5) {
        ret = this.getMedian() - this.getScale();
    } else if (p > .5) {
        ret = this.getMedian() + this.getScale();
    } else {
        ret = this.getMedian();
    }
    
    return ret;
};

/**
 * Access the median.
 */       
CauchyDistributionImpl.prototype.getMedian=function() {
	return this.median;
};

/**
 * Access the scale parameter. 
 */          
CauchyDistributionImpl.prototype.getScale=function() {
	return this.scale;
};

/**
 * For this distribution, X, this method returns the critical point x, such that P(X < x) = p. 
 */       
CauchyDistributionImpl.prototype.inverseCumulativeProbability=function(p) {
	var ret;
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"probability argument must be between 0 and 1 (inclusive)");
    } else if (p == 0) {
        ret = Double.NEGATIVE_INFINITY;
    } else  if (p == 1) {
        ret = Double.POSITIVE_INFINITY;
    } else {
        ret = this.median + this.scale * Math.tan(Math.PI * (p - .5));
    }
    return ret;
};

/**
 * Modify the median.
 */          
CauchyDistributionImpl.prototype.setMedian=function(median) {
	this.median = median;
};

/**
 * Modify the scale parameter.
 */           
CauchyDistributionImpl.prototype.setScale=function(s) {
	if (s <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Scale must be positive.");
    }       
    this.scale = s;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Character class references to java.lang.Character of J2SE1.4 */
 
/**
 * constructor
 * param value 
 */
function Character(value){
	this.jsjava_class="jsjava.lang.Character";
    if(value==undefined||value.length>1){
        return;
    }else{
        this.value=value;
    }
}

/**
 * check whether the input value is a char value
 * param c
 */
Character.checkValid=function(c){
    var type=typeof(c);
    if(type=="string"&&c.length==1){
    	return true;
    }
    return false;
};

/**
 * return the object's char value
 */
Character.prototype.charValue=function(){
    return this.value; 
};

/**
 * compare whether this object value is equals to input Character object value
 * param b input Character object
 */
Character.prototype.compareTo=function(c){
    if(b==undefined){
        return -1; 
    }
    if(this.value==b.value){
        return 1; 
    }else{
        return -1;  
    }
};

/**
 * return a string description
 */
Character.prototype.toString=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Character.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Character"){
        return this.value==o.value; 
    }
    return false;
};

/**
 * return the boolean value whether the input c is a digit
 * param c
 */
Character.isDigit=function(c){
    return !isNaN(c);
};

/**
 * change the c to lower case
 * param c
 */
Character.toLowerCase=function(c){
    if(Character.checkValid(c)){
        return c.toLowerCase();
    }

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The CharRange class references to org.apache.commons.lang.CharRange */
 
/**
 * Constructs a CharRange over a set of characters, optionally negating the range.
 * param start
 * param end
 * param negated
 */
function CharRange(start,end,negated){
	this.jsjava_class="jsorg.apache.commons.lang.CharRange";
	if(CharRange.checkValid(start)){
		this.start=start;
		this.end=end;
	}
	this.negated=false;//nothing to do in this version
}

/**
 * check whether the input value is a char value
 * param c
 */
CharRange.checkValid=function(c){
    var type=typeof(c);
    if(type=="string"&&c.length==1){
    	return true;
    }
    return false;
};

/**
 * Is the character specified contained in this range.
 * param ch
 */
CharRange.prototype.contains=function(ch){
	if(!CharRange.checkValid(ch)){
		return false;
	}
	if(ch>=this.start&&ch<=this.end){
		return true;
	}
	return false;
};

/**
 * Are all the characters of the passed in range contained in this range.
 * param range
 */
CharRange.prototype.containsRange=function(range){
	if(range.start>=this.start&&range.end<=this.end){
		return true;
	}
	return false;
};

/**
 * Gets the start character for this character range.
 */
CharRange.prototype.getStart=function(){
	return this.start;
};

/**
 * Gets the end character for this character range.
 */
CharRange.prototype.getEnd=function(){
	return this.end;
};

/**
 * Is this CharRange negated.
 */
CharRange.prototype.isNegated=function(){
	return this.negated;
};

/**
 * Gets a string representation of the character range.
 */
CharRange.prototype.toString=function(){
	return "["+this.start+","+this.end+"]";
};

/**
 * Compares two CharRange objects
 * param o
 */
CharRange.prototype.equals=function(o){
	if(o.start==this.start&&this.end==this.end){
		return true;
	}
	return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The CharSet class references to org.apache.commons.lang.CharSet */
 
function CharSet(str){
	this.jsjava_class="jsorg.apache.commons.lang.CharSet";
	if(str==undefined){
		str="";
	}
	this.str=str;
}

/**
 * check whether the input value is a char value
 * param c
 */
CharSet.checkValid=function(c){
    var type=typeof(c);
    if(type=="string"&&c.length==1){
    	return true;
    }
    return false;
};

/**
 * Does the CharSet contain the specified character ch.
 * param ch
 */
CharSet.prototype.contains=function(ch){
	if(!CharSet.checkValid(ch)){
		return false;
	}
	for(var i=0;i<this.str.length;i++){
		if(this.str.charAt(i)==ch){
			return true;
		}
	}
	return false;
};

/**
 * Get CharRange object from the CharSet
 */
CharSet.prototype.getCharRange=function(){
	var arr=new Array(this.str.length);
	for(var i=0;i<this.str.length;i++){
		arr[i]=this.str.charAt(i);
	}
	arr.sort();
	return new CharRange(arr[0],arr[arr.length-1],false);
};

/**
 * Gets a string representation of the set.
 */
CharSet.prototype.toString=function(){
	return this.str;
};

/**
 * Compares two CharSet objects
 */
CharSet.prototype.equals=function(o){
	if(o.str=this.str){
		return true;
	}
	return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The CharSetUtils class references to org.apache.commons.lang.CharSetUtils */
 
function CharSetUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.CharSetUtils";
}

/**
 * Takes an argument in set-syntax, returns the number of characters present in the specified string.
 * param str String to count characters in, may be null
 * param arr String set of characters to count, may be null
 */
CharSetUtils.count=function(str,set){
	if(str==null||str==""||set==null||set==""){
		return 0;
	}
	var count=0;
	for(var i=0;i<str.length;i++){
		if(set.indexOf(str.charAt(i))!=-1){
			count++;
		}
	}
	return count;
};

/**
 * Takes an argument in set-syntax, see evaluateSet, and deletes any of characters present 
 * in the specified string.
 * param str String to delete characters from, may be null
 * param set String set of characters to delete, may be null 
 */
CharSetUtils.remove=function(str,set){
	if(str==null){
		return null;
	}
	if(str==""){
		return "";
	}
	if(set==null||set==""){
		return str;
	}
	var nstr="";
	for(var i=0;i<str.length;i++){
		var ch=str.charAt(i);
		if(set.indexOf(ch)==-1){
			nstr+=ch;
		}
	}
	return nstr;
};

/**
 * Takes an argument in set-syntax, see evaluateSet, and keeps any of characters present in the specified string.
 * param str String to keep characters from, may be null
 * param set String set of characters to keep, may be null
 */
CharSetUtils.keep=function(str,set){
	if(str==null){
		return null;
	}
	if(str==""||set==null||set==""){
		return "";
	}
	var nstr="";
	for(var i=0;i<str.length;i++){
		var ch=str.charAt(i);
		if(set.indexOf(ch)!=-1){
			nstr+=ch;
		}
	}
	return nstr;
};

/**
 * Squeezes any repetitions of a character that is mentioned in the supplied set.
 * param str the string to squeeze, may be null
 * param set the character set to use for manipulation, may be null
 */
CharSetUtils.squeeze=function(str,set){
	if(str==null||str==""){
		return str;
	}
	if(set==null||set==""){
		return str;
	}
	for(var i=0;i<set.length;i++){
		var ch=set.charAt(i);
		str=str.replace(new RegExp(ch+"{2,}","g"),ch);
	}
	return str;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The CharUtils class references to org.apache.commons.lang.CharUtils */
 
function CharUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.CharUtils";
}

/**
 * check whether the input value is a char value
 * param c
 */
CharUtils.checkValid=function(c){
    var type=typeof(c);
    if(type=="string"&&c.length==1){
    	return true;
    }
    return false;
};

/**
 * Checks whether the character is ASCII 7 bit.
 * param ch
 */
CharUtils.isAscii=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch < 128;
};

/**
 * Checks whether the character is ASCII 7 bit alphabetic.
 * param ch
 */
CharUtils.isAsciiAlpha=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return (ch >= 'A'.charCodeAt(0) && ch <= 'Z'.charCodeAt(0)) || (ch >= 'a'.charCodeAt(0) && ch <= 'z'.charCodeAt(0));
};

/**
 * Checks whether the character is ASCII 7 bit alphabetic lower case.
 * param ch
 */
CharUtils.isAsciiAlphaLower=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch >= 'a'.charCodeAt(0) && ch <= 'z'.charCodeAt(0);
};

/**
 * Checks whether the character is ASCII 7 bit numeric.
 * param ch
 */
CharUtils.isAsciiAlphanumeric=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return (ch >= 'A'.charCodeAt(0) && ch <= 'Z'.charCodeAt(0)) || (ch >= 'a'.charCodeAt(0) && ch <= 'z'.charCodeAt(0)) || (ch >= '0'.charCodeAt(0) && ch <= '9'.charCodeAt(0));
};

/**
 * Checks whether the character is ASCII 7 bit alphabetic upper case.
 * param ch
 */
CharUtils.isAsciiAlphaUpper=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch >= 'A'.charCodeAt(0) && ch <= 'Z'.charCodeAt(0);
};

/**
 * Checks whether the character is ASCII 7 bit control.
 * param ch
 */
CharUtils.isAsciiControl=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch < 32 || ch == 127;
};

/**
 * Checks whether the character is ASCII 7 bit numeric.
 * param ch
 */
CharUtils.isAsciiNumeric=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch >= '0'.charCodeAt(0) && ch <= '9'.charCodeAt(0);
};

/**
 * Checks whether the character is ASCII 7 bit printable.
 * param ch
 */
CharUtils.isAsciiPrintable=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch >= 32 && ch < 127;
};

/**
 * Converts the Character to a char handling null.
 * param chobj
 * param defaultValue
 */
CharUtils.toChar=function(chobj,defaultValue){
	if(chobj==null){
		return defaultValue;
	}
	if(typeof(chobj=="object")){
		return chobj.charValue();
	}
	return;
};

/**
 * Converts the character to the Integer it represents, throwing an exception if the character is not numeric.
 * param ch
 * param defaultValue
 */
CharUtils.toIntValue=function(ch,defaultValue){	
	if(defaultValue!=undefined){
		if(isNaN(defaultValue)){
			return;
		}
	}
	if(ch==null){
		return defaultValue;
	}
	if(isNaN(ch)){
		return;
	}
	if(CharUtils.checkValid(ch)){
		return parseInt(ch);
	}
};

/**
 * Converts the character to a Character.
 * param ch
 */
CharUtils.toCharacterObject=function(ch){
	return new Character(ch);
};

CharUtils.toString=function(ch){
	return ch;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function ChinaChineseValidator(){
	this.jsjava_class="jsorg.eob.validator.country.cn.ChinaChineseValidator";
}

/**
 * Check whether the given value is valid chinese string
 * param str - the given value
 */
ChinaChineseValidator.validate=function(str){
	var regx=/^[\u4e00-\u9fa5]+$/;
    return regx.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function ChinaCity(){
	this.jsjava_class="jsorg.eob.information.country.cn.ChinaCity";
	this.counties=new List();
}

ChinaCity.TYPE_PROVINCE=0;
ChinaCity.TYPE_CITY=1;
ChinaCity.TYPE_AUTONOMOUS_PREFECTURE=2;
ChinaCity.TYPE_PREFECTURE_MENG=3;
ChinaCity.TYPE_PREFECTURE_DIQU=4;

/**
 * Set the city id
 * param id - city id
 */
ChinaCity.prototype.setId=function(id){
	this.id=id;
};

/**
 * Get the city id
 */
ChinaCity.prototype.getId=function(){
	return this.id;
};

/**
 * Set the city name
 * param name - city name
 */
ChinaCity.prototype.setName=function(name){
	this.name=name;
};

/**
 * Get the city name
 */
ChinaCity.prototype.getName=function(){
	return this.name;
};

/**
 * Set the city type
 * param type - city type
 */
ChinaCity.prototype.setType=function(type){
	this.type=type;
};

/**
 * Get the city type
 */
ChinaCity.prototype.getType=function(){
	return this.type;
};

/**
 * Set the city short name
 * param shortName - city short name
 */
ChinaCity.prototype.setShortName=function(shortName){
	this.shortName=shortName;
};

/**
 * Get the city short name
 */
ChinaCity.prototype.getShortName=function(){
	return this.shortName;
};

/**
 * Check whether the city is province level
 */
ChinaCity.prototype.isProvince=function(){
	return this.type==ChinaCity.TYPE_PROVINCE;
};

/**
 * Check whether the city is city level
 */
ChinaCity.prototype.isCity=function(){
	return this.type==ChinaCity.TYPE_CITY;
};

/**
 * Check whether the city is autonomous prefecture
 */
ChinaCity.prototype.isAutonomousPrefecture=function(){
	return this.type==ChinaCity.TYPE_AUTONOMOUS_PREFECTURE;
};

/**
 * Check whether the city is prefecture
 */
ChinaCity.prototype.isPrefectureMeng=function(){
	return this.type==ChinaCity.TYPE_PREFECTURE_MENG;
};

/**
 * Check whether the city is prefecture
 */
ChinaCity.prototype.isPrefectureDiqu=function(){
	return this.type==ChinaCity.TYPE_PREFECTURE_DIQU;
};

/**
 * Set the province belonged to
 * param province - the province belonged to
 */
ChinaCity.prototype.setProvince=function(province){
	this.province=province;
};

/**
 * Get the province belonged to
 */
ChinaCity.prototype.getProvince=function(){
	return this.province;
};

/**
 * Set the city postcode
 * param postcode - the city postcode
 */
ChinaCity.prototype.setPostcode=function(postcode){
	this.postcode=postcode;
};

/**
 * Get the city postcode
 */
ChinaCity.prototype.getPostcode=function(){
	return this.postcode;
};

/**
 * Set the city phone area code
 * param phoneAreaCode - the city phone area code
 */
ChinaCity.prototype.setPhoneAreaCode=function(phoneAreaCode){
	this.phoneAreaCode=phoneAreaCode;
};

/**
 * Get the city phone area code
 */
ChinaCity.prototype.getPhoneAreaCode=function(){
	return this.phoneAreaCode;
};

/**
 * Set the city region code
 * param regionCode - the city region code
 */
ChinaCity.prototype.setRegionCode=function(regionCode){
	this.regionCode=regionCode; 
};

/**
 * Get the city region code
 */
ChinaCity.prototype.getRegionCode=function(){
	return this.regionCode;
};

/**
 * Add county
 * param county
 */
ChinaCity.prototype.addCounty=function(county){
	this.counties.add(county);
};

/**
 * Get county by county id
 * param countyId
 */
ChinaCity.prototype.getCountyById=function(countyId){
	var it=this.iterator();
	while(it.hasNext()){
		var county=it.next();
		if(county.getId()==countyId){
			return county;
		}
	}
};

/**
 * Get county by county name
 * param countyName
 */
ChinaCity.prototype.getCountyByName=function(countyName){
	var it=this.iterator();
	while(it.hasNext()){
		var county=it.next();
		if(county.getName()==countyName){
			return county;
		}
	}
};

/**
 * Convert to iterator object
 */
ChinaCity.prototype.iterator=function(){
	return this.counties.iterator();
};

/**
 * Get all counties belonged to the city
 */
ChinaCity.prototype.getCounties=function(){
	return this.counties;
};

/**
 * Get number of counties
 */
ChinaCity.prototype.getSize=function(){
	return this.counties.getSize();
};

/**
 * Get the city description
 */
ChinaCity.prototype.toString=function(){
	var str="["+this.id+","+this.name+","+this.postcode+","+this.phoneAreaCode+","+this.regionCode+"]";
	return str;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function ChinaCountry(){
	this.jsjava_class="jsorg.eob.information.country.cn.ChinaCountry";
	this.provinces=new List();
	this.id="china";
	this.name="\u4E2D\u56FD";
}

/**
 * Get the country id
 */
ChinaCountry.prototype.getId=function(){
	return "china";
};

/**
 * Get the country name
 */
ChinaCountry.prototype.getName=function(){
	return "\u4E2D\u56FD";
};

/**
 * Add province
 * param province
 */
ChinaCountry.prototype.addProvince=function(province){
	this.provinces.add(province);
};

/**
 * Get province by its id
 * param provinceId
 */
ChinaCountry.prototype.getProvinceById=function(provinceId){
	var it=this.iterator();
	while(it.hasNext()){
		var province=it.next();
		if(province.getId()==provinceId){
			return province;
		}
	}
};

/**
 * Get province by its name
 * param provinceName
 */
ChinaCountry.prototype.getProvinceByName=function(provinceName){
	var it=this.iterator();
	while(it.hasNext()){
		var province=it.next();
		if(province.getName()==provinceName){
			return province;
		}
	}
};

/**
 * Convert to iterator object
 */
ChinaCountry.prototype.iterator=function(){
	return this.provinces.iterator();
};

/**
 * Get all provinces
 */
ChinaCountry.prototype.getprovinces=function(){
	return this.provinces;
};

/**
 * Get number of provinces
 */
ChinaCountry.prototype.getSize=function(){
	return this.provinces.getSize();
};

/**
 * Get the description
 */
ChinaCountry.prototype.toString=function(){
	var str="["+this.id+","+this.name+"]";
	return str;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */
function ChinaCounty(){
	this.jsjava_class="jsorg.eob.information.country.cn.ChinaCounty";
	this.towns=new List();
}

ChinaCounty.TYPE_COUNTY=0;
ChinaCounty.TYPE_AUTONOMOUS_COUNTY=1;
ChinaCounty.TYPE_CITY=2;
ChinaCounty.TYPE_DISTRICT=3;

/**
 * Set the county id
 * param id - county id
 */
ChinaCounty.prototype.setId=function(id){
	this.id=id;
};

/**
 * Get the county id
 */
ChinaCounty.prototype.getId=function(){
	return this.id;
};

/**
 * Set the county name
 * param name - county name
 */
ChinaCounty.prototype.setName=function(name){
	this.name=name;
};

/**
 * Get the county name
 */
ChinaCounty.prototype.getName=function(){
	return this.name;
};

/**
 * Set the county type
 * param type - county type
 */
ChinaCounty.prototype.setType=function(type){
	this.type=type;
};

/**
 * Get the county type
 */
ChinaCounty.prototype.getType=function(){
	return this.type;
};

/**
 * Check whether the city is county
 */
ChinaCounty.prototype.isCounty=function(){
	return this.type==ChinaCounty.TYPE_COUNTY;
};

/**
 * Check whether the county is autonomous county
 */
ChinaCounty.prototype.isAutonomousCounty=function(){
	return this.type==ChinaCounty.TYPE_AUTONOMOUS_COUNTY;
};

/**
 * Check whether the county is city
 */
ChinaCounty.prototype.isCity=function(){
	return this.type==ChinaCounty.TYPE_CITY;
};

/**
 * Check whether the county is district
 */
ChinaCounty.prototype.isDistrict=function(){
	return this.type==ChinaCounty.TYPE_DISTRICT;
};

/**
 * Set the city belonged to
 */
ChinaCounty.prototype.setCity=function(city){
	this.city=city;
};

/**
 * Set the city belonged to
 */
ChinaCounty.prototype.setCity=function(city){
	this.city=city;
};


/**
 * Set the city belonged to
 * param city
 */
ChinaCounty.prototype.setCity=function(city){
	this.city=city;
};

/**
 * Get the city belonged to
 */
ChinaCounty.prototype.getCity=function(){
	return this.city;
};

/**
 * Add town
 * param town
 */
ChinaCounty.prototype.addTown=function(town){
	this.towns.add(town);
};

/**
 * Get town by id
 * param townId
 */
ChinaCounty.prototype.getTownById=function(townId){
	var it=this.iterator();
	while(it.hasNext()){
		var town=it.next();
		if(town.getId()==townId){
			return town;
		}
	}
};

/**
 * Get town by name
 * param townName
 */
ChinaCounty.prototype.getTownByName=function(townName){
	var it=this.iterator();
	while(it.hasNext()){
		var town=it.next();
		if(town.getName()==townName){
			return town;
		}
	}
};

/**
 * Convert to iterator object
 */
ChinaCounty.prototype.iterator=function(){
	return this.towns.iterator();
};

/**
 * Get all counties belonged to the county
 */
ChinaCounty.prototype.getTowns=function(){
	return this.towns;
};

/**
 * Get number of towns
 */
ChinaCounty.prototype.getSize=function(){
	return this.towns.getSize();
};

/**
 * Get the county description
 */
ChinaCounty.prototype.toString=function(){
	var str="["+this.id+","+this.name+"]";
	return str;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function ChinaIDCardValidator(){
	this.jsjava_class="jsorg.eob.validator.country.cn.ChinaIDCardValidator";
}

/**
 * Check whether the given value is valid ID card
 * param str - the given value
 */
ChinaIDCardValidator.validate=function(str){
	var regx=/^(\d{15}|\d{17}[\dx])$/;
    return regx.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function ChinaInformationLoader(){
	this.jsjava_class="jsorg.eob.information.country.cn.ChinaInformationLoader";	
}

ChinaInformationLoader.INFO_PROVINCE=[
["Beijing","BJ","\u5317\u4eac\u5e02","\u4eac","110000",2],
["Tianjing","TJ","\u5929\u6d25\u5e02","\u6d25","120000",2],
["Hebei","HE","\u6cb3\u5317\u7701","\u5180","130000",0],
["Shanxi","SX","\u5c71\u897f\u7701","\u664b","140000",0],
["Inner Mongoria IM","NM","\u5185\u8499\u53e4\u81ea\u6cbb\u533a","\u5185\u8499\u53e4","150000",1],
["Liaoning","LN","\u8fbd\u5b81\u7701","\u8fbd","210000",0],
["Jilin","JL","\u5409\u6797\u7701","\u5409","220000",0],
["Heilongjiang","HJ","\u9ed1\u9f99\u6c5f\u7701","\u9ed1","230000",0],
["Shanghai","SH","\u4e0a\u6d77\u5e02","\u6caa","310000",2],
["Jiangsu","JS","\u6c5f\u82cf\u7701","\u82cf","320000",0],
["Zhejiang","ZJ","\u6d59\u6c5f\u7701","\u6d59","330000",0],
["Anhui","AH","\u5b89\u5fbd\u7701","\u7696","340000",0],
["Fujian","FJ","\u798f\u5efa\u7701","\u95fd","350000",0],
["Jiangxi","JX","\u6c5f\u897f\u7701","\u8d63","360000",0],
["Shandong","SD","\u5c71\u4e1c\u7701","\u9c81","370000",0],
["Henan","HA","\u6cb3\u5357\u7701","\u8c6b","410000",0],
["Hubei","HB","\u6e56\u5317\u7701","\u9102","420000",0],
["Hunan","HN","\u6e56\u5357\u7701","\u6e58","430000",0],
["Guangdong","GD","\u5e7f\u4e1c\u7701","\u7ca4","440000",0],
["Guangxi","GX","\u5e7f\u897f\u58ee\u65cf\u81ea\u6cbb\u533a","\u6842","450000",1],
["Hainan","HI","\u6d77\u5357\u7701","\u743c","460000",0],
["Chongqing","CQ","\u91cd\u5e86\u5e02","\u6e1d","500000",2],
["Sichuan","SC","\u56db\u5ddd\u7701",["\u5ddd","\u8700"],"510000",0],
["Guizhou","GZ","\u8d35\u5dde\u7701",["\u9ed4","\u8d35"],"520000",0],
["Yunnan","YN","\u4e91\u5357\u7701",["\u6ec7","\u4e91"],"530000",0],
["Tibet","XZ","\u897f\u85cf\u81ea\u6cbb\u533a","\u85cf","540000",1],
["Shaanxi","SN","\u9655\u897f\u7701",["\u9655","\u79e6"],"610000",0],
["Gansu","GS","\u7518\u8083\u7701",["\u7518","\u9647"],"620000",0],
["Qinghai","QH","\u9752\u6d77\u7701","\u9752","630000",0],
["Ningxia","NX","\u5b81\u590f\u56de\u65cf\u81ea\u6cbb\u533a","\u5b81","640000",1],
["Xinjiang","XJ","\u65b0\u7586\u7ef4\u543e\u5c14\u81ea\u6cbb\u533a","\u65b0","650000",1],
["Hong Kong","HK","\u9999\u6e2f\u7279\u522b\u884c\u653f\u533a","\u6e2f","",3],
["Macao","MO","\u6fb3\u95e8\u7279\u522b\u884c\u653f\u533a","\u6fb3","",3],
["Taiwan","TW","\u53f0\u6e7e\u7701","\u53f0","",3]
];

ChinaInformationLoader.INFO_CITY=[
["Beijing",[["Beijing","\u5317\u4eac\u5e02","\u4eac","100001","110000","010",0]]],
["Tianjing",[["Tianjing","\u5929\u6d25\u5e02","\u6d25","300040","120000","022",0]]],
["Hebei",[["Shijiazhuang","\u77f3\u5bb6\u5e84\u5e02","","050011","130100","0311",1],["Tangshan","\u5510\u5c71\u5e02","","063006","130200","0315",1],["Qinhuangdao","\u79e6\u7687\u5c9b\u5e02","","066000","130300","0335",1],["Handan","\u90af\u90f8\u5e02","","056002","130400","0310",1],["Xingtai","\u90a2\u53f0\u5e02","","054001","130500","0319",1],["Baoding","\u4fdd\u5b9a\u5e02","","071052","130600","0312",1],["Zhangjiakou","\u5f20\u5bb6\u53e3","","075061","130700","0313",1],["Chengde","\u627f\u5fb7\u5e02","","067000","130800","0314",1],["Cangzhou","\u6ca7\u5dde\u5e02","","061001","130900","0317",1],["0317","\u5eca\u574a\u5e02","065000","131000","0316","",1],["Hengshui","\u8861\u6c34\u5e02","","053000","131100","0318",1]]],
["Shanxi",[["Taiyuan","\u592a\u539f\u5e02","","030082","140100","0351",1],["Datong","\u5927\u540c\u5e02","","037008","140200","0352",1],["Yangquan","\u9633\u6cc9\u5e02","","045000","140300","0353",1],["Changzhi","\u957f\u6cbb\u5e02","","046000","140400","0355",1],["Jincheng","\u664b\u57ce\u5e02","","048000","140500","0356",1],["Shuozhou","\u6714\u5dde\u5e02","","038500","140600","0349",1],["Jinzhong","\u664b\u4e2d\u5e02","","030600","140700","0354",1],["Yuncheng","\u8fd0\u57ce\u5e02","","044000","140800 ","0359",1],["Xinzhou","\u5ffb\u5dde\u5e02","","034000","140900","0350",1],["Linfen","\u4e34\u6c7e\u5e02","","041000","141000","0357",1],["L\u00fcliang","\u5415\u6881\u5e02","","033000","141100","0358",1]]],
["Inner Mongoria IM",[["Huhehaote","\u547c\u548c\u6d69\u7279\u5e02","","010020","150100","0471",1],["Baotou","\u5305\u5934\u5e02","","014025","150200","0472",1],["Wuhai","\u4e4c\u6d77\u5e02","","016000","150300","0473",1],["Chifeng","\u8d64\u5cf0\u5e02","","024000","150400","0476",1],["Tongliao","\u901a\u8fbd\u5e02","","028000","150500","0475",1],["eerduosi","\u9102\u5c14\u591a\u65af\u5e02","","017004","150600","0477",1],["Hulunbeier","\u547c\u4f26\u8d1d\u5c14\u5e02","","021008","150700","0470",1],["Bayannaoer","\u5df4\u5f66\u6dd6\u5c14\u5e02","","015001","150800","0478",1],["Wulanchabu","\u4e4c\u5170\u5bdf\u5e03\u5e02","","012000","150900","0474",1],["Xingan","\u5174\u5b89\u76df","","137401","152200","0482",3],["Xilinguole","\u9521\u6797\u90ed\u52d2\u76df","","026021","152500","0479",3],["Alashan","\u963f\u62c9\u5584\u76df","","750306","152900","0483",3]]],
["Liaoning",[["Shenyang","\u6c88\u9633\u5e02","","110013","210100","024",1],["Dalian","\u5927\u8fde\u5e02","","116000","210200","0411",1],["Anshan","\u978d\u5c71\u5e02","","210300","114001","0412",1],["Fushun","\u629a\u987a\u5e02","","113008","210400","0413",1],["Benxi","\u672c\u6eaa\u5e02","","117000","210500","0414",1],["Dandong","\u4e39\u4e1c\u5e02","","118000","210600","0415",1],["Jinzhou","\u9526\u5dde\u5e02","","121000","210700","0416",1],["Yingkou","\u8425\u53e3\u5e02","","210800","115003","0417",1],["Fuxin","\u961c\u65b0\u5e02","","123000","210900","0418",1],["Liaoyang","\u8fbd\u9633\u5e02","","111000","211000","0419",1],["Panjin","\u76d8\u9526\u5e02","","124010","211100","0427",1],["Tieling","\u94c1\u5cad\u5e02","","112000","211200","0410",1],["Chaoyang","\u671d\u9633\u5e02","","122000","211300","0421",1],["Huludao","\u846b\u82a6\u5c9b\u5e02","","125000","211400","0429",1]]],
["Jilin",[["Changchun","\u957f\u6625\u5e02","","130061","220100","0431",1],["Jilin","\u5409\u6797\u5e02","","132011","220200","0432",1],["Siping","\u56db\u5e73\u5e02","","136000","220300","0434",1],["Liaoyuan","\u8fbd\u6e90\u5e02","","136200","220400","0437",1],["Tonghua","\u901a\u5316\u5e02","","134001","220500","0435",1],["Baishan","\u767d\u5c71\u5e02","","134300","220600","0439",1],["Songyuan","\u677e\u539f\u5e02","","138000","220700","0438",1],["Baicheng","\u767d\u57ce\u5e02","","137000","220800","0436",1],["YanbianChaoxianzu","\u5ef6\u8fb9\u671d\u9c9c\u65cf\u81ea\u6cbb\u5dde","","133000","222400","0433",2]]],
["Heilongjiang",[["Haerbin","\u54c8\u5c14\u6ee8\u5e02","","150028","230100","0451",1],["Qiqihaer","\u9f50\u9f50\u54c8\u5c14\u5e02","","161005","230200","0452",1],["Jixi","\u9e21\u897f\u5e02","","158100","230300","0467",1],["Hegang","\u9e64\u5c97\u5e02","","154100","230400","0468",1],["Shuangyashan","\u53cc\u9e2d\u5c71\u5e02","","155100","230500","0469",1],["Daqing","\u5927\u5e86\u5e02","","163311","230600","0459",1],["Yichun","\u4f0a\u6625\u5e02","","153000","230700","0458",1],["Jiamusi","\u4f73\u6728\u65af\u5e02","","154002","230800","0454",1],["Qitaihe","\u4e03\u53f0\u6cb3\u5e02","","154600","230900","0464",1],["Mudanjiang","\u7261\u4e39\u6c5f\u5e02","","157000","231000","0453",1],["Heihe","\u9ed1\u6cb3\u5e02","","164300","231100","0456",1],["Suihua","\u7ee5\u5316\u5e02","","152000","231200","0455",1],["Daxinganling","\u5927\u5174\u5b89\u5cad\u5730\u533a","","165000","232700","0457",4]]],
["Shanghai",[["Shanghai","\u4e0a\u6d77\u5e02","\u6caa","200000","310000","021",1]]],
["Jiangsu",[["Nanjing","\u5357\u4eac\u5e02","","210008","320100","025",1],["Wuxi","\u65e0\u9521\u5e02","","214001","320200","0510",1],["Xuzhou","\u5f90\u5dde\u5e02","","221003","320300","0516",1],["Changzhou","\u5e38\u5dde\u5e02","","213022","320400","0519",1],["Suzhou","\u82cf\u5dde\u5e02","","215002","320500","0512",1],["Nantong","\u5357\u901a\u5e02","","226001","320600","0513",1],["Lianyungang","\u8fde\u4e91\u6e2f\u5e02","","222002","320700","0518",1],["Huaian","\u6dee\u5b89\u5e02","","223001","320800","0517",1],["Yancheng","\u76d0\u57ce\u5e02","","224005","320900","0515",1],["Yangzhou","\u626c\u5dde\u5e02","","225002","321000","0514",1],["Zhenjiang","\u9547\u6c5f\u5e02","","212001","321100","0511",1],["Taizhou","\u6cf0\u5dde\u5e02","","225300","321200","0523",1],["Suqian","\u5bbf\u8fc1\u5e02","","223800","321300","0527",1]]],
["Zhejiang",[["Hangzhou","\u676d\u5dde\u5e02","","310026","330100","0571",1],["Ningbo","\u5b81\u6ce2\u5e02","","315000","330200","0574",1],["Wenzhou","\u6e29\u5dde\u5e02","","325000","330300","0577",1],["Jiaxing","\u5609\u5174\u5e02","","314000","330400","0573",1],["Huzhou","\u6e56\u5dde\u5e02","","313000","330500","0572",1],["Shaoxing","\u7ecd\u5174\u5e02","","312000","330600","0575",1],["Jinhua","\u91d1\u534e\u5e02","","321000","330700","0579",1],["Quzhou","\u8862\u5dde\u5e02","","324002","330800","0570",1],["Zhoushan","\u821f\u5c71\u5e02","","316000","330900","0580",1],["Taizhou","\u53f0\u5dde\u5e02","","318000","331000","0576",1],["Lishui","\u4e3d\u6c34\u5e02","","323000","331100","0578",1]]],
["Anhui",[["Hefei","\u5408\u80a5\u5e02","","230000","340100","0551",1],["Wuhu","\u829c\u6e56\u5e02","","241000","340200","0553",1],["Bengbu","\u868c\u57e0\u5e02","","233000","340300","0552",1],["Huainan","\u6dee\u5357\u5e02","","232001","340400","0554",1],["Maanshan","\u9a6c\u978d\u5c71\u5e02","","243001","340500","0555",1],["Huaibei","\u6dee\u5317\u5e02","","235000","340600","0561",1],["Tongling","\u94dc\u9675\u5e02","","244000","340700","0562",1],["Anqing","\u5b89\u5e86\u5e02","","246001","340800","0556",1],["Huangshan","\u9ec4\u5c71\u5e02","","245000","341000","0559",1],["Chuzhou","\u6ec1\u5dde\u5e02","","239000","341100","0550",1],["Fuyang","\u961c\u9633\u5e02","","236033","0558","341200",1],["Suzhou","\u5bbf\u5dde\u5e02","","234000","341300","0557",1],["Chaohu","\u5de2\u6e56\u5e02","","238000","341400","0565",1],["Luan","\u516d\u5b89\u5e02","","237006","341500","0564",1],["Bozhou","\u4eb3\u5dde\u5e02","","236802","341600","0558",1],["Chizhou","\u6c60\u5dde\u5e02","","247100","341700","0566",1],["Xuancheng","\u5ba3\u57ce\u5e02","","242000","341800","0563",1]]],
["Fujian",[["Fuzhou","\u798f\u5dde\u5e02","","350001","350100","0591",1],["Xiamen","\u53a6\u95e8\u5e02","","361003","350200","0592",1],["Putian","\u8386\u7530\u5e02","","351100","350300","0594",1],["Sanming","\u4e09\u660e\u5e02","","365000","350400","0598",1],["Quanzhou","\u6cc9\u5dde\u5e02","","362000","350500","0595",1],["Zhangzhou","\u6f33\u5dde\u5e02","","363000","350600","0596",1],["Nanping","\u5357\u5e73\u5e02","","353000","350700","0599",1],["Longyan","\u9f99\u5ca9\u5e02","","364000","350800","0597",1],["Ningde","\u5b81\u5fb7\u5e02","","352100","350900","0593",1]]],
["Jiangxi",[["Nanchang","\u5357\u660c\u5e02","","330008","360100","0791",1],["Jingdezhen","\u666f\u5fb7\u9547\u5e02","","333000","360200","0798",1],["Pingxiang","\u840d\u4e61\u5e02","","337000","360300","0799",1],["Jiujiang","\u4e5d\u6c5f\u5e02","","332000","360400","0792",1],["Xinyu","\u65b0\u4f59\u5e02","","360500","338025","0790",1],["Yingtan","\u9e70\u6f6d\u5e02","","335000","360600","0701",1],["Ganzhou","\u8d63\u5dde\u5e02","","360700","341000","0797",1],["Jian","\u5409\u5b89\u5e02","","343000","360800","0796",1],["Yichun","\u5b9c\u6625\u5e02","","336000","360900","0795",1],["Fuzhou","\u629a\u5dde\u5e02","","344000","361000","0794",1],["Shangrao","\u4e0a\u9976\u5e02","","334000","361100","0793",1]]],
["Shandong",[["Jinan","\u6d4e\u5357\u5e02","","250001","370100","0531",1],["Qingdao","\u9752\u5c9b\u5e02","","266001","370200","0532",1],["Zibo","\u6dc4\u535a\u5e02","","255039","370300","0533",1],["Zaozhuang","\u67a3\u5e84\u5e02","","277101","370400","0632",1],["Dongying","\u4e1c\u8425\u5e02","","257093","370500","0546",1],["Yantai","\u70df\u53f0\u5e02","","264001","370600","0535",1],["Weifang","\u6f4d\u574a\u5e02","","261041","370700","0536",1],["Weihai","\u5a01\u6d77\u5e02","","264200","371000","0631",1],["Jining","\u6d4e\u5b81\u5e02","","272119","370800","0537",1],["Taian","\u6cf0\u5b89\u5e02","","271000","370900","0538",1],["Rizhao","\u65e5\u7167\u5e02","","276800","371100","0633",1],["Laiwu","\u83b1\u829c\u5e02","","271100","371200","0634",1],["Linyi","\u4e34\u6c82\u5e02","","276001","371300","0539",1],["Dezhou","\u5fb7\u5dde\u5e02","","253012","371400","0534",1],["Liaocheng","\u804a\u57ce\u5e02","","252052","371500","0635",1],["Binzhou","\u6ee8\u5dde\u5e02","","256619","371600","0543",1],["Heze","\u83cf\u6cfd\u5e02","","274020","371700","0530",1]]],
["Henan",[["Zhengzhou","\u90d1\u5dde\u5e02","","450007","410100","0371",1],["Kaifeng","\u5f00\u5c01\u5e02","","475001","410200","0378",1],["Luoyang","\u6d1b\u9633\u5e02","","471000","410300","0379",1],["Pingdingshan","\u5e73\u9876\u5c71\u5e02","","467000","410400","0375",1],["Jiaozuo","\u7126\u4f5c\u5e02","","454002","410800","0391",1],["Hebi","\u9e64\u58c1\u5e02","","458030","410600","0392",1],["Xinxiang","\u65b0\u4e61\u5e02","","453000","410700","0373",1],["Anyang","\u5b89\u9633\u5e02","","455000","410500","0372",1],["Puyang","\u6fee\u9633\u5e02","","457000","410900","0393",1],["Xuchang","\u8bb8\u660c\u5e02","","461000","411000","0374",1],["Luohe","\u6f2f\u6cb3\u5e02","","462000","411100","0395",1],["Sanmenxia","\u4e09\u95e8\u5ce1\u5e02","","472000","411200","0398",1],["Nanyang","\u5357\u9633\u5e02","","473002","411300","0377",1],["Shangqiu","\u5546\u4e18\u5e02","","476000","411400","0370",1],["Xinyang","\u4fe1\u9633\u5e02","","464000","411500","0376",1],["Zhoukou","\u5468\u53e3\u5e02","","466000","411600","0394",1],["humadian","\u9a7b\u9a6c\u5e97\u5e02","","463000","411700","0396",1]]],
["Hubei",[["Wuhan","\u6b66\u6c49\u5e02","\u6c49","430014","420100","027",1],["Huangshi","\u9ec4\u77f3\u5e02","","435003","420200","0714",1],["Xiangfan","\u8944\u6a0a\u5e02","","441021","420600","0710",1],["Shiyan","\u5341\u5830\u5e02","","442000","420300","0719",1],["Jingzhou","\u8346\u5dde\u5e02","","434000","421000","0716",1],["Yichang","\u5b9c\u660c\u5e02","","443000","420500","0717",1],["Jingmen","\u8346\u95e8\u5e02","","448000","420800","0724",1],["Ezhou","\u9102\u5dde\u5e02","","436000","420700","0711",1],["Xiaogan","\u5b5d\u611f\u5e02","","432100","420900","0712",1],["Huanggang","\u9ec4\u5188\u5e02","","438000","421100","0713",1],["Xianning","\u54b8\u5b81\u5e02","","437000","421200","0715",1],["Suizhou","\u968f\u5dde\u5e02","","441300","421300","0722",1],["EnshiTujiazuMiaozu","\u6069\u65bd\u571f\u5bb6\u65cf\u82d7\u65cf\u81ea\u6cbb\u5dde","","445000","422800","0718",1]]],
["Hunan",[["Changsha","\u957f\u6c99\u5e02","","410005","430100","0731",1],["Zhuzhou","\u682a\u6d32\u5e02","","412000","430200","0733",1],["Xiangtan","\u6e58\u6f6d\u5e02","","411100","430300","0732",1],["Hengyang","\u8861\u9633\u5e02","","421001","430400","0734",1],["Shaoyang","\u90b5\u9633\u5e02","","422000","430500","0739",1],["Yueyang","\u5cb3\u9633\u5e02","","414000","430600","0730",1],["Changde","\u5e38\u5fb7\u5e02","","415000","430700","0736",1],["Zhangjiajie","\u5f20\u5bb6\u754c\u5e02","","427000","430800","0744",1],["Yiyang","\u76ca\u9633\u5e02","","413000","430900","0737",1],["Chenzhou","\u90f4\u5dde\u5e02","","423000","431000","0735",1],["Yongzhou","\u6c38\u5dde\u5e02","","425000","431100","0746",1],["Huaihua","\u6000\u5316\u5e02","","418000","431200","0745",1],["Loudi","\u5a04\u5e95\u5e02","","4170000","431300","0738",1],["XiangxiTujiazuMiaozu","\u6e58\u897f\u571f\u5bb6\u65cf\u82d7\u65cf\u81ea\u6cbb\u5dde","","416000","433100","0743",2]]],
["Guangdong",[["Guangzhou","\u5e7f\u5dde\u5e02","","510130","440100","020",1],["Shenzhen","\u6df1\u5733\u5e02","","518027","440300","0755",1],["Zhuhai","\u73e0\u6d77\u5e02","","519000","440400","0756",1],["Shantou","\u6c55\u5934\u5e02","","515031","440500","0754",1],["Shaoguan","\u97f6\u5173\u5e02","","512000","440200","0751",1],["Foshan","\u4f5b\u5c71\u5e02","","528000","440600","0757",1],["Jiangmen","\u6c5f\u95e8\u5e02","","529020","440700","0750",1],["Zhanjiang","\u6e5b\u6c5f\u5e02","","524038","440800","0759",1],["Maoming","\u8302\u540d\u5e02","","525000","440900","0668",1],["Zhaoqing","\u8087\u5e86\u5e02","","526040","441200","0758",1],["Huizhou","\u60e0\u5dde\u5e02","","516001","441300","0752",1],["Meizhou","\u6885\u5dde\u5e02","","514021","441400","0753",1],["Shanwei","\u6c55\u5c3e\u5e02","","516601","441500","0660",1],["Heyuan","\u6cb3\u6e90\u5e02","","517001","441600","0762",1],["Yangjiang","\u9633\u6c5f\u5e02","","529525","441700","0662",1],["Qingyuan","\u6e05\u8fdc\u5e02","","511500","441800","0763",1],["Dongguan","\u4e1c\u839e\u5e02","","523003","441900","0769",1],["Zhongshan","\u4e2d\u5c71\u5e02","","528403","442000","0760",1],["Chaozhou","\u6f6e\u5dde\u5e02","","521000","445100","0768",1],["Jieyang","\u63ed\u9633\u5e02","","522000","445200","0663",1],["Yunfu","\u4e91\u6d6e\u5e02","","527300","445300","0766",1]]],
["Guangxi",[["Nanning","\u5357\u5b81\u5e02","","530012","450100","0771",1],["Liuzhou","\u67f3\u5dde\u5e02","","545001","450200","0772",1],["Guilin","\u6842\u6797\u5e02","","541002","450300","0773",1],["Wuzhou","\u68a7\u5dde\u5e02","","543000","450400","0774",1],["Beihai","\u5317\u6d77\u5e02","","536000","450500","0779",1],["Fangchenggang","\u9632\u57ce\u6e2f\u5e02","","538001","450600","0770",1],["Qinzhou","\u94a6\u5dde\u5e02","","535000","450700","0777",1],["Guigang","\u8d35\u6e2f\u5e02","","537100","450800","0775",1],["Yulin","\u7389\u6797\u5e02","","537000","450900","0775",1],["Baise","\u767e\u8272\u5e02","","533000","451000","0776",1],["Hezhou","\u8d3a\u5dde\u5e02","","542800","451100","0774",1],["Hechi","\u6cb3\u6c60\u5e02","","547000","451200","0778",1],["Laibin","\u6765\u5bbe\u5e02","","546100","451300","0772",1],["Chongzuo","\u5d07\u5de6\u5e02","","532200","451400","0771",1]]],
["Hainan",[["Haikou","\u6d77\u53e3\u5e02","","570145","460100","0898",1],["Sanya","\u4e09\u4e9a\u5e02","","572002","460200","0898",1]]],
["Chongqing",[["Chongqing","\u91cd\u5e86\u5e02","\u6e1d","400000","500000","023",1]]],
["Sichuan",[["Chengdu","\u6210\u90fd\u5e02","","610015","510100","028",1],["Zigong","\u81ea\u8d21\u5e02","","643000","510300","0813",1],["Panzhihua","\u6500\u679d\u82b1\u5e02","","617000","510400","0812",1],["Luzhou","\u6cf8\u5dde\u5e02","","646000","510500","0830",1],["Deyang","\u5fb7\u9633\u5e02","","618000","510600","0838",1],["Mianyang","\u7ef5\u9633\u5e02","","621000","510700","0816",1],["Guangyuan","\u5e7f\u5143\u5e02","","628017","510800","0839",1],["Suining","\u9042\u5b81\u5e02","","629000","510900","0825",1],["Neijiang","\u5185\u6c5f\u5e02","","641000","511000","0832",1],["Leshan","\u4e50\u5c71\u5e02","","614000","511100","0833",1],["Nanchong","\u5357\u5145\u5e02","","637000","511300","0817",1],["Yibin","\u5b9c\u5bbe\u5e02","","644000","511500","0831",1],["Guangan","\u5e7f\u5b89\u5e02","","638500","511600","0826",1],["Dazhou","\u8fbe\u5dde\u5e02","","635000","511700","0818",1],["Meishan","\u7709\u5c71\u5e02","","620010","511400","0833",1],["Yaan","\u96c5\u5b89\u5e02","","625000","511800","0835",1],["Bazhong","\u5df4\u4e2d\u5e02","","636600","511900","0827",1],["Ziyang","\u8d44\u9633\u5e02","","641300","512000","0832",1],["AbaZangzuQiangzu","\u963f\u575d\u85cf\u65cf\u7f8c\u65cf\u81ea\u6cbb\u5dde","","624000","513200","0837",2],["GanziZangzu","\u7518\u5b5c\u85cf\u65cf\u81ea\u6cbb\u5dde","","626000","513300","0836",2],["LiangshanYizu","\u51c9\u5c71\u5f5d\u65cf\u81ea\u6cbb\u5dde","","615000","513400","0834",2]]],
["Guizhou",[["Guiyang","\u8d35\u9633\u5e02","","550001","520100","0851",1],["Liupanshui","\u516d\u76d8\u6c34\u5e02","","553001","520200","0858",1],["Zunyi","\u9075\u4e49\u5e02","","563000","520300","0852",1],["Anshun","\u5b89\u987a\u5e02","","561000","520400","0853",1],["Tongren","\u94dc\u4ec1\u5730\u533a","","554300","522200","0856",4],["Bijie","\u6bd5\u8282\u5730\u533a","","551700","522400","0857",4],["QianxinanBuyizuMiaozu","\u9ed4\u897f\u5357\u5e03\u4f9d\u65cf\u82d7\u65cf\u81ea\u6cbb\u5dde","","562400","522300","0859",2],["QiandongnanMiaozuDongzu","\u9ed4\u4e1c\u5357\u82d7\u65cf\u4f97\u65cf\u81ea\u6cbb\u5dde","","556000","522600","0855",2],["QiannanBuyizuMiaozu","\u9ed4\u5357\u5e03\u4f9d\u65cf\u82d7\u65cf\u81ea\u6cbb\u5dde","","558000","522700","0854",1]]],
["Yunnan",[["Kunming","\u6606\u660e\u5e02","","650011","530100","0871",1],["Qujing","\u66f2\u9756\u5e02","","655000","530300","0874",1],["Yuxi","\u7389\u6eaa\u5e02","","653100","530400","0877",1],["Baoshan","\u4fdd\u5c71\u5e02","","530500","678000","0875",1],["Zhaotong","\u662d\u901a\u5e02","","657000","530600","0870",1],["Lijiang","\u4e3d\u6c5f\u5e02","","674100","530700","0888",1],["Puer","\u666e\u6d31\u5e02","","665000","532700","0879",1],["Lincang","\u4e34\u6ca7\u5e02","","677000","530900","0883",1],["WenshanZhuangzuMiaozu","\u6587\u5c71\u58ee\u65cf\u82d7\u65cf\u81ea\u6cbb\u5dde","","663000","532600","0876",2],["HongheHanizuYizu","\u7ea2\u6cb3\u54c8\u5c3c\u65cf\u5f5d\u65cf\u81ea\u6cbb\u5dde","","661400","532500","0873",2],["XiShuangbannaDaizu","\u897f\u53cc\u7248\u7eb3\u50a3\u65cf\u81ea\u6cbb\u5dde","","666100","532800","0691",2],["ChuxiongYizu","\u695a\u96c4\u5f5d\u65cf\u81ea\u6cbb\u5dde","","675000","532300","0878",2],["DaliBaizu","\u5927\u7406\u767d\u65cf\u81ea\u6cbb\u5dde","","671000","532900","0872",2],["DehongDaizuJingpozu","\u5fb7\u5b8f\u50a3\u65cf\u666f\u9887\u65cf\u81ea\u6cbb\u5dde","","678400","533100","0692",2],["NujiangLisuzu","\u6012\u6c5f\u5088\u5088\u65cf\u81ea\u6cbb\u5dde","","673100","533300","0886",2],["DiqingZangzu","\u8fea\u5e86\u85cf\u65cf\u81ea\u6cbb\u5dde","","674400","533400","0887",2]]],
["Tibet",[["Lasa","\u62c9\u8428\u5e02","","850012","540100","0891",1],["Changdu","\u660c\u90fd\u5730\u533a","","854000","542100","0895",4],["Shannan","\u5c71\u5357\u5730\u533a","","856000","542200","0893",4],["Rikaze","\u65e5\u5580\u5219\u5730\u533a","","857000","542300","0892",4],["Naqu","\u90a3\u66f2\u5730\u533a","","852000","542400","0896",4],["Ali","\u963f\u91cc\u5730\u533a","","859000","542500","0897",4],["Linzhi","\u6797\u829d\u5730\u533a","","860000","542600","0894",4]]],
["Shaanxi",[["Xian","\u897f\u5b89\u5e02","","710000","610100","029",1],["Tongchuan","\u94dc\u5ddd\u5e02","","727000","610200","0919",1],["Baoji","\u5b9d\u9e21\u5e02","","721000","610300","0917",1],["Xianyang","\u54b8\u9633\u5e02","","712000","610400","029",1],["Weinan","\u6e2d\u5357\u5e02","","714000","610500","0913",1],["Yanan","\u5ef6\u5b89\u5e02","","716000","610600","0911",1],["Hanzhong","\u6c49\u4e2d\u5e02","","723000","610700","0916",1],["Yulin","\u6986\u6797\u5e02","","719000","610800","0912",1],["Ankang","\u5b89\u5eb7\u5e02","","725000","610900","0915",1],["Shangluo","\u5546\u6d1b\u5e02","","726000","611000","0914",1]]],
["Gansu",[["Lanzhou","\u5170\u5dde\u5e02","","730030","620100","0931",1],["Jiayuguan","\u5609\u5cea\u5173\u5e02","","735100","620200","0937",1],["Jingchang","\u91d1\u660c\u5e02","","620300","737100","0935",1],["Baiyin","\u767d\u94f6\u5e02","","730900","620400","0943",1],["Tianshui","\u5929\u6c34\u5e02","","741000","620500","0938",1],["Wuwei","\u6b66\u5a01\u5e02","","733000","620600","0935",1],["Zhangye","\u5f20\u6396\u5e02","","734000","620700","0936",1],["Pingliang","\u5e73\u51c9\u5e02","","744000","620800","0933",1],["Jiuquan","\u9152\u6cc9\u5e02","","735000","620900","0937",1],["Qingyang","\u5e86\u9633\u5e02","","745000","621000","0934",1],["Dingxi","\u5b9a\u897f\u5e02","","743000","621100","0932",1],["Longnan","\u9647\u5357\u5e02","","742500","621200","0939",1],["LinxiaHuizu","\u4e34\u590f\u56de\u65cf\u81ea\u6cbb\u5dde","","731100","622900","0930",2],["GannanZangzu","\u7518\u5357\u85cf\u65cf\u81ea\u6cbb\u5dde","","747000","623000","0941",2]]],
["Qinghai",[["Xining","\u897f\u5b81\u5e02","","810000","630100","0971",1],["Haidong","\u6d77\u4e1c\u5730\u533a","","810600","632100","0972",4],["HaibeiZangzu","\u6d77\u5317\u85cf\u65cf\u81ea\u6cbb\u533a","","812200","632200","0970",2],["HuangnanZangzu","\u9ec4\u5357\u85cf\u65cf\u81ea\u6cbb\u5dde","","811300","632300","0973",2],["HainanZangzu","\u6d77\u5357\u85cf\u65cf\u81ea\u6cbb\u5dde","","813000","632500","0974",2],["GuoluoZangzu","\u679c\u6d1b\u85cf\u65cf\u81ea\u6cbb\u5dde","","814000","632600","0975",2],["YushuZangzu","\u7389\u6811\u85cf\u65cf\u81ea\u6cbb\u5dde","","815000","632700","0976",2],["HaixiMengguzu","\u6d77\u897f\u8499\u53e4\u65cf\u85cf\u65cf\u81ea\u6cbb\u5dde","","817000","632800","0977",2]]],
["Ningxia",[["Yinchuan","\u94f6\u5ddd\u5e02","","750004","640100","0951",1],["Shizuishan","\u77f3\u5634\u5c71\u5e02","","753000","640200","0952",1],["Wuzhong","\u5434\u5fe0\u5e02","","751100","640300","0953",1],["Guyuan","\u56fa\u539f\u5e02","","756000","640400","0954",1],["Zhongwei","\u4e2d\u536b\u5e02","","751700","640500","0953",1]]],
["Xinjiang",[["Wulumuqi","\u4e4c\u9c81\u6728\u9f50\u5e02","","830002","650100","0991",1],["Kelamayi","\u514b\u62c9\u739b\u4f9d\u5e02","","834000","650200","0990",1],["Tulufan","\u5410\u9c81\u756a\u5730\u533a","","838000","652100","0995",4],["Hami","\u54c8\u5bc6\u5730\u533a","","839000","652200","0902",4],["Hetian","\u548c\u7530\u5730\u533a","","848000","653200","0903",4],["Akesu","\u963f\u514b\u82cf\u5730\u533a","","843000","652900","0997",4],["Kashi","\u5580\u4ec0\u5730\u533a","","844000","653100","0998",4],["KezilesuKeerkezi","\u514b\u5b5c\u52d2\u82cf\u67ef\u5c14\u514b\u5b5c\u81ea\u6cbb\u5dde","","845350","63000","0908",4],["BayinguolengMengguzu","\u5df4\u97f3\u90ed\u695e\u8499\u53e4\u81ea\u6cbb\u5dde","","841000","652800","0996",4],["ChangjiHuizu","\u660c\u5409\u56de\u65cf\u81ea\u6cbb\u5dde","","831100","652300","0994",4],["BoertalaMengguzu","\u535a\u5c14\u5854\u62c9\u8499\u53e4\u81ea\u6cbb\u5dde","","833400","652700","0909",4],["Yilihasaka","\u4f0a\u7281\u54c8\u8428\u514b\u81ea\u6cbb\u5dde","","835000","654000","0999",4],["Tacheng","\u5854\u57ce\u5730\u533a","","834700","654200","0901",4],["Aletai","\u963f\u52d2\u6cf0\u5730\u533a","","836500","654300","0906",4]]],
["Hong Kong",[["Hong Kong","\u9999\u6e2f\u7279\u522b\u884c\u653f\u533a","\u6e2f","25175","","0852",0]]],
["Macao",[["Macao","\u6fb3\u95e8\u7279\u522b\u884c\u653f\u533a","\u6fb3","25175","","0853",0]]],
["Taiwan",[["Taiwan","\u53f0\u6e7e\u7701","\u53f0","","","",0]]]
];

/**
 * Load china information
 */
ChinaInformationLoader.load=function(){
	var country=new ChinaCountry();
	var provincesInfo=ChinaInformationLoader.INFO_PROVINCE;
	for(var i=0;i<provincesInfo.length;i++){
		var provinceInfo=provincesInfo[i];
		var province=new ChinaProvince();
		province.setId(provinceInfo[0]);
		province.setAbbreviate(provinceInfo[1]);
		province.setName(provinceInfo[2]);
		province.setShortName(provinceInfo[3]);
		province.setRegionCode(provinceInfo[4]);
		province.setType(provinceInfo[5]);
		country.addProvince(province);
	}
	var citiesInfo=ChinaInformationLoader.INFO_CITY;
	for(var i=0;i<citiesInfo.length;i++){
		var cityInfoArray=citiesInfo[i];
		var provinceId=cityInfoArray[0];
		var province=country.getProvinceById(provinceId);
		var citiesInfoOfProvince=cityInfoArray[1];
		for(var j=0;j<citiesInfoOfProvince.length;j++){
			var cityInfo=citiesInfoOfProvince[j];
			var city=new ChinaCity();
			city.setId(cityInfo[0]);
			city.setName(cityInfo[1]);
			city.setShortName(cityInfo[2]);
			city.setPostcode(cityInfo[3]);
			city.setRegionCode(cityInfo[4]);
			city.setPhoneAreaCode(cityInfo[5]);
			city.setType(cityInfo[6]);
			province.addCity(city);
		}
	}
	return country;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**
 * constructor
 */
function ChinaLunarCalendar(){
	this.jsjava_class="jsorg.eob.calendar.country.cn.ChinaLunarCalendar";
	this.calendarData=[0x41A95,0xD4A,0xDA5,0x20B55,0x56A,0x7155B,0x25D,0x92D,0x5192B,0xA95,0xB4A,0x416AA,0xAD5,0x90AB5,0x4BA,0xA5B,0x60A57,0x52B,0xA93,0x40E95];
	this.madd=[0,31,59,90,120,151,181,212,243,273,304,334];
	this.date=new Date();
	this.tgString="\u7532\u4e59\u4e19\u4e01\u620a\u5df1\u5e9a\u8f9b\u58ec\u7678";
	this.dzString="\u5b50\u4e11\u5bc5\u536f\u8fb0\u5df3\u5348\u672a\u7533\u9149\u620c\u4ea5";
	this.numString="\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341";
	this.monString="\u6b63\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341\u51ac\u814a";
	this.weekString="\u65e5\u4e00\u4e8c\u4e09\u56db\u4e94\u516d";
	this.sxString="\u9f20\u725b\u864e\u5154\u9f99\u86c7\u9a6c\u7f8a\u7334\u9e21\u72d7\u732a";
	this.cYear;
	this.cMonth;
	this.cDate;
	this.cDay;
	this.cHour;
	this.tiangan;
	this.dizhi;
	this.shengxiao;
	this.convert();	
}

ChinaLunarCalendar.jia=0;
ChinaLunarCalendar.yi=1;
ChinaLunarCalendar.bing=2;
ChinaLunarCalendar.ding=3;
ChinaLunarCalendar.wu=4;
ChinaLunarCalendar.ji=5;
ChinaLunarCalendar.geng=6;
ChinaLunarCalendar.xin=7;
ChinaLunarCalendar.ren=8;
ChinaLunarCalendar.gui=9;

ChinaLunarCalendar.zi=0;
ChinaLunarCalendar.chou=1;
ChinaLunarCalendar.yin=2;
ChinaLunarCalendar.mao=3;
ChinaLunarCalendar.chen=4;
ChinaLunarCalendar.si=5;
ChinaLunarCalendar.wu=6;
ChinaLunarCalendar.wei=7;
ChinaLunarCalendar.shen=8;
ChinaLunarCalendar.you=9;
ChinaLunarCalendar.xu=10;
ChinaLunarCalendar.hai=11;

ChinaLunarCalendar.shu=0;
ChinaLunarCalendar.niu=1;
ChinaLunarCalendar.hu=2;
ChinaLunarCalendar.tu=3;
ChinaLunarCalendar.lon=4;
ChinaLunarCalendar.she=5;
ChinaLunarCalendar.ma=6;
ChinaLunarCalendar.yang=7;
ChinaLunarCalendar.hou=8;
ChinaLunarCalendar.ji=9;
ChinaLunarCalendar.gou=10;
ChinaLunarCalendar.zhu=11;

ChinaLunarCalendar.DISPLAY_NIAN="\u5e74";
ChinaLunarCalendar.DISPLAY_YUE="\u6708";
ChinaLunarCalendar.DISPLAY_RI="\u65e5";
ChinaLunarCalendar.DISPLAY_SHI="\u65f6";
ChinaLunarCalendar.DISPLAY_FEN="\u5206";
ChinaLunarCalendar.DISPLAY_MIAO="\u79d2";
ChinaLunarCalendar.DISPLAY_HAOMIAO="\u6beb\u79d2";
ChinaLunarCalendar.DISPLAY_ZHOU="\u5468";
ChinaLunarCalendar.DISPLAY_XINGQI="\u661f\u671f";
ChinaLunarCalendar.DISPLAY_RUN="\u95f0";
ChinaLunarCalendar.DISPLAY_CHU="\u521d";
ChinaLunarCalendar.DISPLAY_SHI="\u5341";
ChinaLunarCalendar.DISPLAY_ERSHI="\u5eff";
ChinaLunarCalendar.DISPLAY_SANSHI="\u5345";

/**
 * Convert to lunar calendar
 */
ChinaLunarCalendar.prototype.convert=function(){
	var total,m,n,k;
	var isEnd=false;
	var tmp=this.date.getYear();
	if (tmp<1900){ 
		tmp+=1900;
	}
	total=(tmp-2001)*365+Math.floor((tmp-2001)/4)+this.madd[this.date.getMonth()]+this.date.getDate()-23;
	if (this.date.getYear()%4==0&&this.date.getMonth()>1){
		total++;
	}
	for(m=0;;m++){
		k=(this.calendarData[m]<0xfff)?11:12;
		for(n=k;n>=0;n--){
			if(total<=29+((this.calendarData[m]>>n)&1)){
				isEnd=true;
				break;
			}
			total=total-29-((this.calendarData[m]>>n)&1);
		}
		if(isEnd){
		    break;
		}
	}
	this.cYear=2001 + m;
	this.cMonth=k-n+1;
	this.cDate=total;
	this.cDay=this.date.getDay();
	if(k==12){
		if(this.cMonth==Math.floor(this.calendarData[m]/0x10000)+1){
			this.cMonth=1-this.cMonth;
		}
		if(this.cMonth>Math.floor(this.calendarData[m]/0x10000)+1){
			this.cMonth--;
		}
	}
	this.cHour=Math.floor((this.date.getHours()+3)/2);
	this.tiangan=(this.cYear-4)%10;
	this.dizhi=(this.cYear-4)%12;
	this.shengxiao=(this.cYear-4)%12;
};

/**
 * Get the tiangan of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getTianGan=function(){
	return this.tiangan;
};

/**
 * Get the dizhi of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDiZhi=function(){
	return this.dizhi;
};

/**
 * Get the shengxiao of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getShengXiao=function(){
	return this.shengxiao;
};

/**
 * Get the year of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getYear=function(){
	return this.cYear;
};

/**
 * Get the month of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getMonth=function(){
	return this.cMonth;
};

/**
 * Get the date of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDate=function(){
	return this.cDate;
};

/**
 * Get the day of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDay=function(){
	return this.cDay;
};

/**
 * Get the hours of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getHours=function(){
	return this.cHour;
};

/**
 * Get the tiangan title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfTianGan=function(){
	return this.tgString.charAt(this.tiangan);
};

/**
 * Get the dizhi title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfDiZhi=function(){
	return this.dzString.charAt(this.dizhi);
};

/**
 * Get the shengxiao title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfShengXiao=function(){
	return this.sxString.charAt(this.shengxiao);
};

/**
 * Get the year title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfYear=function(){
	return this.getDescOfTianGan()+this.getDescOfDiZhi()+ChinaLunarCalendar.DISPLAY_NIAN;
};

/**
 * Get the month title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfMonth=function(){
    var monthdes="";
	if(this.cMonth<1){
		monthdes+=ChinaLunarCalendar.DISPLAY_RUN;
		monthdes+=this.monString.charAt(-this.cMonth-1);
	}else{
		monthdes+=this.monString.charAt(this.cMonth-1);
	}
	monthdes+=ChinaLunarCalendar.DISPLAY_YUE;
	return monthdes;
};

/**
 * Get the date title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfDate=function(){
    var datedes="";
	datedes+=(this.cDate<11)?ChinaLunarCalendar.DISPLAY_CHU:((this.cDate<20)?ChinaLunarCalendar.DISPLAY_SHI:((this.cDate<30)?ChinaLunarCalendar.DISPLAY_ERSHI:ChinaLunarCalendar.DISPLAY_SANSHI));
	if(this.cDate%10!=0||this.cDate==10){
		datedes+=this.numString.charAt((this.cDate-1)%10);
	}
	return datedes;
};

/**
 * Get the day title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfDay=function(){
	return ChinaLunarCalendar.DISPLAY_XINGQI+this.weekString.charAt(this.cDay);
};

/**
 * Get the hours title of chinese lunar calendar
 */
ChinaLunarCalendar.prototype.getDescOfHours=function(){
	return this.dzString.charAt((this.cHour-1)%12)+ChinaLunarCalendar.DISPLAY_SHI;
};

/**
 * Set the time with date object
 */
ChinaLunarCalendar.prototype.setTime=function(date){
	this.date=date;
	this.convert();

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function ChinaMobileValidator(){
	this.jsjava_class="jsorg.eob.validator.country.cn.ChinaMobileValidator";
}

/**
 * Check whether the given value is valid mobile number
 * param str - the given value
 */
ChinaMobileValidator.validate=function(str){
	var regx=/^13[0-9]\d{8}$/;	
    return regx.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */
function ChinaOicqValidator(){
	this.jsjava_class="jsorg.eob.validator.country.cn.ChinaOicqValidator";
}

/**
 * Check whether the given value is valid oicq number
 * param str - the given value
 */
ChinaOicqValidator.validate=function(str){
	var regx=/^[1-9][0-9]{4,}$/;
    return regx.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function ChinaPhoneValidator(){
	this.jsjava_class="jsorg.eob.validator.country.cn.ChinaPhoneValidator";
}

/**
 * Check whether the given value is valid phone number
 * param str - the given value
 */
ChinaPhoneValidator.validate=function(str){
	var regx=/^\d{3}-\d{8}|\d{4}-\d{7}$/;
    return regx.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */
function ChinaProvince(){
	this.jsjava_class="jsorg.eob.information.country.cn.ChinaProvince";
	this.cities=new List();
}

ChinaProvince.TYPE_PROVINCE=0;
ChinaProvince.TYPE_AUTONOMOUS_REGION=1;
ChinaProvince.TYPE_MUNICIPALITY=2;
ChinaProvince.TYPE_SAR=3;

/**
 * Set the province id
 * param id - province id
 */
ChinaProvince.prototype.setId=function(id){
	this.id=id;
};

/**
 * Get the province id
 */
ChinaProvince.prototype.getId=function(){
	return this.id;
};

/**
 * Set the province name
 * param name - province name
 */
ChinaProvince.prototype.setName=function(name){
	this.name=name;
};

/**
 * Get the province name
 */
ChinaProvince.prototype.getName=function(){
	return this.name;
};

/**
 * Set the province type
 * param type - county type
 */
ChinaProvince.prototype.setType=function(type){
	this.type=type;
};

/**
 * Get the province type
 */
ChinaProvince.prototype.getType=function(){
	return this.type;
};

/**
 * Set the province short name
 * param shortName - province short name
 */
ChinaProvince.prototype.setShortName=function(shortName){
	this.shortName=shortName;
};

/**
 * Get the province short name
 */
ChinaProvince.prototype.getShortName=function(){
	return this.shortName;
};

/**
 * Set the province abbreviate name
 * param shortName - province abbreviate name
 */
ChinaProvince.prototype.setAbbreviate=function(abbreviate){
	this.abbreviate=abbreviate;
};

/**
 * Get the province abbreviate name
 */
ChinaProvince.prototype.getAbbreviate=function(){
	return this.abbreviate;
};

/**
 * Check whether the province is general level
 */
ChinaProvince.prototype.isProvince=function(){
	return this.type==ChinaProvince.TYPE_PROVINCE;
};

/**
 * Check whether the province is autonomous region
 */
ChinaProvince.prototype.isAutonomousRegion=function(){
	return this.type==ChinaProvince.TYPE_AUTONOMOUS_REGION;
};

/**
 * Check whether the province is municipality
 */
ChinaProvince.prototype.isMunicipality=function(){
	return this.type==ChinaProvince.TYPE_MUNICIPALITY;
};

/**
 * Check whether the province is SAR
 */
ChinaProvince.prototype.isSAR=function(){
	return this.type==ChinaProvince.TYPE_SAR;
};

/**
 * Set the country belonged to
 * param country - the country belonged to
 */
ChinaProvince.prototype.setCountry=function(country){
	this.country=country; 
};

/**
 * Get the country belonged to
 */
ChinaProvince.prototype.getCountry=function(){
	return this.country;
};

/**
 * Set the province region code
 * param regionCode - the province region code
 */
ChinaProvince.prototype.setRegionCode=function(regionCode){
	this.regionCode=regionCode; 
};

/**
 * Get the province region code
 */
ChinaProvince.prototype.getRegionCode=function(){
	return this.regionCode;
};

/**
 * Add city
 * param city
 */
ChinaProvince.prototype.addCity=function(city){
	this.cities.add(city);
};

/**
 * Get city by city id
 * param cityId
 */
ChinaProvince.prototype.getCityById=function(cityId){
	var it=this.iterator();
	while(it.hasNext()){
		var city=it.next();
		if(city.getId()==cityId){
			return city;
		}
	}
};

/**
 * Get city by city name
 * param cityName
 */
ChinaProvince.prototype.getCityByName=function(cityName){
	var it=this.iterator();
	while(it.hasNext()){
		var city=it.next();
		if(city.getName()==cityName){
			return city;
		}
	}
};

/**
 * Convert to iterator object
 */
ChinaProvince.prototype.iterator=function(){
	return this.cities.iterator();
};

/**
 * Get all cities belonged to the province
 */
ChinaProvince.prototype.getCities=function(){
	return this.cities;
};

/**
 * Get number of cities
 */
ChinaProvince.prototype.getSize=function(){
	return this.cities.getSize();
};

/**
 * Get the province description
 */
ChinaProvince.prototype.toString=function(){
	var str="["+this.id+","+this.abbreviate+","+this.name+","+this.shortName+","+this.type+"]";
	return str;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function ChinaTown(){
	this.jsjava_class="jsorg.eob.information.country.cn.ChinaTown";
	this.villages=new List();
}

ChinaTown.TYPE_TOWN=0;
ChinaTown.TYPE_TOWNSHIP=1;
ChinaTown.TYPE_ETHNIC_TOWNSHIP=2;
ChinaTown.TYPE_SUB_DISTRICT=3;

/**
 * Set the town id
 * param id - town id
 */
ChinaTown.prototype.setId=function(id){
	this.id=id;
};

/**
 * Get the town id
 */
ChinaTown.prototype.getId=function(){
	return this.id;
};

/**
 * Set the town name
 * param name - town name
 */
ChinaTown.prototype.setName=function(name){
	this.name=name;
};

/**
 * Get the town name
 */
ChinaTown.prototype.getName=function(){
	return this.name;
};

/**
 * Set the town type
 * param type - town type
 */
ChinaTown.prototype.setType=function(type){
	this.type=type;
};

/**
 * Get the town type
 */
ChinaTown.prototype.getType=function(){
	return this.type;
};

/**
 * Check whether the town is general town
 */
ChinaTown.prototype.isTown=function(){
	return this.type==ChinaTown.TYPE_TOWN;
};

/**
 * Check whether the town is township
 */
ChinaTown.prototype.isTownship=function(){
	return this.type==ChinaTown.TYPE_TOWNSHIP;
};

/**
 * Check whether the town is ethnic township
 */
ChinaTown.prototype.isEthnicTownship=function(){
	return this.type==ChinaTown.TYPE_ETHNIC_TOWNSHIP;
};

/**
 * Check whether the town is sub district
 */
ChinaTown.prototype.isSubDistrict=function(){
	return this.type==ChinaTown.TYPE_SUB_DISTRICT;
};

/**
 * Set the county belonged to
 * param county - the county belonged to
 */
ChinaTown.prototype.setCounty=function(county){
	this.county=county;
};

/**
 * Get the county belonged to
 */
ChinaTown.prototype.getCounty=function(){
	return this.county;
};

/**
 * Add village
 * param village
 */
ChinaTown.prototype.addVillage=function(village){
	this.villages.add(village);
};

/**
 * Get village by city id
 * param villageId
 */
ChinaTown.prototype.getVillageById=function(villageId){
	var it=this.iterator();
	while(it.hasNext()){
		var village=it.next();
		if(village.getId()==villageId){
			return village;
		}
	}
};

/**
 * Get village by city name
 * param villageName
 */
ChinaTown.prototype.getVillageByName=function(villageName){
	var it=this.iterator();
	while(it.hasNext()){
		var village=it.next();
		if(village.getName()==villageName){
			return village;
		}
	}
};

/**
 * Convert to iterator object
 */
ChinaTown.prototype.iterator=function(){
	return this.villages.iterator();
};

/**
 * Get all villages belonged to the town
 */
ChinaTown.prototype.getVillages=function(){
	return this.villages;
};

/**
 * Get number of villages
 */
ChinaTown.prototype.getSize=function(){
	return this.villages.getSize();
};

/**
 * Get the town description
 */
ChinaTown.prototype.toString=function(){
	var str="["+this.id+","+this.name+"]";
	return str;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function ChinaVillage(){
	this.jsjava_class="jsorg.eob.information.country.cn.ChinaVillage";
}

/**
 * Set the village id
 * param id - village id
 */
ChinaVillage.prototype.setId=function(id){
	this.id=id;
};

/**
 * Get the village id
 */
ChinaVillage.prototype.getId=function(){
	return this.id;
};

/**
 * Set the village name
 * param name - village name
 */
ChinaVillage.prototype.setName=function(name){
	this.name=name;
};

/**
 * Get the village name
 */
ChinaVillage.prototype.getName=function(){
	return this.name;
};

/**
 * Set the town belonged to
 * param town - the town belonged to
 */
ChinaVillage.prototype.setTown=function(town){
	this.town=town;
};

/**
 * Get the town belonged to
 */
ChinaVillage.prototype.getTown=function(){
	return this.town;
};

/**
 * Get the village description
 */
ChinaVillage.prototype.toString=function(){
	var str="["+this.id+","+this.name+"]";
	return str;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function ChinaZipValidator(){
	this.jsjava_class="jsorg.eob.validator.country.cn.ChinaZipValidator";
}

/**
 * Check whether the given value is valid zip code
 * param str - the given value
 */
ChinaZipValidator.validate=function(str){
	var regx=/^\d{6}$/;
    return regx.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The ChiSquaredDistributionImpl class references to org.apache.commons.math.distribution.ChiSquaredDistributionImpl */

function ChiSquaredDistributionImpl(degreesOfFreedom){
	this.jsjava_class="org.apache.commons.math.distribution.ChiSquaredDistributionImpl";	
	this.gamma=	DistributionFactoryImpl.newInstance().createGammaDistribution(
            degreesOfFreedom / 2.0, 2.0);
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
ChiSquaredDistributionImpl.prototype.cumulativeProbability=function(x){
	return this.gamma.cumulativeProbability(x);
};

/**
 * Access the degrees of freedom.
 */
ChiSquaredDistributionImpl.prototype.getDegreesOfFreedom=function(){
	return this.gamma.getAlpha() * 2.0;
};

/**
 * Modify the degrees of freedom.
 * param degreesOfFreedom
 */
ChiSquaredDistributionImpl.prototype.setDegreesOfFreedom=function(degreesOfFreedom){
	this.gamma.setAlpha(this.degreesOfFreedom / 2.0);
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
ChiSquaredDistributionImpl.prototype.getDomainLowerBound=function(p){
	return Double.MIN_VALUE * this.getGamma().getBeta();
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
ChiSquaredDistributionImpl.prototype.getDomainUpperBound=function(p){
	var ret;

    if (p < .5) {
        // use mean
        ret = this.getDegreesOfFreedom();
    } else {
        // use max
        ret = Double.MAX_VALUE;
    }
    
    return ret;
};

/** 
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
ChiSquaredDistributionImpl.prototype.getInitialDomain=function(p){
	var ret;

    if (p < .5) {
        // use 1/2 mean
        ret = this.getDegreesOfFreedom() * .5;
    } else {
        // use mean
        ret = this.getDegreesOfFreedom();
    }
    
    return ret;
};

/**
 * Access the Gamma distribution.
 */
ChiSquaredDistributionImpl.prototype.getGamma=function(){
	return this.gamma;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The CloneNotSupportedException class references to java.lang.CloneNotSupportedException of J2SE1.4 */

CloneNotSupportedException.prototype=new Error();
CloneNotSupportedException.prototype.constructor=CloneNotSupportedException;

CloneNotSupportedException.ERROR=0;

/**
 * constructor
 * param code - error code
 * param message - error message
 */
function CloneNotSupportedException(code,message){
	this.jsjava_class="jsjava.lang.CloneNotSupportedException";
	this.code=code;
    this.message=message;
    this.name="jsjava.lang.CloneNotSupportedException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Color class references to java.awt.Color of J2SE1.4 */
 
/**
 * constructor
 * param hex a hex color such as #FFFFFF
 */
function Color(hex){
	this.jsjava_class="jsjava.awt.Color";
    this.hex=hex;	
}

/**
 * return the hex value
 */
Color.prototype.getHex=function(){
    return this.hex;	
}

/**
 * set hex value
 * param hex a hex color such as #FFFFFF
 */
Color.prototype.setHex=function(hex){
    this.hex=hex;	

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Complex class references to org.apache.commons.math.complex.Complex */

function Complex(real,imaginary){
	this.jsjava_class="org.apache.commons.math.complex.Complex";
	this.real=real;
	this.imaginary=imaginary;
}

/*** The square root of -1. A number representing "0.0 + 1.0i" */
Complex.I = new Complex(0.0, 1.0);
    
/*** A complex number representing "NaN + NaNi" */
Complex.NaN = new Complex(Double.NaN, Double.NaN);

/*** A complex number representing "1.0 + 0.0i" */    
Complex.ONE = new Complex(1.0, 0.0);

/*** A complex number representing "0.0 + 0.0i" */    
Complex.ZERO = new Complex(0.0, 0.0);

/**
 * Return the absolute value of this complex number.
 */
Complex.prototype.abs=function(){
	if (this.isNaN()) {
        return Double.NaN;
    }
    
    if (this.isInfinite()) {
        return Double.POSITIVE_INFINITY;
    }
    var real=this.real;
    var imaginary=this.imaginary;
    if (Math.abs(real) < Math.abs(imaginary)) {
        if (imaginary == 0.0) {
            return Math.abs(real);
        }
        var q = real / imaginary;
        return (Math.abs(imaginary) * Math.sqrt(1 + q*q));
    } else {
        if (real == 0.0) {
            return Math.abs(imaginary);
        }
        var q = imaginary / real;
        return (Math.abs(real) * Math.sqrt(1 + q*q));
    }
};

/**
 * Return the sum of this complex number and the given complex number.
 * param rsh - the other complex number 
 */
Complex.prototype.add=function(rhs){
	return new Complex(this.real + rhs.getReal(),this.imaginary + rhs.getImaginary());
};

/**
 * the conjugate of this Complex object
 */
Complex.prototype.conjugate=function(){
	if (this.isNaN()) {
        return Complex.NaN;
    }   
    return new Complex(this.real, -this.imaginary);
};

/**
 * Return the quotient of this complex number and the given complex number. 
 * param rhs - the other complex number 
 */
Complex.prototype.divide=function(rhs){
	if (this.isNaN() || rhs.isNaN()) {
        return Complext.NaN;
    }
    var real=this.real;
    var imaginary=this.imaginary;
    var c = rhs.getReal();
    var d = rhs.getImaginary();
    if (c == 0.0 && d == 0.0) {
        return Complex.NaN;
    }
    
    if (rhs.isInfinite() && !this.isInfinite()) {
        return Complex.ZERO;
    }

    if (Math.abs(c) < Math.abs(d)) {
        if (d == 0.0) {
            return new Complex(real/c, imaginary/c);
        }
        var q = c / d;
        var denominator = c * q + d;
        return new Complex((real * q + imaginary) / denominator,(imaginary * q - real) / denominator);
    } else {
        if (c == 0.0) {
            return new Complex(imaginary/d, -real/c);
        }
        var q = d / c;
        var denominator = d * q + c;
        return new Complex((imaginary * q + real) / denominator,(imaginary - real * q) / denominator);
    }
};

/**
 * Test for the equality of two Complex objects.
 * param o
 */
Complex.prototype.equals=function(o){
	if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="org.apache.commons.math.complex.Complex"){
        return this.real==o.real&&this.imaginary==o.imaginary;
    }
    return false;
};

/**
 * Access the imaginary part. 
 */
Complex.prototype.getImaginary=function(){
	return this.imaginary;
};

/**
 * Access the real part. 
 */
Complex.prototype.getReal=function(){
	return this.real;
};

/**
 * Access the real part.
 */
Complex.prototype.isInfinite=function(){
	return !this.isNaN() && (Double.isInfinite(this.real) || Double.isInfinite(this.imaginary));   
};

/**
 * Returns true if either or both parts of this complex number is NaN; false otherwise
 */
Complex.prototype.isNaN=function(){
	return Double.isNaN(this.real) || Double.isNaN(this.imaginary); 
};

/**
 * Return the product of this complex number and the given complex number. 
 * param rhs - the other complex number 
 */
Complex.prototype.multiply=function(rhs){
	if (this.isNaN() || rhs.isNaN()) {
        return Complex.NaN;
    }
    return new Complex(this.real * rhs.real - this.imaginary * rhs.imaginary,
            this.real * rhs.imaginary + this.imaginary * rhs.real);
};

/**
 * Return the additive inverse of this complex number. 
 */
Complex.prototype.negate=function(){
	if (this.isNaN()) {
        return Complex.NaN;
    }    
    return new Complex(-this.real, -this.imaginary);
};

/**
 * Return the difference between this complex number and the given complex number. 
 * param rhs - the other complex number 
 */
Complex.prototype.subtract=function(rhs){
	if (this.isNaN() || rhs.isNaN()) {
        return Complex.NaN;
    }
    
    return new Complex(this.real - rhs.getReal(),
        this.imaginary - rhs.getImaginary());
};

/**
 * return a string description
 */
Complex.prototype.toString=function(){
	var str=this.real;
	if(this.imaginary>=0){
		str+="+";
	}
	str+=this.imaginary+"i";
	return str;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Complex class references to org.apache.commons.math.complex.ComplexUtils */

function ComplexUtils(){
	this.jsjava_class="org.apache.commons.math.complex.ComplexUtils";
}

/**
 * Compute the inverse cosine for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.acos=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }

    return Complex.I.negate().multiply(ComplexUtils.log(z.add(
        Complex.I.multiply(ComplexUtils.sqrt1z(z))))); 
};

/**
 * Compute the inverse sine for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.asin=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }

    return Complex.I.negate().multiply(ComplexUtils.log(ComplexUtils.sqrt1z(z).add(
        Complex.I.multiply(z))));
};

/**
 * Compute the inverse tangent for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.atan=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    return Complex.I.multiply(
        ComplexUtils.log(Complex.I.add(z).divide(Complex.I.subtract(z))))
        .divide(new Complex(2.0, 0.0));
};

/**
 * Compute the cosine for the given complex argument.
 * param z - a complex number 
 */
ComplexUtils.cos=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var a = z.getReal();
    var b = z.getImaginary();
    
    return new Complex(Math.cos(a) * MathUtils.cosh(b),
        -Math.sin(a) * MathUtils.sinh(b));
};

/**
 * Compute the hyperbolic cosine for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.cosh=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var a = z.getReal();
    var b = z.getImaginary();
    
    return new Complex(MathUtils.cosh(a) * Math.cos(b),
        MathUtils.sinh(a) * Math.sin(b));
};

/**
 * Compute the exponential function for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.exp=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var b = z.getImaginary();
    var expA = Math.exp(z.getReal());
    return new Complex(expA *  Math.cos(b), expA * Math.sin(b));
};

/**
 * Compute the natural logarithm for the given complex argument. 
 * param z - a complex number
 */
ComplexUtils.log=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }

    return new Complex(Math.log(z.abs()),
        Math.atan2(z.getImaginary(), z.getReal())); 
};

/**
 * Creates a complex number from the given polar representation.
 * param r - the modulus of the complex number to create
 * param theta - the argument of the complex number to create
 */
ComplexUtils.polar2Complex=function(r,theta){
	if (r < 0) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"Complex modulus must not be negative");
    }
    return new Complex(r * Math.cos(theta), r * Math.sin(theta));
};

/**
 * Returns of value of y raised to the power of x.
 * param y - a complex number
 * param x - a complex number
 */
ComplexUtils.pow=function(y,x){
	return ComplexUtils.exp(x.multiply(ComplexUtils.log(y)));
};

/**
 * Compute the sine for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.sin=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var a = z.getReal();
    var b = z.getImaginary();
    
    return new Complex(Math.sin(a) * MathUtils.cosh(b),
        Math.cos(a) * MathUtils.sinh(b));
};

/**
 * Compute the hyperbolic sine for the given complex argument.
 * param z - a complex number 
 */
ComplexUtils.sinh=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var a = z.getReal();
    var b = z.getImaginary();
    
    return new Complex(MathUtils.sinh(a) * Math.cos(b),
        MathUtils.cosh(a) * Math.sin(b));
};

/**
 * Compute the square root for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.sqrt=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var a = z.getReal();
    var b = z.getImaginary();
    
    var t = Math.sqrt((Math.abs(a) + z.abs()) / 2.0);
    if (a >= 0.0) {
        return new Complex(t, b / (2.0 * t));
    } else {
        return new Complex(Math.abs(b) / (2.0 * t),
            MathUtils.indicator(b) * t);
    }
};

/**
 * Compute the square root of 1 - z2 for the given complex argument.
 * param z - a complex number 
 */
ComplexUtils.sqrt1z=function(z){
	return ComplexUtils.sqrt(Complex.ONE.subtract(z.multiply(z)));
};

/**
 * Compute the tangent for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.tan=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var a2 = 2.0 * z.getReal();
    var b2 = 2.0 * z.getImaginary();
    var d = Math.cos(a2) + MathUtils.cosh(b2);
    
    return new Complex(Math.sin(a2) / d, MathUtils.sinh(b2) / d);
};

/**
 * Compute the hyperbolic tangent for the given complex argument.
 * param z - a complex number
 */
ComplexUtils.tanh=function(z){
	if (z.isNaN()) {
        return Complex.NaN;
    }
    
    var a2 = 2.0 * z.getReal();
    var b2 = 2.0 * z.getImaginary();
    var d = MathUtils.cosh(a2) + Math.cos(b2);
    
    return new Complex(MathUtils.sinh(a2) / d, Math.sin(b2) / d);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**  The ConditionTrigger class not references to any class of J2SE1.4 
 *  This is a class used to condition assert.
 */
 
/**
 * constructor
 * param components
 * param conditionNumber
 */ 
function ConditionTrigger(components,conditionNumber){
	this.jsjava_class="jsorg.eob.component.trigger.ConditionTrigger";
    this.components=components;
    this.conditions=new Array(conditionNumber);
    this.size=0;
}

/**
 * add a condition expression
 * param condition
 */
ConditionTrigger.prototype.addCondition=function(condition){
    this.conditions[this.size++]=condition;
    
};

/**
 * triggered according to the given conditionSeed
 * param conditionSeed
 */
ConditionTrigger.prototype.trigger=function(conditionSeed){
    var triggerCondition="ConditionTrigger_NULL";
    var conditions=this.conditions;
    for(var i=0;i<conditions.length;i++){
        if(conditions[i].conditionSeed==conditionSeed){
            triggerCondition=conditions[i];
        }
    }
    if(triggerCondition=="ConditionTrigger_NULL"){
        return;	
    }
    var visibles;
    if(triggerCondition!=null){
        visibles=triggerCondition.visibles;	
    }
    if(visibles!=null){
        for(var i=0;i<visibles.length;i++){
            this.show(visibles[i]);
        }
    }
    var invisibles=this.getDiff(this.components,visibles);
    for(var i=0;i<invisibles.length;i++){
        this.hide(invisibles[i]);
    }
};

/**
 * display the component identified by id
 * param id
 */
ConditionTrigger.prototype.show=function(id){
    document.getElementById(id).style.display="block";
};

/**
 * hide the component identified by id
 * param id
 */
ConditionTrigger.prototype.hide=function(id){
    document.getElementById(id).style.display="none";
};

/**
 * return the different components between collections and parts 
 * param collections all components
 * param parts
 */
ConditionTrigger.prototype.getDiff=function(collection,parts){
	if(parts==null){
	    return collection;	
	}
    var res=new Array(collection.length-parts.length);
    var resCount=0;
    for(var i=0;i<collection.length;i++){
        if(!this.contains(parts,collection[i])){
            res[resCount]=collection[i];
            resCount++;
        }
    }
    return res;
};

/**
 * return the boolean value whether parts contains part
 * param parts
 * param part
 */
ConditionTrigger.prototype.contains=function(parts,part){
    for(var i=0;i<parts.length;i++){
        if(parts[i]==part){
            return true;
        }
    }
    return false;
};    
    /**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The ConvergenceException class references to org.apache.commons.math.ConvergenceException */

ConvergenceException.prototype=new Error();
ConvergenceException.prototype.constructor=ConvergenceException;

ConvergenceException.ERROR=0;

/**
 * param code - error code
 * param message - error message
 */
function ConvergenceException(code,message){
	this.jsjava_class="org.apache.commons.math.ConvergenceException";
	this.code=code;
    this.message=message;
    this.name="org.apache.commons.math.ConvergenceException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Cookie class references to javax.servlet.http.Cookie of J2EE1.4 */
 
/**
 * constructor
 * param name
 * param value
 */
function Cookie(name,value){
	this.jsjava_class="jsjavax.servlet.http.Cookie";
    this.name=name;
    this.value=value;	
    this.secure=false;
    this.maxAge=0;
}

/**
 * clone a new Cookie
 */
Cookie.prototype.clone=function(){
    var clonedCookie=new cookie(this.getName(),this.getValue());
    clonedCookie.setComment(this.getComment());
    clonedCookie.setDomain(this.getDomain());
    clonedCookie.setMaxAge(this.getMaxAge());
    clonedCookie.setPath(this.getPath());
    clonedCookie.setSecure(this.getSecure());
    clonedCookie.setVersion(this.getVersion());
    return clonedCookie;
};

/**
 * return the cookie comment
 */
Cookie.prototype.getComment=function(){
    return this.comment;
};

/**
 * set the cookie comment
 * param comment
 */
Cookie.prototype.setComment=function(comment){
    this.comment=comment;
};

/**
 * return the cookie domain
 */
Cookie.prototype.getDomain=function(){
    return this.domain;
};

/**
 * set the cookie domain
 * param domain
 */
Cookie.prototype.setDomain=function(domain){
    this.domain=domain;
};

/**
 * return the cookie max age
 */
Cookie.prototype.getMaxAge=function(){
    return this.maxAge;
};

/**
 * set the cookie max age
 * param maxAge
 */
Cookie.prototype.setMaxAge=function(maxAge){
    this.maxAge=maxAge;
};

/**
 * return the cookie name
 */
Cookie.prototype.getName=function(){
    return this.name;
};

/**
 * return the cookie path
 */
Cookie.prototype.getPath=function(){
    return this.path;
};

/**
 * set the cookie path
 * param path
 */
Cookie.prototype.setPath=function(path){
    this.path=path;
};

/**
 * return the cookie secure
 */
Cookie.prototype.getSecure=function(){
    return this.secure;
};

/**
 * set the cookie secure
 * param secure
 */
Cookie.prototype.setSecure=function(secure){
    this.secure=secure;
};

/**
 * return the cookie value
 */
Cookie.prototype.getValue=function(){
    return this.value;
};

/**
 * set the cookie value
 * param value
 */
Cookie.prototype.setValue=function(value){
    this.value=value;
};

/**
 * return the cookie version
 */
Cookie.prototype.getVersion=function(){
    return this.version;
};

/**
 * set the cookie version
 * param version
 */
Cookie.prototype.setVersion=function(version){
    this.version=version;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 
/**  The DateFormat class references to java.text.SimpleDateFormat of J2SE1.4 */
 
/**
 * constructor
 */
 function DateFormat(){
     this.jsjava_class="jsjava.text.DateFormat";
 }
 
 DateFormat.zh_cn_month2=["01","02","03","04","05","06","07","08","09","10","11","12"];
 DateFormat.zh_cn_month3=["\u4e00\u6708","\u4e8c\u6708","\u4e09\u6708","\u56db\u6708","\u4e94\u6708","\u516d\u6708","\u4e03\u6708","\u516b\u6708","\u4e5d\u6708","\u5341\u6708","\u5341\u4e00\u6708","\u5341\u4e8c\u6708",];
 DateFormat.zh_cn_month4=["\u4e00\u6708","\u4e8c\u6708","\u4e09\u6708","\u56db\u6708","\u4e94\u6708","\u516d\u6708","\u4e03\u6708","\u516b\u6708","\u4e5d\u6708","\u5341\u6708","\u5341\u4e00\u6708","\u5341\u4e8c\u6708",];
 DateFormat.us_en_month4=["Janu","Febr","Marc","Apri","May","Juhn","July","Augu","Sept","Octo","Nove","Dece"];
 DateFormat.us_en_month3=["Jan","Feb","Mar","Apr","May","Juh","Jul","Aug","Sep","Oct","Nov","Dec"];
 DateFormat.us_en_month2=["01","02","03","04","05","06","07","08","09","10","11","12"];
 DateFormat.zh_cn_week=["\u661f\u671f\u65e5","\u661f\u671f\u4e00","\u661f\u671f\u4e8c","\u661f\u671f\u4e09","\u661f\u671f\u56db","\u661f\u671f\u4e94","\u661f\u671f\u516d"];
 DateFormat.zh_cn_am="\u4e0b\u5348";
 DateFormat.zh_cn_pm="\u4e0a\u5348";  
 DateFormat.language=(navigator.userLanguage==undefined?navigator.language:navigator.userLanguage).replace("-","_");
 
/**
 * apply the pattern
 * param pattern
 */
 DateFormat.prototype.applyPattern=function(pattern){
     this.pattern=pattern;
 };
 
/**
 * format a date by specified pattern
 * param date
 */
 DateFormat.prototype.format=function(date){
     var year4=date.getYear();
     var year2=year4.toString().substring(2);
     var pattern=this.pattern;
     pattern=pattern.replace(/yyyy/,year4);
     pattern=pattern.replace(/yy/,year2);
     var month=date.getMonth();
     pattern=pattern.replace(/MMMM/,eval("DateFormat."+DateFormat.language+"_month4[month]"));
     pattern=pattern.replace(/MMM/,eval("DateFormat."+DateFormat.language+"_month3[month]"));
     pattern=pattern.replace(/MM/,eval("DateFormat."+DateFormat.language+"_month2[month]"));
     var dayOfMonth=date.getDate();
     var dayOfMonth2=dayOfMonth;
     var dayOfMonthLength=dayOfMonth.toString().length;
     if(dayOfMonthLength==1){
         dayOfMonth2="0"+dayOfMonth;	
     }
     pattern=pattern.replace(/dd/,dayOfMonth2);
     pattern=pattern.replace(/d/,dayOfMonth);
     var hours=date.getHours();
     var hours2=hours;
     var hoursLength=hours.toString().length;
     if(hoursLength==1){
         hours2="0"+hours;	
     }
     pattern=pattern.replace(/HH/,hours2);
     pattern=pattern.replace(/H/,hours);
     var minutes=date.getMinutes();
     var minutes2=minutes;
     var minutesLength=minutes.toString().length;
     if(minutesLength==1){
         minutes2="0"+minutes;	
     }
     pattern=pattern.replace(/mm/,minutes2);
     pattern=pattern.replace(/m/,minutes);
     var seconds=date.getSeconds();
     var seconds2=seconds;
     var secondsLength=seconds.toString().length;
     if(secondsLength==1){
         seconds2="0"+seconds;	
     }
     pattern=pattern.replace(/ss/,seconds2);
     pattern=pattern.replace(/s/,seconds);
     var milliSeconds=date.getMilliseconds();
     pattern=pattern.replace(/S+/,milliSeconds);
     var day=date.getDay();
     pattern=pattern.replace(/E+/,eval("DateFormat."+DateFormat.language+"_week[day]"));
     if(hours>12){
         pattern=pattern.replace(/a+/,eval("DateFormat."+DateFormat.language+"_am"));	
     }else{
         pattern=pattern.replace(/a+/,eval("DateFormat."+DateFormat.language+"_pm"));  
     }
     var kHours=hours;
     if(kHours==0){
         kHours=24;	
     }
     var kHours2=kHours;
     var kHoursLength=kHours.toString().length;
     if(kHoursLength==1){
         kHours2="0"+kHours;	
     }
     pattern=pattern.replace(/kk/,kHours2);
     pattern=pattern.replace(/k/,kHours);
     var KHours=hours;
     if(hours>11){
         KHours=hours-12;	
     }
     var KHours2=KHours;
     var KHoursLength=KHours.toString().length;
     if(KHoursLength==1){
         KHours2="0"+KHours;	
     }
     pattern=pattern.replace(/KK/,KHours2);
     pattern=pattern.replace(/K/,KHours);
     var hHours=KHours;
     if(hHours==0){
         hHours=12;	
     }
     var hHours2=hHours;
     var hHoursLength=hHours.toString().length;
     if(KHoursLength==1){
         hHours2="0"+hHours;	
     }
     pattern=pattern.replace(/hh/,hHours2);
     pattern=pattern.replace(/h/,hHours);
     return pattern;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function DegreeTransform(){
	this.jsjava_class="jsorg.eob.math.transform.DegreeTransform";
}

/**
 * Get the degree of the given radian
 * param radian
 */
DegreeTransform.toDegree=function(radian){
	if(isNaN(radian)){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"radian must be a number!");
	}
	return 180*radian/Math.PI;
};

/**
 * Get the radian of the given degree
 * param degree
 */
DegreeTransform.toRadian=function(degree){
	if(isNaN(degree)){
		throw new IllegalArgumentException(IllegalArgumentException.ERROR,
				"degree must be a number!");
	}
	return Math.PI*degree/180;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The DistributionFactoryImpl class references to org.apache.commons.math.distribution.DistributionFactoryImpl */

function DistributionFactoryImpl(){
	this.jsjava_class="org.apache.commons.math.distribution.DistributionFactoryImpl";	
}

DistributionFactoryImpl.newInstance=function(){
	return new DistributionFactoryImpl();
};

/**
 * Create a binomial distribution with the given number of trials and probability of success.
 * param numberOfTrials
 * param probabilityOfSuccess
 */
DistributionFactoryImpl.prototype.createBinomialDistribution=function(numberOfTrials,probabilityOfSuccess){
	return new BinomialDistributionImpl(numberOfTrials,
            probabilityOfSuccess);
};

/**
 * Create a new chi-square distribution with the given degrees of freedom.
 * param degreesOfFreedom
 */
DistributionFactoryImpl.prototype.createChiSquareDistribution=function(degreesOfFreedom){
	return new ChiSquaredDistributionImpl(degreesOfFreedom);
};

/**
 * Create a new exponential distribution with the given degrees of freedom.
 * param mean
 */
DistributionFactoryImpl.prototype.createExponentialDistribution=function(mean){
	return new ExponentialDistributionImpl(mean);
};

/**
 * Create a new F-distribution with the given degrees of freedom.
 * param numeratorDegreesOfFreedom
 * param denominatorDegreesOfFreedom
 */
DistributionFactoryImpl.prototype.createFDistribution=function(numeratorDegreesOfFreedom,denominatorDegreesOfFreedom){
	return new FDistributionImpl(numeratorDegreesOfFreedom,
            denominatorDegreesOfFreedom);
};

/**
 * 
 * param
 * param
 */
DistributionFactoryImpl.prototype.createGammaDistribution=function(alpha,beta){
	return new GammaDistributionImpl(alpha, beta);
};

/**
 * Create a new gamma distribution the given shape and scale parameters.
 * param populationSize
 * param numberOfSuccesses
 * param sampleSize
 */
DistributionFactoryImpl.prototype.createHypergeometricDistribution=function(populationSize,numberOfSuccesses,sampleSize){
	return new HypergeometricDistributionImpl(populationSize,
            numberOfSuccesses, sampleSize);
};

/**
 * Create a new normal distribution with the given mean and standard deviation.
 * param mean
 * param sd
 */
DistributionFactoryImpl.prototype.createNormalDistribution=function(mean,sd){
	return new NormalDistributionImpl(mean, sd);
};

/**
 * Create a new Poisson distribution with poisson parameter lambda.
 * param lambda
 */
DistributionFactoryImpl.prototype.createPoissonDistribution=function(lambda){
	return new PoissonDistributionImpl(lambda);
};

/**
 * Create a new t distribution with the given degrees of freedom.
 * param degreesOfFreedom
 */
DistributionFactoryImpl.prototype.createTDistribution=function(degreesOfFreedom){
	return new TDistributionImpl(degreesOfFreedom);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function DocumentUtils(){
	this.jsjava_class="jsorg.eob.document.DocumentUtils";
}

/**
 * Get elements by classname of HTML tags
 * @param domObj - object in document model
 * @param tagName - HTML tag name
 * @param className - css class name
 */
DocumentUtils.getElementsByClassName=function(domObj,tagName,className){
	var elems=new List();
	var tagElems=domObj.getElementsByTagName(tagName.toUpperCase());
	for(var i=0;i<tagElems.length;i++){
		var tagElem=tagElems[i];
		if(tagElem.className==className){
		    elems.add(tagElem);
		}
	}
	return elems.toArray();
};

/**
 * Get frame sub window object
 * @param winObj - the object of the window where the frame is on
 * @param frameName - the name of the frame
 */
DocumentUtils.getFrameWindowObjectByName=function(winObj,frameName){
    var frameObj=eval("winObj."+frameName);
    return frameObj.window;
};

/**
 * Get frame sub window object
 * @param winObj - the object of the window where the frame is on
 * @param frameId - the id of the frame
 */
DocumentUtils.getFrameWindowObjectById=function(winObj,frameId){
    var frameTagObj=DocumentUtils.getFrameTagObjectById(winObj,frameId);
    return frameTagObj.contentWindow;
};

/**
 * Get frame tag object
 * @param winObj - the object of the window where the frame is on
 * @param frameId - the id of the frame
 */
DocumentUtils.getFrameTagObjectById=function(winObj,frameId){
	return winObj.document.getElementById(frameId);
};

/**
 * Get frame tag object
 * @param winObj - the object of the window where the frame is on
 * @param frameId - the id of the frame
 */
DocumentUtils.getFrameTagObjectByName=function(winObj,frameName){
	var elems=winObj.document.getElementsByName(frameName);
	return elems[0];
};

/**
 * Get the top window of the current window
 */
DocumentUtils.getTopWindowObjectOfCurrent=function(){
	return window.top;
};

/**
 * Get the parent window of the current window
 */
DocumentUtils.getParentWindowObjectOfCurrent=function(){
	return window.parent;
};

/**
 * Get the operner window from where the current window is opened
 */
DocumentUtils.getOpenerWindowObjectOfCurrent=function(){
    return window.opener;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Double class references to java.lang.Double of J2SE1.4 */
 
/**
 * constructor
 * param value
 */
function Double(value){
	this.jsjava_class="jsjava.lang.Double";
    this.value=value;
}
Double.MIN=Math.pow(2,-1074);
Double.MAX=(2-Math.pow(2,-52))*Math.pow(2,1023);
Double.MIN_VALUE=Math.pow(2,-1074);
Double.MAX_VALUE=(2-Math.pow(2,-52))*Math.pow(2,1023);
Double.POSITIVE_INFINITY=1.0/0.0;
Double.NEGATIVE_INFINITY=-1.0/0.0;
Double.NaN=0.0/0.0;

/**
 * check whether the input value is a double value
 * param d
 */
Double.checkValid=function(d){
	if(isNaN(d)){
		return false;
	}
	d=parseFloat(d);
    if(d<Double.POSITIVE_INFINITY&&d>Double.NEGATIVE_INFINITY){
        return true;
    }
    return false;
};


/**
 * judge whether the given d is an infinite number
 * param d
 */
Double.isInfinite=function(d){
    return (d==Double.POSITIVE_INFINITY||d==Double.NEGATIVE_INFINITY);
};

/**
 * return the double value parsed from str
 * param str
 */
Double.parseDouble=function(str){
    if(isNaN(str)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
    return parseFloat(str);
};

/**
 * compare whether this object value is equals to input Double object value
 * param b input Double object
 */
Double.prototype.compareTo=function(b){
    if(b==undefined){
        return -1; 
    }
    if(this.value>b.value){
        return 1; 
    }else if(this.value==b.value){
        return 0; 
    }else{
        return -1;  
    }
};

/**
 * judge whether the current Double value is an infinite number
 * param d
 */
Double.prototype.isInfinite=function(){
    return (this.value==Double.POSITIVE_INFINITY||this.value==Double.NEGATIVE_INFINITY);
};

/**
 * return the object's double value
 */
Double.prototype.DoubleValue=function(){
    return this.value;
};

/**
 * return a string description
 */
Double.prototype.toString=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Double.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Double"){
        return this.value==o.value; 
    }
    return false;
};

/**
 * Returns true if the specified number is a Not-a-Number (NaN) value, false otherwise.
 * param v
 */
Double.isNaN=function(v) {
	return (v!= v);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function DoubleValidator(){
	this.jsjava_class="jsorg.eob.validator.DoubleValidator";
}

DoubleValidator.POSITIVE_INFINITY=1.0/0.0;
DoubleValidator.NEGATIVE_INFINITY=-1.0/0.0;

/**
 * Check whether the given value is double
 * param str - the given value
 */
DoubleValidator.validate=function(str){
	return Double.checkValid(str);
};

/**
 * Check whether the given value is double
 * param d - the given value
 */
DoubleValidator.validate2=function(d){
	if(isNaN(d)){
		return false;
	}
	d=parseFloat(d);
	if(d<DoubleValidator.POSITIVE_INFINITY&&d>DoubleValidator.NEGATIVE_INFINITY){
        return true;
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function EmailValidator(){
	this.jsjava_class="jsorg.eob.validator.EmailValidator";
}

EmailValidator.defaultPattern=/^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;

/**
 * Check whether the given email is valid
 * param str - the given email
 * param pattern - the email pattern
 */
EmailValidator.validate=function(str,pattern){
	if(str==undefined||str==""){
	    return false;
	}
	if(pattern==undefined||pattern==""){
	    return EmailValidator.defaultPattern.test(str);
	}
	if(typeof(pattern)=="string"){
	    pattern=new RegExp(pattern);
	}
	return pattern.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Gamma class references to org.apache.commons.math.special.Beta */

function Erf(){
	this.jsjava_class="org.apache.commons.math.special.Erf";
}

/**
 * Returns the error function erf(x).
 * param x - the value.
 */
Erf.erf=function(x){
	var ret = Gamma.regularizedGammaP2(0.5, x * x, 1.0e-15, 10000);
    if (x < 0) {
        ret = -ret;
    }
    return ret;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function EventUtils(){
	this.jsjava_class="jsorg.eob.event.EventUtils";
}

/**
 * Add event to given dom object
 * @param domObj - object in document model
 * @param eventName - event name such as onclick
 * @param funcName - javascript function
 * @param isBroadcase
 */
EventUtils.addDomEvent=function(domObj, eventName, funcName, isBroadcast){
	if(eventName.indexOf("on")==0){
		eventName=eventName.substring(2);
	}
	if (domObj.addEventListener) {
����		domObj.addEventListener(eventName, funcName, isBroadcast);
����		return true;
����	} else if (domObj.attachEvent) {
����		return domObj.attachEvent("on" + eventName, funcName);
����	}
����	else {
����		element['on' + eventName] = funcName;
����	}	
};

/**
 * remove event from given dom object
 * @param domObj - object in document model
 * @param eventName - event name such as onclick
 * @param funcName - javascript function
 * @param isBroadcase
 */
EventUtils.removeDomEvent=function(domObj, eventName, funcName,isBroadcast){
	if(eventName.indexOf("on")==0){
		eventName=eventName.substring(2);
	}
	if (domObj.removeEventListener) {
����		domObj.removeEventListener(eventName, funcName,isBroadcast);
����		return true;
����	} else if (domObj.detachEvent) {
����		return domObj.detachEvent("on" + eventName, funcName);
����	}
����	else {
����		element['on' + eventName] = null;
����	}	
};

/**
 * Check whether the current mouse click is left click
 * @param event - the current window event
 */
EventUtils.isLeftClick=function(event){
	return event.which==1||event.button==0;
};

/**
 * Get the event soruce object
 * @param event - the current window event
 */
EventUtils.getEventSource=function(event){
	return event.srcElement||event.target;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Exception class references to java.lang.Exception of J2SE1.4 */

Exception.prototype=new Error();
Exception.prototype.constructor=Exception;

/**
 * constructor
 * param code - error code
 * param message - error message
 */
function Exception(code,message){
	this.jsjava_class="jsjava.lang.Exception";
	this.code=code;
    this.message=message;
    this.name="jsjava.lang.Exception";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The ExclusiveGroupTrigger class not references to any class of J2SE1.4 
 *  This class is a trigger instance scene that two groups of objects are 
 *  exclusive each other.the one is named positive,and the other is named 
 *  minus.
 */
 
/**
 * constructor
 */ 
function ExclusiveGroupTrigger(){
    this.jsjava_class="jsorg.eob.component.trigger.ExclusiveGroupTrigger";
}

/**
 * set the form
 * param formName
 */ 
ExclusiveGroupTrigger.prototype.setExclusiveGroupForm=function(formName){
	this.formName=formName;
};

/**
 * return the form
 */ 
ExclusiveGroupTrigger.prototype.getExclusiveGroupForm=function(){
    return this.formName;	
};

/**
 * set name of the checkboxes of one group
 * param pc the name of positive checkbox
 */ 
ExclusiveGroupTrigger.prototype.setExclusiveGroupPositiveCheckbox=function(pc){
	this.pc=pc;
};

/**
 * get name of the checkboxes of one group
 */ 
ExclusiveGroupTrigger.prototype.getExclusiveGroupPositiveCheckbox=function(){
    return this.pc;	
};

/**
 * set name of the checkboxes of the other group
 * param mc the name of minus checkbox
 */  
ExclusiveGroupTrigger.prototype.setExclusiveGroupMinusCheckbox=function(mc){
	this.mc=mc;
};

/**
 * get name of the checkboxes of the other group
 */
ExclusiveGroupTrigger.prototype.getExclusiveGroupMinusCheckbox=function(){
    return this.mc;	
};

/**
 * set name of the select all checkbox of one group
 * param pac the name of positive all checkbox
 */
ExclusiveGroupTrigger.prototype.setExclusiveGroupPositiveAllCheckbox=function(pac){
	this.pac=pac;
};

/**
 * get name of the select all checkbox of one group
 */
ExclusiveGroupTrigger.prototype.getExclusiveGroupPositiveAllCheckbox=function(){
    return this.pac;	
};

/**
 * set name of the select all checkbox of the other group
 * param mac the name of the minus all checkbox
 */
ExclusiveGroupTrigger.prototype.setExclusiveGroupMinusAllCheckbox=function(mac){
	this.mac=mac;
};

/**
 * get name of the select all checkbox of the other group
 */
ExclusiveGroupTrigger.prototype.getExclusiveGroupMinusAllCheckbox=function(){
    return this.mac;	
};

/**
 * set the event source object
 * param eventSource
 */
ExclusiveGroupTrigger.prototype.setExclusiveGroupEventSource=function(eventSource){
	this.eventSource=eventSource;
};

/**
 * get the event source object
 */
ExclusiveGroupTrigger.prototype.getExclusiveGroupEventSource=function(){
    return this.eventSource;	
};

/**
 * execute exclusive trigger
 * param command
 */
ExclusiveGroupTrigger.prototype.exclusiveGrouptrigger=function(command){
    if(command=="positive"){
    	this.positiveEventTrigger();
    }else if(command=="minus"){
    	this.minusEventTrigger();
    }else if(command=="positiveAll"){
    	this.positiveAllEventTrigger();
    }else if(command=="minusAll"){
    	this.minusAllEventTrigger();
    }	
};

/**
 * execute positive event trigger
 */
ExclusiveGroupTrigger.prototype.positiveEventTrigger=function(){
	    var eventSource=this.getEventSource();
	    var formName=this.getForm();
	    var pcName=this.getPositiveCheckbox();
	    var mcName=this.getMinusCheckbox();
	    var pacName=this.getPositiveAllCheckbox();
	    var macName=this.getMinusAllCheckbox();
	    var formObj=document.forms(formName);
	    var pcObj=formObj.elements(pcName);
	    var mcObj=formObj.elements(mcName);
	    var pacObj=formObj.elements(pacName);
	    var macObj=formObj.elements(macName);
	    
	    if(eventSource.checked==false){
            pacObj.checked=false;
        }else{
            var isAllSelected=true;
            for(var i=0;i<pcObj.length;i++){
                if(!pcObj[i].checked){
                    isAllSelected=false;
                }
            }
            if(isAllSelected){
                pacObj.checked=true;
            }
        }
        macObj.checked=false;
        var value=eventSource.value;
        if(mcObj.length){
            for(var i=0;i<mcObj.length;i++){
                if(mcObj[i].value==value){
                    mcObj[i].checked=false;
                }
            }
        }else{
            mcObj.checked=false;
        }
        return false;
};

/**
 * execute minus event trigger
 */
ExclusiveGroupTrigger.prototype.minusEventTrigger=function(){
	    var eventSource=trigger.getEventSource();
	    var formName=this.getForm();
	    var pcName=this.getPositiveCheckbox();
	    var mcName=this.getMinusCheckbox();
	    var pacName=this.getPositiveAllCheckbox();
	    var macName=this.getMinusAllCheckbox();
	    var formObj=document.forms(formName);
	    var pcObj=formObj.elements(pcName);
	    var mcObj=formObj.elements(mcName);
	    var pacObj=formObj.elements(pacName);
	    var macObj=formObj.elements(macName);
	    
	    if(eventSource.checked==false){
            macObj.checked=false;
        }else{
            var isAllSelected=true;
            for(var i=0;i<mcObj.length;i++){
                if(!mcObj[i].checked){
                    isAllSelected=false;
                }
            }
            if(isAllSelected){
                macObj.checked=true;
            }
        }
        pacObj.checked=false;
        var value=eventSource.value;
        if(formObj.allow.length){
            for(var i=0;i<pcObj.length;i++){
                if(pcObj[i].value==value){
                    pcObj[i].checked=false;
                }
            }
        }else{
            pcObj.checked=false;
        }
        return false;
};

/**
 * execute positive all event trigger
 */
ExclusiveGroupTrigger.prototype.positiveAllEventTrigger=function(){
	    var eventSource=this.getEventSource();
	    if(eventSource.checked){
            this.changeAllPositiveState(true);
        }else{
            this.changeAllPositiveState(false);
        }
        return false;
};

/**
 * execute minus all event trigger
 */
ExclusiveGroupTrigger.prototype.minusAllEventTrigger=function(){
	    var eventSource=this.getEventSource();
	    if(eventSource.checked){
            this.changeAllMinusState(true);
        }else{
            this.changeAllMinusState(false);
        }
        return false;
};

/**
 * change all positive state to active
 */
ExclusiveGroupTrigger.prototype.changeAllPositiveState=function(isChecked){
	var eventSource=this.getEventSource();
	    var formName=this.getForm();
	    var pcName=this.getPositiveCheckbox();
	    var mcName=this.getMinusCheckbox();
	    var pacName=this.getPositiveAllCheckbox();
	    var macName=this.getMinusAllCheckbox();
	    var formObj=document.forms(formName);
	    var pcObj=formObj.elements(pcName);
	    var mcObj=formObj.elements(mcName);
	    var pacObj=formObj.elements(pacName);
	    var macObj=formObj.elements(macName);
	    
	if(isChecked){
        macObj.checked=false;
        if(pcObj.length){
            for(var i=0;i<pcObj.length;i++){
                pcObj[i].checked=true;
                mcObj[i].checked=false;
            }
        }else{
            pcObj.checked=true;
            mcObj.checked=false;
        }
    }else{
        pacObj.checked=false;
    }
};

/**
 * change all minus state to active
 */
ExclusiveGroupTrigger.prototype.changeAllMinusState=function(isChecked){
	var eventSource=this.getEventSource();
	    var formName=this.getForm();
	    var pcName=this.getPositiveCheckbox();
	    var mcName=this.getMinusCheckbox();
	    var pacName=this.getPositiveAllCheckbox();
	    var macName=this.getMinusAllCheckbox();
	    var formObj=document.forms(formName);
	    var pcObj=formObj.elements(pcName);
	    var mcObj=formObj.elements(mcName);
	    var pacObj=formObj.elements(pacName);
	    var macObj=formObj.elements(macName);
	    
	    if(isChecked){
        pacObj.checked=false;
        if(mcObj.length){
            for(var i=0;i<mcObj.length;i++){
                mcObj[i].checked=true;
                pcObj[i].checked=false;
            }
        }else{
            pcObj.checked=false;
            mcObj.checked=true;
        }
    }else{
        macObj.checked=false;
    }

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The ExponentialDistributionImpl class references to org.apache.commons.math.distribution.ExponentialDistributionImpl */

function ExponentialDistributionImpl(mean){
	this.jsjava_class="org.apache.commons.math.distribution.ExponentialDistributionImpl";	
	if (mean <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"mean must be positive.");
    }
    this.mean = mean;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
ExponentialDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    if (x <= 0.0) {
        ret = 0.0;
    } else {
        ret = 1.0 - Math.exp(-x / this.getMean());
    }
    return ret;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
ExponentialDistributionImpl.prototype.getDomainLowerBound=function(p){
	return 0;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
ExponentialDistributionImpl.prototype.getDomainUpperBound=function(p){
	// NOTE: exponential is skewed to the left
    // NOTE: therefore, P(X < &mu;) > .5

    if (p < .5) {
        // use mean
        return this.getMean();
    } else {
        // use max
        return Double.MAX_VALUE;
    }
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
ExponentialDistributionImpl.prototype.getInitialDomain=function(p){
	// Exponential is skewed to the left, therefore, P(X < &mu;) > .5
    if (p < .5) {
        // use 1/2 mean
        return this.getMean() * .5;
    } else {
        // use mean
        return this.getMean();
    }
};

/**
 * Access the mean.
 */
ExponentialDistributionImpl.prototype.getMean=function(){
	return this.mean;
};

/**
 * For this distribution, X, this method returns the critical point x, such that P(X < x) = p.
 * param p
 */
ExponentialDistributionImpl.prototype.inverseCumulativeProbability=function(p){
	var ret;
        
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"probability argument must be between 0 and 1 (inclusive)");
    } else if (p == 1.0) {
        ret = Double.POSITIVE_INFINITY;
    } else {
        ret = -this.getMean() * Math.log(1.0 - p);
    }
    
    return ret;
};

/**
 * Modify the mean.
 * param mean
 */
ExponentialDistributionImpl.prototype.setMean=function(mean){
	if (mean <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"mean must be positive.");
    }
    this.mean = mean;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The FDistributionImpl class references to org.apache.commons.math.distribution.FDistributionImpl */

function FDistributionImpl(numeratorDegreesOfFreedom,denominatorDegreesOfFreedom){
	this.jsjava_class="org.apache.commons.math.distribution.FDistributionImpl";
	if (numeratorDegreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.numeratorDegreesOfFreedom = numeratorDegreesOfFreedom;	
    if (denominatorDegreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.denominatorDegreesOfFreedom = denominatorDegreesOfFreedom;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
FDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    if (x <= 0.0) {
        ret = 0.0;
    } else {
        var n = this.getNumeratorDegreesOfFreedom();
        var m = this.getDenominatorDegreesOfFreedom();
        
        ret = Beta.regularizedBeta((n * x) / (m + n * x),
            0.5 * n,
            0.5 * m);
    }
    return ret;
};

/**
 * Access the denominator degrees of freedom.
 */
FDistributionImpl.prototype.getDenominatorDegreesOfFreedom=function(){
	return this.denominatorDegreesOfFreedom;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
FDistributionImpl.prototype.getDomainLowerBound=function(p){
	return 0.0;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
FDistributionImpl.prototype.getDomainUpperBound=function(p){
	return Double.MAX_VALUE;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
FDistributionImpl.prototype.getInitialDomain=function(p){
	return this.getDenominatorDegreesOfFreedom() /
            (this.getDenominatorDegreesOfFreedom() - 2.0);
};

/**
 * Access the numerator degrees of freedom.
 */
FDistributionImpl.prototype.getNumeratorDegreesOfFreedom=function(){
	return this.numeratorDegreesOfFreedom;
};

/**
 * Modify the denominator degrees of freedom.
 * param degreesOfFreedom
 */
FDistributionImpl.prototype.setDenominatorDegreesOfFreedom=function(degreesOfFreedom){
	if (degreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.denominatorDegreesOfFreedom = degreesOfFreedom;
};

/**
 * Modify the numerator degrees of freedom.
 * param degreesOfFreedom
 */
FDistributionImpl.prototype.setNumeratorDegreesOfFreedom=function(degreesOfFreedom){
	if (degreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.numeratorDegreesOfFreedom = degreesOfFreedom;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Float class references to java.lang.Float of J2SE1.4 */
 
/**
 * constructor
 * param value
 */
function Float(value){
	this.jsjava_class="jsjava.lang.Float";
    this.value=value;
}
Float.MIN=Math.pow(2,-149);
Float.MAX=(2-Math.pow(2,-23))*Math.pow(2,127);
Float.MIN_VALUE=Math.pow(2,-149);
Float.MAX_VALUE=(2-Math.pow(2,-23))*Math.pow(2,127);
Float.POSITIVE_INFINITY=1.0/0.0;
Float.NEGATIVE_INFINITY=-1.0/0.0;

/**
 * check whether the input value is a float value
 * param f
 */
Float.checkValid=function(f){
	if(isNaN(f)){
		return false;
	}
	f=parseFloat(f);
    if(f<Float.POSITIVE_INFINITY&&f>Float.NEGATIVE_INFINITY){
    	return true;
	}
	return false;
};

/**
 * judge whether the given f is an infinite number
 * param f
 */
Float.isInfinite=function(f){
    return (f==Float.POSITIVE_INFINITY||f==Float.NEGATIVE_INFINITY);
};

/**
 * return the float value parsed from str
 * param str
 */
Float.parseFloat=function(str){
    if(isNaN(str)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
    return parseFloat(str);
};

/**
 * compare whether this object value is equals to input Float object value
 * param b input Float object
 */
Float.prototype.compareTo=function(b){
    if(b==undefined){
        return -1; 
    }
    if(this.value>b.value){
        return 1; 
    }else if(this.value==b.value){
        return 0; 
    }else{
        return -1;  
    }
};

/**
 * return the object's float value
 */
Float.prototype.floatValue=function(){
    return this.value;
};

/**
 * judge whether the current Float value is an infinite number
 */
Float.prototype.isInfinite=function(){
    return (this.value==Float.POSITIVE_INFINITY||this.value==Float.NEGATIVE_INFINITY);
};

/**
 * return a string description
 */
Float.prototype.toString=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Float.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Float"){
        return this.value==o.value; 
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function FloatValidator(){
	this.jsjava_class="jsorg.eob.validator.FloatValidator";
}

FloatValidator.POSITIVE_INFINITY=1.0/0.0;
FloatValidator.NEGATIVE_INFINITY=-1.0/0.0;

/**
 * Check whether the given value is float
 * param str - the given value
 */
FloatValidator.validate=function(str){
	return Float.checkValid(str);
};

/**
 * Check whether the given value is float
 * param f - the given value
 */
FloatValidator.validate2=function(f){
	if(isNaN(f)){
		return false;
	}
	f=parseFloat(f);
	if(f<FloatValidator.POSITIVE_INFINITY&&f>FloatValidator.NEGATIVE_INFINITY){
    	return true;
	}
	return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Font class references to java.awt.Font of J2SE1.4 */
 
/**
 * constructor
 * param font family
 * param style css style
 * param size font size
 * param weight font weight
 */
function Font(family,style,size,weight){
	this.jsjava_class="jsjava.awt.Font";
    this.family=family;
    this.style=style;
    this.size=size;	
    this.weight=weight;
}

/**
 * return the font family
 */
Font.prototype.getFamily=function(){
    return this.family;	
}

/**
 * return the font css style
 */
Font.prototype.getStyle=function(){
    return this.style;	
}

/**
 * return the font size
 */
Font.prototype.getSize=function(){
    return this.size;	
}

/**
 * return the font weight
 */
Font.prototype.getWeight=function(){
    return this.weight;	

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Fraction class references to org.apache.commons.math.fraction.Fraction */

/**
 * Create a fraction given the numerator and denominator.
 * param num
 * param den
 */
function Fraction(num,den){
	this.jsjava_class="org.apache.commons.math.fraction.Fraction";
	if (den == 0) {
        throw new ArithmeticException(ArithmeticException.ERROR,"The denominator must not be zero");
    }
    if (den < 0) {
        if (num == Integer.MIN_VALUE ||
                den == Integer.MIN_VALUE) {
            throw new ArithmeticException(ArithmeticException.ERROR,"overflow: can't negate");
        }
        num = -num;
        den = -den;
    }
    this.numerator = num;
    this.denominator = den;
    var d = MathUtils.gcd(this.numerator, this.denominator);
    if (d > 1) {
        this.numerator /= d;
        this.denominator /= d;
    }
    // move sign to numerator.
    if (this.denominator < 0) {
        this.numerator *= -1;
        this.denominator *= -1;
    }
}

Fraction.ONE = new Fraction(1, 1);
Fraction.ZERO = new Fraction(0, 1);

/**
 * Returns the absolute value of this fraction.
 */
Fraction.prototype.abs=function(){
	var ret;
    if (this.numerator >= 0) {
        ret = this;
    } else {
        ret = this.negate();
    }
    return ret;
};

/**
 * Compares this object to another based on size.
 * param o
 */
Fraction.prototype.compareTo=function(o){
	if(!o||!o.jsjava_class||o.jsjava_class!="org.apache.commons.math.fraction.Fraction"){
		return -1;
	}
	var ret = 0;   
    var first = this.doubleValue();
    var second = o.doubleValue();    
    if (first < second) {
        ret = -1;
    } else if (first > second) {
        ret = 1;
    }
    return ret;
};

/**
 * Gets the fraction as a double.
 */
Fraction.prototype.doubleValue=function(){
	return this.numerator / this.denominator;
};

/**
 * Test for the equality of two fractions.
 * param o
 */
Fraction.prototype.equals=function(o){
	if(!o||!o.jsjava_class||o.jsjava_class!="org.apache.commons.math.fraction.Fraction"){
		return false;
	}
	if(this.numerator==o.numerator&&this.denominator==o.denominator){
		return true;
	}
	return false;
};

/** 
 * Gets the fraction as a float.
 */
Fraction.prototype.floatValue=function(){
	return this.doubleValue();
};

/**
 * Access the denominator.
 */
Fraction.prototype.getDenominator=function(){
	return this.denominator;
};

/**
 * Access the numerator.
 */
Fraction.prototype.getNumerator=function(){
	return this.numerator;
};

/**
 * Gets the fraction as an int.
 */
Fraction.prototype.intValue=function(){
	return Math.round(this.doubleValue());
};

/**
 * Gets the fraction as a long.
 */
Fraction.prototype.longValue=function(){
	return Math.round(this.doubleValue());
};

/**
 * Return the additive inverse of this fraction.
 */
Fraction.prototype.negate=function(){
	if (this.numerator==Integer.MIN_VALUE) {
        throw new ArithmeticException(ArithmeticException.ERROR,"overflow: too large to negate");
    }
    return new Fraction(-this.numerator, this.denominator);
};

/**
 * Return the multiplicative inverse of this fraction.
 */
Fraction.prototype.reciprocal=function(){
	return new Fraction(this.denominator, this.numerator);
};

/**
 * Adds the value of this fraction to another, returning the result in reduced form.
 * param fraction
 */
Fraction.prototype.add=function(fraction){
	return this.addSub(fraction, true);
};

/**
 * Subtracts the value of another fraction from the value of this one, returning the result in reduced form.
 * param fraction
 */
Fraction.prototype.subtract=function(fraction){
	return this.addSub(fraction, false);
};

/**
 * Implement add and subtract using algorithm described in Knuth 4.5.1.
 * param fraction
 * param isAdd
 */
Fraction.prototype.addSub=function(fraction,isAdd){
	if (fraction == null) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"The fraction must not be null");
    }
    // zero is identity for addition.
    if (this.numerator == 0) {
        return isAdd ? fraction : fraction.negate();
    }
    if (fraction.numerator == 0) {
        return this;
    }     
    // if denominators are randomly distributed, d1 will be 1 about 61%
    // of the time.
    var d1 = MathUtils.gcd(this.denominator, fraction.denominator);
    if (d1==1) {
        // result is ( (u*v' +/- u'v) / u'v')
        var uvp = this.numerator*fraction.denominator;
        var upv = fraction.numerator*this.denominator;
        return new Fraction
            (isAdd ? (uvp+upv) : (uvp-upv),this.denominator*fraction.denominator);
    }
    // the quantity 't' requires 65 bits of precision; see knuth 4.5.1
    // exercise 7.  we're going to use a BigInteger.
    // t = u(v'/d1) +/- v(u'/d1)
    var uvp = this.numerator*fraction.denominator/d1;
    var upv = fraction.numerator*this.denominator/d1;
    var t = isAdd ? (uvp+upv) : (uvp-upv);
    // but d2 doesn't need extra precision because
    // d2 = gcd(t,d1) = gcd(t mod d1, d1)
    var tmodd1 = t%d1;
    var d2 = (tmodd1==0)?d1:MathUtils.gcd(tmodd1, d1);

    // result is (t/d2) / (u'/d1)(v'/d2)
    var w = t/d2;
    return new Fraction (w, this.denominator/d1*fraction.denominator/d2);
};

/**
 * Multiplies the value of this fraction by another, returning the result in reduced form.
 * param fraction
 */
Fraction.prototype.multiply=function(fraction){
	if (fraction == null) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"The fraction must not be null");
    }
    if (this.numerator == 0 || fraction.numerator == 0) {
        return Fraction.ZERO;
    }
    // knuth 4.5.1
    // make sure we don't overflow unless the result *must* overflow.
    var d1 = MathUtils.gcd(this.numerator, fraction.denominator);
    var d2 = MathUtils.gcd(fraction.numerator, this.denominator);
    return Fraction.getReducedFraction
    (this.numerator/d1*fraction.numerator/d2,
            this.denominator/d2*fraction.denominator/d1);
};

/**
 * Divide the value of this fraction by another.
 * param divide
 */
Fraction.prototype.divide=function(fraction){
	if (fraction==undefined||fraction == null) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"The fraction must not be null");
    }
    if (fraction.numerator == 0) {
        throw new ArithmeticException(IllegalArgumentException.ERROR,"The fraction to divide by must not be zero");
    }
    return this.multiply(fraction.reciprocal());
};

/**
 * Creates a Fraction instance with the 2 parts of a fraction Y/Z.
 * param numerator
 * param denominator
 */
Fraction.getReducedFraction=function(numerator,denominator){
	if (denominator == 0) {
        throw new ArithmeticException(ArithmeticException.ERROR,"The denominator must not be zero");
    }
    if (numerator==0) {
        return Fraction.ZERO; // normalize zero.
    }
    // allow 2^k/-2^31 as a valid fraction (where k>0)
    if (denominator==Integer.MIN_VALUE && (numerator&1)==0) {
        numerator/=2; denominator/=2;
    }
    if (denominator < 0) {
        if (numerator==Integer.MIN_VALUE ||
                denominator==Integer.MIN_VALUE) {
            throw new ArithmeticException(ArithmeticException.ERROR,"overflow: can't negate");
        }
        numerator = -numerator;
        denominator = -denominator;
    }
    // simplify fraction.
    var gcd = MathUtils.gcd(numerator, denominator);
    numerator /= gcd;
    denominator /= gcd;
    return new Fraction(numerator, denominator);
};

/**
 * return a string description
 */
Fraction.prototype.toString=function(){
	return this.numerator+"/"+this.denominator;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The FunctionEvaluationException class references to org.apache.commons.math.FunctionEvaluationException */

FunctionEvaluationException.prototype=new Error();
FunctionEvaluationException.prototype.constructor=FunctionEvaluationException;

FunctionEvaluationException.ERROR=0;

/**
 * param code - error code
 * param message - error message
 */
function FunctionEvaluationException(code,message){
	this.jsjava_class="org.apache.commons.math.FunctionEvaluationException";
	this.code=code;
    this.message=message;
    this.name="org.apache.commons.math.FunctionEvaluationException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Gamma class references to org.apache.commons.math.special.Gamma */

function Gamma(){
	this.jsjava_class="org.apache.commons.math.special.Erf";
}

Gamma.DEFAULT_EPSILON = 10e-9;

Gamma.lanczos =
    [
        0.99999999999999709182,
        57.156235665862923517,
        -59.597960355475491248,
        14.136097974741747174,
        -0.49191381609762019978,
        .33994649984811888699e-4,
        .46523628927048575665e-4,
        -.98374475304879564677e-4,
        .15808870322491248884e-3,
        -.21026444172410488319e-3,
        .21743961811521264320e-3,
        -.16431810653676389022e-3,
        .84418223983852743293e-4,
        -.26190838401581408670e-4,
        .36899182659531622704e-5
    ];
    
Gamma.HALF_LOG_2_PI = 0.5 * Math.log(2.0 * Math.PI);

/**
 * Returns the natural logarithm of the gamma function ��(x).
 * param x - the value.
 */
Gamma.logGamma=function(x){
	var ret;
    if (Double.isNaN(x) || (x <= 0.0)) {
        ret = Double.NaN;
    } else {
        var g = 607.0 / 128.0;        
        var sum = 0.0;
        for (var i = Gamma.lanczos.length - 1; i > 0; --i) {
        	sum = sum + (Gamma.lanczos[i] / (x + i));
        }
        sum = sum + Gamma.lanczos[0];
        var tmp = x + g + .5;
        ret = ((x + .5) * Math.log(tmp)) - tmp +
            Gamma.HALF_LOG_2_PI + Math.log(sum / x);
            
    }

    return ret;Gamma.js
};

/**
 * Returns the regularized gamma function P(a, x).
 * param a - the a parameter.
 * param x - the value.
 */
Gamma.regularizedGammaP=function(a,x){
	return Gamma.regularizedGammaP2(a, x, Gamma.DEFAULT_EPSILON, Integer.MAX_VALUE);
};

/**
 * Returns the regularized gamma function P(a, x).
 * param a - the a parameter.
 * param x - the value.
 * param epsilon - When the absolute value of the nth item in the series is less 
 * than epsilon the approximation ceases to calculate further elements in the series. 
 * param maxIterations - Maximum number of "iterations" to complete.
 */
Gamma.regularizedGammaP2=function(a,x,epsilon,maxIterations){
	var ret;
    if (Double.isNaN(a) || Double.isNaN(x) || (a <= 0.0) || (x < 0.0)) {
        ret = Double.NaN;
    } else if (x == 0.0) {
        ret = 0.0;
    } else if (a >= 1.0 && x > a) {
        // use regularizedGammaQ because it should converge faster in this
        // case.
        ret = 1.0 - Gamma.regularizedGammaQ2(a, x, epsilon, maxIterations);
    } else {
        // calculate series
        var n = 0.0; // current element index
        var an = 1.0 / a; // n-th element in the series
        var sum = an; // partial sum
        while (Math.abs(an) > epsilon && n < maxIterations) {
            // compute next element in the series
            n = n + 1.0;
            an = an * (x / (a + n));

            // update partial sum
            sum = sum + an;
        }
        if (n >= maxIterations) {
            throw new ConvergenceException(ConvergenceException.ERROR,
                "maximum number of iterations reached");
        } else {
            ret = Math.exp(-x + (a * Math.log(x)) - Gamma.logGamma(a)) * sum;
        }
    }

    return ret;
};

/**
 * Returns the regularized gamma function Q(a, x) = 1 - P(a, x).
 * param a - the a parameter.
 * param x - the value.
 */
Gamma.regularizedGammaQ=function(a,x){
	return Gamma.regularizedGammaQ2(a, x, Gamma.DEFAULT_EPSILON, Integer.MAX_VALUE);
};

/**
 * Returns the regularized gamma function Q(a, x) = 1 - P(a, x).
 * param a - the a parameter.
 * param x - the value.
 * param epsilon - When the absolute value of the nth item in the series is less than 
 * epsilon the approximation ceases to calculate further elements in the series.
 * param maxIterations - Maximum number of "iterations" to complete. 
 */
Gamma.regularizedGammaQ2=function(a,x,epsilon,maxIterations){
	function ContinuedFraction(){
		
	}
	ContinuedFraction.DEFAULT_EPSILON = 10e-9;
	ContinuedFraction.prototype.evaluate=function(x){
		return this.evaluate(x, ContinuedFraction.DEFAULT_EPSILON, Integer.MAX_VALUE);
	};
	ContinuedFraction.prototype.evaluate2=function(x,epsilon){
		return this.evaluate(x, epsilon, Integer.MAX_VALUE);
	};
	ContinuedFraction.prototype.evaluate3=function(x,maxIterations){
		return this.evaluate(x, ContinuedFraction.DEFAULT_EPSILON, maxIterations);
	};
	ContinuedFraction.prototype.evaluate4=function(x,epsilon,maxIterations){
		var p0 = 1.0;
        var p1 = this.getA(0, x);
        var q0 = 0.0;
        var q1 = 1.0;
        var c = p1 / q1;
        var n = 0;
        var relativeError = Double.MAX_VALUE;
        while (n < maxIterations && relativeError > epsilon) {
            ++n;
            var a = this.getA(n, x);
            var b = this.getB(n, x);
            var p2 = a * p1 + b * p0;
            var q2 = a * q1 + b * q0;
            if (Double.isInfinite(p2) || Double.isInfinite(q2)) {
                // need to scale
                if (a != 0.0) {
                    p2 = p1 + (b / a * p0);
                    q2 = q1 + (b / a * q0);
                } else if (b != 0) {
                    p2 = (a / b * p1) + p0;
                    q2 = (a / b * q1) + q0;
                } else {
                    // can not scale an convergent is unbounded.
                    throw new ConvergenceException(ConvergenceException.ERROR,
                        "Continued fraction convergents diverged to +/- " +
                        "infinity.");
                }
            }
            var r = p2 / q2;
            relativeError = Math.abs(r / c - 1.0);
                
            // prepare for next iteration
            c = p2 / q2;
            p0 = p1;
            p1 = p2;
            q0 = q1;
            q1 = q2;
        }

        if (n >= maxIterations) {
            throw new ConvergenceException(ConvergenceException.ERROR,
                "Continued fraction convergents failed to converge.");
        }

        return c;
	};
	ContinuedFraction.prototype.getA=function(n,x){
		return ((2.0 * n) + 1.0) - a + x;
	};
	ContinuedFraction.prototype.getB=function(n,x){
		return n * (a - n);
	};
	var ret;
    if (Double.isNaN(a) || Double.isNaN(x) || (a <= 0.0) || (x < 0.0)) {
        ret = Double.NaN;
    } else if (x == 0.0) {
        ret = 1.0;
    } else if (x < a || a < 1.0) {
        // use regularizedGammaP because it should converge faster in this
        // case.
        ret = 1.0 - Gamma.regularizedGammaP2(a, x, epsilon, maxIterations);
    } else {
        // create continued fraction
        var cf = new ContinuedFraction();        
        ret = 1.0 / cf.evaluate4(x, epsilon, maxIterations);
        ret = Math.exp(-x + (a * Math.log(x)) - Gamma.logGamma(a)) * ret;
    }    
    return ret;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The GammaDistributionImpl class references to org.apache.commons.math.distribution.GammaDistributionImpl */

function GammaDistributionImpl(alpha,beta){
	this.jsjava_class="org.apache.commons.math.distribution.GammaDistributionImpl";		
	if (alpha <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"alpha must be positive");
    }
    this.alpha = alpha;
    if (beta <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"beta must be positive");
    }
    this.beta = beta;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
GammaDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    
    if (x <= 0.0) {
        ret = 0.0;
    } else {
        ret = Gamma.regularizedGammaP(this.getAlpha(), x / this.getBeta());
    }

    return ret;
};

/**
 * Access the shape parameter, alpha
 */
GammaDistributionImpl.prototype.getAlpha=function(){
	return this.alpha;
};

/**
 * Access the scale parameter, beta
 */
GammaDistributionImpl.prototype.getBeta=function(){
	return this.beta;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
GammaDistributionImpl.prototype.getDomainLowerBound=function(p){
	return Double.MIN_VALUE;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
GammaDistributionImpl.prototype.getDomainUpperBound=function(p){
	var ret;

    if (p < .5) {
        // use mean
        ret = this.getAlpha() * this.getBeta();
    } else {
        // use max value
        ret = Double.MAX_VALUE;
    }
    
    return ret;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
GammaDistributionImpl.prototype.getInitialDomain=function(p){
	var ret;

    if (p < .5) {
        // use 1/2 mean
        ret = this.getAlpha() * this.getBeta() * .5;
    } else {
        // use mean
        ret = this.getAlpha() * this.getBeta();
    }
    
    return ret;
};

/**
 * Modify the shape parameter, alpha.
 * param alpha
 */
GammaDistributionImpl.prototype.setAlpha=function(alpha){
	if (alpha <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"alpha must be positive");
    }
    this.alpha = alpha;
};

/**
 * Modify the scale parameter, beta.
 * param beta
 */
GammaDistributionImpl.prototype.setBeta=function(beta){
	if (beta <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"beta must be positive");
    }
    this.beta = beta;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Hashtable class references to java.util.Hashtable of J2SE1.4 */
 
/**
 * constructor
 */
function Hashtable(){
	this.jsjava_class="jsjava.util.Hashtable";
    this.capacity=50;
    this.size=0;
    this.span=10;
    this.elements=new Array(this.capacity);
}

/**
 * Increases the capacity of and internally reorganizes this 
 * hashtable, in order to accommodate and access its entries 
 * more efficiently.
 */
Hashtable.prototype.recapacity=function(){
    if(this.capacity-this.size<10){
     this.capacity+=this.span;
     var oldElements=this.elements;
        this.elements=new Array(this.capacity); 
        for(var i=0;i<this.size;i++){
            this.elements[i]=oldElements[i]; 
        }
    }
};

/**
 * Removes all mappings from this map 
 */
Hashtable.prototype.clear=function(){
    this.capacity=50;
    this.size=0;
    this.elements=new Array(this.capacity); 
};

/**
 * Associates the specified value with the specified key in this map 
 * param pname
 * param pvalue 
 */
Hashtable.prototype.put=function (pname,pvalue){
    this.recapacity();
    if(this.containsKey(pname)){
        for(var i=0;i<this.size;i++){
            var elem=this.elements[i];
            if(elem[0].equals(pname)){
                elem[1]=pvalue;
                return;
            } 
        } 
    }
    this.elements[this.size++]=[pname,pvalue];
   
};

/**
 * Returns the value to which this map maps the specified key. 
 * param pname
 */
Hashtable.prototype.get=function (pname){
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        if(elem[0].equals(pname)){
            return elem[1]; 
        } 
    }
};

/**
 * Returns true if this map contains a mapping for the specified key.
 * param pname
 */
Hashtable.prototype.containsKey=function(pname){
    if(this.get(pname)==undefined){
        return false; 
    }
    return true;
};

/**
 * Returns true if this map maps one or more keys to the specified value.
 * param pname
 */
Hashtable.prototype.containsValue=function (pvalue){
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        if(elem[1].equals(pvalue)){
            return true;
        } 
    }
    return false;
};

/**
 * Returns a array view of the values contained in this map.
 */
Hashtable.prototype.values=function (){
    var values=new Array(this.size);
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        values[i]=elem[1]; 
    } 
    return values;
};

/**
 * Returns a set view of the mappings contained in this map.
 */
Hashtable.prototype.entrySet=function (){
    return this.elements; 
};

/**
 * Returns true if this map contains no key-value mappings.
 */
Hashtable.prototype.isEmpty=function (){
    return this.size==0; 
};

/**
 * Returns an array of the keys in this hashtable.
 */
Hashtable.prototype.keys=function (){
    var keys=new Array(this.size);
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        keys[i]=elem[0]; 
    } 
    return keys;
};

/**
 * Returns an array of the keys in this hashtable.
 */
Hashtable.prototype.keySet=function (){
    var set=new Set();
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        set.add(elem[0]); 
    } 
    return set;
};

/**
 * Returns the number of keys in this hashtable.
 */
Hashtable.prototype.getSize=function (){
    return this.size; 
};

/**
 * Removes the key (and its corresponding value) from this hashtable.
 * param key
 */
Hashtable.prototype.remove=function (key){
    if(this.containsKey(key)){
        var oldElems=this.elements;
        var oldSize=this.size;
        this.elements=new Array(this.capacity);
        this.size=0;
        for(var i=0;i<oldSize;i++){
            var oldElem=oldElems[i];
            if(!oldElem[0].equals(key)){
                this.put(oldElem[0],oldElem[1]); 
            } 
        } 
    }
};

/**
 * add a array to the hash
 * param arr
 */
Hashtable.prototype.addArray=function (arr){
    if(arr!=null&&arr.length>0){
        for(var i=0;i<arr.length;i++){
            this.put(arr[i][0],arr[i][1]); 
        } 
    } 
};

/**
 * add a hash to the hash
 * param hash
 */
Hashtable.prototype.addHashtable=function (hash){
    if(hash!=null&&hash.size()>0){
        var keys=hash.keys();
        for(var i=0;i<keys.length;i++){
            this.put(keys[i],hash.get(keys[i])); 
        } 
    } 
};

/**
 * Returns a string representation of this Hashtable 
 * object in the form of a set of entries, enclosed 
 * in braces and separated by the ASCII characters ", " 
 * (comma and space).
 */
Hashtable.prototype.toString=function (){
    return this.elements.toString(); 
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The HttpRequest class references to javax.servlet.http.HttpServletRequest of J2EE1.4 */
 
/**
 * constructor
 * param url
 */
   function HttpRequest(url){
   	  this.jsjava_class="jsjavax.servlet.http.HttpRequest";
      this.url=url;
      if(!url||url==""){
          this.url=location.href;
      }
      this.pos=url.indexOf("?");    
      this.length=url.length;
      this.method="GET";
      this.queryString=this.url.substring(this.pos+1,this.length);
      this.parameterEntries=this.queryString.split("&");
   }
   
/**
 * return the value of the parameter named paramName
 * param paramName
 */
   HttpRequest.prototype.getParameter=function (paramName){
       if(!this.hasQuery){
           return null;
       }
       for(var i=0;i<this.parameterEntries.length;i++){
           var param=this.parameterEntries[i];
           var paramNameValue=param.split("=");
           if(paramNameValue[0]==paramName){
              return paramNameValue[1];
           }
       }
       return null;
   };
   
/**
 * return the values of the parameter named paramName
 * param paramName
 */
   HttpRequest.prototype.getParameterValues=function (paramName){
       if(!this.hasQuery){
           return null;
       }
       var paramNameCounter=0;
       for(var i=0;i<this.parameterEntries.length;i++){
           var param=this.parameterEntries[i];
           var paramNameValue=param.split("=");
           if(paramNameValue[0]==paramName){
               paramNameCounter++;
           }
       }
       var paramValues=new Array(paramNameCounter);
       paramValueCounter=0;
       for(var i=0;i<this.parameterEntries.length;i++){
           var param=this.parameterEntries[i];
           var paramNameValue=param.split("=");
           if(paramNameValue[0]==paramName){
              paramValues[paramValueCounter++]=paramNameValue[1];
           }
       }
       if(paramValueCounter==0){
           return null;
       }
       return paramValues;
   };
   
/**
 * judge wheter the request url has query
 */
   HttpRequest.prototype.hasQuery=function (){
       return this.pos!=-1
   };
   
/**
 * return the query string
 */
   HttpRequest.prototype.queryString=function (){
       return this.queryString;
   };
   
/**
 * return the request method
 */
   HttpRequest.prototype.getMethod=function (){
       return this.method;
   };

/**
 * return the request url
 */
   HttpRequest.prototype.getRequestURL=function (){
       return this.url; 
   };
   
/**
 * return the request uri
 */
   HttpRequest.prototype.getRequestURI=function (){
       var pos=this.url.indexOf("://");
       var uriPos=this.url.indexOf("/",pos+3);
       return this.url.substring(uriPos,this.pos);
   };
   
/**
 * return the context path
 */
   HttpRequest.prototype.getContextPath=function (){
       var pos=this.url.indexOf("://");
       var uriPos=this.url.indexOf("/",pos+3);
       var contextPathEndPos=this.url.indexOf("/",uriPos+1);
       return this.url.substring(uriPos,contextPathEndPos);
   };
   
/**
 * return the context name
 */
   HttpRequest.prototype.getContextName=function (){
       var contextPath=this.getContextPath();
       return contextPath.substring(1);
   };
   
/**
 * return all document cookies
 */
   HttpRequest.prototype.getCookies=function (){
       var cookies=document.cookie.split(";");
       return cookies; 
   };
   
/**
 * return the cookie value
 * param name
 */
   HttpRequest.prototype.getCookie=function(name){
       var dc = document.cookie;
       var prefix = name + "=";
       var begin = dc.indexOf("; " + prefix);
       if (begin == -1) {
	   begin = dc.indexOf(prefix);
	   if (begin != 0) {
	       return null;
	   }
       } else {
	   begin += 2;
       }
       var end = document.cookie.indexOf(";", begin);
       if (end == -1) {
	   end = dc.length;
       }
       return unescape(dc.substring(begin + prefix.length, end));	
   };
   
/**
 * remove a cookie
 * param name
 * param path
 * path domain
 */
   HttpRequest.prototype.removeCookie=function(name,path,domain){
       if (this.getCookie(name)) {
           document.cookie = name + "=" +
           ((path) ? "; path=" + path : "") +
           ((domain) ? "; domain=" + domain : "") +
           "; expires=Thu, 01-Jan-70 00:00:01 GMT";
       }
   };
   /**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The HttpResponse class references to javax.servlet.http.HttpServletResponse of J2EE1.4 */
 
/**
 * constructor
 */
function HttpResponse(){     
	this.jsjava_class="jsjavax.servlet.http.HttpResponse";
}

/**
 * add a cookie by items
 * param name
 * param value
 * param expires
 * param path
 * param domain
 * param secure
 */
HttpResponse.prototype.addCookieByItems=function (name, value, expires, path, domain, secure){
    var curCookie = name + "=" + escape(value) +
      ((expires) ? "; expires=" + expires.toGMTString() : "") +
      ((path) ? "; path=" + path : "") +
      ((domain) ? "; domain=" + domain : "") +
      ((secure) ? "; secure" : "");
    document.cookie = curCookie;
};

/**
 * add a cookie by object
 * param cookie
 */
HttpResponse.prototype.addCookie=function (cookie){
    if(cookie==null||cookie==undefined||cookie==""){
        return;
    }
    var cName=cookie.getName();
    var cValue=cookie.getValue();
    var cExpires=cookie.getMaxAge();
    var cPath=cookie.getPath();
    var cDomain=cookie.getDomain();
    var cSecure=cookie.getSecure();
    this.addCookieByItems(cName,cValue,cExpires,cPath,cDomain,cSecure);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The HypergeometricDistributionImpl class references to org.apache.commons.math.distribution.HypergeometricDistributionImpl */

function HypergeometricDistributionImpl(populationSize,numberOfSuccesses,sampleSize){
	this.jsjava_class="org.apache.commons.math.distribution.HypergeometricDistributionImpl";	
	if (numberOfSuccesses > populationSize) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"number of successes must be less than or equal to " +
            "population size");
    }
    if (sampleSize > populationSize) {
        throw new IllegalArgumentException(
        IllegalArgumentException.ERROR,"sample size must be less than or equal to population size");
    }
    if(populationSize <= 0){
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"population size must be positive.");
    }
    this.populationSize = populationSize;
    if (sampleSize < 0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"sample size must be non-negative.");
    }    
    this.sampleSize = sampleSize;
    if(numberOfSuccesses < 0){
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"number of successes must be non-negative.");
    }
    this.numberOfSuccesses = numberOfSuccesses;
}

/**
 * For this disbution, X, this method returns P(X �� x).
 * param x
 */
HypergeometricDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    var sx=new String(x);
	if(sx.indexOf(".")!=-1){
		x=Math.floor(x);
	}    
    var n = this.getPopulationSize();
    var m = this.getNumberOfSuccesses();
    var k = this.getSampleSize();

    var domain = this.getDomain(n, m, k);
    if (x < domain[0]) {
        ret = 0.0;
    } else if(x >= domain[1]) {
        ret = 1.0;
    } else {
        ret = this.innerCumulativeProbability(domain[0], x, 1, n, m, k);
    }
    
    return ret;
};

/**
 * Return the domain for the given hypergeometric distribution parameters.
 * param n
 * param m
 * param k
 */
HypergeometricDistributionImpl.prototype.getDomain=function(n,m,k){
	var arr=new Array(2);
	arr[0]=this.getLowerDomain(n, m, k);
	arr[1]=this.getUpperDomain(m, k);
	return arr;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a PDF root.
 * param p
 */
HypergeometricDistributionImpl.prototype.getDomainLowerBound=function(p){
	return this.getLowerDomain(this.getPopulationSize(), this.getNumberOfSuccesses(),
            this.getSampleSize());
};

/**
 * Access the domain value upper bound, based on p, used to bracket a PDF root.
 * param p
 */
HypergeometricDistributionImpl.prototype.getDomainUpperBound=function(p){
	return this.getUpperDomain(this.getSampleSize(), this.getNumberOfSuccesses());
};

/**
 * Return the lowest domain value for the given hypergeometric distribution parameters.
 * param n
 * param m
 * param k
 */
HypergeometricDistributionImpl.prototype.getLowerDomain=function(n,m,k){
	return Math.max(0, m - (n - k));
};

/**
 * Access the number of successes.
 */
HypergeometricDistributionImpl.prototype.getNumberOfSuccesses=function(){
	return this.numberOfSuccesses;
};

/**
 * Access the population size.
 */
HypergeometricDistributionImpl.prototype.getPopulationSize=function(){
	return this.populationSize;
};

/**
 * Access the sample size.
 */
HypergeometricDistributionImpl.prototype.getSampleSize=function(){
	return this.sampleSize;
};

/**
 * Return the highest domain value for the given hypergeometric distribution parameters.
 * param m
 * param k
 */
HypergeometricDistributionImpl.prototype.getUpperDomain=function(m,k){
	return Math.min(k, m);
};

/**
 * For this disbution, X, this method returns P(X = x).
 * param x
 */
HypergeometricDistributionImpl.prototype.probability=function(x){
	var ret;       
    var n = this.getPopulationSize();
    var m = this.getNumberOfSuccesses();
    var k = this.getSampleSize();
	var domain = this.getDomain(n, m, k);
    if(x < domain[0] || x > domain[1]){
        ret = 0.0;
    } else {
        ret = this.probability2(n, m, k, x);
    }
    
    return ret;
};

/**
 * For the disbution, X, defined by the given hypergeometric distribution
 * parameters, this method returns P(X = x).
 * param n
 * param m
 * param k
 * param x
 */
HypergeometricDistributionImpl.prototype.probability2=function(n, m, k, x){
	return Math.exp(MathUtils.binomialCoefficientLog(m, x) +
            MathUtils.binomialCoefficientLog(n - m, k - x) -
            MathUtils.binomialCoefficientLog(n, k));
};

/**
 * Modify the number of successes.
 * param num
 */
HypergeometricDistributionImpl.prototype.setNumberOfSuccesses=function(num){
	if(num < 0){
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"number of successes must be non-negative.");
    }
    this.numberOfSuccesses = num;
};

/**
 * Modify the population size.
 * param size
 */
HypergeometricDistributionImpl.prototype.setPopulationSize=function(size){
	if(size <= 0){
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"population size must be positive.");
    }
    this.populationSize = size;
};

/**
 * Modify the sample size.
 * param size
 */
HypergeometricDistributionImpl.prototype.setSampleSize=function(size){
	if (size < 0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"sample size must be non-negative.");
    }    
    this.sampleSize = size;
};

/**
 * For this disbution, X, this method returns P(X �� x).
 * param x
 */
HypergeometricDistributionImpl.prototype.upperCumulativeProbability=function(x){
	var ret;
    var sx=new String(x);
	if(sx.indexOf(".")!=-1){
		x=Math.floor(x);
	}     
    var n = this.getPopulationSize();
    var m = this.getNumberOfSuccesses();
    var k = this.getSampleSize();

    var domain = this.getDomain(n, m, k);
    if (x < domain[0]) {
        ret = 1.0;
    } else if(x > domain[1]) {
        ret = 0.0;
    } else {
        ret = this.innerCumulativeProbability(domain[1], x, -1, n, m, k);
    }
    
    return ret;
};

/**
 * For this disbution, X, this method returns P(X �� x).
 * param x
 */
HypergeometricDistributionImpl.prototype.innerCumulativeProbability=function(
	x0, x1, dx, n, m, k){
	var ret = this.probability2(n, m, k, x0);
    while (x0 != x1) {
        x0 += dx;
        ret += this.probability2(n, m, k, x0);
    }
    return ret;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The IllegalArgumentException class references to java.lang.IllegalArgumentException of J2SE1.4 */

IllegalArgumentException.prototype=new Error();
IllegalArgumentException.prototype.constructor=IllegalArgumentException;

IllegalArgumentException.ERROR=0;

/**
 * constructor
 * param code - error code
 * param message - error message
 */
function IllegalArgumentException(code,message){
	this.jsjava_class="jsjava.lang.IllegalArgumentException";
	this.code=code;
    this.message=message;
    this.name="jsjava.lang.IllegalArgumentException";

}
/**
 *  author:mathzhang
 *  Email:mathzhang8@163.com
 */

/**  The Inet4Address class references to java.net.Inet4Address of J2SE1.4 */
 
/**
 * constructor
 * param str
 */
function Inet4Address(str){
	this.jsjava_class="jsjava.net.Inet4Address";
    this.ip=str;
}

/**
 * return the ip address
 */
Inet4Address.prototype.getAddress=function(){
    return this.ip; 
};

/**
 * return the ip address in bytes array form
 */
Inet4Address.prototype.getBytesAddress=function(){
    return this.ip.split("."); 
};

/**
 * return a string description
 */
Inet4Address.prototype.toString=function(){
    return this.ip; 
};

/**
 * judge whether the input str is  valid ip address
 * param IPValue
 * param strict
 */
Inet4Address.isIpAddress=function(IPvalue,strict){
    if(strict != null  && strict == ""){
  /**  */
  if (IPvalue == "0.0.0.0")
   return false;
  else if (IPvalue == "255.255.255.255")
   return false;
 };
 theName = "IPaddress";
  /** match such as 568.335.1.2 */
 var ipPattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
 var ipArray = IPvalue.match(ipPattern);
 if (ipArray == null){
  return false;
 }else {
  for (i = 1; i < 5; i++)
  {
   thisSegment = parseInt(ipArray[i]);
   if (thisSegment > 255) {
    return false;
   }
   if (i == 1 && parseInt(ipArray[1]) == 0 ) {
    return false ;
   }
  }
 }
 return true; 
};

/**
 * judge whether the mask is a ip mask address
 * param mask
 */
Inet4Address.isIpMask=function(mask){
    var _maskTable = new Array("0.0.0.0", "128.0.0.0", "192.0.0.0", "224.0.0.0",
"240.0.0.0", "248.0.0.0", "252.0.0.0", "254.0.0.0", "255.0.0.0", "255.128.0.0",
"255.192.0.0", "255.224.0.0", "255.240.0.0", "255.248.0.0", "255.252.0.0",
"255.254.0.0", "255.255.0.0", "255.255.128.0", "255.255.192.0", "255.255.224.0",
"255.255.240.0", "255.255.248.0", "255.255.252.0", "255.255.254.0", "255.255.255.0",
"255.255.255.128", "255.255.255.192", "255.255.255.224", "255.255.255.240",
"255.255.255.248", "255.255.255.252", "255.255.255.254", "255.255.255.255");
 var i;
 for(i = 1; i< _maskTable.length -1; i++){
  if(mask == _maskTable[i]){
   return true;
  }
 }
 return(false); 
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Insets class references to java.awt.Insets of J2SE1.4 */
 
/**
 * constructor
 * param top
 * param left
 * param bottom
 * param right
 */
function Insets(top,left,bottom,right){
	this.jsjava_class="jsjava.awt.Insets";
    this.top=top;
    this.left=left;
    this.bottom=bottom;
    this.right=right;	
}

/**
 * return the Insets top
 */
Insets.prototype.getTop=function(){
    return this.top;	
}

/**
 * return the Insets left
 */
Insets.prototype.getLeft=function(){
    return this.left;	
}

/**
 * return the Insets bottom
 */
Insets.prototype.getBottom=function(){
    return this.bottom;	
}

/**
 * return the Insets right
 */
Insets.prototype.getRight=function(){
    return this.right;	

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Integer class references to java.lang.Integer of J2SE1.4 */
 
/**
 * constructor
 * param value
 */
function Integer(value){
	this.jsjava_class="jsjava.lang.Integer";
    this.value=value;
}
Integer.MIN=-Math.pow(2,31);
Integer.MAX=Math.pow(2,31)-1;
Integer.MIN_VALUE=-Math.pow(2,31);
Integer.MAX_VALUE=Math.pow(2,31)-1;

/**
 * check whether the input value is a int value
 * param d
 */
Integer.checkValid=function(i){
	if(isNaN(i)){
		return false;
	}
	i=parseInt(i);
    if(i<=Integer.MAX&&i>=Integer.MIN){
    	return true;
    }
    return false;
};

/**
 * return the int value parsed from str
 * param str
 */
Integer.parseInt=function(str){
    if(isNaN(str)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
    var i=parseInt(str);
    if(!Integer.checkValid(i)){
        return;
    }
    return i;
};

/**
 * compare whether this object value is equals to input Integer object value
 * param b input Integer object
 */
Integer.prototype.compareTo=function(b){
    if(b==undefined){
        return -1; 
    }
    if(this.value>b.value){
        return 1; 
    }else if(this.value==b.value){
        return 0; 
    }else{
        return -1;  
    }
};

/**
 * return the object's int value
 */
Integer.prototype.intValue=function(){
    return this.value; 
};

/**
 * return a string description
 */
Integer.prototype.toString=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Integer.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Integer"){
        return this.value==o.value; 
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function IntegerValidator(){
	this.jsjava_class="jsorg.eob.validator.IntegerValidator";
}

IntegerValidator.MIN=-Math.pow(2,31);
IntegerValidator.MAX=Math.pow(2,31)-1;

/**
 * Check whether the given value is int
 * param str - the given value
 */
IntegerValidator.validate=function(str){
	return Integer.checkValid(str);
};

/**
 * Check whether the given value is int
 * param i - the given value
 */
IntegerValidator.validate2=function(i){
	if(isNaN(i)){
		return false;
	}
	if(typeof(i)=="number"){
		if(Math.floor(i)!=i){
			return false;
		}
	}else{
		if(i.indexOf(".")!=-1){
			return false;
		}
	}
	i=parseInt(i);
	if(i<=IntegerValidator.MAX&&i>=IntegerValidator.MIN){
    	return true;
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The MatrixIndexException class references to org.apache.commons.math.linear.InvalidMatrixException */

InvalidMatrixException.prototype=new Error();
InvalidMatrixException.prototype.constructor=InvalidMatrixException;

InvalidMatrixException.ERROR=0;

/**
 * constructor
 * param msg
 */
function InvalidMatrixException(code,message){
	this.jsjava_class="org.apache.commons.math.linear.InvalidMatrixException";
	this.code=code;
    this.message=message;
    this.name="org.apache.commons.math.linear.InvalidMatrixException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function IP4Validator(){
	this.jsjava_class="jsorg.eob.validator.IP4Validator";
}

/**
 * Check whether the given value is valid IP address
 * param str - the given value
 * param strict - boolean flag
 */
IP4Validator.validate=function(str,strict){
	if(strict != null  && strict == ""){
		if (str == "0.0.0.0")
			return false;
		else if (str == "255.255.255.255")
			return false;
	};
	theName = "IPaddress";
	var ipPattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
	var ipArray = str.match(ipPattern);
	if (ipArray == null){
		return false;
	}else {
		for (i = 1; i < 5; i++){
			thisSegment = parseInt(ipArray[i]);
			if (thisSegment > 255) {
				return false;
			}
			if (i == 1 && parseInt(ipArray[1]) == 0 ) {
				return false ;
			}
		}
	}
	return true; 

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Iterator class references to java.util.Iterator of J2SE1.4 */
 
/**
 * constructor
 * param list a List object
 */
function Iterator(list){
	this.jsjava_class="jsjava.util.Iterator";
    this.list=list;
    this.nextIndex=0;
    this.size=list.getSize();
}

/**
 * Returns true if the iteration has more elements.
 */
Iterator.prototype.hasNext=function(){
    return this.nextIndex<this.size;
};

/**
 * Returns the next element in the iteration.
 */
Iterator.prototype.next=function(){
    var nextObj;
    if(this.nextIndex<this.size){
        nextObj=this.list.get(this.nextIndex);
        this.nextIndex++;
        return nextObj;
    }
    return null;
};

/**
 * Move the opertion position to the specified index
 */
Iterator.prototype.moveTo=function(index){
    this.nextIndex=index;	

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The JLabel class references to javax.swing.JLabel of J2SE1.4 */
 
/**
 * constructor
 * param text
 */
function JLabel(text){
	this.jsjava_class="jsjavax.swing.JLabel";
    this.text=text;    
    this.invisible=true;
}

/**
 * return the text
 */
JLabel.prototype.getText=function(){
    return this.text;	
};

/**
 * set the text
 * param text
 */
JLabel.prototype.setText=function(text){
    this.text=text;	
};

/**
 * set the font
 * param font
 */
JLabel.prototype.setFont=function(font){
    this.font=font;	
};

/**
 * return the font
 */
JLabel.prototype.getFont=function(){
    return this.font;	
};

/**
 * set foreground color
 * param foreground
 */
JLabel.prototype.setForeground=function(foreground){
    this.foreground=foreground;	
};

/**
 * return foreground color
 */
JLabel.prototype.getForeground=function(){
    return this.foreground;	
};

/**
 * set the border
 * param border
 */
JLabel.prototype.setBorder=function(border){
    this.border=border;	
};

/**
 * return the border
 */
JLabel.prototype.getBorder=function(){
    return this.border;	
};

/**
 * set the background color
 * param background
 */
JLabel.prototype.setBackground=function(background){
    this.background=background;	
};

/**
 * return the background colore
 */
JLabel.prototype.getBackground=function(){
    return this.background;	
};

/**
 * set the insets
 * param insets
 */
JLabel.prototype.setInsets=function(insets){
    this.insets=insets;	
};

/**
 * return the insets
 */
JLabel.prototype.getInsets=function(){
    return this.insets;	
};

/**
 * set the invisibility
 * param invisible true or false
 */
JLabel.prototype.setInvisible=function(invisible){
    this.invisible=invisible;	
};

/**
 * return the invisibility
 */
JLabel.prototype.getInvisible=function(){
    return this.invisible;	
};

/**
 * return the display content HTML
 */
JLabel.prototype.show=function(){
    var border=this.getBorder();
    var font=this.getFont();
    var foreground=this.getForeground();
    var background=this.getBackground();
    var insets=this.getInsets();
    var invisible=this.getInvisible();
    var display="inline";
    if(!invisible){
        display="none";	
    }
    var str="";
    str+="<span style='border-width:";
    str+=border.getWidth();
    str+=";border-color:";
    str+=border.getColor();
    str+=";border-style:";
    str+=border.getStyle();
    str+=";color:";
    str+=foreground.getHex();
    str+=";font-family:";
    str+=font.getFamily();
    str+=";font-size:";
    str+=font.getSize();
    str+=";background-color:";
    str+=background.getHex();
    str+=";padding:";
    str+=insets.getTop()+" "+insets.getRight()+" "+insets.getBottom()+" "+insets.getLeft();
    str+=";display:";
    str+=display;
    str+=";'>";
    str+=this.getText();
    str+="</span>";
    document.writeln(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The JTextField class references to javax.swing.JTextField of J2SE1.4 */
 
/**
 * constructor
 * param text
 */
function JTextField(text){
	this.jsjava_class="jsjavax.swing.JTextField";
    this.text=text;    
    this.invisible=true;
}

/**
 * return the text
 */
JTextField.prototype.getText=function(){
    return this.text;	
};

/**
 * set the text
 * param text
 */
JTextField.prototype.setText=function(text){
    this.text=text;	
};

/**
 * set the font
 * param font
 */
JTextField.prototype.setFont=function(font){
    this.font=font;	
};

/**
 * return the font
 */
JTextField.prototype.getFont=function(){
    return this.font;	
};

/**
 * set the foreground colore
 * param foreground
 */
JTextField.prototype.setForeground=function(foreground){
    this.foreground=foreground;	
};

/**
 * return the foreground color
 */
JTextField.prototype.getForeground=function(){
    return this.foreground;	
};

/**
 * set the border
 * param border
 */
JTextField.prototype.setBorder=function(border){
    this.border=border;	
};

/**
 * return the border
 */
JTextField.prototype.getBorder=function(){
    return this.border;	
};

/**
 * set the background colore
 * param background
 */
JTextField.prototype.setBackground=function(background){
    this.background=background;	
};

/**
 * return the background colore
 */
JTextField.prototype.getBackground=function(){
    return this.background;	
};

/**
 * set the insets
 * param insets
 */
JTextField.prototype.setInsets=function(insets){
    this.insets=insets;	
};

/**
 * return the insets
 */
JTextField.prototype.getInsets=function(){
    return this.insets;	
};

/**
 * set the invisibility
 * param invisible
 */
JTextField.prototype.setInvisible=function(invisible){
    this.invisible=invisible;	
};

/**
 * return the invisibility
 */
JTextField.prototype.getInvisible=function(){
    return this.invisible;	
};

/**
 * return the display content HTML
 */
JTextField.prototype.show=function(){
    var border=this.getBorder();
    var font=this.getFont();
    var foreground=this.getForeground();
    var background=this.getBackground();
    var insets=this.getInsets();
    var invisible=this.getInvisible();
    var display="inline";
    if(!invisible){
        display="none";	
    }
    var str="";
    str+="<input style='border-width:";
    str+=border.getWidth();
    str+=";border-color:";
    str+=border.getColor();
    str+=";border-style:";
    str+=border.getStyle();
    str+=";color:";
    str+=foreground.getHex();
    str+=";font-family:";
    str+=font.getFamily();
    str+=";font-size:";
    str+=font.getSize();
    str+=";background-color:";
    str+=background.getHex();
    str+=";padding:";
    str+=insets.getTop()+" "+insets.getRight()+" "+insets.getBottom()+" "+insets.getLeft();
    str+=";display:";
    str+=display;
    str+=";'";
    str+="value='"+this.getText()+"'";
    str+="/>";
    document.writeln(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The List class references to java.util.List of J2SE1.4 */
 
/**
 * constructor
 */
function List(){
	this.jsjava_class="jsjava.util.List";
    this.capacity=50;
    this.size=0;
    this.span=10;
    this.elements=new Array(this.capacity);
}

/**
 * Increases the capacity of and internally reorganizes this 
 * list, in order to accommodate and access its entries 
 * more efficiently.
 */
List.prototype.recapacity=function (){
    if(this.capacity-this.size<10){
     this.capacity+=this.span;
     var oldElements=this.elements;
        this.elements=new Array(this.capacity); 
        for(var i=0;i<this.size;i++){
            this.elements[i]=oldElements[i]; 
        }
    }
};

/**
 * Appends the specified element to the end of this list
 * param pvalue
 */
List.prototype.add=function (pvalue){
    this.recapacity();
    this.elements[this.size++]=pvalue; 
};

/**
 * Inserts the specified element at the specified position in this list
 * param index
 * param pvalue
 */
List.prototype.addIndexOf=function (index,pvalue){
    this.recapacity();
    if(index>=this.size){
        this.elements[this.size]=pvalue;
        return; 
    }
    this.size++;      
    for(var i=this.size-1;i>index;i--){
     this.elements[i]=this.elements[i-1];
    } 
    this.elements[index]=pvalue;
};

/**
 * Removes all of the elements from this list
 */
List.prototype.clear=function (){
    this.elements=new Array(this.capacity); 
};

/**
 * Returns true if this list contains the specified element.
 * param pvalue
 */
List.prototype.contains=function (pvalue){
    for(var i=0;i<this.size;i++){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return true; 
        } 
    } 
    return false;
};

/**
 * Returns the element at the specified position in this list.
 * param index
 */
List.prototype.get=function (index){
    return this.elements[index];
};

/**
 * Returns the index in this list of the first occurrence of the 
 * specified element, or -1 if this list does not contain this element.
 * param pvalue
 */
List.prototype.indexOf=function (pvalue){
    for(var i=0;i<this.size;i++){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return i; 
        } 
    } 
    return -1;
};

/**
 * Returns true if this list contains no elements.
 */
List.prototype.isEmpty=function (){
    return this.size==0;
};

/**
 * Returns an iterator over the elements in this list in proper sequence.
 */
List.prototype.iterator=function (){
    return new Iterator(this);
};

/**
 * Returns the index in this list of the last occurrence of the specified 
 * element, or -1 if this list does not contain this
 */
List.prototype.lastIndexOf=function (pvalue){
    for(var i=this.size-1;i>=0;i--){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return i; 
        } 
    } 
    return -1;
};

/**
 * Removes the element at the specified position in this list
 * param index
 */
List.prototype.removeIndexOf=function (index){
    if(index>-1&&index<this.size){
     var oldElems=this.elements;
     this.elements=new Array(this.capacity);
     this.size--;
     for(var i=0;i<this.size;i++){
         if(i<index){
             this.elements[i]=oldElems[i]; 
         }else{
             this.elements[i]=oldElems[i+1];
         } 
        
     }
    }
};

/**
 * Removes the first occurrence in this list of the specified element
 * param pvalue
 */
List.prototype.remove=function (pvalue){
    this.removeIndexOf(this.indexOf(pvalue));
};

/**
 * Replaces the element at the specified position in this list with the 
 * specified element
 * param index
 * param pvalue
 */
List.prototype.set=function (index,pvalue){
    this.elements[index]=pvalue;
};

/**
 * Returns a view of the portion of this list between the specified 
 * fromIndex, inclusive, and toIndex, exclusive.
 * param index1
 * param index2
 */
List.prototype.subList=function (index1,index2){
    var l=new List();
    for(var i=index1;i<index2;i++){
        l.add(this.elements[i]); 
    }
    return l;
};

/**
 * Appends all of the elements in the specified array to the end of 
 * this list
 * param arr
 */
List.prototype.addArray=function (arr){
    if(arr==undefined||arr.length==undefined){
        return; 
    } 
    for(var i=0;i<arr.length;i++){
        this.add(arr[i]); 
    }
};

/**
 * Appends all of the elements in the specified list to the end of 
 * this list
 * param list
 */
List.prototype.addList=function (list){
    if(list==undefined||list.size<=0){
        return; 
    }
    this.addArray(list.elements);
};

/**
 * Returns the number of elements in this list. 
 */
List.prototype.getSize=function (){
    return this.size;
};

/**
 * Returns an array containing all of the elements 
 * in this list in proper sequence. 
 */
List.prototype.toArray=function (){
    var arr=new Array(this.size);
    for(var i=0;i<this.size;i++){
        arr[i]=this.elements[i]; 
    } 
    return arr;
};

/**
 * Returns a string representation of this List object
 */
List.prototype.toString=function (){
    return this.toArray().toString(); 
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Locale class references to java.util.Locale of J2SE1.4 */

/**
 * Construct a locale from language, country, variant.
 */
function Locale(language,country,variant){
	this.jsjava_class="jsjava.util.Locale";
	this.language=language;
	this.country=country;
	this.variant=variant;
	this.displayLanguage="";
	this.displayCountry="";
	this.displayVariant="";
}
Locale.locales=[["ar","Arabic","","","",""],["ar","Arabic","AE","United Arab Emirates","",""],["ar","Arabic","BH","Bahrain","",""],["ar","Arabic","DZ","Algeria","",""],["ar","Arabic","EG","Egypt","",""],["ar","Arabic","IQ","Iraq","",""],["ar","Arabic","JO","Jordan","",""],["ar","Arabic","KW","Kuwait","",""],["ar","Arabic","LB","Lebanon","",""],["ar","Arabic","LY","Libya","",""],["ar","Arabic","MA","Morocco","",""],["ar","Arabic","OM","Oman","",""],["ar","Arabic","QA","Qatar","",""],["ar","Arabic","SA","Saudi Arabia","",""],["ar","Arabic","SD","Sudan","",""],["ar","Arabic","SY","Syria","",""],["ar","Arabic","TN","Tunisia","",""],["ar","Arabic","YE","Yemen","",""],["hi","Hindi","IN","India","",""],["iw","Hebrew","","","",""],["iw","Hebrew","IL","Israel","",""],["ja","Japanese","","","",""],["ja","Japanese","JP","Japan","",""],["ko","Korean","","","",""],["ko","Korean","KR","South Korea","",""],["th","Thai","","","",""],["th","Thai","TH","Thailand","",""],["th","Thai","TH","Thailand","TH","TH"],["zh","Chinese","","","",""],["zh","Chinese","CN","China","",""],["zh","Chinese","HK","Hong Kong","",""],["zh","Chinese","TW","Taiwan","",""],["be","Byelorussian","","","",""],["be","Byelorussian","BY","Belarus","",""],["bg","Bulgarian","","","",""],["bg","Bulgarian","BG","Bulgaria","",""],["ca","Catalan","","","",""],["ca","Catalan","ES","Spain","",""],["cs","Czech","","","",""],["cs","Czech","CZ","Czech Republic","",""],["da","Danish","","","",""],["da","Danish","DK","Denmark","",""],["de","German","","","",""],["de","German","AT","Austria","",""],["de","German","CH","Switzerland","",""],["de","German","DE","Germany","",""],["de","German","LU","Luxembourg","",""],["el","Greek","","","",""],["el","Greek","GR","Greece","",""],["en","English","AU","Australia","",""],["en","English","CA","Canada","",""],["en","English","GB","United Kingdom","",""],["en","English","IE","Ireland","",""],["en","English","IN","India","",""],["en","English","NZ","New Zealand","",""],["en","English","ZA","South Africa","",""],["es","Spanish","","","",""],["es","Spanish","AR","Argentina","",""],["es","Spanish","BO","Bolivia","",""],["es","Spanish","CL","Chile","",""],["es","Spanish","CO","Colombia","",""],["es","Spanish","CR","Costa Rica","",""],["es","Spanish","DO","Dominican Republic","",""],["es","Spanish","EC","Ecuador","",""],["es","Spanish","ES","Spain","",""],["es","Spanish","GT","Guatemala","",""],["es","Spanish","HN","Honduras","",""],["es","Spanish","MX","Mexico","",""],["es","Spanish","NI","Nicaragua","",""],["es","Spanish","PA","Panama","",""],["es","Spanish","PE","Peru","",""],["es","Spanish","PR","Puerto Rico","",""],["es","Spanish","PY","Paraguay","",""],["es","Spanish","SV","El Salvador","",""],["es","Spanish","UY","Uruguay","",""],["es","Spanish","VE","Venezuela","",""],["et","Estonian","","","",""],["et","Estonian","EE","Estonia","",""],["fi","Finnish","","","",""],["fi","Finnish","FI","Finland","",""],["fr","French","","","",""],["fr","French","BE","Belgium","",""],["fr","French","CA","Canada","",""],["fr","French","CH","Switzerland","",""],["fr","French","FR","France","",""],["fr","French","LU","Luxembourg","",""],["hr","Croatian","","","",""],["hr","Croatian","HR","Croatia","",""],["hu","Hungarian","","","",""],["hu","Hungarian","HU","Hungary","",""],["is","Icelandic","","","",""],["is","Icelandic","IS","Iceland","",""],["it","Italian","","","",""],["it","Italian","CH","Switzerland","",""],["it","Italian","IT","Italy","",""],["lt","Lithuanian","","","",""],["lt","Lithuanian","LT","Lithuania","",""],["lv","Latvian (Lettish)","","","",""],["lv","Latvian (Lettish)","LV","Latvia","",""],["mk","Macedonian","","","",""],["mk","Macedonian","MK","Macedonia","",""],["nl","Dutch","","","",""],["nl","Dutch","BE","Belgium","",""],["nl","Dutch","NL","Netherlands","",""],["no","Norwegian","","","",""],["no","Norwegian","NO","Norway","",""],["no","Norwegian","NO","Norway","NY","Nynorsk"],["pl","Polish","","","",""],["pl","Polish","PL","Poland","",""],["pt","Portuguese","","","",""],["pt","Portuguese","BR","Brazil","",""],["pt","Portuguese","PT","Portugal","",""],["ro","Romanian","","","",""],["ro","Romanian","RO","Romania","",""],["ru","Russian","","","",""],["ru","Russian","RU","Russia","",""],["sh","Serbo-Croatian","","","",""],["sh","Serbo-Croatian","YU","Yugoslavia","",""],["sk","Slovak","","","",""],["sk","Slovak","SK","Slovakia","",""],["sl","Slovenian","","","",""],["sl","Slovenian","SI","Slovenia","",""],["sq","Albanian","","","",""],["sq","Albanian","AL","Albania","",""],["sr","Serbian","","","",""],["sr","Serbian","YU","Yugoslavia","",""],["sv","Swedish","","","",""],["sv","Swedish","SE","Sweden","",""],["tr","Turkish","","","",""],["tr","Turkish","TR","Turkey","",""],["uk","Ukrainian","","","",""],["uk","Ukrainian","UA","Ukraine","",""],["en","English","","","",""],["en","English","US","United States","",""]];

/**
 * Returns a list of all installed locales.
 */
Locale.getAvailableLocales=function(){
	var length=Locale.locales.length;
	var larr=new Array(length);
	for(var i=0;i<length;i++){
		var arr=Locale.locales[i];
		var locale=new Locale(arr[0],arr[2],arr[4]);
		locale.displayLanguage=arr[1];
		locale.displayCountry=arr[3];
		locale.displayVariant=arr[5];
		larr[i]=locale;
	}
	return larr;
};

/**
 * Returns the country/region code for this locale, which will either be the 
 * empty string or an upercase ISO 3166 2-letter code.
 */
Locale.prototype.getCountry=function(){
	return this.country;
};

/**
 * Returns a name for the locale's country that is appropriate for display to the user.
 */
Locale.prototype.getDisplayCountry=function(){
	return this.displayCountry;
};

/**
 * Returns the language code for this locale, which will either be the empty string or a lowercase ISO 639 code.
 */
Locale.prototype.getLanguage=function(){
	return this.language;
};

/**
 * Returns a name for the locale's language that is appropriate for display to the user.
 */
Locale.prototype.getDisplayLanguage=function(){
	return this.displayLanguage;
};

/**
 * Returns the variant code for this locale.
 */
Locale.prototype.getVariant=function(){
	return this.variant;
};

/**
 * Returns a name for the locale's variant code that is appropriate for display to the user.
 */
Locale.prototype.getDisplayVariant=function(){
	return this.displayVariant;
};

/**
 * Getter for the programmatic name of the entire locale, with the language, country and variant separated by underbars.
 */
Locale.prototype.toString=function(){
	var str="";
	var language=this.language
	if(language!=""){
		str+=language;
	}
	var country=this.country;
	if(country!=""){
		str+="-"+country;
	}
	return str;
};

/**
 * Returns true if this Locale is equal to another object.
 */
Locale.prototype.equals=function(o){
	if(!o){
		return false;
	}
	if(o.jsjava_class&&o.jsjava_class=="jsjava.util.Locale"){
        if(this.language==o.language&&this.country==o.country&&this.variant==o.variant){
			return true;
		}	
	}
	return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The LocaleUtils class references to org.apache.commons.lang.LocaleUtils */
 
function LocaleUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.LocaleUtils";
}

/**
 * Obtains an unmodifiable list of installed locales.
 */
LocaleUtils.availableLocaleList=function(){
	var list=new List();
	list.addArray(Locale.getAvailableLocales());
	return list;
};

/**
 * Obtains an unmodifiable set of installed locales.
 */
LocaleUtils.availableLocaleSet=function(){
	var set=new Set();
	set.addArray(Locale.getAvailableLocales());
	return set;
};

/**
 * Obtains the list of countries supported for a given language.
 * param language
 */
LocaleUtils.countriesByLanguage=function(language){
	var larr=Locale.getAvailableLocales();
	var length=larr.length;
	var list=new List();
	for(var i=0;i<length;i++){
		var locale=larr[i];
		if(locale.getLanguage()==language){
			list.add(locale);
		}
	}
	return list;
};

/**
 * Checks if the locale specified is in the list of available locales.
 * param locale
 */
LocaleUtils.isAvailableLocale=function(locale){
	var larr=Locale.getAvailableLocales();
	var length=larr.length;
	for(var i=0;i<length;i++){
		var clocale=larr[i];
		if(clocale.equals(locale)){
			return true;
		}
	}
	return false;
};

/**
 * Obtains the list of languages supported for a given country.
 * param country
 */
LocaleUtils.languagesByCountry=function(country){
	var larr=Locale.getAvailableLocales();
	var length=larr.length;
	var list=new List();
	for(var i=0;i<length;i++){
		var locale=larr[i];
		if(locale.getCountry()==country){
			list.add(locale);
		}
	}
	return list;
};

/**
 * Converts a String to a Locale.
 * param str
 */
LocaleUtils.toLocale=function(str){
	var arr=str.split("_");
	var length=arr.length;
	var language="";
	var country="";
	var variant="";
	if(length>=1){
		language=arr[0];
	}
	if(length>=2){
		country=arr[1];
	}
	if(length>=3){
		variant=arr[2];
	}
	var locale=new Locale(language,country,variant);
	if(LocaleUtils.isAvailableLocale(locale)){
		return locale;
	}
	return null;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Long class references to java.lang.Long of J2SE1.4 */
 
/**
 * constructor
 * param value
 */ 
function Long(value){
	this.jsjava_class="jsjava.lang.Long";
    this.value=value;
}
Long.MIN=-Math.pow(2,63);
Long.MAX=Math.pow(2,63)-1;
Long.MIN_VALUE=-Math.pow(2,63);
Long.MAX_VALUE=Math.pow(2,63)-1;

/**
 * check whether the input value is a long value
 * param l
 */
Long.checkValid=function(l){
	if(isNaN(l)){
		return false;
	}
	l=parseInt(l);
    if(l<=Long.MAX&&l>=Long.MIN){
    	return true;
    }
    return false;
};

/**
 * return the long value parsed from str
 * param str
 */
Long.parseLong=function(str){
    if(isNaN(str)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
    var l=parseInt(str);
    if(!Long.checkValid(l)){
        return;
    }
    return l;
};

/**
 * compare whether this object value is equals to input Long object value
 * param b input Long object
 */
Long.prototype.compareTo=function(b){
    if(b==undefined){
        return -1; 
    }
    if(this.value>b.value){
        return 1; 
    }else if(this.value==b.value){
        return 0; 
    }else{
        return -1;  
    }
};

/**
 * return the object's long value
 */
Long.prototype.longValue=function(){
    return this.value;
};

/**
 * return a string description
 */
Long.prototype.toString=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Long.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Long"){
        return this.value==o.value; 
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**
 * Constructor
 */
function LongValidator(){
	this.jsjava_class="jsorg.eob.validator.LongValidator";
}

LongValidator.MIN=-Math.pow(2,63);
LongValidator.MAX=Math.pow(2,63)-1;

/**
 * Check whether the given value is long
 * param str - the given value
 */
LongValidator.validate=function(str){
	return Long.checkValid(str);
};

/**
 * Check whether the given value is long
 * param l - the given value
 */
LongValidator.validate2=function(l){
	if(isNaN(l)){
		return false;
	}
	if(typeof(l)=="number"){
		if(Math.floor(l)!=l){
			return false;
		}
	}else{
		if(l.indexOf(".")!=-1){
			return false;
		}
	}
	l=parseInt(l);
	if(l<=LongValidator.MAX&&l>=LongValidator.MIN){
    	return true;
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The MathException class references to org.apache.commons.math.MathException */

MathException.prototype=new Error();
MathException.prototype.constructor=MathException;

MathException.ERROR=0;

/**
 * param code - error code
 * param message - error message
 */
function MathException(code,message){
	this.jsjava_class="org.apache.commons.math.MathException";
	this.code=code;
    this.message=message;
    this.name="org.apache.commons.math.MathException";

}

/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The MatrixIndexException class references to org.apache.commons.math.linear.MatrixIndexException */

MatrixIndexException.prototype=new Error();
MatrixIndexException.prototype.constructor=MatrixIndexException;

MatrixIndexException.ERROR=0;

/**
 * constructor
 * param msg
 */
function MatrixIndexException(code,message){
	this.jsjava_class="org.apache.commons.math.linear.MatrixIndexException";
	this.code=code;
    this.message=message;
    this.name="org.apache.commons.math.linear.MatrixIndexException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The MatrixUtils class references to org.apache.commons.math.linear.MatrixUtils */
 
function MatrixUtils(){
	this.jsjava_class="jsorg.apache.commons.math.linear.MatrixUtils";
}

MatrixUtils.createRowRealMatrix=function(rowData){
	var nCols = rowData.length;
    var data=new Array(1);
    for(var i=0;i<1;i++){
    	data[i]=new Array(nCols);
    }
    for(var j=0;j<nCols;j++){
    	data[0][j]=rowData[j];
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(data);
};

MatrixUtils.createColumnRealMatrix=function(columnData){
	var nRows = columnData.length;
    var data=new Array(nRows);
    for(var i=0;i<nRows;i++){
    	data[i]=new Array(1);
    }
    for (var row = 0; row < nRows; row++) {
        data[row][0] = columnData[row];
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(data);
};


MatrixUtils.createRealIdentityMatrix=function(dimension){
	var out = new RealMatrixImpl(dimension, dimension);
    var d = out.getDataRef();
    for (var row = 0; row < dimension; row++) {
        for (var col = 0; col < dimension; col++) {
            d[row][col] = row == col ? 1 : 0;
        }
    }
    return out;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Menu class does not references to java.awt.Menu of J2SE1.4 */
 
/**
 * constructor
 * param id
 * param capacity the number of the menu being able to contain menutiems 
 */
function Menu(id,capacity){
	  this.jsjava_class="jsorg.eob.component.menu.Menu";
      this.id=id;                        
      this.capacity=capacity;            
      this.children=new Array(capacity); 
      this.size=0;                       
      this.isLeaf=false;
      if(capacity==0)
      {
         this.isLeaf=true;
      }  
      this.parent=null;
      this._isURLForbid=false;
      this._isScriptForbid=false;
      this._isPassURLScriptArgsOnly=false;
   }
   
   /**
    * set menu title
    * param title
    */
   Menu.prototype.setTitle=function (title){
      this.title=title;
   };  
   
   /**
    * get menu title
    */
   Menu.prototype.getTitle=function(){
      return this.title;
   };  
   
   /**
    * add a menuitem
    * param childNode a menu object
    */
   Menu.prototype.addChild=function (childNode){
      this.children[this.size]=childNode;
      this.size=this.size+1;
      childNode.parent=this;
   };   
   
   /**
    * get all child menuitems
    */     
   Menu.prototype.getChildren=function (){
      var children=new Array(this.size);
      for(var i=0;i<children.length;i++)
      {
         children[i]=this.children[i];
      }
      return children;
   };    
   
   /**
    * get menu's parent menu
    */  
   Menu.prototype.getParent=function (){
      return this.parent;
   };   
   
   /**
    * set menu display icon
    * param icon a image url string
    */
   Menu.prototype.setIcon=function (icon){
      this.icon=icon;
   };    
   
   /**
    * return menu icon
    */
   Menu.prototype.getIcon=function (){
      return this.icon;
   };  
   
   /**
    * set menu default icon
    * param defaultIcon
    */            
   Menu.prototype.setDefaultIcon=function (defaultIcon){
      this.defaultIcon=defaultIcon;
   };
   
   /**
    * return menu default icon
    */
   Menu.prototype.getDefaultIcon=function (){
      return this.defaultIcon;
   };
   
   /**
    * set menu link
    * param url a url string 
    */
   Menu.prototype.setLink=function (url){
      this.url=url;
   };    
   
   /**
    * return menu link
    */  
   Menu.prototype.getLink=function (){
      return this.url;
   };      
   
   /**
    * set menu link target such as _blank _top and so on
    * param target
    */  
   Menu.prototype.setTarget=function (target){
      this.target=target;	
   };   
   
   /**
    * get menu link target
    */
   Menu.prototype.getTarget=function (){
      return this.target;	
   };    
   
   /**
    * set features of the window of the linked page such as menubar=no status=no and so on
    * param title
    */      
   Menu.prototype.setFeature=function (feature){
      this.feature=feature;	
   };
   
   /**
    * get features of the window of the linked page
    */
   Menu.prototype.getFeature=function (){
      return this.feature;	
   };
   
   /**
    * set menu script function name on clicking the menu
    * param scriptName javascript function name of the page
    */
   Menu.prototype.setScriptName=function (scriptName){
      this.scriptName=scriptName;	
   };  
   
   /**
    * get menu script function name
    */
   Menu.prototype.getScriptName=function (){
      return this.scriptName;	
   };  
   
   /**
    * set menu script function arguments
    * param scriptArgs 
    */
   Menu.prototype.setScriptArgs=function (scriptArgs){
      this.scriptArgs=scriptArgs;	
   };  
   
   /**
    * get menu script function arguments
    */
   Menu.prototype.getScriptArgs=function (){
      return this.scriptArgs;	
   };  	
   
   /**
    * set script function on mouse over the menu
    * param mouseover
    */
   Menu.prototype.setMouseover=function (mouseover){
      this.mouseover=mouseover;	
   };
   
   /**
    * get script function on mouse over the menu
    */
   Menu.prototype.getMouseover=function (){
      return this.mouseover;
   };	
   
   /**
    * set script function on mouse out of he menu
    * param mouseout
    */
   Menu.prototype.setMouseout=function (mouseout){
      this.mouseout=mouseout;	
   };
   
   /**
    * get script function on mouse out of the menu
    */
   Menu.prototype.getMouseout=function (){
      return this.mouseout;
   };
   
   /**
    * set menu background color
    * param background a color
    */
   Menu.prototype.setBackground=function (background){
      this.background=background;	
   };
   
   /**
    * get menu background color
    */
   Menu.prototype.getBackground=function (){
      return this.background;	
   };
   
   /**
    * set the boolean value whether rendering the menu display on mouse over the menu
    * param isRender a boolean value
    */
   Menu.prototype.setMouseRender=function (isRender){
      this.mouseRender=isRender;	
   };
   
   /**
    * get the boolean value whether rendering the menu display on mouse over the menu
    */
   Menu.prototype.isMouseRender=function(){
      return this.mouseRender;	
   };
   
   /**
    * return the display HTML content
    */
   Menu.prototype.getContent=function (){
   	var topNode=this.getTop();
        var content="<table width='100%' cellpadding='3' cellspacing='0' borderColor='#316AC5' class='WindowMenu' background='"+this.getBackground(this)+"'>";
    	for(var i=0;i<this.size;i++){
    	    var child=this.children[i];
    	    var linkUrl=child.getLink();
    	    var linkTarget=child.getTarget();
    	    var clickStr=child.getScriptName();
    	    var scriptArgs=child.getScriptArgs();
    	    if(clickStr==null||clickStr==""){
    	        clickStr=topNode.getScriptName();	
    	        scriptArgs=topNode.getScriptArgs();
    	    }
    	    var cursor="default";
    	    if(clickStr==null||clickStr==undefined){
    	    	clickStr="";
    	    }else{    	        
    	        if(topNode.isPassURLScriptArgsOnly()){
    	            clickStr+="(\""+linkUrl+"\","+"\""+linkTarget+"\")";	
    	        }else{
    	            clickStr+="("+scriptArgs+")";
    	        }
    	        cursor="hand";
    	    }
    	    var linkLeftStr="";
    	    var linkRightStr="";
    	    
    	    var isURLForbid=topNode.isURLForbid();
    	    if(linkUrl!=null&&linkUrl!=undefined&&!isURLForbid){
    	    	if(linkTarget==null||linkTarget==undefined){
    	    	    linkTarget="_self";	
    	    	}
    	    	var openStr="\""+linkUrl+"\",\""+linkTarget+"\","+"\"\"";
    	        linkLeftStr="<span style='text-decoration:none;cursor:hand' onclick='window.open("+openStr+")'>";
    	        linkRightStr="</span>";
    	    }
    	    var icon=child.getIcon();
    	    if(icon==null||icon==undefined){
    	        icon=topNode.getDefaultIcon();
    	    }
    	    content+="<tr>";
    	    content+="<td id='node_0_"+this.id+"' width='1'>";
    	    content+="<img id='node_0_1"+this.id+"' src='"+icon+"' nowrap/>";
    	    content+="</td>";
    	    content+="<td id='node_1_"+this.id+"' nowrap valign='middle' style='cursor:"+cursor+"' onclick='"+clickStr+"'";
    	    if(this.isMouseRender()){
    	    	content+=" onmouseover='parentElement.className=\"WindowMenuMouseOver\"' onmouseout='parentElement.className=\"WindowMenuMouseOut\"'";
    	    }
    	    content+=">";
    	    content+=linkLeftStr+child.getTitle()+linkRightStr;
    	    content+="</td>";
    	    content+="</tr>";
    	}    
    	content+="</table>";
    	return content;
   };
   
   /**
    * get menu's root menu
    */
   Menu.prototype.getTop=function (){
      var parentNode=this.getParent();
      if(parentNode==null||parentNode==undefined){
      	 return this;
      }
      return parentNode.getTop();
   };
   
   /**
    * forbid url link operation
    */
   Menu.prototype.forbidURL=function(){
       this._isURLForbid=true;	
   };
   
   /**
    * allow url link operation
    */
   Menu.prototype.enableURL=function(){
       this._isURLForbid=false;	
   };
   
   /**
    * return the boolean value whether forbidding url link operation
    */
   Menu.prototype.isURLForbid=function(){
       return this._isURLForbid;
   };
   
   /**
    * forbid script event operation
    */
   Menu.prototype.forbidScript=function(){
       this._isScriptForbid=true;	
   };
   
   /**
    * allow script event operation
    */
   Menu.prototype.enableScript=function(){
       this._isScriptForbid=false;	
   };
   
   /**
    * return the boolean value whether allowing script event operation
    */
   Menu.prototype.isScriptForbid=function(){
       return this._isScriptForbid;	
   };
   
   /**
    *  only allow pass url link and target args to the javascript function
    */
   Menu.prototype.passURLScriptArgsOnly=function(){
       this._isPassURLScriptArgsOnly=true;
   };
   
   /**
    * return the boolean value whether only allowing pass url link and target 
    * args to the javascript function
    */
   Menu.prototype.isPassURLScriptArgsOnly=function(){
       return this._isPassURLScriptArgsOnly;
   };
   
   /**
    *  init the menu capacity
    */
   Menu.prototype.init=function (capacity){
      this.capacity=capacity;
   };        
   /**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function MultiDimensionArrayUtils(){
	this.jsjava_class="jsorg.eob.lang.MultiDimensionArrayUtils";	
}

/**
 * Create a two dimension array
 * param n - length of the first dimension
 * param m - length of the second dimension
 */
MultiDimensionArrayUtils.createTwoDimensionArray=function(n,m){
	if(n<0||m<0){
		throw new IllegalArgumentException(
	            IllegalArgumentException.ERROR,"n and m must be postive");
	}
	var arr=new Array(n);
	for(var i=0;i<n;i++){
		arr[i]=new Array(m);
	}
	return arr;
};

/**
 * Create a three dimension array
 * param n - length of the first dimension
 * param m - length of the second dimension
 * param k - length of the third dimension
 */
MultiDimensionArrayUtils.createThreeDimensionArray=function(n,m,k){
	if(n<0||m<0||k<0){
		throw new IllegalArgumentException(
	            IllegalArgumentException.ERROR,"n and m and k must be postive");
	}
	var arr=new Array(n);
	for(var i=0;i<n;i++){
		arr[i]=new Array(m);
		for(var j=0;j<m;j++){
			arr[i][j]=new Array(k);
		}
	}
	return arr;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The NormalDistributionImpl class references to org.apache.commons.math.distribution.NormalDistributionImpl */

function NormalDistributionImpl(mean,sd){
	this.jsjava_class="org.apache.commons.math.distribution.NormalDistributionImpl";	
	this.mean = mean;
    if (sd <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Standard deviation must be positive.");
    }       
    this.standardDeviation = sd;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
NormalDistributionImpl.prototype.cumulativeProbability=function(x){
	return 0.5 * (1.0 + Erf.erf((x - this.mean) /
            (this.standardDeviation * Math.sqrt(2.0))));
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
NormalDistributionImpl.prototype.getDomainLowerBound=function(p){
	var ret;

    if (p < .5) {
        ret = -Double.MAX_VALUE;
    } else {
        ret = this.getMean();
    }
    
    return ret;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
NormalDistributionImpl.prototype.getDomainUpperBound=function(p){
	var ret;

    if (p < .5) {
        ret = this.getMean();
    } else {
        ret = Double.MAX_VALUE;
    }
    
    return ret;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
NormalDistributionImpl.prototype.getInitialDomain=function(p){
	var ret;

    if (p < .5) {
        ret = this.getMean() - this.getStandardDeviation();
    } else if (p > .5) {
        ret = this.getMean() + this.getStandardDeviation();
    } else {
        ret = this.getMean();
    }
    
    return ret;
};

/**
 * Access the mean.
 */
NormalDistributionImpl.prototype.getMean=function(){
	return this.mean;
};

/**
 * Access the standard deviation.
 */
NormalDistributionImpl.prototype.getStandardDeviation=function(){
	return this.standardDeviation;
};

/**
 * Modify the mean.
 * param mean
 */
NormalDistributionImpl.prototype.setMean=function(mean){
	this.mean = mean;
};

/**
 * Modify the standard deviation.
 * param sd
 */
NormalDistributionImpl.prototype.setStandardDeviation=function(sd){
	if (sd <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Standard deviation must be positive.");
    }       
    this.standardDeviation = sd;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**
 * Constructor
 */
function NullValidator(){
	this.jsjava_class="jsorg.eob.validator.NullValidator";
}

/**
 * Check whether the given value is null or blank or undefined
 * param str - the given value
 */
NullValidator.validate=function(str){
	if(str==undefined||str==""){
	    return true;
	}
	return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 
/**  The NumberFormat class references to java.text.NumberFormat of J2SE1.4 */
 
/**
 * constructor
 */
 function NumberFormat(){
     this.jsjava_class="jsjava.text.NumberFormat";
 }
 
 NumberFormat.SPECIAL_CHARS=["0",".","-",",","E","%","\u00A4","\u2030"];
 
 /**
 * apply the pattern
 * param pattern
 */
 NumberFormat.prototype.applyPattern=function(pattern){
 	 if(pattern==undefined){
 	 	pattern="";
 	 }
 	 function contains(arr,char){
 	 	for(var i=0;i<arr.length;i++){
 	 		if(arr[i]==char){
 	 			return true;
 	 		}
 	 	}
 	 	return false;
 	 }
 	 for(var i=0;i<pattern.length;i++){
 	 	if(!contains(NumberFormat.SPECIAL_CHARS,pattern.charAt(i))){
 	 		throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Malformed pattern "+pattern);
 	 	}
 	 } 
     this.pattern=pattern;
 };
 
  /**
 * format the number
 * param number
 */
 NumberFormat.prototype.format=function(number){
 	 if(isNaN(number)){
     	throw new IllegalArgumentException(IllegalArgumentException.ERROR,"The argument must be a number");
     }
     var pattern=this.pattern;
     if(pattern==""){
     	return number;
     }
     var strNum=new String(number);
     var numNum=parseFloat(number);
     var isNegative=false;
     if(numNum<0){
     	isNegative=true;
     }
     if(isNegative){
     	strNum=strNum.substring(1,strNum.length);
     	numNum=-numNum;
     }
     var ePos=pattern.indexOf("E");
     var pPos=pattern.indexOf("%");
     if(ePos!=-1&&pPos!=-1){
     	throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Malformed exponential pattern : E and % can not be existed at the same time");
     }
     if(ePos!=-1){
     	if(ePos==pattern.length-1){
     		throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Malformed exponential pattern "+this.pattern);
     	}
     	beStr=pattern.substring(0,ePos);
     	aeStr=pattern.substring(ePos+1);
     	var dPos=beStr.indexOf(".");
     	var dPosOfNum=strNum.indexOf(".");
     	if(dPos!=-1){     		
     		if(dPosOfNum==-1){
     			dPosOfNum=strNum.length-1;
     		}
     		var strNumBuffer=new StringBuffer(strNum);
     		strNumBuffer.deleteCharAt(dPosOfNum);
     		strNumBuffer.insert(dPos,".");
     		var snbStr=strNumBuffer.getValue();
     		var adStrLength=beStr.length-dPos;
     		var snbFixed=new Number(parseFloat(snbStr)).toFixed(adStrLength-1);     		
     		var aeLabel=dPosOfNum-dPos;
	     	if(isNegative){
	     		return "-"+snbFixed+"e"+(aeLabel);
	     	}else{
	     		return snbFixed+"e"+(aeLabel);
	     	}
     	}else{
     		if(dPosOfNum==-1){
     			dPosOfNum=strNum.length-1;
     		}
     		var strNumBuffer=new StringBuffer(strNum);
     		strNumBuffer.deleteCharAt(dPosOfNum);
     		strNumBuffer.insert(beStr.length,".");
     		var snbStr=strNumBuffer.getValue();
     		var adStrLength=beStr.length-beStr.length;
     		var snbFixed=-1;
     		if(adStrLength==0){
     			snbFixed=new Number(parseFloat(snbStr)).toFixed();     		
     		}else{
     			snbFixed=new Number(parseFloat(snbStr)).toFixed(adStrLength-1);
     		}
     		var aeLabel=dPosOfNum-beStr.length;
	     	if(isNegative){
	     		return "-"+snbFixed+"e"+(aeLabel);
	     	}else{
	     		return snbFixed+"e"+(aeLabel);
	     	}
     	}    	
     }
     if(pPos!=-1){
     	if(pPos!=pattern.length-1){
     		throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Malformed exponential pattern "+this.pattern);
     	}
   	 	pattern=pattern.substring(0,pattern.length-1);
   	 	numNum=parseFloat(number)*100;
     	strNum=new String(numNum);
     	if(isNegative){
	     	strNum=strNum.substring(1,strNum.length);
	     	numNum=-numNum;
	    }
   	 }    
     var dPos=pattern.indexOf(".");
   	 var dPosOfNum=strNum.indexOf(".");   	
   	 var result=""; 
   	 if(dPos!=-1){     		
   		if(dPosOfNum==-1){
   			dPosOfNum=strNum.length-1;
   		}
   		var adStrLength=pattern.length-dPos;
   		var snbFixed=new Number(parseFloat(strNum)).toFixed(adStrLength-1);   
   		if(isNegative){
     		result="-"+snbFixed;
     	}else{
     		result=snbFixed;
     	}
   	 }else{
   	 	if(dPosOfNum==-1){
   			dPosOfNum=strNum.length-1;
   		}
   		var snbFixed=new Number(parseFloat(strNum)).toFixed();   
   		if(isNegative){
     		result="-"+snbFixed;
     	}else{
     		result=snbFixed;
     	}
   	 }
   	 if(pPos!=-1){
   	 	result+="%";
   	 }
   	 return result;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The NumberFormatException class references to java.lang.NumberFormatException of J2SE1.4 */

NumberFormatException.prototype=new Error();
NumberFormatException.prototype.constructor=NumberFormatException;

NumberFormatException.NOT_NUMBER=1;

/**
 * constructor
 * param code - error code
 * param message - error message
 */
function NumberFormatException(code,message){
	this.jsjava_class="jsjava.lang.NumberFormatException";
	this.code=code;
    this.message=message;
    this.name="jsjava.lang.NumberFormatException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function NumberScaleValidator(){
	this.jsjava_class="jsorg.eob.validator.NumberScaleValidator";
}

/**
 * validate whether a number n is between n1 and n2
 * param n
 * param n1
 * param n2
 */
NumberScaleValidator.validateBetween=function(n,n1,n2){
	if(isNaN(n)||isNaN(n1)||isNaN(n2)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
	n=parseInt(n);
	n1=parseInt(n1);
	n2=parseInt(n2);
	if(n>=n1&&n<=n2){
    	return true;
    }
    return false;
};

/**
 * validate whether a number is larger than n1
 * param n
 * param n1
 */
NumberScaleValidator.validateLargerThan=function(n,n1){
	if(isNaN(n)||isNaN(n1)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
	n=parseInt(n);
	n1=parseInt(n1);
	if(n>=n1){
    	return true;
    }
    return false;
};

/**
 * validate whether a number is less than n1
 * param n
 * param n1
 */
NumberScaleValidator.validateLessThan=function(n,n1){
	if(isNaN(n)||isNaN(n1)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
	n=parseInt(n);
	n1=parseInt(n1);
	if(n<=n1){
    	return true;
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**
 * Constructor
 */ 
function ObjectPrototype(){
	this.jsjava_class="jsorg.eob.prototype.ObjectPrototype";
}

/**
 * Load the extended Object prototype
 */
ObjectPrototype.load=function(){
	Object.prototype.jsjava_class="Object";
	
	Object.prototype.equals=function(o){
		if(this==o){
			return true;
		}		
		if(this.toString()==o.toString()){
			return true;
		}
		return false;
	};
	
	Object.prototype.clone=function(){
		throw new CloneNotSupportedException(CloneNotSupportedException.ERROR,"The object,which calls the clone method,need implement the clone method by itself");
	};
	
	Object.prototype.getClass=function(){
		if(this.jsjava_class){
			return this.jsjava_class;
		}
		if(this instanceof Array){
			return "Array";
		}
		if(this instanceof Boolean){
			return "Boolean";
		}
		if(this instanceof Date){
			return "Date";
		}
		if(this instanceof Function){
			return "Function";
		}
		if(this instanceof Number){
			return "Number";
		}
		if(this instanceof RegExp){
			return "RegExp";
		}
		if(this instanceof String){
			return "String";
		}
	};
};

ObjectPrototype.load();/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function OSUtils(){
	this.jsjava_class="jsorg.eob.os.OSUtils";
}

/**
 * Check whether the current OS is Windows
 */
OSUtils.isWindows=function(){
	return navigator.userAgent.indexOf("Win")!=-1;
};

/**
 * Check whether the current OS is Mac
 */
OSUtils.isMac=function(){
	return navigator.userAgent.indexOf("Mac")!=-1;
};

/**
 * Check whether the current OS is Unix
 */
OSUtils.isUnix=function(){
	return navigator.userAgent.indexOf("X11")!=-1;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The PoissonDistributionImpl class references to org.apache.commons.math.distribution.PoissonDistributionImpl */

function PoissonDistributionImpl(p){
	this.jsjava_class="org.apache.commons.math.distribution.PoissonDistributionImpl";	
	if (p <= 0) {
        throw new IllegalArgumentException(
                IllegalArgumentException.ERROR,"The Poisson mean must be positive");
    }
    this.mean = p;
}

/**
 * The probability distribution function P(X <= x) for a Poisson distribution.
 * param x
 */
PoissonDistributionImpl.prototype.cumulativeProbability=function(x){
	if (x < 0) {
        return 0;
    }
    if (x == Integer.MAX_VALUE) {
        return 1;
    }
    var sx=new String(x);
	if(sx.indexOf(".")!=-1){
		x=Math.floor(x);
	}
    return Gamma.regularizedGammaQ2(x + 1, this.mean, 
            1E-12, Integer.MAX_VALUE);
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
PoissonDistributionImpl.prototype.getDomainLowerBound=function(p){
	return 0;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
PoissonDistributionImpl.prototype.getDomainUpperBound=function(p){
	return Integer.MAX_VALUE;
};

/**
 * Get the Poisson mean for the distribution.
 */
PoissonDistributionImpl.prototype.getMean=function(){
	return this.mean;
};

/**
 * Calculates the Poisson distribution function using a normal approximation.
 * param x
 */
PoissonDistributionImpl.prototype.normalApproximateProbability=function(x){
	var normal = DistributionFactoryImpl.newInstance()
            .createNormalDistribution(this.getMean(),
                    Math.sqrt(this.getMean()));

    // calculate the probability using half-correction
    return normal.cumulativeProbability(x + 0.5);
};

/**
 * The probability mass function P(X = x) for a Poisson distribution.
 * param x
 */
PoissonDistributionImpl.prototype.probability=function(x){
	if (x < 0 || x == Integer.MAX_VALUE) {
        return 0;
    }
    return Math.pow(this.getMean(), x) / 
        MathUtils.factorialDouble(x) * Math.exp(-this.mean);
};

/**
 * Set the Poisson mean for the distribution.
 * param p
 */
PoissonDistributionImpl.prototype.setMean=function(p){
	if (p <= 0) {
        throw new IllegalArgumentException(
                IllegalArgumentException.ERROR,"The Poisson mean must be positive");
    }
    this.mean = p;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The PolynomialFunction class references to org.apache.commons.math.analysis.PolynomialFunction */
 
function PolynomialFunction(arr){
	this.jsjava_class="jsorg.apache.commons.math.analysis.PolynomialFunction";
	if (arr.length < 1) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Polynomial coefficient array must have postive length.");
    }
    this.coefficients = new Array(arr.length);
    for(var i=0;i<arr.length;i++){
    	this.coefficients[i]=arr[i];
    }
}

/**
 * Returns the degree of the polynomial
 */
PolynomialFunction.prototype.degree=function(){
	return this.coefficients.length - 1;
};

/**
 * Returns the derivative as a UnivariateRealFunction
 */
PolynomialFunction.prototype.derivative=function(){
	return this.polynomialDerivative();
};

/**
 * Returns a copy of the coefficients array.
 */
PolynomialFunction.prototype.getCoefficients=function(){
	var out = new Array(this.coefficients.length);
	for(var i=0;i<this.coefficients.length;i++){
    	out[i]=this.coefficients[i];
    }
    return out;
};

/**
 * Returns the derivative as a PolynomialRealFunction
 */
PolynomialFunction.prototype.polynomialDerivative=function(){
	return new PolynomialFunction(PolynomialFunction.differentiate(this.coefficients));
};

/**
 * Compute the value of the function for the given argument.
 */
PolynomialFunction.prototype.value=function(x){
	return PolynomialFunction.evaluate(this.coefficients, x);
};

/**
 * Returns the coefficients of the derivative of the polynomial with the given coefficients.
 * 
 * @param coefficients  the coefficients of the polynomial to differentiate
 * @return the coefficients of the derivative or null if coefficients has length 1.
 * @throws IllegalArgumentException if coefficients is empty
 * @throws NullPointerException if coefficients is null
 */
PolynomialFunction.differentiate=function(coefficients){
	var n = coefficients.length;
    if (n < 1) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Coefficient array must have positive length for differentiation");
    }
    if (n == 1) {
        return [0];
    }
    var result = new Array(n - 1);
    for (var i = n - 1; i  > 0; i--) {
        result[i - 1] = i * coefficients[i];
    }
    return result;
};

/**
 * Uses Horner's Method to evaluate the polynomial with the given coefficients at
 * the argument.
 * 
 * @param coefficients  the coefficients of the polynomial to evaluate
 * @param argument  the input value
 * @return  the value of the polynomial 
 * @throws IllegalArgumentException if coefficients is empty
 * @throws NullPointerException if coefficients is null
 */
PolynomialFunction.evaluate=function(coefficients,argument){
	var n = coefficients.length;
    if (n < 1) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Coefficient array must have positive length for evaluation");
    }
    var result = coefficients[n - 1];
    for (var j = n -2; j >=0; j--) {
        result = argument * result + coefficients[j];
    }
    return result;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The PolynomialSplineFunction class references to org.apache.commons.math.analysis.PolynomialSplineFunction */
 
/**
 * Construct a polynomial spline function with the given segment delimiters
 * and interpolating polynomials.
 * <p>
 * The constructor copies both arrays and assigns the copies to the knots
 * and polynomials properties, respectively.
 * 
 * @param knots spline segment interval delimiters
 * @param polynomials polynomial functions that make up the spline
 * @throws NullPointerException if either of the input arrays is null
 * @throws IllegalArgumentException if knots has length less than 2,  
 * <code>polynomials.length != knots.length - 1 </code>, or the knots array
 * is not strictly increasing.
 * 
 */
function PolynomialSplineFunction(knots,polynomials){
	this.jsjava_class="jsorg.apache.commons.math.analysis.PolynomialSplineFunction";
	if (knots.length < 2) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"Not enough knot values -- spline partition must have at least 2 points.");
    }
    if (knots.length - 1 != polynomials.length) {
        throw new IllegalArgumentException 
        (IllegalArgumentException.ERROR,"Number of polynomial interpolants must match the number of segments.");
    }
    if (!PolynomialSplineFunction.isStrictlyIncreasing(knots)) {
        throw new IllegalArgumentException 
            (IllegalArgumentException.ERROR,"Knot values must be strictly increasing.");
    }
    
    this.n = knots.length -1;
    this.knots = new Array(this.n + 1);
    for(var i=0;i<knots.length;i++){
    	this.knots[i]=knots[i];
    }
    this.polynomials = new Array(this.n);
    for(var i=0;i<polynomials.length;i++){
    	this.polynomials[i]=polynomials[i];
    }
}

/**
 * Returns the derivative of the polynomial spline function as a UnivariateRealFunction
 */
PolynomialSplineFunction.prototype.derivative=function(){
	return this.polynomialSplineDerivative();
};

/**
 * Returns an array copy of the knot points.
 */
PolynomialSplineFunction.prototype.getKnots=function(){
	var out = new Array(this.n + 1);
    for(var i=0;i<out.length;i++){
    	out[i]=this.knots[i];
    }
    return out;
};

/**
 *  Returns a copy of the interpolating polynomials array.
 */
PolynomialSplineFunction.prototype.getPolynomials=function(){
	var p = new Array(this.n);
    for(var i=0;i<p.length;i++){
    	p[i]=this.polynomials[i];
    }
    return p;
};

/**
 * Returns the derivative of the polynomial spline function as a PolynomialSplineFunction
 */
PolynomialSplineFunction.prototype.polynomialSplineDerivative=function(){
	var derivativePolynomials = new Array(this.n);
    for (var i = 0; i < this.n; i++) {
        derivativePolynomials[i] = this.polynomials[i].polynomialDerivative();
    }
    return new PolynomialSplineFunction(this.knots, derivativePolynomials);
};

/**
 * Compute the value for the function.
 */
PolynomialSplineFunction.prototype.value=function(v){
	if (v < this.knots[0] || v > this.knots[this.n]) {
        throw new FunctionEvaluationException(FunctionEvaluationException.ERROR,"Argument outside domain");
    }
    var i=-1;
    for(var m=0;m<this.knots.length;m++){
    	if(v==this.knots[m]){
    		i=m;
    		break;
    	}
    }
    if (i < 0) {
        i = -i - 2;
    }
    //This will handle the case where v is the last knot value
    //There are only n-1 polynomials, so if v is the last knot
    //then we will use the last polynomial to calculate the value.
    if ( i >= this.polynomials.length ) {
        i--;
    }
    return this.polynomials[i].value(v - this.knots[i]);
};

/**
 * Determines if the given array is ordered in a strictly increasing
 * fashion.
 * 
 * @param x the array to examine.
 * @return <code>true</code> if the elements in <code>x</code> are ordered
 * in a stricly increasing manner.  <code>false</code>, otherwise.
 */
PolynomialSplineFunction.isStrictlyIncreasing=function(arr) {
    for (var i = 1; i < arr.length; ++i) {
        if (arr[i - 1] >= arr[i]) {
            return false;
        }
    }
    return true;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Properties class references to java.util.Properties of J2SE1.4 */
 
/**
 * constructor
 */
function Properties(){
	this.jsjava_class="jsjava.util.Properties";
    this.capacity=50;
    this.size=0;
    this.span=10;
    this.elements=new Array(this.capacity);
}

/**
 * Increases the capacity of and internally reorganizes this 
 * properties, in order to accommodate and access its entries 
 * more efficiently.
 */
Properties.prototype.recapacity=function(){
    if(this.capacity-this.size<10){
     this.capacity+=this.span;
     var oldElements=this.elements;
        this.elements=new Array(this.capacity); 
        for(var i=0;i<this.size;i++){
            this.elements[i]=oldElements[i]; 
        }
    }
};

/**
 * Removes all of the elements from this properties
 */
Properties.prototype.clear=function(){
    this.capacity=50;
    this.size=0;
    this.elements=new Array(this.capacity); 
};

/**
 * Replaces the element at the specified position in this properties with the 
 * specified element
 * param index
 * param pvalue
 */
Properties.prototype.set=function (pname,pvalue){
    this.recapacity();
    if(this.containsKey(pname)){
        for(var i=0;i<this.size;i++){
            var elem=this.elements[i];
            if(elem[0].equals(pname)){
                elem[1]=pvalue;
                return;
            } 
        } 
    }
    this.elements[this.size++]=[pname,pvalue];
   
};

/**
 * Associates the specified value with the specified key in this properties 
 * param pname
 * param pvalue 
 */
Properties.prototype.setProperty=function(pname,pvalue){
    if(typeof(pname)=="string"&&typeof(pvalue)=="string"){
        this.set(pname,pvalue);	
    }
};

/**
 * Returns the value to which this properties maps the specified key. 
 * param pname
 */
Properties.prototype.get=function (pname){
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        if(elem[0].equals(pname)){
            return elem[1]; 
        } 
    }
};

/**
 * Searches for the property with the specified key in this property list.
 */
Properties.prototype.getProperty=function (pname){
    var pvalue= this.get(pname);
    if(typeof(pvalue)=="string"){
    	return pvalue;
    }
    return null;
};

/**
 * Returns true if this properties contains a mapping for the specified key.
 * param pname
 */
Properties.prototype.containsKey=function(pname){
    if(this.get(pname)==undefined){
        return false; 
    }
    return true;
};

/**
 * Returns true if this properties maps one or more keys to the specified value.
 * param pname
 */
Properties.prototype.containsValue=function (pvalue){
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        if(elem[1].equals(pvalue)){
            return true;
        } 
    }
    return false;
};

/**
 * Returns a array view of the values contained in this properties.
 */
Properties.prototype.values=function (){
    var values=new Array(this.size);
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        values[i]=elem[1]; 
    } 
    return values;
};

/**
 * Returns a set view of the mappings contained in this properties.
 */
Properties.prototype.entrySet=function (){
    return this.elements; 
};

/**
 * Returns true if this properties contains no key-value mappings.
 */
Properties.prototype.isEmpty=function (){
    return this.size==0; 
};

/**
 * Returns an array of the keys in this properties.
 */
Properties.prototype.keys=function (){
    var keys=new Array(this.size);
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        keys[i]=elem[0]; 
    } 
    return keys;
};

/**
 * Returns the number of keys in this properties.
 */
Properties.prototype.getSize=function (){
    return this.size; 
};

/**
 * Removes the key (and its corresponding value) from this properties.
 * param key
 */
Properties.prototype.remove=function (key){
    if(this.containsKey(key)){
        var oldElems=this.elements;
        var oldSize=this.size;
        this.elements=new Array(this.capacity);
        this.size=0;
        for(var i=0;i<oldSize;i++){
            var oldElem=oldElems[i];
            if(!oldElem[0].equals(key)){
                this.put(oldElem[0],oldElem[1]); 
            } 
        } 
    }
};

/**
 * add a array to the properties
 * param arr
 */
Properties.prototype.addArray=function (arr){
    if(arr!=null&&arr.length>0){
        for(var i=0;i<arr.length;i++){
            this.put(arr[i][0],arr[i][1]); 
        } 
    } 
};

/**
 * add a hash to the properties
 * param hash
 */
Properties.prototype.addProperties=function (hash){
    if(hash!=null&&hash.size()>0){
        var keys=hash.keys();
        for(var i=0;i<keys.length;i++){
            this.put(keys[i],hash.get(keys[i])); 
        } 
    } 
};

/**
 * Returns a string representation of this Properties object
 */
Properties.prototype.toString=function (){
    return this.elements.toString(); 
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The RandomStringUtils class references to org.apache.commons.lang.RandomStringUtils */
 
function RandomStringUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.RandomStringUtils";
}

/**
 * Creates a random string whose length is the number of characters specified.
 * param count - the length of random string to create
 * param letters(boolean) - if true, generated string will include alphabetic characters
 * param numbers(boolean) - if true, generated string will include numeric characters 
 */
RandomStringUtils.random=function(count,letters,numbers){
	if(isNaN(count)){
		return;
	}
	if(count<0){
		return;
	}
	if(count==0){
		return "";
	}
	var minAlpha="a".charCodeAt(0);
	var maxAlpha="z".charCodeAt(0);
	var alphas=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"];
	var digits=["0","1","2","3","4","5","6","7","8","9"];
	if(!letters&&numbers){
		var str="";
		for(var i=0;i<count;i++){
			str+=digits[Math.floor(Math.random()*10)];
		}
		return str;
	}
	if(letters&&!numbers){
		var str="";
		for(var i=0;i<count;i++){
			str+=alphas[Math.floor(Math.random()*26)];
		}
		return str;
	}
	if(letters&&numbers||!letters&&!numbers){
		var str="";
		for(var i=0;i<count;i++){
			var r=Math.floor(Math.random()*2);
			if(r==0){
				str+=alphas[Math.floor(Math.random()*26)];
			}else if(r==1){
				str+=digits[Math.floor(Math.random()*10)];
			}
		}
		return str;
	}
	return "";
};

/**
 * Creates a random string whose length is the number of characters specified.
 * param count
 */
RandomStringUtils.randomAlphabetic=function(count){
	return RandomStringUtils.random(count,true,false);
};

/**
 * Creates a random string whose length is the number of characters specified.
 * param count
 */
RandomStringUtils.randomAlphanumeric=function(count){
	return RandomStringUtils.random(count,true,true);
};

/**
 * Creates a random string whose length is the number of characters specified.
 * param count
 */
RandomStringUtils.randomNumeric=function(count){
	return RandomStringUtils.random(count,false,true);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The RealMatrixImpl class references to org.apache.commons.math.linear.RealMatrixImpl */

function RealMatrixImpl(rowDimension,columnDimension){
	this.jsjava_class="org.apache.commons.math.linear.RealMatrixImpl";
	if(rowDimension==undefined||columnDimension==undefined){
	
	}else{
		if (rowDimension <= 0 || columnDimension <= 0) {
		    throw new IllegalArgumentException(
		            IllegalArgumentException.ERROR,"row and column dimensions must be postive");
		}
		this.data = new Array(rowDimension);
		for(var i=0;i<rowDimension;i++){
			this.data[i]=new Array(columnDimension);
		}
		this.lu = null;
    }
    this.parity=1;
}

RealMatrixImpl.TOO_SMALL= 10E-12;

RealMatrixImpl.CreateBlankRealMatrixImpl=function(){
	return new RealMatrixImpl();
};

RealMatrixImpl.CreateRealMatrixImplByFullArray=function(d){
	var row=0;
	var column=0;
	if ((row < 0) || (column < 0)){
        throw new MatrixIndexException
            (MatrixIndexException.ERROR,"invalid row or column index selection");          
    }
    var subMatrix=d;
    var nRows = subMatrix.length;
    if (nRows == 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,
        "Matrix must have at least one row."); 
    }
    var nCols = subMatrix[0].length;
    if (nCols == 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,
        "Matrix must have at least one column."); 
    }    
    var matrix=new RealMatrixImpl(nRows,nCols);
    for (var r = 1; r < nRows; r++) {
        if (subMatrix[r].length != nCols) {
            throw new IllegalArgumentException(IllegalArgumentException.ERROR,
            "All input rows must have the same length.");
        }
    }        
    if ((row > 0)||(column > 0)) {
    	throw new MatrixIndexException(MatrixIndexException.ERROR,"matrix must be initialized to perfom this method");
    }
    matrix.data = new Array(nRows);
    for(var i=0;i<nRows;i++){
		matrix.data[i]=new Array(nCols);
	}
    for(var i=0;i<nRows;i++){
    	for(var j=0;j<nCols;j++){
    		matrix.data[i][j]=subMatrix[i][j];
    	}
    }     
    if (((nRows + row) > matrix.getRowDimension()) ||(nCols + column > matrix.getColumnDimension())){
        throw new MatrixIndexException(MatrixIndexException.ERROR,"invalid row or column index selection");  
    }                 
    for (var i = 0; i < nRows; i++) {
        for(var j=0;j<nCols;j++){
        	matrix.data[row + i][j]=subMatrix[i][j];
        }
    } 
    matrix.lu = null;
    return matrix;
};

RealMatrixImpl.prototype.copy=function(){
	return RealMatrixImpl.CreateRealMatrixImplByFullArray(this.copyOut());
};

RealMatrixImpl.prototype.add=function(m){
	if (this.getColumnDimension() != m.getColumnDimension() ||
            this.getRowDimension() != m.getRowDimension()) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"matrix dimension mismatch");
    }
    var rowCount = this.getRowDimension();
    var columnCount = this.getColumnDimension();
    var outData = new Array(rowCount);
    for(var i=0;i<rowCount;i++){
    	outData[i]=new Array(columnCount);
    }
    for (var row = 0; row < rowCount; row++) {
        for (var col = 0; col < columnCount; col++) {
            outData[row][col] = this.data[row][col] + m.getEntry(row, col);
        }  
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(outData);
};

RealMatrixImpl.prototype.subtract=function(m){
	if (this.getColumnDimension() != m.getColumnDimension() ||
            this.getRowDimension() != m.getRowDimension()) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"matrix dimension mismatch");
    }
    var rowCount = this.getRowDimension();
    var columnCount = this.getColumnDimension();
    var outData = new Array(rowCount);
    for(var i=0;i<rowCount;i++){
    	outData[i]=new Array(columnCount);
    }
    for (var row = 0; row < rowCount; row++) {
        for (var col = 0; col < columnCount; col++) {
            outData[row][col] = this.data[row][col] - m.getEntry(row, col);
        }
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(outData);
};

RealMatrixImpl.prototype.scalarAdd=function(d){
	var rowCount = this.getRowDimension();
    var columnCount = this.getColumnDimension();
    var outData = new Array(rowCount);
    for(var i=0;i<rowCount;i++){
    	outData[i]=new Array(columnCount);
    }
    for (var row = 0; row < rowCount; row++) {
        for (var col = 0; col < columnCount; col++) {
            outData[row][col] = this.data[row][col] + d;
        }
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(outData);
};

RealMatrixImpl.prototype.scalarMultiply=function(d){
	var rowCount = this.getRowDimension();
    var columnCount = this.getColumnDimension();
    var outData = new Array(rowCount);
    for(var i=0;i<rowCount;i++){
    	outData[i]=new Array(columnCount);
    }
    for (var row = 0; row < rowCount; row++) {
        for (var col = 0; col < columnCount; col++) {
            outData[row][col] = this.data[row][col] * d;
        }
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(outData);
};

RealMatrixImpl.prototype.multiply=function(m){
	if (this.getColumnDimension() != m.getRowDimension()) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Matrices are not multiplication compatible.");
    }
    var nRows = this.getRowDimension();
    var nCols = m.getColumnDimension();
    var nSum = this.getColumnDimension();
    var outData = new Array(nRows);
    for(var i=0;i<nRows;i++){
    	outData[i]=new Array(nCols);
    }
    var sum = 0;
    for (var row = 0; row < nRows; row++) {
        for (var col = 0; col < nCols; col++) {
            sum = 0;
            for (var i = 0; i < nSum; i++) {
                sum += this.data[row][i] * m.getEntry(i, col);
            }
            outData[row][col] = sum;
        }
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(outData);
};

RealMatrixImpl.prototype.preMultiply=function(m){
	return m.multiply(this);
};

RealMatrixImpl.prototype.getData=function(){
	return this.copyOut();
};

RealMatrixImpl.prototype.getDataRef=function(){
	return this.data;
};

RealMatrixImpl.prototype.getNorm=function(){
	var maxColSum = 0;
    for (var col = 0; col < this.getColumnDimension(); col++) {
        var sum = 0;
        for (var row = 0; row < this.getRowDimension(); row++) {
            sum += Math.abs(this.data[row][col]);
        }
        maxColSum = Math.max(maxColSum, sum);
    }
    return maxColSum;
};

RealMatrixImpl.prototype.getSubMatrix=function(startRow,endRow,startColumn,endColumn){
	if (startRow < 0 || startRow > endRow || endRow > this.data.length ||
         startColumn < 0 || startColumn > endColumn ||
         endColumn > this.data[0].length ) {
        throw new MatrixIndexException(MatrixIndexException.ERROR,
                "invalid row or column index selection");
    }
    var subMatrix = new RealMatrixImpl(endRow - startRow+1,
            endColumn - startColumn+1);
    var subMatrixData = subMatrix.getDataRef();
    for (var i = startRow; i <= endRow; i++) {
        for (var j = startColumn; j <= endColumn; j++) {
                subMatrixData[i - startRow][j - startColumn] = this.data[i][j];
            }
        }
    return subMatrix;
};

RealMatrixImpl.prototype.getSubMatrix2=function(selectedRows,selectedColumns){
	if (selectedRows.length * selectedColumns.length == 0) {
        throw new MatrixIndexException(MatrixIndexException.ERROR,
                "selected row and column index arrays must be non-empty");
    }
    var subMatrix = new RealMatrixImpl(selectedRows.length,
            selectedColumns.length);
    var subMatrixData = subMatrix.getDataRef();
    try  {
        for (var i = 0; i < selectedRows.length; i++) {
            for (var j = 0; j < selectedColumns.length; j++) {
                subMatrixData[i][j] = this.data[selectedRows[i]][selectedColumns[j]];
            }
        }
    } catch (e) {
        throw new MatrixIndexException(MatrixIndexException.ERROR,"matrix dimension mismatch");
    }
    return subMatrix;
};

RealMatrixImpl.prototype.setSubMatrix=function(subMatrix,row,column){
	if ((row < 0) || (column < 0)){
        throw new MatrixIndexException
            (MatrixIndexException.ERROR,"invalid row or column index selection");          
    }
    var nRows = subMatrix.length;
    if (nRows == 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,
        "Matrix must have at least one row."); 
    }
    var nCols = subMatrix[0].length;
    if (nCols == 0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,
        "Matrix must have at least one column."); 
    }
    for (var r = 1; r < nRows; r++) {
        if (subMatrix[r].length != nCols) {
            throw new IllegalArgumentException(IllegalArgumentException.ERROR,
            "All input rows must have the same length.");
        }
    }       
    if (this.data == null) {
        if ((row > 0)||(column > 0)) throw new MatrixIndexException
            (MatrixIndexException.ERROR,"matrix must be initialized to perfom this method");
        this.data = new Array(nRows);		    
		for(var i=0;i<nRows;i++){
			outData[i]=new Array(nCols);
		}
        var values=subMatrix.getData();
        for (var i = 0; i < nRows; i++) {
		    for (var j = 0; j < nCols; j++) {
		        this.data[i][j]=values[i][j];
		    }
		}   
    }   
    if (((nRows + row) > this.getRowDimension()) ||
        (nCols + column > this.getColumnDimension()))
        throw new MatrixIndexException(MatrixIndexException.ERROR,
                "invalid row or column index selection");                   
    for (var i = 0; i < nRows; i++) {
        for(var j=0;j<nCols;j++){
        	this.data[row + i][j]=subMatrix[i][j];
        }
    } 
    this.lu = null;
};

RealMatrixImpl.prototype.getRowMatrix=function(row){
	if ( !this.isValidCoordinate( row, 0)) {
        throw new MatrixIndexException(MatrixIndexException.ERROR,"illegal row argument");
    }
    var ncols = this.getColumnDimension();
    var out=new Array(row);
    for(var i=0;i<row;i++){
    	out[i]=new Array(1);
    }
    for(var j=0;j<ncols;j++){
    	out[0][j]=this.data[row][j];
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(out);
};

RealMatrixImpl.prototype.getColumnMatrix=function(column){
	if ( !this.isValidCoordinate( 0, column)) {
        throw new MatrixIndexException("illegal column argument");
    }
    var nRows = this.getRowDimension();
    var out=new Array(nRows);
    for(var i=0;i<nRows;i++){
    	out[i]=new Array(1);
    }
    for (var i = 0; i < nRows; i++) {
        out[i][0] = this.data[i][column];
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(out);
};

RealMatrixImpl.prototype.getRow=function(row){
	if ( !this.isValidCoordinate( row, 0 ) ) {
        throw new MatrixIndexException(MatrixIndexException.ERROR,"illegal row argument");
    }
    var ncols = this.getColumnDimension();
    var out = new Array(ncols);
    for(var j=0;j<ncols;j++){
    	out[j]=this.data[row][j];
    }
    return out;
};

RealMatrixImpl.prototype.getColumn=function(col){
	if ( !this.isValidCoordinate(0, col) ) {
        throw new MatrixIndexException(MatrixIndexException.ERROR,"illegal column argument");
    }
    var nRows = this.getRowDimension();
    var out = new Array(nRows);
    for (var i = 0; i < nRows; i++) {
        out[i] = this.data[i][col];
    }
    return out;
};

RealMatrixImpl.prototype.getEntry=function(row,column){
	if (!this.isValidCoordinate(row,column)) {
        throw new MatrixIndexException(MatrixIndexException.ERROR,"matrix entry does not exist");
    }
    return this.data[row][column];
};

RealMatrixImpl.prototype.transpose=function(){
	var nRows = this.getRowDimension();
    var nCols = this.getColumnDimension();
    var out = new RealMatrixImpl(nCols, nRows);
    var outData = out.getDataRef();
    for (var row = 0; row < nRows; row++) {
        for (var col = 0; col < nCols; col++) {
            outData[col][row] = this.data[row][col];
        }
    }
    return out;
};

RealMatrixImpl.prototype.inverse=function(){
	return this.solveMatrix(MatrixUtils.createRealIdentityMatrix
            (this.getRowDimension()));
};

RealMatrixImpl.prototype.getDeterminant=function(){
	if (!this.isSquare()) {
        throw new InvalidMatrixException(InvalidMatrixException.ERROR,"matrix is not square");
    }
    if (this.isSingular()) {   // note: this has side effect of attempting LU decomp if lu == null
        return 0;
    } else {
        var det = this.parity;
        for (var i = 0; i < this.getRowDimension(); i++) {
            det *= this.lu[i][i];
        }
        return det;
    }
};

RealMatrixImpl.prototype.isSquare=function(){
	return (this.getColumnDimension() == this.getRowDimension());
};

RealMatrixImpl.prototype.isSingular=function(){
	if (this.lu == undefined||this.lu==null) {
        try {
            this.luDecompose();
            return false;
        } catch (ex) {
            return true;
        }
    } else { // LU decomp must have been successfully performed
        return false; // so the matrix is not singular
    }
};

RealMatrixImpl.prototype.getRowDimension=function(){
	return this.data.length;
};

RealMatrixImpl.prototype.getColumnDimension=function(){
	return this.data[0].length;
};

RealMatrixImpl.prototype.getTrace=function(){
	if (!this.isSquare()) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"matrix is not square");
    }
    var trace = this.data[0][0];
    for (var i = 1; i < this.getRowDimension(); i++) {
        trace += this.data[i][i];
    }
    return trace;
};

RealMatrixImpl.prototype.operate=function(v){
	if (v.length != this.getColumnDimension()) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"vector has wrong length");
    }
    var nRows = this.getRowDimension();
    var nCols = this.getColumnDimension();
    var out = new Array(v.length);
    for (var row = 0; row < nRows; row++) {
        var sum = 0;
        for (var i = 0; i < nCols; i++) {
            sum += this.data[row][i] * v[i];
        }
        out[row] = sum;
    }
    return out;
};

RealMatrixImpl.prototype.preMultiplyArray=function(v){
	var nRows = this.getRowDimension();
    if (v.length != nRows) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"vector has wrong length");
    }
    var nCols = this.getColumnDimension();
    var out = new Array(nCols);
    for (var col = 0; col < nCols; col++) {
        var sum = 0;
        for (var i = 0; i < nRows; i++) {
            sum += this.data[i][col] * v[i];
        }
        out[col] = sum;
    }
    return out;
};

RealMatrixImpl.prototype.solve=function(b){	
	var nRows = this.getRowDimension();
	if (b.length != nRows) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"constant vector has wrong length");
    }
    var bMatrix = RealMatrixImpl.CreateRealMatrixImplByFullArray(b);
    var solution =  this.solveMatrix(bMatrix).getDataRef();
    var out = new Array(nRows);
    for (var row = 0; row < nRows; row++) {
        out[row] = solution[row][0];
    }
    return out;
};

RealMatrixImpl.prototype.solveMatrix=function(b){
	if (b.getRowDimension() != this.getRowDimension()) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Incorrect row dimension");
    }
    if (!this.isSquare()) {
        throw new InvalidMatrixException(InvalidMatrixException.ERROR,"coefficient matrix is not square");
    }
    if (this.isSingular()) { // side effect: compute LU decomp
        throw new InvalidMatrixException(InvalidMatrixException.ERROR,"Matrix is singular.");
    }

    var nCol = this.getColumnDimension();
    var nColB = b.getColumnDimension();
    var nRowB = b.getRowDimension();

    // Apply permutations to b
    var bp=new Array(nRowB);
    for(var i=0;i<nRowB;i++){
    	bp[i]=new Array(nColB);
    }
    for (var row = 0; row < nRowB; row++) {
        for (var col = 0; col < nColB; col++) {
            bp[row][col] = b.getEntry(this.permutation[row], col);
        }
    }

    // Solve LY = b
    for (var col = 0; col < nCol; col++) {
        for (var i = col + 1; i < nCol; i++) {
            for (var j = 0; j < nColB; j++) {
                bp[i][j] -= bp[col][j] * this.lu[i][col];
            }
        }
    }

    // Solve UX = Y
    for (var col = nCol - 1; col >= 0; col--) {
        for (var j = 0; j < nColB; j++) {
            bp[col][j] /= this.lu[col][col];
        }
        for (var i = 0; i < col; i++) {
            for (var j = 0; j < nColB; j++) {
                bp[i][j] -= bp[col][j] * this.lu[i][col];
            }
        }
    }

    var outMat = RealMatrixImpl.CreateRealMatrixImplByFullArray(bp);
    return outMat;
};

RealMatrixImpl.prototype.luDecompose=function(){
	var nRows = this.getRowDimension();
    var nCols = this.getColumnDimension();
    if (nRows != nCols) {
        throw new InvalidMatrixException(InvalidMatrixException.ERROR,"LU decomposition requires that the matrix be square.");
    }
    this.lu = this.getData();

    // Initialize permutation array and parity
    this.permutation = new Array(nRows);
    for (var row = 0; row < nRows; row++) {
        this.permutation[row] = row;
    }
    this.parity = 1;

    // Loop over columns
    for (var col = 0; col < nCols; col++) {

        var sum = 0;

        // upper
        for (var row = 0; row < col; row++) {
            sum = this.lu[row][col];
            for (var i = 0; i < row; i++) {
                sum -= this.lu[row][i] * this.lu[i][col];
            }
            this.lu[row][col] = sum;
        }

        // lower
        var max = col; // permutation row
        var largest = 0;
        for (var row = col; row < nRows; row++) {
            sum = this.lu[row][col];
            for (var i = 0; i < col; i++) {
                sum -= this.lu[row][i] * this.lu[i][col];
            }
            this.lu[row][col] = sum;

            // maintain best permutation choice
            if (Math.abs(sum) > largest) {
                largest = Math.abs(sum);
                max = row;
            }
        }

        // Singularity check
        if (Math.abs(this.lu[max][col]) < RealMatrixImpl.TOO_SMALL) {
            this.lu = null;
            throw new InvalidMatrixException(InvalidMatrixException.ERROR,"matrix is singular");
        }

        // Pivot if necessary
        if (max != col) {
            var tmp = 0;
            for (var i = 0; i < nCols; i++) {
                tmp = this.lu[max][i];
                this.lu[max][i] = this.lu[col][i];
                this.lu[col][i] = tmp;
            }
            var temp = this.permutation[max];
            this.permutation[max] = this.permutation[col];
            this.permutation[col] = temp;
            this.parity = -this.parity;
        }

        //Divide the lower elements by the "winning" diagonal elt.
        for (var row = col + 1; row < nRows; row++) {
            this.lu[row][col] /= this.lu[col][col];
        }
    }
};

RealMatrixImpl.prototype.toString=function(){
	var res = new StringBuffer();
    res.append("RealMatrixImpl{");
    if (this.data != null) {
        for (var i = 0; i < this.data.length; i++) {
            if (i > 0)
                res.append(",");
            res.append("{");
            for (var j = 0; j < this.data[0].length; j++) {
                if (j > 0)
                    res.append(",");
                res.append(this.data[i][j]);
            } 
            res.append("}");
        } 
    }
    res.append("}");
    return res.toString();
};

RealMatrixImpl.prototype.equals=function(o){
	if(!o||!o.jsjava_class||o.jsjava_class!="org.apache.commons.math.linear.RealMatrixImpl"){
		return false;
	}
	var nRows = this.getRowDimension();
    var nCols = this.getColumnDimension();
    if (o.getColumnDimension() != nCols || o.getRowDimension() != nRows) {
        return false;
    }
    for (var row = 0; row < nRows; row++) {
        for (var col = 0; col < nCols; col++) {
            if (this.data[row][col] != o.getEntry(row, col)) {
                return false;
            }
        }
    }
    return true;
};

RealMatrixImpl.prototype.getLUMatrix=function(){
	if (this.lu == null) {
        this.luDecompose();
    }
    return RealMatrixImpl.CreateRealMatrixImplByFullArray(this.lu);
};

RealMatrixImpl.prototype.getPermutation=function(){
	var out = new Array(this.permutation.length);
	for(var i=0;i<this.permutation.length;i++){
		out[i]=this.permutation[i];
	}
    return out;
};

RealMatrixImpl.prototype.copyOut=function(){
	var nRows = this.getRowDimension();
	var nCols=this.getColumnDimension();
    var out=new Array(nRows);
    for(var i=0;i<nRows;i++){
    	out[i]=new Array(nCols);
    }
    // can't copy 2-d array in one shot, otherwise get row references
    for (var i = 0; i < nRows; i++) {
        for(var j=0;j<nCols;j++){
        	out[i][j]=this.data[i][j];
        }
    }
    return out;
};

RealMatrixImpl.prototype.copyIn=function(ins){
	this.setSubMatrix(ins,0,0);
};

RealMatrixImpl.prototype.isValidCoordinate=function(row,col){
	var nRows = this.getRowDimension();
    var nCols = this.getColumnDimension();
    return !(row < 0 || row > nRows - 1 || col < 0 || col > nCols -1);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Set class references to java.util.Set of J2SE1.4 */
 
/**
 * constructor
 */
function Set(){
	this.jsjava_class="jsjava.util.Set";
    this.capacity=50;
    this.size=0;
    this.span=10;
    this.elements=new Array(this.capacity);
}

/**
 * Increases the capacity of and internally reorganizes this 
 * set, in order to accommodate and access its entries 
 * more efficiently.
 */
Set.prototype.recapacity=function (){
    if(this.capacity-this.size<10){
     this.capacity+=this.span;
     var oldElements=this.elements;
        this.elements=new Array(this.capacity); 
        for(var i=0;i<this.size;i++){
            this.elements[i]=oldElements[i]; 
        }
    }
};

/**
 * Adds the specified element to this set if it is not already present
 */
Set.prototype.add=function (pvalue){
    if(this.contains(pvalue)){
    	return;
    }
    this.recapacity();
    this.elements[this.size++]=pvalue;    
};

/**
 * Inserts the specified element at the specified position in this set
 * if it is not already present
 * param index
 * param pvalue
 */
Set.prototype.addIndexOf=function (index,pvalue){
    if(this.contains(pvalue)){
    	return;
    }
    this.recapacity();
    if(index>=this.size){
        this.elements[this.size]=pvalue;
        return; 
    }
    this.size++;      
    for(var i=this.size-1;i>index;i--){
     this.elements[i]=this.elements[i-1];
    } 
    this.elements[index]=pvalue;
};

/**
 * Removes all of the elements from this set.
 */
Set.prototype.clear=function (){
    this.elements=new Array(this.capacity); 
};

/**
 * Returns true if this set contains the specified element.
 * param pvalue
 */
Set.prototype.contains=function (pvalue){
    for(var i=0;i<this.size;i++){
     var elem=this.elements[i]
        if(elem.equals(pvalue)){
            return true; 
        } 
    } 
    return false;
};

/**
 * Returns the element at the specified position in this set.
 * param index
 */
Set.prototype.get=function (index){
    return this.elements[index];
};

/**
 * Returns the index in this set of the first occurrence of the 
 * specified element, or -1 if this list does not contain this element.
 * param pvalue
 */
Set.prototype.indexOf=function (pvalue){
    for(var i=0;i<this.size;i++){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return i; 
        } 
    } 
    return -1;
};

/**
 * Returns true if this set contains no elements.
 */
Set.prototype.isEmpty=function (){
    return this.size==0;
};

/**
 * Returns an iterator over the elements in this set in proper sequence.
 */
Set.prototype.iterator=function (){
    return new Iterator(this);
};

/**
 * Returns the index in this set of the last occurrence of the specified 
 * element, or -1 if this set does not contain this
 */
Set.prototype.lastIndexOf=function (pvalue){
    for(var i=this.size-1;i>=0;i--){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return i; 
        } 
    } 
    return -1;
};

/**
 * Removes the element at the specified position in this set
 * param index
 */
Set.prototype.removeIndexOf=function (index){
    if(index>-1&&index<this.size){
     var oldElems=this.elements;
     this.elements=new Array(this.capacity);
     this.size--;
     for(var i=0;i<this.size;i++){
         if(i<index){
             this.elements[i]=oldElems[i]; 
         }else{
             this.elements[i]=oldElems[i+1];
         } 
        
     }
    }
};

/**
 * Removes the first occurrence in this set of the specified element
 * param pvalue
 */
Set.prototype.remove=function (pvalue){
    this.removeIndexOf(this.indexOf(pvalue));
};

/**
 * Replaces the element at the specified position in this set with the 
 * specified element
 * param index
 * param pvalue
 *
Set.prototype.set=function (index,pvalue){
    if(this.contains(pvalue)){
    	return;
    }
    this.elements[index]=pvalue;
};

/**
 * Returns a view of the portion of this set between the specified 
 * fromIndex, inclusive, and toIndex, exclusive.
 * param index1
 * param index2
 */
Set.prototype.subSet=function (index1,index2){
    var l=new Set();
    for(var i=index1;i<index2;i++){
        l.add(this.elements[i]); 
    }
    return l;
};

/**
 * Appends all of the elements in the specified array to the end of 
 * this set
 * param arr
 */
Set.prototype.addArray=function (arr){
    if(arr==undefined||arr.length==undefined){
        return; 
    } 
    for(var i=0;i<arr.length;i++){
    	if(this.contains(arr[i])){
    	    continue;
        }
        this.add(arr[i]); 
    }
};

/**
 * Appends all of the elements in the specified set to the end of 
 * this set
 * param set
 */
Set.prototype.addSet=function (Set){
    if(Set==undefined||Set.size<=0){
        return; 
    }
    this.addArray(Set.elements);
};

/**
 * Returns the number of elements in this set. 
 */
Set.prototype.getSize=function (){
    return this.size;
};

/**
 * Returns an array containing all of the elements 
 * in this set in proper sequence. 
 */
Set.prototype.toArray=function (){
    var arr=new Array(this.size);
    for(var i=0;i<this.size;i++){
        arr[i]=this.elements[i]; 
    } 
    return arr;
};

/**
 * Returns a string representation of this Set object
 */
Set.prototype.toString=function (){
    return this.toArray().toString(); 
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */


/**  The Short class references to java.lang.Short of J2SE1.4 */
 
/**
 * constructor
 * param value
 */
function Short(value){
	this.jsjava_class="jsjava.lang.Short";
    this.value=value;
}
Short.MIN=-Math.pow(2,15);
Short.MAX=Math.pow(2,15)-1;
Short.MIN_VALUE=-Math.pow(2,15);
Short.MAX_VALUE=Math.pow(2,15)-1;

/**
 * check whether the input value is a short value
 * param s
 */
Short.checkValid=function(s){
	if(isNaN(s)){
		return false;
	}
	s=parseInt(s);
    if(s<=Short.MAX&&s>=Short.MIN){
    	return true;
    }
    return false;
};

/**
 * return the short value parsed from str
 * param str
 */
Short.parseShort=function(str){
    if(isNaN(str)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
    var s=parseInt(str);
    if(!Short.checkValid(s)){
        return;
    }
    return s;
};

/**
 * compare whether this object value is equals to input Short object value
 * param b input Short object
 */
Short.prototype.compareTo=function(b){
    if(b==undefined){
        return -1; 
    }
    if(this.value>b.value){
        return 1; 
    }else if(this.value==b.value){
        return 0; 
    }else{
        return -1;  
    }
};

/**
 * return the object's short value
 */
Short.prototype.shortValue=function(){
    return this.value; 
};

/**
 * return a string description
 */
Short.prototype.toString=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Short.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Short"){
        return this.value==o.value; 
    } 
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function ShortValidator(){
	this.jsjava_class="jsorg.eob.validator.ShortValidator";
}

ShortValidator.MIN=-Math.pow(2,15);
ShortValidator.MAX=Math.pow(2,15)-1;

/**
 * Check whether the given value is short int
 * param str - the given value
 */
ShortValidator.validate=function(str){
	return Short.checkValid(str);
};

/**
 * Check whether the given value is short int
 * param s - the given value
 */
ShortValidator.validate2=function(s){
	if(isNaN(s)){
		return false;
	}
	if(typeof(s)=="number"){
		if(Math.floor(s)!=s){
			return false;
		}
	}else{
		if(s.indexOf(".")!=-1){
			return false;
		}
	}
	s=parseInt(s);
	if(s<=ShortValidator.MAX&&s>=ShortValidator.MIN){
    	return true;
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The SplineInterpolator class references to org.apache.commons.math.analysis.SplineInterpolator */
 
function SplineInterpolator(){
	this.jsjava_class="jsorg.apache.commons.math.analysis.SplineInterpolator";
}

/**
 * Computes an interpolating function for the data set.
 * param arrx - the arguments for the varerpolation povars
 * param arry - the values for the varerpolation povars
 */
SplineInterpolator.prototype.interpolate=function(arrx,arry){
	if (arrx.length != arry.length) {
            throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Dataset arrays must have same length.");
        }
        
        if (arrx.length < 3) {
            throw new IllegalArgumentException
                (IllegalArgumentException.ERROR,"At least 3 datapovars are required to compute a spline varerpolant");
        }
        
        // Number of varervals.  The number of data povars is n + 1.
        var n = arrx.length - 1;   
        
        for (var i = 0; i < n; i++) {
            if (arrx[i]  >= arrx[i + 1]) {
                throw new IllegalArgumentException(IllegalArgumentException.ERROR,"Dataset arrx values must be strictly increasing.");
            }
        }
        
        // Differences between knot povars
        var h = new Array(n);
        for (var i = 0; i < n; i++) {
            h[i] = arrx[i + 1] - arrx[i];
        }
        
        var mu = new Array(n);
        var z = new Array(n + 1);
        mu[0] = 0;
        z[0] = 0;
        var g = 0;
        for (var i = 1; i < n; i++) {
            g = 2 * (arrx[i+1]  - arrx[i - 1]) - h[i - 1] * mu[i -1];
            mu[i] = h[i] / g;
            z[i] = (3 * (arry[i + 1] * h[i - 1] - arry[i] * (arrx[i + 1] - arrx[i - 1])+ arry[i - 1] * h[i]) /
                    (h[i - 1] * h[i]) - h[i - 1] * z[i - 1]) / g;
        }
       
        // cubic spline coefficients --  b is linear, c quadratic, d is cubic (original arry's are constants)
        var b = new Array(n);
        var c = new Array(n+1);
        var d = new Array(n);
        
        z[n] = 0;
        c[n] = 0;
        
        for (var j = n -1; j >=0; j--) {
            c[j] = z[j] - mu[j] * c[j + 1];
            b[j] = (arry[j + 1] - arry[j]) / h[j] - h[j] * (c[j + 1] + 2 * c[j]) / 3;
            d[j] = (c[j + 1] - c[j]) / (3 * h[j]);
        }
        
        var polynomials = new Array(n);
        var coefficients = new Array(4);
        for (var i = 0; i < n; i++) {
            coefficients[0] = arry[i];
            coefficients[1] = b[i];
            coefficients[2] = c[i];
            coefficients[3] = d[i];
            polynomials[i] = new PolynomialFunction(coefficients);
        }
        
        return new PolynomialSplineFunction(arrx, polynomials);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Stack class references to java.util.Stack of J2SE1.4 */
 
/**
 * constructor
 */
function Stack(){
	this.jsjava_class="jsjava.util.Stack";
	this.capacity=50;
    this.size=0;
    this.span=10;
    this.elements=new Array(this.capacity);
}
Stack.MESSAGE_NOTFOUND=-1;

/**
 * Increases the capacity of and internally reorganizes this 
 * stack, in order to accommodate and access its entries 
 * more efficiently.
 */
Stack.prototype.recapacity=function (){
    if(this.capacity-this.size<10){
     this.capacity+=this.span;
     var oldElements=this.elements;
        this.elements=new Array(this.capacity); 
        for(var i=0;i<this.size;i++){
            this.elements[i]=oldElements[i]; 
        }
    }
};

/**
 * Pushes an item onto the top of this stack.
 * param obj
 */
Stack.prototype.push=function(obj){
	this.recapacity();
	this.elements[this.size++]=obj;
};

/**
 * Removes the object at the top of this stack and returns that object 
 * as the value of this function.
 */
Stack.prototype.pop=function(){
    var oldElems=this.elements;
	this.elements=new Array(this.capacity);
	for(var i=0;i<this.size-1;i++){
	    this.elements[i]=oldElems[i];
	}
	this.size--;
	return oldElems[this.size];
};

/**
 * Looks at the object at the top of this stack without removing 
 * it from the stack
 */
Stack.prototype.peek=function(){
    return this.elements[this.size-1];
};

/**
 * Tests if this stack is empty.
 */
Stack.prototype.empty=function(){
	return this.size==0;
};

/**
 * Returns the 1-based position where an object is on this stack.
 */
Stack.prototype.search=function(obj){
	for(var i=0;i<this.size;i++){
	    if(this.elements[i].equals(obj)){
	        return i+1;
	    }
	}
	return Stack.MESSAGE_NOTFOUND;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The StatUtils class references to org.apache.commons.math.stat.StatUtils */

function StatUtils(){
	this.jsjava_class="org.apache.commons.math.stat.StatUtils";
}

/**
 * Returns the geometric mean of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.geometricMean=function(values){
	return Math.pow(StatUtils.product(values),1/values.length);
};

/**
 * Returns the maximum of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.max=function(values){
	var max=Double.MIN_VALUE;
	for(var i=0;i<values.length;i++){
		var value=values[i];
		if(value>max){
			max=value;
		}
	}
	return max;
};

/**
 * Returns the arithmetic mean of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.mean=function(values){
	return StatUtils.sum(values)/values.length;
};

/**
 * Returns the mean of the (signed) differences between corresponding elements of the input arrays -- i.e., 
 * sum(sample1[i] - sample2[i]) / sample1.length.
 * param sample1
 * param sample2
 */
StatUtils.meanDifference=function(sample1,sample2){
	var length1=sample1.length;
	var length2=sample2.length;
	if(!length1||!length2||length1!=length2){
		return new IllegalArgumentException ("Input arrays must have the same (positive) length.");
	}
	var sample=new Array(length1);
	for(var i=0;i<length1;i++){
		sample[i]=sample1[i]-sample2[i];
	}
	return StatUtils.mean(sample);
};

/**
 * Returns the minimum of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.min=function(values){
	var min=Double.MAX_VALUE;
	for(var i=0;i<values.length;i++){
		var value=values[i];
		if(value<min){
			min=value;
		}
	}
	return min;
};

/**
 * Returns an estimate of the pth percentile of the values in the values array.
 * param values
 * p
 */
StatUtils.percentile=function(values,p){
	if ((p > 100) || (p <= 0)) {
        throw new IllegalArgumentException("invalid quantile value: " + p);
    }
    var length=values.length;
    if (length == 0) {
        return Double.NaN;
    }
    if (length == 1) {
        return values[0]; // always return single value for n = 1
    }
    var n =  length;
    var pos = p * (n + 1) / 100;
    var fpos = Math.floor(pos);
    var intPos =  fpos;
    var dif = pos - fpos;
    var sorted = new Array(length);
    for(var i=0;i<length;i++){
    	sorted[i]=values[i];
    }
    sorted.sort();
    if (pos < 1) {
        return sorted[0];
    }
    if (pos >= n) {
        return sorted[length - 1];
    }
    var lower = sorted[intPos - 1];
    var upper = sorted[intPos];
    return lower + dif * (upper - lower);
};

/**
 * Returns the product of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.product=function(values){
	var value=1;
	for(var i=0;i<values.length;i++){
		value*=values[i];
	}
	return value;
};

/**
 * Returns the sum of the values in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.sum=function(values){
	var sum=0;
	for(var i=0;i<values.length;i++){
		sum+=values[i];
	}
	return sum;
};

/**
 * Returns the sum of the (signed) differences between corresponding 
 * elements of the input arrays -- i.e., sum(sample1[i] - sample2[i]).
 * param sample1
 * param sample2
 */
StatUtils.sumDifference=function(sample1,sample2){
	var length1=sample1.length;
	var length2=sample2.length;
	if(!length1||!length2||length1!=length2){
		return new IllegalArgumentException ("Input arrays must have the same (positive) length.");
	}
    var result = 0;
    for (var i = 0; i < length1; i++) {
        result += sample1[i] - sample2[i];
    }
    return result;
};

/**
 * Returns the sum of the natural logs of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.sumLog=function(values){
	var sumLog=0;
	for(var i=0;i<values.length;i++){
		sumLog+=Math.log(values[i]);
	}
	return sumLog;
};

/**
 * Returns the sum of the squares of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.sumSq=function(values){
	var sumLog=0;
	for(var i=0;i<values.length;i++){
		sumLog+=values[i]*values[i];
	}
	return sumLog;
};

/**
 * Returns the variance of the entries in the input array, or Double.NaN if the array is empty.
 * param values
 */
StatUtils.variance=function(values){
	var v;
	var length=values.length;
	if(length==1){
		return 0.0;
	}
	var mean=StatUtils.mean(values);
	var accum = 0.0;
    var accum2 = 0.0;
    for (var i = 0; i < length; i++) {
        accum += Math.pow((values[i] - mean), 2.0);
        accum2 += (values[i] - mean);
    }
    v=(accum - (Math.pow(accum2, 2) / (length))) /(length - 1);    
    return v;
};

/**
 * Returns the variance of the (signed) differences between corresponding elements of the input 
 * arrays -- i.e., var(sample1[i] - sample2[i]).
 * param sample1
 * param sample2
 * param meanDifference
 */
StatUtils.varianceDifference=function(sample1,sample2,meanDifference){
	var sum1 = 0;
    var sum2 = 0;
    var diff = 0;
    var length1=sample1.length;
	var length2=sample2.length;
	if(!length1||!length2||length1!=length2){
		return new IllegalArgumentException ("Input arrays must have the same (positive) length.");
	}
    for (var i = 0; i < length1; i++) {
        diff = sample1[i] - sample2[i];
        sum1 += (diff - meanDifference) *(diff - meanDifference);
        sum2 += diff - meanDifference;
    }
    return (sum1 - (sum2 * sum2 / length1)) / (length1 - 1);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The StopWatch class references to org.apache.commons.lang.StopWatch */
 
function StopWatch(){
	this.jsjava_class="jsorg.apache.commons.lang.StopWatch";
	this.startTime=0;
	this.endTime=0;
}

/**
 * Start the stopwatch.
 */
StopWatch.prototype.start=function(){
	this.startTime=new Date().getTime();
};

/**
 * Stop the stopwatch.
 */
StopWatch.prototype.stop=function(){
	this.endTime=new Date().getTime();
};

/**
 * Get the milliseconds on the stopwatch.
 */
StopWatch.prototype.getTime=function(){
	return this.endTime-this.startTime;
};

/**
 * Get the milliseconds on the stopwatch.
 */
StopWatch.prototype.getMilliSeconds=function(){
	return this.getTime();
};

/**
 * Get the seconds on the stopwatch.
 */
StopWatch.prototype.getSeconds=function(){
	return this.getTime()/1000;
};

/**
 * Get the minutes on the stopwatch.
 */
StopWatch.prototype.getMinutes=function(){
	return this.getTime()/(1000*60);
};

/**
 * Get the hours on the stopwatch.
 */
StopWatch.prototype.getHours=function(){
	return this.getTime()/(1000*3600);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The StringBuffer class references to java.lang.StringBuffer of J2SE1.4 */
 
/**
 * constructor
 * param str
 */
function StringBuffer(str){
	this.jsjava_class="jsjava.lang.StringBuffer";
	if(str==undefined||str==null){
		str="";
	}
    this.orig=str; 
    this.nStr=str;
}

/**
 * append a string after the current string
 * param pvalue
 */
StringBuffer.prototype.append=function (pvalue){
    this.nStr+=pvalue; 
};

/**
 * return the length of the current string
 */
StringBuffer.prototype.getLength=function (){
    return this.nStr.length; 
};

/**
 * return the char at specified index
 * param index
 */
StringBuffer.prototype.charAt=function (index){
    return this.nStr.charAt(index); 
};

/**
 * delete content from index1 to index2
 * param index1
 * param index2
 */
StringBuffer.prototype.deleteBetween=function (index1,index2){
    if(index1<index2){
     var str=this.nStr.substring(0,index1)+this.nStr.substring(index2);
     this.nStr=str;
    }else if(index1==index2){
     var str=this.nStr.substring(0,index1)+this.nStr.substring(index1+1);
     this.nStr=str;
    }
    
};

/**
 * return the current string
 */
StringBuffer.prototype.getValue=function (){
    return this.nStr; 
};

/**
 * return a string description
 */
StringBuffer.prototype.toString=function (){
    return this.nStr; 
};

/**
 * delete a char at specified index
 * param index
 */
StringBuffer.prototype.deleteCharAt=function (index){
    this.deleteBetween(index,index); 
};

/**
 * return the chars array from the current string
 */
StringBuffer.prototype.getChars=function (){
    var chars=new Array(this.getLength()); 
    for(var i=0;i<chars.length;i++){
        chars[i]=this.nStr.charAt(i); 
    }
   return chars;
};

/**
 * return the index of str in the current string
 * param str
 */
StringBuffer.prototype.indexOf=function (str){
    return this.nStr.indexOf(str); 
};

/**
 * insert a string in specified index
 * param index
 * param str
 */
StringBuffer.prototype.insert=function (index,str){
    var s= this.nStr.substring(0,index)+str+this.nStr.substring(index);
    this.nStr=s;
};

/**
 * return the last index of str in the current string
 * param str
 */
StringBuffer.prototype.lastIndexOf=function (str){
    return this.nStr.lastIndexOf(str); 
};

/**
 * return the substring from index
 * param index
 */
StringBuffer.prototype.substring=function (index){
    return this.nStr.substring(index); 
};

/**
 * return the substring from index1 to index2
 * param index1
 * param index2
 */
StringBuffer.prototype.substringBetween=function (index1,index2){
    return this.nStr.substring(index1,index2); 
};

/**
 * reverse the current string char sequence
 */
StringBuffer.prototype.reverse=function (){
    var str="";
    for(var i=this.getLength()-1;i>=0;i--){
        str+=this.charAt(i); 
    } 
    this.nStr=str;
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The StringCharacterIterator class references to java.text.StringCharacterIterator of J2SE1.4 */
 
/**
 * constructor
 * param str
 */
function StringCharacterIterator(str){
	this.jsjava_class="jsjava.text.StringCharacterIterator";
    this.str=str;
    if(str==null){
        this.str="";	
    }
    this.list=new List();
    var length=str.length;
    for(var i=0;i<length;i++){
        this.list.add(str.charAt(i));	
    }
    this.nextIndex=0;
    this.prevIndex=this.list.getSize()-1;
    this.currentIndex=0;
}

/**
 * judge whether the iterator has more elements
 */
StringCharacterIterator.prototype.hasMore=function(){
    if(this.nextIndex==this.list.getSize()+1||this.prevIndex==-2){
    	return false;
    }
    return true;	
};

/**
 * return the current char
 */
StringCharacterIterator.prototype.current=function(){
    return this.list.get(this.currentIndex);
};

/**
 * return the first char
 */
StringCharacterIterator.prototype.first=function(){
    this.nextIndex=1;
    this.currentIndex=this.nextIndex-1;
    return this.list.get(0);	
};

/**
 * return the last char
 */
StringCharacterIterator.prototype.last=function(){
    this.prevIndex=this.list.getSize()-2;
    this.currentIndex=this.prevIndex+1;
    return this.list.get(this.list.getSize()-1);	
};

/**
 * return the next char
 */
StringCharacterIterator.prototype.next=function(){
    this.currentIndex=this.nextIndex;
    return this.list.get(this.nextIndex++);	
};

/**
 * return the previous char
 */
StringCharacterIterator.prototype.previous=function(){
    this.currentIndex=this.prevIndex;
    return this.list.get(this.prevIndex--);	
};

/**
 * return the begin index from where the iterator start
 */
StringCharacterIterator.prototype.getBeginIndex=function(){
    return 0;	
};

/**
 * return the end index where the iterator stop
 */
StringCharacterIterator.prototype.getEndIndex=function(){
    return this.list.getSize()-1;
};

/**
 * return the current index
 */
StringCharacterIterator.prototype.getIndex=function(){
    return this.currentIndex;
};

/**
 * set the current index
 * param index
 */
StringCharacterIterator.prototype.setIndex=function(index){
    this.currentIndex=index;
    this.nextIndex=index+1;
    this.prevIndex=index-1;	
};

/**
 * set the string
 * param text
 */
StringCharacterIterator.prototype.setText=function(text){
    this.str=text;
    if(text==null){
        this.str="";	
    }
    this.list=new List();
    var length=text.length;
    for(var i=0;i<length;i++){
        this.list.add(text.charAt(i));	
    }
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function StringPrototype(){
	this.jsjava_class="jsorg.eob.prototype.StringPrototype";
}

/**
 * Load the extended String prototype
 */
StringPrototype.load=function(){
	String.prototype.jsjava_class="String";

	String.prototype.trim=function(){
		return this.replace(/(^\s*)|(\s*$)/g, "");
	};
	
	String.prototype.startsWith=function(prefix,toffset){
		if(toffset==undefined){
			toffset=0;
		}
		if(prefix==undefined){
			return false;
		}
		if(this.indexOf(prefix)==toffset){
			return true;
		}
		return false;
	};
	
	String.prototype.endsWith=function(suffix){
		if(suffix==undefined){
			return false;
		}
		if(this.lastIndexOf(suffix)==this.length-suffix.length){
			return true;
		}
		return false;
	};
	
	String.prototype.concat=function(str){
		if(str==undefined){
			str="";
		}
		return this+str;
	};
	
	String.prototype.toCharArray=function(){
		if(str==undefined){
			return null;
		}
		var length=this.length;
		var chars=new Array(length);
		for(var i=0;i<length;i++){
			chars[i]=this.charAt(i);			
		}
		return chars;
	};
};

StringPrototype.load();/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The StringTokenizer class references to java.util.StringTokenizer of J2SE1.4 */
 
/**
 * constructor
 * param str
 * param delim
 */
function StringTokenizer(str,delim){
	this.jsjava_class="jsjava.util.StringTokenizer";
    this.str=str;
    this.delim=delim;
    this.elements=str.split(delim);
    this.size=0;
    if(this.elements){
        this.size=this.elements.length;
    }
    this.nextIndex=0;
}

/**
 * Calculates the number of times that this tokenizer's nextToken 
 * method can be called before it generates an exception.
 */
StringTokenizer.prototype.countTokens=function(){
	return this.size;
};

/**
 * Returns the same value as the hasMoreTokens method.
 */
StringTokenizer.prototype.hasMoreElements=function(){
	return this.nextIndex<this.size;
};

/**
 * Tests if there are more tokens available from this tokenizer's string.
 */
StringTokenizer.prototype.hasMoreTokens=function(){
	return this.nextIndex<this.size;
};

/**
 * Returns the same value as the nextToken method, except that its declared 
 * return value is Object rather than String.
 */
StringTokenizer.prototype.nextElement=function(){
	return this.elements[this.nextIndex++];
	
};

/**
 * Returns the next token from this string tokenizer.
 */
StringTokenizer.prototype.nextToken=function(){
	return this.elements[this.nextIndex++];
};

/**
 * Returns the next token in this string tokenizer's string.
 */
StringTokenizer.prototype.nextToken=function(delim){
	return this.str.split(delim)[this.nextIndex];

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The StringUtils class references to org.apache.commons.lang.StringUtils */
 
function StringUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.StringUtils";	
}

/**
 * Abbreviates a String using ellipses.
 * param str the String to check, may be null
 * param offset left edge of source String
 * param maxWidth maximum length of result String, must be at least 4
 */
StringUtils.abbreviate=function(str,offset,maxWidth){
	if (str == null) {
        return null;
    }
    if (maxWidth < 4) {
        maxWidth==4;
    }
    if (str.length <= maxWidth) {
        return str;
    }
    if (offset > str.length) {
        offset = str.length;
    }
    if ((str.length - offset) < (maxWidth - 3)) {
        offset = str.length - (maxWidth - 3);
    }
    if (offset <= 4) {
        return str.substring(0, maxWidth - 3) + "...";
    }
    if (maxWidth < 7) {
        maxWidth=7;
    }
    if ((offset + (maxWidth - 3)) < str.length) {
        return "..." + StringUtils.abbreviate(str.substring(offset),0, maxWidth - 3);
    }
    return "..." + str.substring(str.length - (maxWidth - 3));
};

/**
 * Capitalizes a String changing the first letter to title case.
 * param str
 */
StringUtils.capitalize=function(str){
	if(str==null||str==""){
		return str;
	}
	if(str.length==1){
		return str.toUpperCase();
	}
	var nstr=str.charAt(0).toUpperCase()+str.substring(1);
	return nstr;
};

/**
 * Checks if a String is empty ("") or null.
 * param str
 */
StringUtils.isEmpty=function(str){
	if(str==undefined||str==""||str==null){
		return true;
	}
	return false;
};

/**
 * Checks if a String is not empty ("") and not null.
 * param str
 */
StringUtils.isNotEmpty=function(str){
	return !StringUtils.isEmpty(str);
};

/**
 * Checks if a String is whitespace, empty ("") or null.
 * param str
 */
StringUtils.isBlank=function(str){
	if(str==undefined||str==""||str==null||/^\s*/.test(str)){
		return true;
	}
	return false;
};

/**
 * Checks if a String is not empty (""), not null and not whitespace only.
 * param str
 */
StringUtils.isNotBlank=function(str){
	return !StringUtils.isBlank(str);
};

/**
 * Checks if the String contains only unicode letters.
 * param str
 */
StringUtils.isAlpha=function(str){
	return /^[A-Za-z]+$/.test(str);
};

/**
 * Checks if the String contains only unicode letters or digits.
 * param str
 */
StringUtils.isAlphanumeric=function(str){
	return /^[A-Za-z0-9]+$/.test(str);
};

/**
 * Checks if the String contains only unicode letters, digits or space (' ').
 * param str
 */
StringUtils.isAlphanumericSpace=function(str){
	if(str==""){
		return true;
	}
	return /^[A-Za-z0-9\s]+$/.test(str);
};

/**
 * Checks if the String contains only unicode letters and space (' ').
 * param str
 */
StringUtils.isAlphaSpace=function(str){
	if(str==""){
		return true;
	}
	return /^[A-Za-z\s]+$/.test(str);
};

/**
 * Checks if the string contains only ASCII printable characters.
 * param str
 */
StringUtils.isAsciiPrintable=function(str){
	if (str == null) {
        return false;
    }
    var length = str.length();
    for (var i = 0; i < length; i++) {
        var ch=str.charAt(i);
        ch=ch.charCodeAt(0);
        if(ch < 32 && ch >= 127){
        	return false;
        }
    }
    return true;
};

/**
 * Checks if the String contains only unicode digits.
 * param str
 */
StringUtils.isNumeric=function(str){
	return /^[0-9]+$/.test(str);
};

/**
 * Checks if the String contains only unicode digits or space (' ').
 * param str
 */
StringUtils.isNumericSpace=function(str){
	return /^[0-9\s]+$/.test(str);
};

/**
 * Checks if the String contains only whitespace.
 * param str
 */
StringUtils.isWhitespace=function(str){
	return /^[\s]+$/.test(str);
};

/**
 * Joins the elements of the provided array into a single String containing the provided list of elements.
 * param arr
 * param separtor
 */
StringUtils.joinArray=function(arr,separator){
	if(StringUtils.isEmpty(separator)){
		return arr.join("");
	}
	return arr.join(separator);
};

/**
 * Joins the elements of the provided list into a single String containing the provided list of elements.
 * param list
 * param separator
 */
StringUtils.joinList=function(list,separator){
	if(!list||!list.jsjava_class||list.jsjava_class!="jsjava.util.List"){
		return null;
	}
	if(StringUtils.isEmpty(separator)){
		separator="";
	}
	var arr=list.toArray();
	return arr.join(separator);
};

/**
 * Joins the elements of the provided iterator into a single String containing the provided list of elements.
 * param iterator
 * param separator
 */
StringUtils.joinIterator=function(iterator,separator){
	if(!iterator||!iterator.jsjava_class||iterator.jsjava_class!="jsjava.util.Iterator"){
		return null;
	}
	if(StringUtils.isEmpty(separator)){
		separator="";
	}
	iterator.moveTo(0);
	var list=new List();
	while(iterator.hasNext()){
		list.add(iterator.next());
	}
	var arr=list.toArray();
	return arr.join(separator);
};

/**
 * Removes control characters (char <= 32) from both ends of this String, handling null by returning null.
 * param str
 */
StringUtils.trim=function(str){
	if(StringUtils.isEmpty(str)){
		return str;
	}
	return str.replace(/(^\s*)|(\s*$)/g, ""); 

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The TableComponentExecutor class not references to any class of J2SE1.4 
 *  This is a executor to deal with table application event,such as add a new
 *  item and so on
 */
 
/**
 * constructor
 */
function TableComponentExecutor(){
   	this.jsjava_class="jsorg.eob.component.table.TableComponentExecutor";
}
TableComponentExecutor.us_en_exceptions=["Please do edit operation after row selected","Only one item can be edited at one time","Please do config operation after row selected","Only one item can be configed at one time","Please do delete operation after row selected","Please do move operation after row selected","Command status error,scripts failed"];
TableComponentExecutor.zh_cn_exceptions=["\u8bf7\u9009\u62e9\u540e\u518d\u8fdb\u884c\u7f16\u8f91\uff01","\u53ea\u80fd\u9009\u53d6\u4e00\u9879\u8fdb\u884c\u7f16\u8f91\uff01","\u8bf7\u9009\u62e9\u540e\u518d\u8fdb\u884c\u914d\u7f6e\uff01","\u53ea\u80fd\u9009\u53d6\u4e00\u9879\u8fdb\u884c\u914d\u7f6e\uff01","\u8bf7\u9009\u62e9\u540e\u518d\u8fdb\u884c\u5220\u9664\uff01","\u8bf7\u9009\u62e9\u540e\u518d\u79fb\u52a8\uff01","\u547d\u4ee4\u72b6\u6001\u9519\u8bef\uff0c\u62d2\u7edd\u6267\u884c\u811a\u672c"];
TableComponentExecutor.language=navigator.userLanguage==undefined?navigator.language:navigator.userLanguage;

/**
 * format exception info to i18n info
 * param index the index of exception info returned
 */
TableComponentExecutor.formatExceptions=function(index){
   var lang=TableComponentExecutor.language.replace("-","_").toLowerCase();
   var langExceptions=eval("TableComponentExecutor."+lang+"_exceptions");
   return langExceptions[index];	
};

/**
 * set the executor current command such as create eidt delete and so on
 * param command
 */
TableComponentExecutor.prototype.setCommand=function(command){
   this.command=command;
};

/**
 * set the id of the table row which needs changing the color
 * param id
 */
TableComponentExecutor.prototype.setNeedChangeRowTableId=function(id){
   this.needChangeRowTableId=id;
};

/**
 * return the id of the table row which needs changing the color
 */
TableComponentExecutor.prototype.getNeedChangeRowTableId=function(){
   return this.needChangeRowTableId;
};

/**
 * return the executor current command
 */
TableComponentExecutor.prototype.getCommand=function(){
   return this.command;
};

/**
 * set the submission form if the executor needs execute a submit operation
 * param form the form name
 */
TableComponentExecutor.prototype.setForm=function(form){
   this.form=form;
};

/**
 * return the submission form name
 */
TableComponentExecutor.prototype.getForm=function(){
   return this.form;
};

/**
 * set checkbox name of the table rows
 * param checkbox
 */
TableComponentExecutor.prototype.setCheckbox=function(checkbox){
   this.checkbox=checkbox;
};

/**
 * return the checkbox name of the table rows
 */
TableComponentExecutor.prototype.getCheckbox=function(){
   return this.checkbox;
};

/**
 * set the name of the checkbox used to select all rows
 * param selectAllCheckbox
 */
TableComponentExecutor.prototype.setSelectAllCheckbox=function(selectAllCheckbox){
   this.selectAllCheckbox=selectAllCheckbox;
};

/**
 * return the name of the checkbox used to select all rows 
 */
TableComponentExecutor.prototype.getSelectAllCheckbox=function(){
   return this.selectAllCheckbox;
};

/**
 * set the name of sort collum
 * param sortName
 */
TableComponentExecutor.prototype.setSortName=function(sortName){
   this.sortName=sortName;
};

/**
 * return the name of sort collum
 */
TableComponentExecutor.prototype.getSortName=function(){
   return this.sortName;
};

/**
 * set the sort type
 * param sortType either ASC or DESC
 */
TableComponentExecutor.prototype.setSortType=function(sortType){
   this.sortType=sortType;
};

/**
 * return the sort type
 */
TableComponentExecutor.prototype.getSortType=function(){
   return this.sortType;
};

/**
 * set the name of input field used to record the sort name
 * param sortNameField
 */
TableComponentExecutor.prototype.setSortNameField=function(sortNameField){
   this.sortNameField=sortNameField;
};

/**
 * return the name of input field used to record the sort name
 */
TableComponentExecutor.prototype.getSortNameField=function(){
   return this.sortNameField;
};

/**
 * set the name of input field used to record the sort type
 * param sortTypeField
 */
TableComponentExecutor.prototype.setSortTypeField=function(sortTypeField){
   this.sortTypeField=sortTypeField;
};

/**
 * return the name of input field used to record the sort type
 */
TableComponentExecutor.prototype.getSortTypeField=function(){
   return this.sortTypeField;
};

/**
 * set the name of input field used to record the command
 * param commandField
 */
TableComponentExecutor.prototype.setCommandField=function(commandField){
   this.commandField=commandField;
};

/**
 * return the name of input field used to record the command
 */
TableComponentExecutor.prototype.getCommandField=function(){
   return this.commandField;
};

/**
 * set the window event source object
 * param eventSource
 */
TableComponentExecutor.prototype.setEventSource=function(eventSource){
   this.evnetSource=eventSource;	
};

/**
 * get the window event source object
 */
TableComponentExecutor.prototype.getEventSource=function(){
   return this.evnetSource;	
};

/**
 * set the action of the submission form
 * param formAction
 */
TableComponentExecutor.prototype.setFormAction=function(formAction){
   this.formAction=formAction;	
};

/**
 * return the action of the submission form
 */
TableComponentExecutor.prototype.getFormAction=function(){
   return this.formAction;	
};

/**
 * set the action target of the submission form
 * param formTarget
 */
TableComponentExecutor.prototype.setFormTarget=function(formTarget){
   this.formTarget = formTarget;
};

/**
 * return the action target of the submission form
 */
TableComponentExecutor.prototype.getFormTarget=function() {
   return this.formTarget;
};

/**
 * set the boolean value whether the form need submiting
 * param isSubmit
 */
TableComponentExecutor.prototype.setIsSubmit=function(isSubmit){
   this.isSubmit=isSubmit;
};

/**
 * return the boolean value whether the form need submitting
 */
TableComponentExecutor.prototype.getIsSubmit=function(){
   return this.isSubmit;
};

/**
 * set the command prefix
 * param commandPrefix such as the prefix do in doDelete 
 */
TableComponentExecutor.prototype.setCommandPrefix=function(commandPrefix){
   this.commandPrefix=commandPrefix;	
};

/**
 * return the command prefix
 */
TableComponentExecutor.prototype.getCommandPrefix=function(){
   return this.commandPrefix;
};

/**
 * set the boolean value whether the form may be submit directly
 * param directSubmit
 */
TableComponentExecutor.prototype.setDirectSubmit=function(directSubmit){
   this.directSubmit=directSubmit;	
};

/**
 * return the boolean value whether the form may be submit directly
 */
TableComponentExecutor.prototype.getDirectSubmit=function(){
   return this.directSubmit;	
};

/**
 * execute the command
 * param command 
 */
TableComponentExecutor.prototype.execute=function(command){

	var formName=this.getForm();
	var checkboxObj=this.getCheckbox();
	var selectAllCheckboxObj=this.getSelectAllCheckbox();
	var sortName=this.getSortName();
	var sortType=this.getSortType();
	var sortNameFieldName=this.getSortNameField();
	var sortTypeFieldName=this.getSortTypeField();
	var formObj=document.forms[formName];
	var isSubmit=this.getIsSubmit();
	var commandPrefix=this.getCommandPrefix();
	if(!this.getDirectSubmit()){
		if(command=="create"||command=="save"){
		    
		}else if(command=="edit" || command.indexOf('Radio') > -1){ 
		    if(!this.eidtEventTrigger(formObj,checkboxObj)){
		    	this.setIsSubmit(true);
			return false;
		    }	    
		}else if(command=="config"){ 
		    if(!this.configEventTrigger(formObj,checkboxObj)){
		    	this.setIsSubmit(true);
			return false;
		    }	    
		}else if(command=="delete"||command=="remove"){	
		    if(!this.deleteEventTrigger(formObj,checkboxObj)){
		    	this.setIsSubmit(true);
			return false;
		    } 
		}else if(command=="SelectAllCheckBox"){
		    if(!this.selectAllEventTrigger(formObj,checkboxObj,selectAllCheckboxObj)){
		    	this.setIsSubmit(true);
			return false;
		    }
		}else if(command=="sort"){
		    if(!this.sortEventTrigger(formObj,sortName,sortType,sortNameFieldName,sortTypeFieldName)){
		    	this.setIsSubmit(true);
			return false;
		    }
		}else if(command=="search"){
		    
		}else if(command=="restore"){
		    
		}else if(command=="move"){
		    if(!this.moveEventTrigger(formObj)){
		    	this.setIsSubmit(true);
			return false;
		    }
		}else if(command=="moveUp"){
		    if(!this.moveUpEventTrigger(formObj,checkboxObj)){
		    	this.setIsSubmit(true);
			return false;
		    }
		}else if(command=="moveDown"){

		    if(!this.moveDownEventTrigger(formObj,checkboxObj)){

		    	this.setIsSubmit(true);
			return false;
		    }
		}else if(command=="InitSequence"){
		
		}else if(command=="RowCheckStateChanged"){
		    if(!this.rowCheckStateChanged()){
		    	this.setIsSubmit(true);
			return false;
		    }	    
		}else{
		    ;
		}
	}
	if(command!=null&&commandPrefix!=null){
	    var c1=command.substring(0,1);
	    var c2=command.substring(1);
	    c1=c1.toUpperCase();
	    command=commandPrefix+c1+c2;
	}
	if(this.getCommandField()!=null||formObj.operation!=null){
	    formObj.operation.value=command;
	}	
	if(this.getFormAction()!=null){
	    formObj.action=this.getFormAction();	
	}
	if(this.getFormTarget()!=null){
		formObj.target=this.getFormTarget();
		this.formTarget=null;
	} else {
		formObj.target="_self";
	}
	if(this.getFormTarget()!=null){
		formObj.target=this.getFormTarget();
	}
	if(this.getIsSubmit()){
	    formObj.submit();
	}else{
	    return true;	    
	}	
    };

/**
 * execute when user triggers table row edit event
 * param formObj
 * param checkboxName
 */
TableComponentExecutor.prototype.eidtEventTrigger=function(formObj,checkboxName){
    
    var	checkboxObj=formObj.elements[checkboxName];
    if(!checkboxObj){
	return false;
    } 
    var	counter=0;
    if(!checkboxObj.length){
	if(checkboxObj.checked!=true){
	    alert(TableComponentExecutor.formatExceptions(0));
	    return false;
	}
    }else{ 
	for(var	i=0;i<checkboxObj.length;i++){
	    if(checkboxObj[i].checked){
		  counter++;
	    }
	}
	if(counter==0){
	    alert(TableComponentExecutor.formatExceptions(0));
	    return false;
	}  
	if(counter>1){
	    alert(TableComponentExecutor.formatExceptions(1));
	    return false;
	}
    }
    return true;
};

/**
 * execute when user triggers table row config event
 * param formObj
 * param checkboxName
 */
TableComponentExecutor.prototype.configEventTrigger=function(formObj,checkboxName){
    
    var	checkboxObj=formObj.elements[checkboxName];
    if(!checkboxObj){
	return false;
    } 
    var	counter=0;
    if(!checkboxObj.length){
	if(checkboxObj.checked!=true){
	    alert(TableComponentExecutor.formatExceptions(2));
	    return false;
	}
    }else{ 
	for(var	i=0;i<checkboxObj.length;i++){
	    if(checkboxObj[i].checked){
		  counter++;
	    }
	}
	if(counter==0){
	    alert(TableComponentExecutor.formatExceptions(2));
	    return false;
	}  
	if(counter>1){
	    alert(TableComponentExecutor.formatExceptions(3));
	    return false;
	}
    }
    return true;
};

/**
 * execute when user triggers table row delete event
 * param formObj
 * param checkboxName
 */
TableComponentExecutor.prototype.deleteEventTrigger=function(formObj,checkboxName){
    
    var	checkboxObj=formObj.elements[checkboxName];
    if(!checkboxObj){
	return false;
    } 
    var	counter=0;
    if(!checkboxObj.length){
	if(checkboxObj.checked!=true){
	    alert(TableComponentExecutor.formatExceptions(4));
	    return false;
	}
    }else{ 
	for(var	i=0;i<checkboxObj.length;i++){
	    if(checkboxObj[i].checked){
		  counter++;
	    }
	}
	if(counter==0){
	    alert(TableComponentExecutor.formatExceptions(4));
	    return false;
	}  
    }
    return true;
};

/**
 * execute when user triggers table select all event
 * param formObj
 * param checkboxName
 * param eventSourceName
 */
TableComponentExecutor.prototype.selectAllEventTrigger=function(formObj,checkboxName,eventSourceName){
    
    var	checkboxObj=formObj.elements[checkboxName];
    if(!checkboxObj){
	return false;
    } 
    var	eventSource=formObj.elements[eventSourceName];
    if(!eventSource){
	alert(TableComponentExecutor.formatExceptions(6));
	return false;
    } 
    if(!checkboxObj.length){
	if(eventSource.checked){
	    checkboxObj.checked=true;
	    checkboxObj.parentNode.parentNode.className='evenrow';
	}else{
	    checkboxObj.checked=false;
	    checkboxObj.parentNode.parentNode.className='';
	}
    }else{ 
	if(eventSource.checked){
	    for(var i=0;i<checkboxObj.length;i++){
		checkboxObj[i].checked=true;
		checkboxObj[i].parentNode.parentNode.className='evenrow';
	    }
	}else{
	    for(var i=0;i<checkboxObj.length;i++){
		checkboxObj[i].checked=false;
		checkboxObj[i].parentNode.parentNode.className='';
	    }
	}
    }  
    return false;
};

/**
 * execute when user triggers table sort
 * param formObj
 * param sortName
 * param sortType
 * param sortNameFieldName
 * param sortTypeFieldName
 */
TableComponentExecutor.prototype.sortEventTrigger=function(formObj,sortName,sortType,sortNameFieldName,sortTypeFieldName){    
    formObj.elements(sortNameFieldName).value=sortName;
    formObj.elements(sortTypeFieldName).value=sortType;
    return true;
};


/**
 * execute when user triggers table row move event
 * param formObj
 */
TableComponentExecutor.prototype.moveEventTrigger=function(formObj){    
    formObj.InitSequence.click();
    return false;
};

/**
 * execute when user triggers table row select state change event
 */
TableComponentExecutor.prototype.rowCheckStateChanged=function(){
    var eventSource=executor.getEventSource();	
    if(eventSource.checked){
	eventSource.checked=true;
	eventSource.parentNode.parentNode.className='evenrow';
    }else{
	eventSource.checked=false;
	eventSource.parentNode.parentNode.className='';
    }
};

/**
 * execute when user triggers table row move up event
 * param formObj
 * param checkboxName
 */
TableComponentExecutor.prototype.moveUpEventTrigger=function(formObj,checkboxName){
    var checkboxObj=formObj.elements[checkboxName];
    var length = checkboxObj.length;
    if(length>0)
    {
    	var isSelected=false;
	for(var i=0;i<length;++i)
	{
	   if (checkboxObj[i] && checkboxObj[i].checked)
	   {
	   	isSelected=true;
	        if(i>0&&!checkboxObj[(i-1)].checked)
	        {
	           var tableElement = document.getElementById(getNeedChangeRowTableId());
	            if(i>0){
	            	tableElement.moveRow(i+1,i);	            
	        	    checkboxObj[i-1].checked=true;
	        	}
	        }
	   }
	}
	if(!isSelected){
	   alert(TableComponentExecutor.formatExceptions(5));
	}
    }	
};

/**
 * execute when user triggers table row move down event
 * param formObj
 * param checkboxName
 */
TableComponentExecutor.prototype.moveDownEventTrigger=function(formObj,checkboxName){
    var checkboxObj=formObj.elements[checkboxName];
    var length = checkboxObj.length;
    if(length>0)
    {
    	var isSelected=false;
	for(var i=length;i>=0;--i)
	{
	   if (checkboxObj[i] && checkboxObj[i].checked)
	   {
	   	isSelected=true;
	        if((i+1)<length&&!checkboxObj[(i+1)].checked)
	        {
         
	            var tableElement = document.getElementById(getNeedChangeRowTableId());
	            tableElement.moveRow(i+1,i+2);	            
	            checkboxObj[i+1].checked=true;
	        }
	   }
	}
	if(!isSelected){
	   alert(TableComponentExecutor.formatExceptions(5));
	}
    }
    
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The TDistributionImpl class references to org.apache.commons.math.distribution.TDistributionImpl */

function TDistributionImpl(degreesOfFreedom){
	this.jsjava_class="org.apache.commons.math.distribution.TDistributionImpl";	
	if (degreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.degreesOfFreedom = degreesOfFreedom;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
TDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    if (x == 0.0) {
        ret = 0.5;
    } else {
        var t =
            Beta.regularizedBeta(
                this.getDegreesOfFreedom() / (this.getDegreesOfFreedom() + (x * x)),
                0.5 * this.getDegreesOfFreedom(),
                0.5);
        if (x < 0.0) {
            ret = 0.5 * t;
        } else {
            ret = 1.0 - 0.5 * t;
        }
    }

    return ret;
};

/**
 * Access the degrees of freedom.
 */
TDistributionImpl.prototype.getDegreesOfFreedom=function(){
	return this.degreesOfFreedom;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
TDistributionImpl.prototype.getDomainLowerBound=function(p){
	return -Double.MAX_VALUE;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
TDistributionImpl.prototype.getDomainUpperBound=function(p){
	return Double.MAX_VALUE;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
TDistributionImpl.prototype.getInitialDomain=function(p){
	return 0.0;
};

/**
 * Modify the degrees of freedom.
 * param degreesOfFreedom
 */
TDistributionImpl.prototype.setDegreesOfFreedom=function(degreesOfFreedom){
	if (degreesOfFreedom <= 0.0) {
        throw new IllegalArgumentException(IllegalArgumentException.ERROR,"degrees of freedom must be positive.");
    }
    this.degreesOfFreedom = degreesOfFreedom;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Timer class references to java.util.Timer of J2SE1.4 */
 
/**
 * constructor
 */
function Timer(){
	this.jsjava_class="jsjava.util.Timer";
    this.innerTimer=null;
    this.task=null;
    this.date=null;
    this.period=null;
    this.task2=null;
}

/**
 * Terminates this timer, discarding any currently scheduled tasks.
 */
Timer.prototype.cancel=function(){
    clearInterval(this.innerTimer);
};

/**
 * Tell the timer the current Timer instance
 */
Timer.prototype.setInstance=function(instanceName){
    this.instanceName=instanceName;	
};

/**
 * Schedules the specified task for execution at the specified time.
 * param task a TimerTask object
 * param date a Date object
 */
Timer.prototype.scheduleOnce=function(task,date){
    this.task=task
    this.date=date;
    var currDate=new Date();
    var currDateTime=currDate.getTime();
    var dateTime=date.getTime();
    var diffTime=dateTime-currDateTime;
    if(diffTime>=0){
        this.innerTimer=setTimeout("eval("+this.instanceName+".task.run())",diffTime);	
    }
};

/**
 * Schedules the specified task for repeated fixed-delay execution, 
 * beginning after the specified delay.
 * param task a TimerTask object
 * param period time in milliseconds between successive task executions.
 * param delay delay in milliseconds before task is to be executed.
 */
Timer.prototype.scheduleRepeat=function(task,period,delay){
    this.task2=task
    this.period=period;	
    var evalStr="eval("+this.instanceName+".task2.run())";
    if(!delay||delay==0){
        eval(this.instanceName+".task2.run()");	
    }else{
        eval(this.instanceName+".task2.run()");	
    }
    this.innerTimer=setInterval(evalStr,period);
};

/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The TimerTask class references to java.util.TimerTask of J2SE1.4 */
 
/**
 * constructor
 * param operation
 * param timer
 */
function TimerTask(operation,timer){
	this.jsjava_class="jsjava.util.TimerTask";
    this.operation=operation;
    this.timer=timer;
}

/**
 * Cancels this timer task.
 */
TimerTask.prototype.cancel=function(){
    this.timer.cancel();
};

/**
 * The action to be performed by this timer task.
 */
TimerTask.prototype.run=function(){
    eval(this.operation+"()");
};

/**
 * Returns the scheduled execution time of the most recent 
 * actual execution of this task.
 */
TimerTask.prototype.scheduledExecutionTime=function(){


};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The URL class references to java.net.URL of J2SE1.4 */
 
/**
 * constructor
 * param url
 */
function URL(url){
	this.jsjava_class="jsjava.net.URL";
    this.url=url;
    var schemePos=url.indexOf("://");
    var filePos=url.indexOf("/",schemePos+3);
    var portPos=url.indexOf(":",schemePos+1);
    if(portPos>filePos){
        portPos=-1;	
    }
    var queryPos=url.indexOf("?");
    var anchorPos=url.indexOf("#");
    this.protocol=url.substring(0,schemePos);
    this.host=url.substring(schemePos+3,filePos);
    if(portPos!=-1){
        this.host=url.substring(schemePos+3,portPos);	        
    }
    if(portPos!=-1){
        this.port=url.substring(portPos+1,filePos);	
    }else{
        this.port=getDefaultPort(this.scheme);
    }
    function getDefaultPort(protocol){
    	var defautPort=null;
        switch(protocol){
            case "http":defaultPort="80";break;	
            case "ftp":defaultPort="21";break;
            case "gopher":defaultPort="70";break;            
            default:defaultPort="80";break;
        }
        return defaultPort;
    } 
    if(anchorPos!=-1){
        this.file=url.substring(filePos,anchorPos);
        this.ref=url.substring(anchorPos+1);
    }else{
        this.file=url.substring(filePos);
         this.ref=null;
    }
    if(queryPos==-1){
        this.path=this.file;	
        this.query=null;
    }else{
        this.path=url.substring(filePos,queryPos);
        if(anchorPos!=-1){
            this.query=url.substring(queryPos+1,anchorPos);
        }else{
            this.query=url.substring(queryPos+1);   
        }
    }
    if(url.indexOf("mailto:")!=-1){
        this.protocol="mailto";
        this.host=null;
        this.file=this.path=url.substring("mailto:".length);
        this.port="-1";	
    }
}

/**
 * return the default port by protocol
 */
URL.prototype.getDefaultPort=function(){
    var defautPort=null;
    switch(this.protocol){
        case "http":defaultPort="80";break;	
        case "ftp":defaultPort="21";break;
        case "gopher":defaultPort="70";break;    
        case "file":defaultPort="-1";break;  
        case "mailto":defaultPort="-1";break;        
        default:defaultPort="80";break;
    }
    return defaultPort;
};

/**
 * return the virtual disk path
 */
URL.prototype.getFile=function(){
    return this.file;
};

/**
 * reuturn the host address
 */
URL.prototype.getHost=function(){
    return this.host;	
};

/**
 * return the virtual disk path
 */
URL.prototype.getPath=function(){
    return this.path;
};

/**
 * return the port
 */
URL.prototype.getPort=function(){
    return this.port;
};

/**
 * return the protocol
 */
URL.prototype.getProtocol=function(){
    return this.protocol;
};

/**
 * return the query string
 */
URL.prototype.getQuery=function(){
    return this.query;
};

/**
 * return url anchor
 */
URL.prototype.getRef=function(){
    return this.ref;
};

/**
 * return user info path
 */
URL.prototype.getUserInfo=function(){
    return null;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function URLValidator(){
	this.jsjava_class="jsorg.eob.validator.URLValidator";
}

/**
 * Check whether the given value is valid url
 * param str - the given value
 */
URLValidator.validate=function(str){
	var regx=/^[a-zA-z]+:\/\/[^\s]*$/;
    return regx.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**  The VisualCondition class not references to any class of J2SE1.4 */
 
/**
 * constructor
 * param conditionSeed certain condition
 * param visibles components which are visible
 */
function VisualCondition(conditionSeed,visibles){
	this.jsjava_class="jsorg.eob.component.trigger.VisualCondition";
    this.conditionSeed=conditionSeed;
    this.visibles=visibles;

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The WeibullDistributionImpl class references to org.apache.commons.math.distribution.WeibullDistributionImpl */

function WeibullDistributionImpl(alpha,beta){
	this.jsjava_class="org.apache.commons.math.distribution.WeibullDistributionImpl";	
	if (alpha <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Shape must be positive.");
    }       
    this.alpha = alpha;
    if (beta <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Scale must be positive.");
    }       
    this.beta = beta;
}

/**
 * For this disbution, X, this method returns P(X < x).
 * param x
 */
WeibullDistributionImpl.prototype.cumulativeProbability=function(x){
	var ret;
    if (x <= 0.0) {
        ret = 0.0;
    } else {
        ret = 1.0 - Math.exp(-Math.pow(x / this.getScale(), this.getShape()));
    }
    return ret;
};

/**
 * Access the domain value lower bound, based on p, used to bracket a CDF root.
 * param p
 */
WeibullDistributionImpl.prototype.getDomainLowerBound=function(p){
	return 0.0;
};

/**
 * Access the domain value upper bound, based on p, used to bracket a CDF root.
 * param p
 */
WeibullDistributionImpl.prototype.getDomainUpperBound=function(p){
	return Double.MAX_VALUE;
};

/**
 * Access the initial domain value, based on p, used to bracket a CDF root.
 * param p
 */
WeibullDistributionImpl.prototype.getInitialDomain=function(p){
	return Math.pow(this.getScale() * Math.log(2.0), 1.0 / this.getShape());
};

/**
 * Access the scale parameter.
 */
WeibullDistributionImpl.prototype.getScale=function(){
	return this.beta;
};

/**
 * Access the shape parameter.
 */
WeibullDistributionImpl.prototype.getShape=function(){
	return this.alpha;
};

/**
 * For this distribution, X, this method returns the critical point x, such that P(X < x) = p.
 * param p
 */
WeibullDistributionImpl.prototype.inverseCumulativeProbability=function(p){
	var ret;
    if (p < 0.0 || p > 1.0) {
        throw new IllegalArgumentException
            (IllegalArgumentException.ERROR,"probability argument must be between 0 and 1 (inclusive)");
    } else if (p == 0) {
        ret = 0.0;
    } else  if (p == 1) {
        ret = Double.POSITIVE_INFINITY;
    } else {
        ret = this.getScale() * Math.pow(-Math.log(1.0 - p), 1.0 / this.getShape());
    }
    return ret;
};

/**
 * Modify the scale parameter.
 * param beta
 */
WeibullDistributionImpl.prototype.setScale=function(beta){
	if (beta <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Scale must be positive.");
    }       
    this.beta = beta;
};

/**
 * Modify the shape parameter.
 * param alpha
 */
WeibullDistributionImpl.prototype.setShape=function(alpha){
	if (alpha <= 0.0) {
        throw new IllegalArgumentException(
            IllegalArgumentException.ERROR,"Shape must be positive.");
    }       
    this.alpha = alpha;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function XmlBrowserParser(){
	this.jsjava_class="jsorg.eob.xml.XmlParser";
	this.xmlParser=XmlParserUtils.toXmlParser();
	this.xmlDoc=null;
}

/**
 * Load xml document object from xml file
 * param xmlfile - the xml filename
 */
XmlBrowserParser.prototype.loadXmlFile=function(xmlfile){
	this.xmlDoc=this.xmlParser.load(xmlfile);
};

/**
 * Load xml document object from xml string
 * param xml - the xml string
 */
XmlBrowserParser.prototype.loadXml=function(xml){
	if(window.ActiveXObject){
		this.xmlParser.loadXML(xml);
		this.xmlDoc=this.xmlParser;
	}else if(document.implementation){
		this.xmlDoc=XmlParserUtils.toMozillaXmlParser().parseFromString(xml,"text/xml");
	}
};

/**
 * Get the xml document object
 */
XmlBrowserParser.prototype.toDocument=function(){
	return this.xmlDoc;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function XmlParserUtils(){
	this.jsjava_class="jsorg.eob.xml.XmlParserUtils";
}

/**
 * Get xml parser object of IE
 */
XmlParserUtils.toIEXmlParser=function(){
	return new ActiveXObject("Microsoft.XMLDOM");
};

/**
 * Get xml parser object of Mozilla
 */
XmlParserUtils.toMozillaXmlParser=function(){
	return new DOMParser();
};

/**
 * Get xml document object object of Mozilla
 */
XmlParserUtils.toMozillaXmlDocument=function(){
	return document.implementation.createDocument("","",null);
};

/**
 * Get xml parser object
 */
XmlParserUtils.toXmlParser=function(){
	if (window.ActiveXObject){
		return new ActiveXObject("Microsoft.XMLDOM");
	}else if (document.implementation &&document.implementation.createDocument){
		return document.implementation.createDocument("","",null);
	}else{
		return;
	}

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function XmlSerializerUtils(){
	this.jsjava_class="jsorg.eob.xml.XmlSerializerUtils";
}

/**
 * Serialize xml document or element to string form
 * @param xmldom - xml document or element
 */
XmlSerializerUtils.serializeToString=function(xmldom){
	if(xmldom==undefined){
		return "";
	}
	if(BrowserUtils.isIE()){
		return xmldom.xml;
	}else{
		return new XMLSerializer().serializeToString(xmldom,"text/html");
	}
	return "";
};
