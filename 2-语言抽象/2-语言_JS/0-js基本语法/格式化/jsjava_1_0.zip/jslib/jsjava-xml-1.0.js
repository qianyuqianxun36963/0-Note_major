/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 */

/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function BrowserUtils(){
	this.jsjava_class="jsorg.eob.browser.BrowserUtils";
}

/**
 * Check whether the current browser is IE
 */
BrowserUtils.isIE=function(){
	return navigator.userAgent.indexOf("MSIE")!=-1;
};

/**
 * Check whether the current browser is Firefox
 */
BrowserUtils.isFirefox=function(){
	return navigator.userAgent.indexOf("Firefox")!=-1;
};

/**
 * Check whether the current browser is Opera
 */
BrowserUtils.isOpera=function(){
	return navigator.userAgent.indexOf("Opera")!=-1;

};
/**
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function XmlBrowserParser(){
	this.jsjava_class="jsorg.eob.xml.XmlParser";
	this.xmlParser=XmlParserUtils.toXmlParser();
	this.xmlDoc=null;
}

/**
 * Load xml document object from xml file
 * param xmlfile - the xml filename
 */
XmlBrowserParser.prototype.loadXmlFile=function(xmlfile){
	this.xmlDoc=this.xmlParser.load(xmlfile);
};

/**
 * Load xml document object from xml string
 * param xml - the xml string
 */
XmlBrowserParser.prototype.loadXml=function(xml){
	if(window.ActiveXObject){
		this.xmlParser.loadXML(xml);
		this.xmlDoc=this.xmlParser;
	}else if(document.implementation){
		this.xmlDoc=XmlParserUtils.toMozillaXmlParser().parseFromString(xml,"text/xml");
	}
};

/**
 * Get the xml document object
 */
XmlBrowserParser.prototype.toDocument=function(){
	return this.xmlDoc;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function XmlParserUtils(){
	this.jsjava_class="jsorg.eob.xml.XmlParserUtils";
}

/**
 * Get xml parser object of IE
 */
XmlParserUtils.toIEXmlParser=function(){
	return new ActiveXObject("Microsoft.XMLDOM");
};

/**
 * Get xml parser object of Mozilla
 */
XmlParserUtils.toMozillaXmlParser=function(){
	return new DOMParser();
};

/**
 * Get xml document object object of Mozilla
 */
XmlParserUtils.toMozillaXmlDocument=function(){
	return document.implementation.createDocument("","",null);
};

/**
 * Get xml parser object
 */
XmlParserUtils.toXmlParser=function(){
	if (window.ActiveXObject){
		return new ActiveXObject("Microsoft.XMLDOM");
	}else if (document.implementation &&document.implementation.createDocument){
		return document.implementation.createDocument("","",null);
	}else{
		return;
	}

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function XmlSerializerUtils(){
	this.jsjava_class="jsorg.eob.xml.XmlSerializerUtils";
}

/**
 * Serialize xml document or element to string form
 * @param xmldom - xml document or element
 */
XmlSerializerUtils.serializeToString=function(xmldom){
	if(xmldom==undefined){
		return "";
	}
	if(BrowserUtils.isIE()){
		return xmldom.xml;
	}else{
		return new XMLSerializer().serializeToString(xmldom,"text/html");
	}
	return "";
};
