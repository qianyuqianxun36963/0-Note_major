/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 */

/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The BitSet class references to java.util.BitSet of J2SE1.4 */
 
/**
 * constructor
 */
 function BitSet(){
 	 this.jsjava_class="jsjava.util.BitSet";
     this.elements=new Array();
 }
 
/**
 * Sets the bit at the specified index to true.
 * param bitIndex
 */
 BitSet.prototype.set=function(bitIndex){
     this.elements[bitIndex]=true;
 };
 
/**
 * Sets the bit at the specified index to the specified value.
 * param bitIndex
 * param value
 */
 BitSet.prototype.setByValue=function(bitIndex,value){
     if(value!=true&&value!=false){
         value=false;	
     }
     this.elements[bitIndex]=value;
 };
 
/**
 * Sets the bits from the specified fromIndex(inclusive) to the 
 * specified toIndex(exclusive) to true.
 * param fromIndex
 * param toIndex
 */
 BitSet.prototype.setBetween=function(fromIndex,toIndex){
     for(var i=fromIndex;i<toIndex;i++){
         this.elements[i]=true;
     }
 };
 
/**
 * Sets the bits from the specified fromIndex(inclusive) to the 
 * specified toIndex(exclusive) to the specified value.
 * param fromIndex
 * param toIndex
 * param value
 */
 BitSet.prototype.setBetweenByValue=function(fromIndex,toIndex,value){
     if(value!=true&&value!=false){
         value=false;	
     }
     for(var i=fromIndex;i<toIndex;i++){
         this.elements[i]=value;
     }
 };
 
/**
 * Returns the value of the bit with the specified index.
 * param bitIndex
 */
 BitSet.prototype.get=function(bitIndex){
     var value=this.elements[bitIndex];
     if(value){
         return value;
     }
     return false;
 };

/**
 * Returns a new BitSet composed of bits from this BitSet from 
 * fromIndex(inclusive) to toIndex(exclusive).
 * param fromIndex
 * param toIndex
 */ 
 BitSet.prototype.getBetween=function(fromIndex,toIndex){
     var bs=new BitSet();
     for(var i=fromIndex;i<toIndex;i++){
         bs.setByValue(i,this.get(i));	
     }
     return bs;
 };

/**
 * Returns a string representation of this bit set. 
 */
 BitSet.prototype.toString=function(){
 	 var elems=new Array();
 	 for(var i=0;i<this.elements.length;i++){
 	     var value=this.elements[i];
 	     if(value){
 	         elems[i]=true;
 	     }else{
 	         elems[i]=false;
 	     }
 	 }
     return elems.toString();	
 };

/**
 * Returns the number of bits of space actually in use by 
 * this BitSet to represent bit values. 
 */ 
 BitSet.prototype.size=function(){
     return this.elements.length;	
 };

/**
 * Returns the "logical size" of this BitSet: the index of the 
 * highest set bit in the BitSet plus one.
 */ 
 BitSet.prototype.length=function(){
     return this.size();	
 };

/**
 * Sets all of the bits in this BitSet to false.
 */ 
 BitSet.prototype.clear=function(){
     for(var i=0;i<this.size();i++){
         this.elements[i]=false;	
     }	
 };

/**
 * Sets the bits from the specified fromIndex(inclusive) to 
 * the specified toIndex(exclusive) to false.
 * param fromIndex
 * param toIndex
 */ 
 BitSet.prototype.clearBetween=function(fromIndex,toIndex){
     for(var i=fromIndex;i<toIndex;i++){
         this.elements[i]=false;	
     }	
 };

/**
 * Returns true if this BitSet contains no bits that are set to true.
 */ 
 BitSet.prototype.isEmpty=function(){
     for(var i=0;i<this.size();i++){
         if(this.get(i)){
             return false;
         }
     }	
     return true;
 };

/**
 * Sets the bit at the specified index to to the complement of its current value.
 * param bitIndex
 */ 
 BitSet.prototype.flip=function(bitIndex){
     var value=this.elements[bitIndex];
     if(value!=true&&value!=false){
         value=false;	
     }
     var rValue=false;
     if(!value){
         rValue=true;	
     }
     this.setByValue(bitIndex,rValue);
 };

/**
 * Sets each bit from the specified fromIndex(inclusive) to the 
 * specified toIndex(exclusive) to the complement of its current value.
 * param fromIndex
 * param toIndex
 */
 BitSet.prototype.flipBetween=function(fromIndex,toIndex){
     for(var i=fromIndex;i<toIndex;i++){
         this.flip(i);	
     }
 };

/**
 * Performs a logical AND of this target bit set with the 
 * argument bit set.
 * param bs a BitSet object
 */ 
 BitSet.prototype.and=function(bs){
     var size1=this.size();
     var size2=bs.size();
     var size=size1>size2?size1:size2;
     for(var i=0;i<size;i++){
         var value1=this.get(i);
         var value2=bs.get(i);
         var value=value1&&value2;
         this.setByValue(i,value);
     }	
 };

/**
 * Performs a logical OR of this bit set with the bit set argument.
 * param bs a BitSet object
 */ 
 BitSet.prototype.or=function(bs){
     var size1=this.size();
     var size2=bs.size();
     var size=size1>size2?size1:size2;
     for(var i=0;i<size;i++){
         var value1=this.get(i);
         var value2=bs.get(i);
         var value=value1||value2;
         this.setByValue(i,value);
     }	
 };

/**
 * Performs a logical XOR of this bit set with the bit set argument.
 * param bs a BitSet object
 */  
 BitSet.prototype.xor=function(bs){
     var size1=this.size();
     var size2=bs.size();
     var size=size1>size2?size1:size2;
     for(var i=0;i<size;i++){
         var value1=this.get(i);
         var value2=bs.get(i);
         var value=value1^value2;
         value=value==1?true:false;
         this.setByValue(i,value);
     }	
 };

/**
 * Clears all of the bits in this BitSet whose corresponding bit is 
 * set in the specified BitSet.
 * param bs a BitSet object
 */ 
 BitSet.prototype.andNot=function(bs){
     var size1=this.size();
     var size2=bs.size();
     var size=size1>size2?size1:size2;
     for(var i=0;i<size;i++){
         var value1=this.get(i);
         var value2=bs.get(i);
         var value=value2==true?false:value1;
         this.setByValue(i,value);
     }	
 };

/**
 * Returns the number of bits set to true in this BitSet.
 */ 
 BitSet.prototype.cardinality=function(){
     var value=0;
     for(var i=0;i<this.size();i++){
         if(this.get(i)){
             value++;	
         }	
     }	
     return value;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Hashtable class references to java.util.Hashtable of J2SE1.4 */
 
/**
 * constructor
 */
function Hashtable(){
	this.jsjava_class="jsjava.util.Hashtable";
    this.capacity=50;
    this.size=0;
    this.span=10;
    this.elements=new Array(this.capacity);
}

/**
 * Increases the capacity of and internally reorganizes this 
 * hashtable, in order to accommodate and access its entries 
 * more efficiently.
 */
Hashtable.prototype.recapacity=function(){
    if(this.capacity-this.size<10){
     this.capacity+=this.span;
     var oldElements=this.elements;
        this.elements=new Array(this.capacity); 
        for(var i=0;i<this.size;i++){
            this.elements[i]=oldElements[i]; 
        }
    }
};

/**
 * Removes all mappings from this map 
 */
Hashtable.prototype.clear=function(){
    this.capacity=50;
    this.size=0;
    this.elements=new Array(this.capacity); 
};

/**
 * Associates the specified value with the specified key in this map 
 * param pname
 * param pvalue 
 */
Hashtable.prototype.put=function (pname,pvalue){
    this.recapacity();
    if(this.containsKey(pname)){
        for(var i=0;i<this.size;i++){
            var elem=this.elements[i];
            if(elem[0].equals(pname)){
                elem[1]=pvalue;
                return;
            } 
        } 
    }
    this.elements[this.size++]=[pname,pvalue];
   
};

/**
 * Returns the value to which this map maps the specified key. 
 * param pname
 */
Hashtable.prototype.get=function (pname){
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        if(elem[0].equals(pname)){
            return elem[1]; 
        } 
    }
};

/**
 * Returns true if this map contains a mapping for the specified key.
 * param pname
 */
Hashtable.prototype.containsKey=function(pname){
    if(this.get(pname)==undefined){
        return false; 
    }
    return true;
};

/**
 * Returns true if this map maps one or more keys to the specified value.
 * param pname
 */
Hashtable.prototype.containsValue=function (pvalue){
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        if(elem[1].equals(pvalue)){
            return true;
        } 
    }
    return false;
};

/**
 * Returns a array view of the values contained in this map.
 */
Hashtable.prototype.values=function (){
    var values=new Array(this.size);
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        values[i]=elem[1]; 
    } 
    return values;
};

/**
 * Returns a set view of the mappings contained in this map.
 */
Hashtable.prototype.entrySet=function (){
    return this.elements; 
};

/**
 * Returns true if this map contains no key-value mappings.
 */
Hashtable.prototype.isEmpty=function (){
    return this.size==0; 
};

/**
 * Returns an array of the keys in this hashtable.
 */
Hashtable.prototype.keys=function (){
    var keys=new Array(this.size);
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        keys[i]=elem[0]; 
    } 
    return keys;
};

/**
 * Returns an array of the keys in this hashtable.
 */
Hashtable.prototype.keySet=function (){
    var set=new Set();
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        set.add(elem[0]); 
    } 
    return set;
};

/**
 * Returns the number of keys in this hashtable.
 */
Hashtable.prototype.getSize=function (){
    return this.size; 
};

/**
 * Removes the key (and its corresponding value) from this hashtable.
 * param key
 */
Hashtable.prototype.remove=function (key){
    if(this.containsKey(key)){
        var oldElems=this.elements;
        var oldSize=this.size;
        this.elements=new Array(this.capacity);
        this.size=0;
        for(var i=0;i<oldSize;i++){
            var oldElem=oldElems[i];
            if(!oldElem[0].equals(key)){
                this.put(oldElem[0],oldElem[1]); 
            } 
        } 
    }
};

/**
 * add a array to the hash
 * param arr
 */
Hashtable.prototype.addArray=function (arr){
    if(arr!=null&&arr.length>0){
        for(var i=0;i<arr.length;i++){
            this.put(arr[i][0],arr[i][1]); 
        } 
    } 
};

/**
 * add a hash to the hash
 * param hash
 */
Hashtable.prototype.addHashtable=function (hash){
    if(hash!=null&&hash.size()>0){
        var keys=hash.keys();
        for(var i=0;i<keys.length;i++){
            this.put(keys[i],hash.get(keys[i])); 
        } 
    } 
};

/**
 * Returns a string representation of this Hashtable 
 * object in the form of a set of entries, enclosed 
 * in braces and separated by the ASCII characters ", " 
 * (comma and space).
 */
Hashtable.prototype.toString=function (){
    return this.elements.toString(); 
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Iterator class references to java.util.Iterator of J2SE1.4 */
 
/**
 * constructor
 * param list a List object
 */
function Iterator(list){
	this.jsjava_class="jsjava.util.Iterator";
    this.list=list;
    this.nextIndex=0;
    this.size=list.getSize();
}

/**
 * Returns true if the iteration has more elements.
 */
Iterator.prototype.hasNext=function(){
    return this.nextIndex<this.size;
};

/**
 * Returns the next element in the iteration.
 */
Iterator.prototype.next=function(){
    var nextObj;
    if(this.nextIndex<this.size){
        nextObj=this.list.get(this.nextIndex);
        this.nextIndex++;
        return nextObj;
    }
    return null;
};

/**
 * Move the opertion position to the specified index
 */
Iterator.prototype.moveTo=function(index){
    this.nextIndex=index;	

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The List class references to java.util.List of J2SE1.4 */
 
/**
 * constructor
 */
function List(){
	this.jsjava_class="jsjava.util.List";
    this.capacity=50;
    this.size=0;
    this.span=10;
    this.elements=new Array(this.capacity);
}

/**
 * Increases the capacity of and internally reorganizes this 
 * list, in order to accommodate and access its entries 
 * more efficiently.
 */
List.prototype.recapacity=function (){
    if(this.capacity-this.size<10){
     this.capacity+=this.span;
     var oldElements=this.elements;
        this.elements=new Array(this.capacity); 
        for(var i=0;i<this.size;i++){
            this.elements[i]=oldElements[i]; 
        }
    }
};

/**
 * Appends the specified element to the end of this list
 * param pvalue
 */
List.prototype.add=function (pvalue){
    this.recapacity();
    this.elements[this.size++]=pvalue; 
};

/**
 * Inserts the specified element at the specified position in this list
 * param index
 * param pvalue
 */
List.prototype.addIndexOf=function (index,pvalue){
    this.recapacity();
    if(index>=this.size){
        this.elements[this.size]=pvalue;
        return; 
    }
    this.size++;      
    for(var i=this.size-1;i>index;i--){
     this.elements[i]=this.elements[i-1];
    } 
    this.elements[index]=pvalue;
};

/**
 * Removes all of the elements from this list
 */
List.prototype.clear=function (){
    this.elements=new Array(this.capacity); 
};

/**
 * Returns true if this list contains the specified element.
 * param pvalue
 */
List.prototype.contains=function (pvalue){
    for(var i=0;i<this.size;i++){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return true; 
        } 
    } 
    return false;
};

/**
 * Returns the element at the specified position in this list.
 * param index
 */
List.prototype.get=function (index){
    return this.elements[index];
};

/**
 * Returns the index in this list of the first occurrence of the 
 * specified element, or -1 if this list does not contain this element.
 * param pvalue
 */
List.prototype.indexOf=function (pvalue){
    for(var i=0;i<this.size;i++){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return i; 
        } 
    } 
    return -1;
};

/**
 * Returns true if this list contains no elements.
 */
List.prototype.isEmpty=function (){
    return this.size==0;
};

/**
 * Returns an iterator over the elements in this list in proper sequence.
 */
List.prototype.iterator=function (){
    return new Iterator(this);
};

/**
 * Returns the index in this list of the last occurrence of the specified 
 * element, or -1 if this list does not contain this
 */
List.prototype.lastIndexOf=function (pvalue){
    for(var i=this.size-1;i>=0;i--){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return i; 
        } 
    } 
    return -1;
};

/**
 * Removes the element at the specified position in this list
 * param index
 */
List.prototype.removeIndexOf=function (index){
    if(index>-1&&index<this.size){
     var oldElems=this.elements;
     this.elements=new Array(this.capacity);
     this.size--;
     for(var i=0;i<this.size;i++){
         if(i<index){
             this.elements[i]=oldElems[i]; 
         }else{
             this.elements[i]=oldElems[i+1];
         } 
        
     }
    }
};

/**
 * Removes the first occurrence in this list of the specified element
 * param pvalue
 */
List.prototype.remove=function (pvalue){
    this.removeIndexOf(this.indexOf(pvalue));
};

/**
 * Replaces the element at the specified position in this list with the 
 * specified element
 * param index
 * param pvalue
 */
List.prototype.set=function (index,pvalue){
    this.elements[index]=pvalue;
};

/**
 * Returns a view of the portion of this list between the specified 
 * fromIndex, inclusive, and toIndex, exclusive.
 * param index1
 * param index2
 */
List.prototype.subList=function (index1,index2){
    var l=new List();
    for(var i=index1;i<index2;i++){
        l.add(this.elements[i]); 
    }
    return l;
};

/**
 * Appends all of the elements in the specified array to the end of 
 * this list
 * param arr
 */
List.prototype.addArray=function (arr){
    if(arr==undefined||arr.length==undefined){
        return; 
    } 
    for(var i=0;i<arr.length;i++){
        this.add(arr[i]); 
    }
};

/**
 * Appends all of the elements in the specified list to the end of 
 * this list
 * param list
 */
List.prototype.addList=function (list){
    if(list==undefined||list.size<=0){
        return; 
    }
    this.addArray(list.elements);
};

/**
 * Returns the number of elements in this list. 
 */
List.prototype.getSize=function (){
    return this.size;
};

/**
 * Returns an array containing all of the elements 
 * in this list in proper sequence. 
 */
List.prototype.toArray=function (){
    var arr=new Array(this.size);
    for(var i=0;i<this.size;i++){
        arr[i]=this.elements[i]; 
    } 
    return arr;
};

/**
 * Returns a string representation of this List object
 */
List.prototype.toString=function (){
    return this.toArray().toString(); 
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Properties class references to java.util.Properties of J2SE1.4 */
 
/**
 * constructor
 */
function Properties(){
	this.jsjava_class="jsjava.util.Properties";
    this.capacity=50;
    this.size=0;
    this.span=10;
    this.elements=new Array(this.capacity);
}

/**
 * Increases the capacity of and internally reorganizes this 
 * properties, in order to accommodate and access its entries 
 * more efficiently.
 */
Properties.prototype.recapacity=function(){
    if(this.capacity-this.size<10){
     this.capacity+=this.span;
     var oldElements=this.elements;
        this.elements=new Array(this.capacity); 
        for(var i=0;i<this.size;i++){
            this.elements[i]=oldElements[i]; 
        }
    }
};

/**
 * Removes all of the elements from this properties
 */
Properties.prototype.clear=function(){
    this.capacity=50;
    this.size=0;
    this.elements=new Array(this.capacity); 
};

/**
 * Replaces the element at the specified position in this properties with the 
 * specified element
 * param index
 * param pvalue
 */
Properties.prototype.set=function (pname,pvalue){
    this.recapacity();
    if(this.containsKey(pname)){
        for(var i=0;i<this.size;i++){
            var elem=this.elements[i];
            if(elem[0].equals(pname)){
                elem[1]=pvalue;
                return;
            } 
        } 
    }
    this.elements[this.size++]=[pname,pvalue];
   
};

/**
 * Associates the specified value with the specified key in this properties 
 * param pname
 * param pvalue 
 */
Properties.prototype.setProperty=function(pname,pvalue){
    if(typeof(pname)=="string"&&typeof(pvalue)=="string"){
        this.set(pname,pvalue);	
    }
};

/**
 * Returns the value to which this properties maps the specified key. 
 * param pname
 */
Properties.prototype.get=function (pname){
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        if(elem[0].equals(pname)){
            return elem[1]; 
        } 
    }
};

/**
 * Searches for the property with the specified key in this property list.
 */
Properties.prototype.getProperty=function (pname){
    var pvalue= this.get(pname);
    if(typeof(pvalue)=="string"){
    	return pvalue;
    }
    return null;
};

/**
 * Returns true if this properties contains a mapping for the specified key.
 * param pname
 */
Properties.prototype.containsKey=function(pname){
    if(this.get(pname)==undefined){
        return false; 
    }
    return true;
};

/**
 * Returns true if this properties maps one or more keys to the specified value.
 * param pname
 */
Properties.prototype.containsValue=function (pvalue){
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        if(elem[1].equals(pvalue)){
            return true;
        } 
    }
    return false;
};

/**
 * Returns a array view of the values contained in this properties.
 */
Properties.prototype.values=function (){
    var values=new Array(this.size);
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        values[i]=elem[1]; 
    } 
    return values;
};

/**
 * Returns a set view of the mappings contained in this properties.
 */
Properties.prototype.entrySet=function (){
    return this.elements; 
};

/**
 * Returns true if this properties contains no key-value mappings.
 */
Properties.prototype.isEmpty=function (){
    return this.size==0; 
};

/**
 * Returns an array of the keys in this properties.
 */
Properties.prototype.keys=function (){
    var keys=new Array(this.size);
    for(var i=0;i<this.size;i++){
        var elem=this.elements[i];
        keys[i]=elem[0]; 
    } 
    return keys;
};

/**
 * Returns the number of keys in this properties.
 */
Properties.prototype.getSize=function (){
    return this.size; 
};

/**
 * Removes the key (and its corresponding value) from this properties.
 * param key
 */
Properties.prototype.remove=function (key){
    if(this.containsKey(key)){
        var oldElems=this.elements;
        var oldSize=this.size;
        this.elements=new Array(this.capacity);
        this.size=0;
        for(var i=0;i<oldSize;i++){
            var oldElem=oldElems[i];
            if(!oldElem[0].equals(key)){
                this.put(oldElem[0],oldElem[1]); 
            } 
        } 
    }
};

/**
 * add a array to the properties
 * param arr
 */
Properties.prototype.addArray=function (arr){
    if(arr!=null&&arr.length>0){
        for(var i=0;i<arr.length;i++){
            this.put(arr[i][0],arr[i][1]); 
        } 
    } 
};

/**
 * add a hash to the properties
 * param hash
 */
Properties.prototype.addProperties=function (hash){
    if(hash!=null&&hash.size()>0){
        var keys=hash.keys();
        for(var i=0;i<keys.length;i++){
            this.put(keys[i],hash.get(keys[i])); 
        } 
    } 
};

/**
 * Returns a string representation of this Properties object
 */
Properties.prototype.toString=function (){
    return this.elements.toString(); 
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Set class references to java.util.Set of J2SE1.4 */
 
/**
 * constructor
 */
function Set(){
	this.jsjava_class="jsjava.util.Set";
    this.capacity=50;
    this.size=0;
    this.span=10;
    this.elements=new Array(this.capacity);
}

/**
 * Increases the capacity of and internally reorganizes this 
 * set, in order to accommodate and access its entries 
 * more efficiently.
 */
Set.prototype.recapacity=function (){
    if(this.capacity-this.size<10){
     this.capacity+=this.span;
     var oldElements=this.elements;
        this.elements=new Array(this.capacity); 
        for(var i=0;i<this.size;i++){
            this.elements[i]=oldElements[i]; 
        }
    }
};

/**
 * Adds the specified element to this set if it is not already present
 */
Set.prototype.add=function (pvalue){
    if(this.contains(pvalue)){
    	return;
    }
    this.recapacity();
    this.elements[this.size++]=pvalue;    
};

/**
 * Inserts the specified element at the specified position in this set
 * if it is not already present
 * param index
 * param pvalue
 */
Set.prototype.addIndexOf=function (index,pvalue){
    if(this.contains(pvalue)){
    	return;
    }
    this.recapacity();
    if(index>=this.size){
        this.elements[this.size]=pvalue;
        return; 
    }
    this.size++;      
    for(var i=this.size-1;i>index;i--){
     this.elements[i]=this.elements[i-1];
    } 
    this.elements[index]=pvalue;
};

/**
 * Removes all of the elements from this set.
 */
Set.prototype.clear=function (){
    this.elements=new Array(this.capacity); 
};

/**
 * Returns true if this set contains the specified element.
 * param pvalue
 */
Set.prototype.contains=function (pvalue){
    for(var i=0;i<this.size;i++){
     var elem=this.elements[i]
        if(elem.equals(pvalue)){
            return true; 
        } 
    } 
    return false;
};

/**
 * Returns the element at the specified position in this set.
 * param index
 */
Set.prototype.get=function (index){
    return this.elements[index];
};

/**
 * Returns the index in this set of the first occurrence of the 
 * specified element, or -1 if this list does not contain this element.
 * param pvalue
 */
Set.prototype.indexOf=function (pvalue){
    for(var i=0;i<this.size;i++){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return i; 
        } 
    } 
    return -1;
};

/**
 * Returns true if this set contains no elements.
 */
Set.prototype.isEmpty=function (){
    return this.size==0;
};

/**
 * Returns an iterator over the elements in this set in proper sequence.
 */
Set.prototype.iterator=function (){
    return new Iterator(this);
};

/**
 * Returns the index in this set of the last occurrence of the specified 
 * element, or -1 if this set does not contain this
 */
Set.prototype.lastIndexOf=function (pvalue){
    for(var i=this.size-1;i>=0;i--){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return i; 
        } 
    } 
    return -1;
};

/**
 * Removes the element at the specified position in this set
 * param index
 */
Set.prototype.removeIndexOf=function (index){
    if(index>-1&&index<this.size){
     var oldElems=this.elements;
     this.elements=new Array(this.capacity);
     this.size--;
     for(var i=0;i<this.size;i++){
         if(i<index){
             this.elements[i]=oldElems[i]; 
         }else{
             this.elements[i]=oldElems[i+1];
         } 
        
     }
    }
};

/**
 * Removes the first occurrence in this set of the specified element
 * param pvalue
 */
Set.prototype.remove=function (pvalue){
    this.removeIndexOf(this.indexOf(pvalue));
};

/**
 * Replaces the element at the specified position in this set with the 
 * specified element
 * param index
 * param pvalue
 *
Set.prototype.set=function (index,pvalue){
    if(this.contains(pvalue)){
    	return;
    }
    this.elements[index]=pvalue;
};

/**
 * Returns a view of the portion of this set between the specified 
 * fromIndex, inclusive, and toIndex, exclusive.
 * param index1
 * param index2
 */
Set.prototype.subSet=function (index1,index2){
    var l=new Set();
    for(var i=index1;i<index2;i++){
        l.add(this.elements[i]); 
    }
    return l;
};

/**
 * Appends all of the elements in the specified array to the end of 
 * this set
 * param arr
 */
Set.prototype.addArray=function (arr){
    if(arr==undefined||arr.length==undefined){
        return; 
    } 
    for(var i=0;i<arr.length;i++){
    	if(this.contains(arr[i])){
    	    continue;
        }
        this.add(arr[i]); 
    }
};

/**
 * Appends all of the elements in the specified set to the end of 
 * this set
 * param set
 */
Set.prototype.addSet=function (Set){
    if(Set==undefined||Set.size<=0){
        return; 
    }
    this.addArray(Set.elements);
};

/**
 * Returns the number of elements in this set. 
 */
Set.prototype.getSize=function (){
    return this.size;
};

/**
 * Returns an array containing all of the elements 
 * in this set in proper sequence. 
 */
Set.prototype.toArray=function (){
    var arr=new Array(this.size);
    for(var i=0;i<this.size;i++){
        arr[i]=this.elements[i]; 
    } 
    return arr;
};

/**
 * Returns a string representation of this Set object
 */
Set.prototype.toString=function (){
    return this.toArray().toString(); 
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The Stack class references to java.util.Stack of J2SE1.4 */
 
/**
 * constructor
 */
function Stack(){
	this.jsjava_class="jsjava.util.Stack";
	this.capacity=50;
    this.size=0;
    this.span=10;
    this.elements=new Array(this.capacity);
}
Stack.MESSAGE_NOTFOUND=-1;

/**
 * Increases the capacity of and internally reorganizes this 
 * stack, in order to accommodate and access its entries 
 * more efficiently.
 */
Stack.prototype.recapacity=function (){
    if(this.capacity-this.size<10){
     this.capacity+=this.span;
     var oldElements=this.elements;
        this.elements=new Array(this.capacity); 
        for(var i=0;i<this.size;i++){
            this.elements[i]=oldElements[i]; 
        }
    }
};

/**
 * Pushes an item onto the top of this stack.
 * param obj
 */
Stack.prototype.push=function(obj){
	this.recapacity();
	this.elements[this.size++]=obj;
};

/**
 * Removes the object at the top of this stack and returns that object 
 * as the value of this function.
 */
Stack.prototype.pop=function(){
    var oldElems=this.elements;
	this.elements=new Array(this.capacity);
	for(var i=0;i<this.size-1;i++){
	    this.elements[i]=oldElems[i];
	}
	this.size--;
	return oldElems[this.size];
};

/**
 * Looks at the object at the top of this stack without removing 
 * it from the stack
 */
Stack.prototype.peek=function(){
    return this.elements[this.size-1];
};

/**
 * Tests if this stack is empty.
 */
Stack.prototype.empty=function(){
	return this.size==0;
};

/**
 * Returns the 1-based position where an object is on this stack.
 */
Stack.prototype.search=function(obj){
	for(var i=0;i<this.size;i++){
	    if(this.elements[i].equals(obj)){
	        return i+1;
	    }
	}
	return Stack.MESSAGE_NOTFOUND;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The StringCharacterIterator class references to java.text.StringCharacterIterator of J2SE1.4 */
 
/**
 * constructor
 * param str
 */
function StringCharacterIterator(str){
	this.jsjava_class="jsjava.text.StringCharacterIterator";
    this.str=str;
    if(str==null){
        this.str="";	
    }
    this.list=new List();
    var length=str.length;
    for(var i=0;i<length;i++){
        this.list.add(str.charAt(i));	
    }
    this.nextIndex=0;
    this.prevIndex=this.list.getSize()-1;
    this.currentIndex=0;
}

/**
 * judge whether the iterator has more elements
 */
StringCharacterIterator.prototype.hasMore=function(){
    if(this.nextIndex==this.list.getSize()+1||this.prevIndex==-2){
    	return false;
    }
    return true;	
};

/**
 * return the current char
 */
StringCharacterIterator.prototype.current=function(){
    return this.list.get(this.currentIndex);
};

/**
 * return the first char
 */
StringCharacterIterator.prototype.first=function(){
    this.nextIndex=1;
    this.currentIndex=this.nextIndex-1;
    return this.list.get(0);	
};

/**
 * return the last char
 */
StringCharacterIterator.prototype.last=function(){
    this.prevIndex=this.list.getSize()-2;
    this.currentIndex=this.prevIndex+1;
    return this.list.get(this.list.getSize()-1);	
};

/**
 * return the next char
 */
StringCharacterIterator.prototype.next=function(){
    this.currentIndex=this.nextIndex;
    return this.list.get(this.nextIndex++);	
};

/**
 * return the previous char
 */
StringCharacterIterator.prototype.previous=function(){
    this.currentIndex=this.prevIndex;
    return this.list.get(this.prevIndex--);	
};

/**
 * return the begin index from where the iterator start
 */
StringCharacterIterator.prototype.getBeginIndex=function(){
    return 0;	
};

/**
 * return the end index where the iterator stop
 */
StringCharacterIterator.prototype.getEndIndex=function(){
    return this.list.getSize()-1;
};

/**
 * return the current index
 */
StringCharacterIterator.prototype.getIndex=function(){
    return this.currentIndex;
};

/**
 * set the current index
 * param index
 */
StringCharacterIterator.prototype.setIndex=function(index){
    this.currentIndex=index;
    this.nextIndex=index+1;
    this.prevIndex=index-1;	
};

/**
 * set the string
 * param text
 */
StringCharacterIterator.prototype.setText=function(text){
    this.str=text;
    if(text==null){
        this.str="";	
    }
    this.list=new List();
    var length=text.length;
    for(var i=0;i<length;i++){
        this.list.add(text.charAt(i));	
    }
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The StringTokenizer class references to java.util.StringTokenizer of J2SE1.4 */
 
/**
 * constructor
 * param str
 * param delim
 */
function StringTokenizer(str,delim){
	this.jsjava_class="jsjava.util.StringTokenizer";
    this.str=str;
    this.delim=delim;
    this.elements=str.split(delim);
    this.size=0;
    if(this.elements){
        this.size=this.elements.length;
    }
    this.nextIndex=0;
}

/**
 * Calculates the number of times that this tokenizer's nextToken 
 * method can be called before it generates an exception.
 */
StringTokenizer.prototype.countTokens=function(){
	return this.size;
};

/**
 * Returns the same value as the hasMoreTokens method.
 */
StringTokenizer.prototype.hasMoreElements=function(){
	return this.nextIndex<this.size;
};

/**
 * Tests if there are more tokens available from this tokenizer's string.
 */
StringTokenizer.prototype.hasMoreTokens=function(){
	return this.nextIndex<this.size;
};

/**
 * Returns the same value as the nextToken method, except that its declared 
 * return value is Object rather than String.
 */
StringTokenizer.prototype.nextElement=function(){
	return this.elements[this.nextIndex++];
	
};

/**
 * Returns the next token from this string tokenizer.
 */
StringTokenizer.prototype.nextToken=function(){
	return this.elements[this.nextIndex++];
};

/**
 * Returns the next token in this string tokenizer's string.
 */
StringTokenizer.prototype.nextToken=function(delim){
	return this.str.split(delim)[this.nextIndex];
};
