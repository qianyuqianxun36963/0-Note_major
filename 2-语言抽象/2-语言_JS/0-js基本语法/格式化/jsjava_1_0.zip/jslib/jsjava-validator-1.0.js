/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 */

/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function BooleanValidator(){
	this.jsjava_class="jsorg.eob.validator.BooleanValidator";
}

/**
 * Check whether the given value is boolean
 * param str - the given value
 */
BooleanValidator.validate=function(str){
	return Boolean.checkValid(str);
};

/**
 * Check whether the given value is boolean
 * param b - the given value
 */
BooleanValidator.validate2=function(b){
    if(b=="true"||b=="false"||b==true||b==false){
        return true;
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**
 * Constructor
 */
function ByteValidator(){
	this.jsjava_class="jsorg.eob.validator.ByteValidator";
}

ByteValidator.MIN=-Math.pow(2,7);
ByteValidator.MAX=Math.pow(2,7)-1;

/**
 * Check whether the given value is byte
 * param str - the given value
 */
ByteValidator.validate=function(str){
	return Byte.checkValid(str);
};

/**
 * Check whether the given value is boolean
 * param b - the given value
 */
ByteValidator.validate2=function(b){
	if(isNaN(b)){
		return false;
	}
	b=parseInt(b);
	if(b<=ByteValidator.MAX&&b>=ByteValidator.MIN){
        return true;
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function ChinaChineseValidator(){
	this.jsjava_class="jsorg.eob.validator.country.cn.ChinaChineseValidator";
}

/**
 * Check whether the given value is valid chinese string
 * param str - the given value
 */
ChinaChineseValidator.validate=function(str){
	var regx=/^[\u4e00-\u9fa5]+$/;
    return regx.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function ChinaIDCardValidator(){
	this.jsjava_class="jsorg.eob.validator.country.cn.ChinaIDCardValidator";
}

/**
 * Check whether the given value is valid ID card
 * param str - the given value
 */
ChinaIDCardValidator.validate=function(str){
	var regx=/^(\d{15}|\d{17}[\dx])$/;
    return regx.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function ChinaMobileValidator(){
	this.jsjava_class="jsorg.eob.validator.country.cn.ChinaMobileValidator";
}

/**
 * Check whether the given value is valid mobile number
 * param str - the given value
 */
ChinaMobileValidator.validate=function(str){
	var regx=/^13[0-9]\d{8}$/;	
    return regx.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */
function ChinaOicqValidator(){
	this.jsjava_class="jsorg.eob.validator.country.cn.ChinaOicqValidator";
}

/**
 * Check whether the given value is valid oicq number
 * param str - the given value
 */
ChinaOicqValidator.validate=function(str){
	var regx=/^[1-9][0-9]{4,}$/;
    return regx.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function ChinaPhoneValidator(){
	this.jsjava_class="jsorg.eob.validator.country.cn.ChinaPhoneValidator";
}

/**
 * Check whether the given value is valid phone number
 * param str - the given value
 */
ChinaPhoneValidator.validate=function(str){
	var regx=/^\d{3}-\d{8}|\d{4}-\d{7}$/;
    return regx.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function ChinaZipValidator(){
	this.jsjava_class="jsorg.eob.validator.country.cn.ChinaZipValidator";
}

/**
 * Check whether the given value is valid zip code
 * param str - the given value
 */
ChinaZipValidator.validate=function(str){
	var regx=/^\d{6}$/;
    return regx.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function DoubleValidator(){
	this.jsjava_class="jsorg.eob.validator.DoubleValidator";
}

DoubleValidator.POSITIVE_INFINITY=1.0/0.0;
DoubleValidator.NEGATIVE_INFINITY=-1.0/0.0;

/**
 * Check whether the given value is double
 * param str - the given value
 */
DoubleValidator.validate=function(str){
	return Double.checkValid(str);
};

/**
 * Check whether the given value is double
 * param d - the given value
 */
DoubleValidator.validate2=function(d){
	if(isNaN(d)){
		return false;
	}
	d=parseFloat(d);
	if(d<DoubleValidator.POSITIVE_INFINITY&&d>DoubleValidator.NEGATIVE_INFINITY){
        return true;
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function EmailValidator(){
	this.jsjava_class="jsorg.eob.validator.EmailValidator";
}

EmailValidator.defaultPattern=/^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;

/**
 * Check whether the given email is valid
 * param str - the given email
 * param pattern - the email pattern
 */
EmailValidator.validate=function(str,pattern){
	if(str==undefined||str==""){
	    return false;
	}
	if(pattern==undefined||pattern==""){
	    return EmailValidator.defaultPattern.test(str);
	}
	if(typeof(pattern)=="string"){
	    pattern=new RegExp(pattern);
	}
	return pattern.test(str);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function FloatValidator(){
	this.jsjava_class="jsorg.eob.validator.FloatValidator";
}

FloatValidator.POSITIVE_INFINITY=1.0/0.0;
FloatValidator.NEGATIVE_INFINITY=-1.0/0.0;

/**
 * Check whether the given value is float
 * param str - the given value
 */
FloatValidator.validate=function(str){
	return Float.checkValid(str);
};

/**
 * Check whether the given value is float
 * param f - the given value
 */
FloatValidator.validate2=function(f){
	if(isNaN(f)){
		return false;
	}
	f=parseFloat(f);
	if(f<FloatValidator.POSITIVE_INFINITY&&f>FloatValidator.NEGATIVE_INFINITY){
    	return true;
	}
	return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function IntegerValidator(){
	this.jsjava_class="jsorg.eob.validator.IntegerValidator";
}

IntegerValidator.MIN=-Math.pow(2,31);
IntegerValidator.MAX=Math.pow(2,31)-1;

/**
 * Check whether the given value is int
 * param str - the given value
 */
IntegerValidator.validate=function(str){
	return Integer.checkValid(str);
};

/**
 * Check whether the given value is int
 * param i - the given value
 */
IntegerValidator.validate2=function(i){
	if(isNaN(i)){
		return false;
	}
	if(typeof(i)=="number"){
		if(Math.floor(i)!=i){
			return false;
		}
	}else{
		if(i.indexOf(".")!=-1){
			return false;
		}
	}
	i=parseInt(i);
	if(i<=IntegerValidator.MAX&&i>=IntegerValidator.MIN){
    	return true;
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function IP4Validator(){
	this.jsjava_class="jsorg.eob.validator.IP4Validator";
}

/**
 * Check whether the given value is valid IP address
 * param str - the given value
 * param strict - boolean flag
 */
IP4Validator.validate=function(str,strict){
	if(strict != null  && strict == ""){
		if (str == "0.0.0.0")
			return false;
		else if (str == "255.255.255.255")
			return false;
	};
	theName = "IPaddress";
	var ipPattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
	var ipArray = str.match(ipPattern);
	if (ipArray == null){
		return false;
	}else {
		for (i = 1; i < 5; i++){
			thisSegment = parseInt(ipArray[i]);
			if (thisSegment > 255) {
				return false;
			}
			if (i == 1 && parseInt(ipArray[1]) == 0 ) {
				return false ;
			}
		}
	}
	return true; 

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**
 * Constructor
 */
function LongValidator(){
	this.jsjava_class="jsorg.eob.validator.LongValidator";
}

LongValidator.MIN=-Math.pow(2,63);
LongValidator.MAX=Math.pow(2,63)-1;

/**
 * Check whether the given value is long
 * param str - the given value
 */
LongValidator.validate=function(str){
	return Long.checkValid(str);
};

/**
 * Check whether the given value is long
 * param l - the given value
 */
LongValidator.validate2=function(l){
	if(isNaN(l)){
		return false;
	}
	if(typeof(l)=="number"){
		if(Math.floor(l)!=l){
			return false;
		}
	}else{
		if(l.indexOf(".")!=-1){
			return false;
		}
	}
	l=parseInt(l);
	if(l<=LongValidator.MAX&&l>=LongValidator.MIN){
    	return true;
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**
 * Constructor
 */
function NullValidator(){
	this.jsjava_class="jsorg.eob.validator.NullValidator";
}

/**
 * Check whether the given value is null or blank or undefined
 * param str - the given value
 */
NullValidator.validate=function(str){
	if(str==undefined||str==""){
	    return true;
	}
	return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */
function NumberScaleValidator(){
	this.jsjava_class="jsorg.eob.validator.NumberScaleValidator";
}

/**
 * validate whether a number n is between n1 and n2
 * param n
 * param n1
 * param n2
 */
NumberScaleValidator.validateBetween=function(n,n1,n2){
	if(isNaN(n)||isNaN(n1)||isNaN(n2)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
	n=parseInt(n);
	n1=parseInt(n1);
	n2=parseInt(n2);
	if(n>=n1&&n<=n2){
    	return true;
    }
    return false;
};

/**
 * validate whether a number is larger than n1
 * param n
 * param n1
 */
NumberScaleValidator.validateLargerThan=function(n,n1){
	if(isNaN(n)||isNaN(n1)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
	n=parseInt(n);
	n1=parseInt(n1);
	if(n>=n1){
    	return true;
    }
    return false;
};

/**
 * validate whether a number is less than n1
 * param n
 * param n1
 */
NumberScaleValidator.validateLessThan=function(n,n1){
	if(isNaN(n)||isNaN(n1)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
	n=parseInt(n);
	n1=parseInt(n1);
	if(n<=n1){
    	return true;
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function ShortValidator(){
	this.jsjava_class="jsorg.eob.validator.ShortValidator";
}

ShortValidator.MIN=-Math.pow(2,15);
ShortValidator.MAX=Math.pow(2,15)-1;

/**
 * Check whether the given value is short int
 * param str - the given value
 */
ShortValidator.validate=function(str){
	return Short.checkValid(str);
};

/**
 * Check whether the given value is short int
 * param s - the given value
 */
ShortValidator.validate2=function(s){
	if(isNaN(s)){
		return false;
	}
	if(typeof(s)=="number"){
		if(Math.floor(s)!=s){
			return false;
		}
	}else{
		if(s.indexOf(".")!=-1){
			return false;
		}
	}
	s=parseInt(s);
	if(s<=ShortValidator.MAX&&s>=ShortValidator.MIN){
    	return true;
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constructor
 */ 
function URLValidator(){
	this.jsjava_class="jsorg.eob.validator.URLValidator";
}

/**
 * Check whether the given value is valid url
 * param str - the given value
 */
URLValidator.validate=function(str){
	var regx=/^[a-zA-z]+:\/\/[^\s]*$/;
    return regx.test(str);
};
