/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 */

/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The ArithmeticException class references to java.lang.ArithmeticException of J2SE1.4 */

ArithmeticException.prototype=new Error();
ArithmeticException.prototype.constructor=ArithmeticException;

ArithmeticException.ERROR=0;

/**
 * constructor
 * param code - error code
 * param message - error message
 */
function ArithmeticException(code,message){
	this.jsjava_class="jsjava.lang.ArithmeticException";
	this.code=code;
    this.message=message;
    this.name="jsjava.lang.ArithmeticException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The ArrayUtils class references to org.apache.commons.lang.ArrayUtils */
 
function ArrayUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.ArrayUtils";
}

/**
 * Copies the given array and adds the given element at the end of the new array.
 * param arr
 * param value
 */
ArrayUtils.add=function(arr,value){
	var narr=new Array(arr.length+1);
	for(var i=0;i<arr.length;i++){
		narr[i]=arr[i];
	}
	narr[arr.length]=value;
	return narr;
};

/**
 * Inserts the specified element at the specified position in the array.
 * param arr
 * param index
 * param value
 */
ArrayUtils.addIndexOf=function(arr,index,value){
	if(index>arr.length||index<0){
	    return arr;
	}
	var narr=new Array(arr.length+1);
	for(var i=0;i<narr.length;i++){
	    if(i<index){
	    	narr[i]=arr[i];
	    }else if(i==index){
	    	narr[i]=value;
	    }else{
	    	narr[i]=arr[i-1];
	    }
	} 
	return narr;
};

/**
 * Adds all the elements of the given arrays into a new array.
 * param toArr
 * param fromArr
 */
ArrayUtils.addAll=function(toArr,fromArr){
	var toArrLength=toArr.length;
	var fromArrLength=fromArr.length;
	var narr=new Array(toArrLength+fromArrLength);
	var j=0;
	for(var i=0;i<narr.length;i++){
		if(j==toArrLength){
			j=0;
		}
		if(i<toArrLength){
		    narr[i]=toArr[j];		    
		}else{
			narr[i]=fromArr[j];
		}
		j++;
	}
	return narr;
};

/**
 * Clones an array returning a typecast result.
 * param arr
 */
ArrayUtils.clone=function(arr){
	var narr=new Array(arr.length);
	for(var i=0;i<arr.length;i++){
		narr[i]=arr[i];
	}
	return narr;
};

/**
 * Checks if the value is in the given array.
 * param arr
 * param value
 */
ArrayUtils.contains=function(arr,value){
	for(var i=0;i<arr.length;i++){
		if(arr[i]==value){
			return true;
		}
	}
	return false;
};

/**
 * Checks if the value is in the given array.This method need each object 
 * to initialize the eqeuals method.
 * param arr
 * param value
 */
ArrayUtils.containsEqual=function(arr,value){
	for(var i=0;i<arr.length;i++){
		if(arr[i].equals(value)){
			return true;
		}
	}
	return false;
};

/**
 * Returns the length of the specified array.
 * param arr
 */
ArrayUtils.getLength=function(arr){
	return arr.length;
};

/**
 * Finds the index of the given value in the array.
 * param arr
 * param value
 */
ArrayUtils.indexOf=function(arr,value){
	for(var i=0;i<arr.length;i++){
		if(arr[i]==value){
			return i;
		}
	}
	return -1;
};

/**
 * Checks if an array of primitive booleans is empty or undefined
 * param arr
 */
ArrayUtils.isEmpty=function(arr){
	if(arr==undefined||arr.length==0){
		return true;
	}
	return false;
};

/**
 * Compares two arrays, using equals().
 * param arr1
 * param arr2
 */
ArrayUtils.isEquals=function(arr1,arr2){
	var arr1Length=arr1.length;
	var arr2Length=arr2.length;
	if(arr1Length!=arr2Length){
		return false;
	}	
	for(var i=0;i<arr1Length;i++){
		if(arr1[i]!=arr2[i]){
			return false;
		}
	}
	return true;
};

/**
 * Checks whether two arrays are the same length.
 * param arr1
 * param arr2
 */
ArrayUtils.isSameLength=function(arr1,arr2){
	var arr1Length=arr1.length;
	var arr2Length=arr2.length;
	if(arr1Length!=arr2Length){
		return false;
	}	
	return true;
};

/**
 * Finds the last index of the given value within the array.
 * param arr
 * value
 */
ArrayUtils.lastIndexOf=function(arr,value){
	for(var i=arr.length-1;i>=0;i--){
		if(arr[i]==value){
			return i;
		}
	}
	return -1;
};

/**
 * Removes the element at the specified position from the specified array.
 * param arr
 * param index
 */
ArrayUtils.remove=function(arr,index){
	if(index>arr.length-1||index<0){
		return arr;
	}
	var narr=new Array(arr.length-1);
	for(var i=0;i<narr.length;i++){
		if(i<index){
			narr[i]=arr[i];
		}else{
			narr[i]=arr[i+1];
		}
	}
	return narr;
};

/** 
 * Removes the first occurrence of the specified element from the specified array.
 * param arr
 * param value
 */
ArrayUtils.removeElement=function(arr,value){
	var index=ArrayUtils.indexOf(arr,value);
	if(index==-1){
		return arr;
	}
	return ArrayUtils.remove(arr,index);
};

/**
 * Reverses the order of the given array.
 * param arr
 */
ArrayUtils.reverse=function(arr){
	return arr.reverse();
};

/**
 * Produces a new boolean array containing the elements between the start and end indices.
 * param arr
 * param startIndexInclusive
 * param endIndexExclusive
 */
ArrayUtils.subarray=function(arr,startIndexInclusive,endIndexExclusive){
	if(startIndexInclusive<=endIndexExclusive&&startIndexInclusive>=0&&endIndexExclusive<=arr.length){
		var narr=new Array(endIndexExclusive-startIndexInclusive);
		for(var i=startIndexInclusive;i<endIndexExclusive;i++){
			narr[i]=arr[i];
		}
		return narr;
	}
	return null;
};

/**
 * Outputs an array as a String, treating null as an empty array.
 * param arr
 */
ArrayUtils.toString=function(arr){
	return arr.toString();
};

/**
 * Outputs an array as a String handling nulls.
 * param arr
 * param defaultValue
 */
ArrayUtils.toStringIfNull=function(arr,defaultValue){
	var narr=ArrayUtils.clone(arr);
	for(var i=0;i<narr.length;i++){
		if(narr[i]==undefined||narr[i]==null){
			narr[i]=defaultValue;
		}
	}
	return narr.toString();

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
/**  The Boolean class references to java.lang.Boolean of J2SE1.4 */
 
/**
 * constructor
 * param value true or false
 */
function Boolean(value){
	this.jsjava_class="jsjava.lang.Boolean";
    this.value=value;
}
Boolean.TRUE=true;
Boolean.FALSE=false;

/**
 * check whether the input value is a boolean value
 * param b
 */
Boolean.checkValid=function(b){
    if(b=="true"||b=="false"||b==true||b==false){
        return true;
    }
    return false;
};

/**
 * Returns a Boolean with a value represented by the specified String.
 * param str
 */
Boolean.valueOf=function(str){
	if(Boolean.checkValid(str)){
		return new Boolean(true);
	}
	return new Boolean(false);
};

/**
 * compare whether this object value is equals to input Boolean object value
 * param b input Boolean object
 */
Boolean.prototype.compareTo=function(b){
    if(b==undefined){
        return -1; 
    }
    if(this.value==b.value){
        return 1; 
    }else{
        return -1;  
    }
};

/**
 * return a string description
 */
Boolean.prototype.toString=function(){
    return this.value; 
}

/**
 * return the object's boolean value
 */
Boolean.prototype.booleanValue=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Boolean.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Boolean"){
        return this.value==o.value; 
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The BooleanUtils class references to org.apache.commons.lang.BooleanUtils */
 
function BooleanUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.BooleanUtils";
}

/**
 * Is a Boolean value false
 * param value
 */
BooleanUtils.isFalse=function(value){
	var type=typeof(value);
	if(type=="boolean"){
		if(!value){
			return true;
		}
	}
	if(type=="string"){
	    if(value=="false"){
	    	return true;
	    }
	}
	if(type=="object"){
	    if(value.booleanValue()==false||value.booleanValue()=="false"){
	    	return true;
	    }
	}
	return false;
};

/**
 * Is a Boolean value true
 * param value
 */
BooleanUtils.isTrue=function(value){
	var type=typeof(value);
	if(type=="boolean"){
		if(value){
			return true;
		}
	}
	if(type=="string"){
	    if(value=="true"){
	    	return true;
	    }
	}
	if(type=="object"){
	    if(value.booleanValue()==true||value.booleanValue()=="true"){
	    	return true;
	    }
	}
	return false;
};

/**
 * Negates the specified boolean.
 * param value
 */
BooleanUtils.negate=function(value){
	var type=typeof(value);
	if(type=="boolean"){
		return !value;
	}
	if(type=="string"){
	    if(value=="true"){
	    	return "false";
	    }
	    if(value=="false"){
	    	return "true";
	    }
	}
	if(type=="object"){
		var ovalue=value.booleanValue();
	    if(ovalue=="true"){
	    	return new Boolean("false");
	    }
	    if(ovalue=="false"){
	    	return new Boolean("true");
	    }
	    if(ovalue==true){
	    	return new Boolean(false);
	    }
	    if(ovalue==false){
	    	return new Boolean(true);
	    }
	}
	return null;
};

/**
 * Converts a Boolean to a boolean
 * param value
 */
BooleanUtils.toBoolean=function(value){
	var type=typeof(value);
	if(type=="boolean"){
		return value;
	}
	if(type=="string"){
		if(value=="true"){
			return true;
		}else{
			return false;
		}
	}
	if(type=="object"){
		return value.booleanValue();
	}
	if(type=="number"){
		if(value==0){
			return false;
		}else{
			return true;
		}
	}
	return false;
};

/**
 * Converts a Boolean to a boolean handling null.
 * param value
 * param defaultValue
 */
BooleanUtils.toBooleanDefaultIfNull=function(value,defaultValue){
	if(value==null||value==undefined){
		return defaultValue;	
	}
	return BooleanUtils.toBoolean(value);
};

/**
 * Converts an object to a Boolean using the convention.
 * param value
 */
BooleanUtils.toBooleanObject=function(value){
	return new Boolean(BooleanUtils.toBoolean(value));
};

/**
 *  Converts a boolean to an int specifying the conversion values.
 * param value
 * param trueValue
 * param falseValue
 * param nullValue
 */
BooleanUtils.toInteger=function(value,trueValue,falseValue,nullValue){
	if(value==null||value==undefined){
		return nullValue;	
	}
	if(BooleanUtils.toBoolean(value)){
		return trueValue;
	}
	return falseValue;
};

/**
 * Converts a Boolean to an Integer specifying the conversion values.
 * param value
 * param trueValue
 * param falseValue
 * param nullValue
 */
BooleanUtils.toIntegerObject=function(value,trueValue,falseValue,nullValue){
	if(value==null||value==undefined){
		return nullValue;	
	}
	if(BooleanUtils.toBoolean(value)){
		return trueValue;
	}
	return falseValue;
};

/**
 * Converts a Boolean to a String returning one of the input Strings.
 * param value
 * param trueString
 * param falseString
 * param nullString
 */
BooleanUtils.toString=function(value,trueString,falseString,nullString){
	if(value==null||value==undefined){
		return nullString;	
	}
	if(BooleanUtils.toBoolean(value)){
		return trueString;
	}
	return falseString;
};

/**
 * Converts a boolean to a String returning 'on' or 'off'.
 * param value
 */
BooleanUtils.toStringOnOff=function(value){
	if(value==null||value==undefined){
		return "off";	
	}
	if(BooleanUtils.toBoolean(value)){
		return "on";
	}
	return "off";
};

/**
 * Converts a Boolean to a String returning 'on', 'off'
 * param value
 */
BooleanUtils.toStringTrueFalse=function(value){
	if(value==null||value==undefined){
		return "false";	
	}
	if(BooleanUtils.toBoolean(value)){
		return "true";
	}
	return "false";
};

/**
 * Converts a boolean to a String returning 'yes' or 'no'.
 * param value
 */
BooleanUtils.toStringYesNo=function(value){
	if(value==null||value==undefined){
		return "no";	
	}
	if(BooleanUtils.toBoolean(value)){
		return "yes";
	}
	return "no";
};

/**
 * Performs an xor on a set of booleans.
 * param arr
 */
BooleanUtils.xor=function(arr){
	var narr=new Array(arr.length);
	for(var i=0;i<arr.length;i++){
		narr[i]=BooleanUtils.toBoolean(arr[i]);
	}
	var xvalue=narr[0];
	for(var i=1;i<arr.length;i++){
		xvalue=xvalue^narr[i];
	}
	return BooleanUtils.toBoolean(xvalue);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Byte class references to java.lang.Byte of J2SE1.4 */
 
/**
 * constructor
 * param value 
 */
function Byte(value){
	this.jsjava_class="jsjava.lang.Byte";
    this.value=value;
}
Byte.MIN=-Math.pow(2,7);
Byte.MAX=Math.pow(2,7)-1;
Byte.MIN_VALUE=-Math.pow(2,7);
Byte.MAX_VALUE=Math.pow(2,7)-1;

/**
 * check whether the input value is a byte value
 * param b
 */
Byte.checkValid=function(b){
	if(isNaN(b)){
		return false;
	}
	b=parseInt(b);
    if(b<=Byte.MAX&&b>=Byte.MIN){
        return true;
    }
    return false;
};

/**
 * create a new Byte object with str
 * param str
 */
Byte.parseByte=function(str){
    if(isNaN(str)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	} 
    var b=parseInt(str);
    if(!Byte.checkValid(b)){
        return;
    }
    return b;
};

/**
 * compare whether this object value is equals to input Boolean object value
 * param b input Byte object
 */
Byte.prototype.compareTo=function(b){
    if(b==undefined){
        return -1; 
    }
    if(this.value>b.value){
        return 1; 
    }else if(this.value==b.value){
        return 0; 
    }else{
        return -1;  
    }
};

/**
 * return the object's byte value
 */
Byte.prototype.byteValue=function(){
    return this.value; 
};

/**
 * return a string description
 */
Byte.prototype.toString=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Byte.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Byte"){
        return this.value==o.value; 
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Character class references to java.lang.Character of J2SE1.4 */
 
/**
 * constructor
 * param value 
 */
function Character(value){
	this.jsjava_class="jsjava.lang.Character";
    if(value==undefined||value.length>1){
        return;
    }else{
        this.value=value;
    }
}

/**
 * check whether the input value is a char value
 * param c
 */
Character.checkValid=function(c){
    var type=typeof(c);
    if(type=="string"&&c.length==1){
    	return true;
    }
    return false;
};

/**
 * return the object's char value
 */
Character.prototype.charValue=function(){
    return this.value; 
};

/**
 * compare whether this object value is equals to input Character object value
 * param b input Character object
 */
Character.prototype.compareTo=function(c){
    if(b==undefined){
        return -1; 
    }
    if(this.value==b.value){
        return 1; 
    }else{
        return -1;  
    }
};

/**
 * return a string description
 */
Character.prototype.toString=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Character.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Character"){
        return this.value==o.value; 
    }
    return false;
};

/**
 * return the boolean value whether the input c is a digit
 * param c
 */
Character.isDigit=function(c){
    return !isNaN(c);
};

/**
 * change the c to lower case
 * param c
 */
Character.toLowerCase=function(c){
    if(Character.checkValid(c)){
        return c.toLowerCase();
    }

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The CharRange class references to org.apache.commons.lang.CharRange */
 
/**
 * Constructs a CharRange over a set of characters, optionally negating the range.
 * param start
 * param end
 * param negated
 */
function CharRange(start,end,negated){
	this.jsjava_class="jsorg.apache.commons.lang.CharRange";
	if(CharRange.checkValid(start)){
		this.start=start;
		this.end=end;
	}
	this.negated=false;//nothing to do in this version
}

/**
 * check whether the input value is a char value
 * param c
 */
CharRange.checkValid=function(c){
    var type=typeof(c);
    if(type=="string"&&c.length==1){
    	return true;
    }
    return false;
};

/**
 * Is the character specified contained in this range.
 * param ch
 */
CharRange.prototype.contains=function(ch){
	if(!CharRange.checkValid(ch)){
		return false;
	}
	if(ch>=this.start&&ch<=this.end){
		return true;
	}
	return false;
};

/**
 * Are all the characters of the passed in range contained in this range.
 * param range
 */
CharRange.prototype.containsRange=function(range){
	if(range.start>=this.start&&range.end<=this.end){
		return true;
	}
	return false;
};

/**
 * Gets the start character for this character range.
 */
CharRange.prototype.getStart=function(){
	return this.start;
};

/**
 * Gets the end character for this character range.
 */
CharRange.prototype.getEnd=function(){
	return this.end;
};

/**
 * Is this CharRange negated.
 */
CharRange.prototype.isNegated=function(){
	return this.negated;
};

/**
 * Gets a string representation of the character range.
 */
CharRange.prototype.toString=function(){
	return "["+this.start+","+this.end+"]";
};

/**
 * Compares two CharRange objects
 * param o
 */
CharRange.prototype.equals=function(o){
	if(o.start==this.start&&this.end==this.end){
		return true;
	}
	return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The CharSet class references to org.apache.commons.lang.CharSet */
 
function CharSet(str){
	this.jsjava_class="jsorg.apache.commons.lang.CharSet";
	if(str==undefined){
		str="";
	}
	this.str=str;
}

/**
 * check whether the input value is a char value
 * param c
 */
CharSet.checkValid=function(c){
    var type=typeof(c);
    if(type=="string"&&c.length==1){
    	return true;
    }
    return false;
};

/**
 * Does the CharSet contain the specified character ch.
 * param ch
 */
CharSet.prototype.contains=function(ch){
	if(!CharSet.checkValid(ch)){
		return false;
	}
	for(var i=0;i<this.str.length;i++){
		if(this.str.charAt(i)==ch){
			return true;
		}
	}
	return false;
};

/**
 * Get CharRange object from the CharSet
 */
CharSet.prototype.getCharRange=function(){
	var arr=new Array(this.str.length);
	for(var i=0;i<this.str.length;i++){
		arr[i]=this.str.charAt(i);
	}
	arr.sort();
	return new CharRange(arr[0],arr[arr.length-1],false);
};

/**
 * Gets a string representation of the set.
 */
CharSet.prototype.toString=function(){
	return this.str;
};

/**
 * Compares two CharSet objects
 */
CharSet.prototype.equals=function(o){
	if(o.str=this.str){
		return true;
	}
	return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The CharSetUtils class references to org.apache.commons.lang.CharSetUtils */
 
function CharSetUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.CharSetUtils";
}

/**
 * Takes an argument in set-syntax, returns the number of characters present in the specified string.
 * param str String to count characters in, may be null
 * param arr String set of characters to count, may be null
 */
CharSetUtils.count=function(str,set){
	if(str==null||str==""||set==null||set==""){
		return 0;
	}
	var count=0;
	for(var i=0;i<str.length;i++){
		if(set.indexOf(str.charAt(i))!=-1){
			count++;
		}
	}
	return count;
};

/**
 * Takes an argument in set-syntax, see evaluateSet, and deletes any of characters present 
 * in the specified string.
 * param str String to delete characters from, may be null
 * param set String set of characters to delete, may be null 
 */
CharSetUtils.remove=function(str,set){
	if(str==null){
		return null;
	}
	if(str==""){
		return "";
	}
	if(set==null||set==""){
		return str;
	}
	var nstr="";
	for(var i=0;i<str.length;i++){
		var ch=str.charAt(i);
		if(set.indexOf(ch)==-1){
			nstr+=ch;
		}
	}
	return nstr;
};

/**
 * Takes an argument in set-syntax, see evaluateSet, and keeps any of characters present in the specified string.
 * param str String to keep characters from, may be null
 * param set String set of characters to keep, may be null
 */
CharSetUtils.keep=function(str,set){
	if(str==null){
		return null;
	}
	if(str==""||set==null||set==""){
		return "";
	}
	var nstr="";
	for(var i=0;i<str.length;i++){
		var ch=str.charAt(i);
		if(set.indexOf(ch)!=-1){
			nstr+=ch;
		}
	}
	return nstr;
};

/**
 * Squeezes any repetitions of a character that is mentioned in the supplied set.
 * param str the string to squeeze, may be null
 * param set the character set to use for manipulation, may be null
 */
CharSetUtils.squeeze=function(str,set){
	if(str==null||str==""){
		return str;
	}
	if(set==null||set==""){
		return str;
	}
	for(var i=0;i<set.length;i++){
		var ch=set.charAt(i);
		str=str.replace(new RegExp(ch+"{2,}","g"),ch);
	}
	return str;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The CharUtils class references to org.apache.commons.lang.CharUtils */
 
function CharUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.CharUtils";
}

/**
 * check whether the input value is a char value
 * param c
 */
CharUtils.checkValid=function(c){
    var type=typeof(c);
    if(type=="string"&&c.length==1){
    	return true;
    }
    return false;
};

/**
 * Checks whether the character is ASCII 7 bit.
 * param ch
 */
CharUtils.isAscii=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch < 128;
};

/**
 * Checks whether the character is ASCII 7 bit alphabetic.
 * param ch
 */
CharUtils.isAsciiAlpha=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return (ch >= 'A'.charCodeAt(0) && ch <= 'Z'.charCodeAt(0)) || (ch >= 'a'.charCodeAt(0) && ch <= 'z'.charCodeAt(0));
};

/**
 * Checks whether the character is ASCII 7 bit alphabetic lower case.
 * param ch
 */
CharUtils.isAsciiAlphaLower=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch >= 'a'.charCodeAt(0) && ch <= 'z'.charCodeAt(0);
};

/**
 * Checks whether the character is ASCII 7 bit numeric.
 * param ch
 */
CharUtils.isAsciiAlphanumeric=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return (ch >= 'A'.charCodeAt(0) && ch <= 'Z'.charCodeAt(0)) || (ch >= 'a'.charCodeAt(0) && ch <= 'z'.charCodeAt(0)) || (ch >= '0'.charCodeAt(0) && ch <= '9'.charCodeAt(0));
};

/**
 * Checks whether the character is ASCII 7 bit alphabetic upper case.
 * param ch
 */
CharUtils.isAsciiAlphaUpper=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch >= 'A'.charCodeAt(0) && ch <= 'Z'.charCodeAt(0);
};

/**
 * Checks whether the character is ASCII 7 bit control.
 * param ch
 */
CharUtils.isAsciiControl=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch < 32 || ch == 127;
};

/**
 * Checks whether the character is ASCII 7 bit numeric.
 * param ch
 */
CharUtils.isAsciiNumeric=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch >= '0'.charCodeAt(0) && ch <= '9'.charCodeAt(0);
};

/**
 * Checks whether the character is ASCII 7 bit printable.
 * param ch
 */
CharUtils.isAsciiPrintable=function(ch){
	if(!CharUtils.checkValid(ch)){
		return false;
	}
	ch=ch.charCodeAt(0);
	return ch >= 32 && ch < 127;
};

/**
 * Converts the Character to a char handling null.
 * param chobj
 * param defaultValue
 */
CharUtils.toChar=function(chobj,defaultValue){
	if(chobj==null){
		return defaultValue;
	}
	if(typeof(chobj=="object")){
		return chobj.charValue();
	}
	return;
};

/**
 * Converts the character to the Integer it represents, throwing an exception if the character is not numeric.
 * param ch
 * param defaultValue
 */
CharUtils.toIntValue=function(ch,defaultValue){	
	if(defaultValue!=undefined){
		if(isNaN(defaultValue)){
			return;
		}
	}
	if(ch==null){
		return defaultValue;
	}
	if(isNaN(ch)){
		return;
	}
	if(CharUtils.checkValid(ch)){
		return parseInt(ch);
	}
};

/**
 * Converts the character to a Character.
 * param ch
 */
CharUtils.toCharacterObject=function(ch){
	return new Character(ch);
};

CharUtils.toString=function(ch){
	return ch;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The CloneNotSupportedException class references to java.lang.CloneNotSupportedException of J2SE1.4 */

CloneNotSupportedException.prototype=new Error();
CloneNotSupportedException.prototype.constructor=CloneNotSupportedException;

CloneNotSupportedException.ERROR=0;

/**
 * constructor
 * param code - error code
 * param message - error message
 */
function CloneNotSupportedException(code,message){
	this.jsjava_class="jsjava.lang.CloneNotSupportedException";
	this.code=code;
    this.message=message;
    this.name="jsjava.lang.CloneNotSupportedException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Double class references to java.lang.Double of J2SE1.4 */
 
/**
 * constructor
 * param value
 */
function Double(value){
	this.jsjava_class="jsjava.lang.Double";
    this.value=value;
}
Double.MIN=Math.pow(2,-1074);
Double.MAX=(2-Math.pow(2,-52))*Math.pow(2,1023);
Double.MIN_VALUE=Math.pow(2,-1074);
Double.MAX_VALUE=(2-Math.pow(2,-52))*Math.pow(2,1023);
Double.POSITIVE_INFINITY=1.0/0.0;
Double.NEGATIVE_INFINITY=-1.0/0.0;
Double.NaN=0.0/0.0;

/**
 * check whether the input value is a double value
 * param d
 */
Double.checkValid=function(d){
	if(isNaN(d)){
		return false;
	}
	d=parseFloat(d);
    if(d<Double.POSITIVE_INFINITY&&d>Double.NEGATIVE_INFINITY){
        return true;
    }
    return false;
};


/**
 * judge whether the given d is an infinite number
 * param d
 */
Double.isInfinite=function(d){
    return (d==Double.POSITIVE_INFINITY||d==Double.NEGATIVE_INFINITY);
};

/**
 * return the double value parsed from str
 * param str
 */
Double.parseDouble=function(str){
    if(isNaN(str)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
    return parseFloat(str);
};

/**
 * compare whether this object value is equals to input Double object value
 * param b input Double object
 */
Double.prototype.compareTo=function(b){
    if(b==undefined){
        return -1; 
    }
    if(this.value>b.value){
        return 1; 
    }else if(this.value==b.value){
        return 0; 
    }else{
        return -1;  
    }
};

/**
 * judge whether the current Double value is an infinite number
 * param d
 */
Double.prototype.isInfinite=function(){
    return (this.value==Double.POSITIVE_INFINITY||this.value==Double.NEGATIVE_INFINITY);
};

/**
 * return the object's double value
 */
Double.prototype.DoubleValue=function(){
    return this.value;
};

/**
 * return a string description
 */
Double.prototype.toString=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Double.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Double"){
        return this.value==o.value; 
    }
    return false;
};

/**
 * Returns true if the specified number is a Not-a-Number (NaN) value, false otherwise.
 * param v
 */
Double.isNaN=function(v) {
	return (v!= v);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Exception class references to java.lang.Exception of J2SE1.4 */

Exception.prototype=new Error();
Exception.prototype.constructor=Exception;

/**
 * constructor
 * param code - error code
 * param message - error message
 */
function Exception(code,message){
	this.jsjava_class="jsjava.lang.Exception";
	this.code=code;
    this.message=message;
    this.name="jsjava.lang.Exception";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Float class references to java.lang.Float of J2SE1.4 */
 
/**
 * constructor
 * param value
 */
function Float(value){
	this.jsjava_class="jsjava.lang.Float";
    this.value=value;
}
Float.MIN=Math.pow(2,-149);
Float.MAX=(2-Math.pow(2,-23))*Math.pow(2,127);
Float.MIN_VALUE=Math.pow(2,-149);
Float.MAX_VALUE=(2-Math.pow(2,-23))*Math.pow(2,127);
Float.POSITIVE_INFINITY=1.0/0.0;
Float.NEGATIVE_INFINITY=-1.0/0.0;

/**
 * check whether the input value is a float value
 * param f
 */
Float.checkValid=function(f){
	if(isNaN(f)){
		return false;
	}
	f=parseFloat(f);
    if(f<Float.POSITIVE_INFINITY&&f>Float.NEGATIVE_INFINITY){
    	return true;
	}
	return false;
};

/**
 * judge whether the given f is an infinite number
 * param f
 */
Float.isInfinite=function(f){
    return (f==Float.POSITIVE_INFINITY||f==Float.NEGATIVE_INFINITY);
};

/**
 * return the float value parsed from str
 * param str
 */
Float.parseFloat=function(str){
    if(isNaN(str)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
    return parseFloat(str);
};

/**
 * compare whether this object value is equals to input Float object value
 * param b input Float object
 */
Float.prototype.compareTo=function(b){
    if(b==undefined){
        return -1; 
    }
    if(this.value>b.value){
        return 1; 
    }else if(this.value==b.value){
        return 0; 
    }else{
        return -1;  
    }
};

/**
 * return the object's float value
 */
Float.prototype.floatValue=function(){
    return this.value;
};

/**
 * judge whether the current Float value is an infinite number
 */
Float.prototype.isInfinite=function(){
    return (this.value==Float.POSITIVE_INFINITY||this.value==Float.NEGATIVE_INFINITY);
};

/**
 * return a string description
 */
Float.prototype.toString=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Float.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Float"){
        return this.value==o.value; 
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The IllegalArgumentException class references to java.lang.IllegalArgumentException of J2SE1.4 */

IllegalArgumentException.prototype=new Error();
IllegalArgumentException.prototype.constructor=IllegalArgumentException;

IllegalArgumentException.ERROR=0;

/**
 * constructor
 * param code - error code
 * param message - error message
 */
function IllegalArgumentException(code,message){
	this.jsjava_class="jsjava.lang.IllegalArgumentException";
	this.code=code;
    this.message=message;
    this.name="jsjava.lang.IllegalArgumentException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Integer class references to java.lang.Integer of J2SE1.4 */
 
/**
 * constructor
 * param value
 */
function Integer(value){
	this.jsjava_class="jsjava.lang.Integer";
    this.value=value;
}
Integer.MIN=-Math.pow(2,31);
Integer.MAX=Math.pow(2,31)-1;
Integer.MIN_VALUE=-Math.pow(2,31);
Integer.MAX_VALUE=Math.pow(2,31)-1;

/**
 * check whether the input value is a int value
 * param d
 */
Integer.checkValid=function(i){
	if(isNaN(i)){
		return false;
	}
	i=parseInt(i);
    if(i<=Integer.MAX&&i>=Integer.MIN){
    	return true;
    }
    return false;
};

/**
 * return the int value parsed from str
 * param str
 */
Integer.parseInt=function(str){
    if(isNaN(str)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
    var i=parseInt(str);
    if(!Integer.checkValid(i)){
        return;
    }
    return i;
};

/**
 * compare whether this object value is equals to input Integer object value
 * param b input Integer object
 */
Integer.prototype.compareTo=function(b){
    if(b==undefined){
        return -1; 
    }
    if(this.value>b.value){
        return 1; 
    }else if(this.value==b.value){
        return 0; 
    }else{
        return -1;  
    }
};

/**
 * return the object's int value
 */
Integer.prototype.intValue=function(){
    return this.value; 
};

/**
 * return a string description
 */
Integer.prototype.toString=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Integer.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Integer"){
        return this.value==o.value; 
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The LocaleUtils class references to org.apache.commons.lang.LocaleUtils */
 
function LocaleUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.LocaleUtils";
}

/**
 * Obtains an unmodifiable list of installed locales.
 */
LocaleUtils.availableLocaleList=function(){
	var list=new List();
	list.addArray(Locale.getAvailableLocales());
	return list;
};

/**
 * Obtains an unmodifiable set of installed locales.
 */
LocaleUtils.availableLocaleSet=function(){
	var set=new Set();
	set.addArray(Locale.getAvailableLocales());
	return set;
};

/**
 * Obtains the list of countries supported for a given language.
 * param language
 */
LocaleUtils.countriesByLanguage=function(language){
	var larr=Locale.getAvailableLocales();
	var length=larr.length;
	var list=new List();
	for(var i=0;i<length;i++){
		var locale=larr[i];
		if(locale.getLanguage()==language){
			list.add(locale);
		}
	}
	return list;
};

/**
 * Checks if the locale specified is in the list of available locales.
 * param locale
 */
LocaleUtils.isAvailableLocale=function(locale){
	var larr=Locale.getAvailableLocales();
	var length=larr.length;
	for(var i=0;i<length;i++){
		var clocale=larr[i];
		if(clocale.equals(locale)){
			return true;
		}
	}
	return false;
};

/**
 * Obtains the list of languages supported for a given country.
 * param country
 */
LocaleUtils.languagesByCountry=function(country){
	var larr=Locale.getAvailableLocales();
	var length=larr.length;
	var list=new List();
	for(var i=0;i<length;i++){
		var locale=larr[i];
		if(locale.getCountry()==country){
			list.add(locale);
		}
	}
	return list;
};

/**
 * Converts a String to a Locale.
 * param str
 */
LocaleUtils.toLocale=function(str){
	var arr=str.split("_");
	var length=arr.length;
	var language="";
	var country="";
	var variant="";
	if(length>=1){
		language=arr[0];
	}
	if(length>=2){
		country=arr[1];
	}
	if(length>=3){
		variant=arr[2];
	}
	var locale=new Locale(language,country,variant);
	if(LocaleUtils.isAvailableLocale(locale)){
		return locale;
	}
	return null;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The Long class references to java.lang.Long of J2SE1.4 */
 
/**
 * constructor
 * param value
 */ 
function Long(value){
	this.jsjava_class="jsjava.lang.Long";
    this.value=value;
}
Long.MIN=-Math.pow(2,63);
Long.MAX=Math.pow(2,63)-1;
Long.MIN_VALUE=-Math.pow(2,63);
Long.MAX_VALUE=Math.pow(2,63)-1;

/**
 * check whether the input value is a long value
 * param l
 */
Long.checkValid=function(l){
	if(isNaN(l)){
		return false;
	}
	l=parseInt(l);
    if(l<=Long.MAX&&l>=Long.MIN){
    	return true;
    }
    return false;
};

/**
 * return the long value parsed from str
 * param str
 */
Long.parseLong=function(str){
    if(isNaN(str)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
    var l=parseInt(str);
    if(!Long.checkValid(l)){
        return;
    }
    return l;
};

/**
 * compare whether this object value is equals to input Long object value
 * param b input Long object
 */
Long.prototype.compareTo=function(b){
    if(b==undefined){
        return -1; 
    }
    if(this.value>b.value){
        return 1; 
    }else if(this.value==b.value){
        return 0; 
    }else{
        return -1;  
    }
};

/**
 * return the object's long value
 */
Long.prototype.longValue=function(){
    return this.value;
};

/**
 * return a string description
 */
Long.prototype.toString=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Long.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Long"){
        return this.value==o.value; 
    }
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function MultiDimensionArrayUtils(){
	this.jsjava_class="jsorg.eob.lang.MultiDimensionArrayUtils";	
}

/**
 * Create a two dimension array
 * param n - length of the first dimension
 * param m - length of the second dimension
 */
MultiDimensionArrayUtils.createTwoDimensionArray=function(n,m){
	if(n<0||m<0){
		throw new IllegalArgumentException(
	            IllegalArgumentException.ERROR,"n and m must be postive");
	}
	var arr=new Array(n);
	for(var i=0;i<n;i++){
		arr[i]=new Array(m);
	}
	return arr;
};

/**
 * Create a three dimension array
 * param n - length of the first dimension
 * param m - length of the second dimension
 * param k - length of the third dimension
 */
MultiDimensionArrayUtils.createThreeDimensionArray=function(n,m,k){
	if(n<0||m<0||k<0){
		throw new IllegalArgumentException(
	            IllegalArgumentException.ERROR,"n and m and k must be postive");
	}
	var arr=new Array(n);
	for(var i=0;i<n;i++){
		arr[i]=new Array(m);
		for(var j=0;j<m;j++){
			arr[i][j]=new Array(k);
		}
	}
	return arr;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The NumberFormatException class references to java.lang.NumberFormatException of J2SE1.4 */

NumberFormatException.prototype=new Error();
NumberFormatException.prototype.constructor=NumberFormatException;

NumberFormatException.NOT_NUMBER=1;

/**
 * constructor
 * param code - error code
 * param message - error message
 */
function NumberFormatException(code,message){
	this.jsjava_class="jsjava.lang.NumberFormatException";
	this.code=code;
    this.message=message;
    this.name="jsjava.lang.NumberFormatException";

}
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The RandomStringUtils class references to org.apache.commons.lang.RandomStringUtils */
 
function RandomStringUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.RandomStringUtils";
}

/**
 * Creates a random string whose length is the number of characters specified.
 * param count - the length of random string to create
 * param letters(boolean) - if true, generated string will include alphabetic characters
 * param numbers(boolean) - if true, generated string will include numeric characters 
 */
RandomStringUtils.random=function(count,letters,numbers){
	if(isNaN(count)){
		return;
	}
	if(count<0){
		return;
	}
	if(count==0){
		return "";
	}
	var minAlpha="a".charCodeAt(0);
	var maxAlpha="z".charCodeAt(0);
	var alphas=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"];
	var digits=["0","1","2","3","4","5","6","7","8","9"];
	if(!letters&&numbers){
		var str="";
		for(var i=0;i<count;i++){
			str+=digits[Math.floor(Math.random()*10)];
		}
		return str;
	}
	if(letters&&!numbers){
		var str="";
		for(var i=0;i<count;i++){
			str+=alphas[Math.floor(Math.random()*26)];
		}
		return str;
	}
	if(letters&&numbers||!letters&&!numbers){
		var str="";
		for(var i=0;i<count;i++){
			var r=Math.floor(Math.random()*2);
			if(r==0){
				str+=alphas[Math.floor(Math.random()*26)];
			}else if(r==1){
				str+=digits[Math.floor(Math.random()*10)];
			}
		}
		return str;
	}
	return "";
};

/**
 * Creates a random string whose length is the number of characters specified.
 * param count
 */
RandomStringUtils.randomAlphabetic=function(count){
	return RandomStringUtils.random(count,true,false);
};

/**
 * Creates a random string whose length is the number of characters specified.
 * param count
 */
RandomStringUtils.randomAlphanumeric=function(count){
	return RandomStringUtils.random(count,true,true);
};

/**
 * Creates a random string whose length is the number of characters specified.
 * param count
 */
RandomStringUtils.randomNumeric=function(count){
	return RandomStringUtils.random(count,false,true);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */


/**  The Short class references to java.lang.Short of J2SE1.4 */
 
/**
 * constructor
 * param value
 */
function Short(value){
	this.jsjava_class="jsjava.lang.Short";
    this.value=value;
}
Short.MIN=-Math.pow(2,15);
Short.MAX=Math.pow(2,15)-1;
Short.MIN_VALUE=-Math.pow(2,15);
Short.MAX_VALUE=Math.pow(2,15)-1;

/**
 * check whether the input value is a short value
 * param s
 */
Short.checkValid=function(s){
	if(isNaN(s)){
		return false;
	}
	s=parseInt(s);
    if(s<=Short.MAX&&s>=Short.MIN){
    	return true;
    }
    return false;
};

/**
 * return the short value parsed from str
 * param str
 */
Short.parseShort=function(str){
    if(isNaN(str)){
		throw new NumberFormatException(NumberFormatException.NOT_NUMBER,"Not a number Exception!");
	}
    var s=parseInt(str);
    if(!Short.checkValid(s)){
        return;
    }
    return s;
};

/**
 * compare whether this object value is equals to input Short object value
 * param b input Short object
 */
Short.prototype.compareTo=function(b){
    if(b==undefined){
        return -1; 
    }
    if(this.value>b.value){
        return 1; 
    }else if(this.value==b.value){
        return 0; 
    }else{
        return -1;  
    }
};

/**
 * return the object's short value
 */
Short.prototype.shortValue=function(){
    return this.value; 
};

/**
 * return a string description
 */
Short.prototype.toString=function(){
    return this.value; 
};

/**
 * compare whether this object is equal to input object o
 * param o
 */
Short.prototype.equals=function(o){
    if(o==undefined){
        return false; 
    }
    if(o.jsjava_class&&o.jsjava_class=="jsjava.lang.Short"){
        return this.value==o.value; 
    } 
    return false;

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The StopWatch class references to org.apache.commons.lang.StopWatch */
 
function StopWatch(){
	this.jsjava_class="jsorg.apache.commons.lang.StopWatch";
	this.startTime=0;
	this.endTime=0;
}

/**
 * Start the stopwatch.
 */
StopWatch.prototype.start=function(){
	this.startTime=new Date().getTime();
};

/**
 * Stop the stopwatch.
 */
StopWatch.prototype.stop=function(){
	this.endTime=new Date().getTime();
};

/**
 * Get the milliseconds on the stopwatch.
 */
StopWatch.prototype.getTime=function(){
	return this.endTime-this.startTime;
};

/**
 * Get the milliseconds on the stopwatch.
 */
StopWatch.prototype.getMilliSeconds=function(){
	return this.getTime();
};

/**
 * Get the seconds on the stopwatch.
 */
StopWatch.prototype.getSeconds=function(){
	return this.getTime()/1000;
};

/**
 * Get the minutes on the stopwatch.
 */
StopWatch.prototype.getMinutes=function(){
	return this.getTime()/(1000*60);
};

/**
 * Get the hours on the stopwatch.
 */
StopWatch.prototype.getHours=function(){
	return this.getTime()/(1000*3600);

};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The StringBuffer class references to java.lang.StringBuffer of J2SE1.4 */
 
/**
 * constructor
 * param str
 */
function StringBuffer(str){
	this.jsjava_class="jsjava.lang.StringBuffer";
	if(str==undefined||str==null){
		str="";
	}
    this.orig=str; 
    this.nStr=str;
}

/**
 * append a string after the current string
 * param pvalue
 */
StringBuffer.prototype.append=function (pvalue){
    this.nStr+=pvalue; 
};

/**
 * return the length of the current string
 */
StringBuffer.prototype.getLength=function (){
    return this.nStr.length; 
};

/**
 * return the char at specified index
 * param index
 */
StringBuffer.prototype.charAt=function (index){
    return this.nStr.charAt(index); 
};

/**
 * delete content from index1 to index2
 * param index1
 * param index2
 */
StringBuffer.prototype.deleteBetween=function (index1,index2){
    if(index1<index2){
     var str=this.nStr.substring(0,index1)+this.nStr.substring(index2);
     this.nStr=str;
    }else if(index1==index2){
     var str=this.nStr.substring(0,index1)+this.nStr.substring(index1+1);
     this.nStr=str;
    }
    
};

/**
 * return the current string
 */
StringBuffer.prototype.getValue=function (){
    return this.nStr; 
};

/**
 * return a string description
 */
StringBuffer.prototype.toString=function (){
    return this.nStr; 
};

/**
 * delete a char at specified index
 * param index
 */
StringBuffer.prototype.deleteCharAt=function (index){
    this.deleteBetween(index,index); 
};

/**
 * return the chars array from the current string
 */
StringBuffer.prototype.getChars=function (){
    var chars=new Array(this.getLength()); 
    for(var i=0;i<chars.length;i++){
        chars[i]=this.nStr.charAt(i); 
    }
   return chars;
};

/**
 * return the index of str in the current string
 * param str
 */
StringBuffer.prototype.indexOf=function (str){
    return this.nStr.indexOf(str); 
};

/**
 * insert a string in specified index
 * param index
 * param str
 */
StringBuffer.prototype.insert=function (index,str){
    var s= this.nStr.substring(0,index)+str+this.nStr.substring(index);
    this.nStr=s;
};

/**
 * return the last index of str in the current string
 * param str
 */
StringBuffer.prototype.lastIndexOf=function (str){
    return this.nStr.lastIndexOf(str); 
};

/**
 * return the substring from index
 * param index
 */
StringBuffer.prototype.substring=function (index){
    return this.nStr.substring(index); 
};

/**
 * return the substring from index1 to index2
 * param index1
 * param index2
 */
StringBuffer.prototype.substringBetween=function (index1,index2){
    return this.nStr.substring(index1,index2); 
};

/**
 * reverse the current string char sequence
 */
StringBuffer.prototype.reverse=function (){
    var str="";
    for(var i=this.getLength()-1;i>=0;i--){
        str+=this.charAt(i); 
    } 
    this.nStr=str;
};
/**
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
 /**  The StringUtils class references to org.apache.commons.lang.StringUtils */
 
function StringUtils(){
	this.jsjava_class="jsorg.apache.commons.lang.StringUtils";	
}

/**
 * Abbreviates a String using ellipses.
 * param str the String to check, may be null
 * param offset left edge of source String
 * param maxWidth maximum length of result String, must be at least 4
 */
StringUtils.abbreviate=function(str,offset,maxWidth){
	if (str == null) {
        return null;
    }
    if (maxWidth < 4) {
        maxWidth==4;
    }
    if (str.length <= maxWidth) {
        return str;
    }
    if (offset > str.length) {
        offset = str.length;
    }
    if ((str.length - offset) < (maxWidth - 3)) {
        offset = str.length - (maxWidth - 3);
    }
    if (offset <= 4) {
        return str.substring(0, maxWidth - 3) + "...";
    }
    if (maxWidth < 7) {
        maxWidth=7;
    }
    if ((offset + (maxWidth - 3)) < str.length) {
        return "..." + StringUtils.abbreviate(str.substring(offset),0, maxWidth - 3);
    }
    return "..." + str.substring(str.length - (maxWidth - 3));
};

/**
 * Capitalizes a String changing the first letter to title case.
 * param str
 */
StringUtils.capitalize=function(str){
	if(str==null||str==""){
		return str;
	}
	if(str.length==1){
		return str.toUpperCase();
	}
	var nstr=str.charAt(0).toUpperCase()+str.substring(1);
	return nstr;
};

/**
 * Checks if a String is empty ("") or null.
 * param str
 */
StringUtils.isEmpty=function(str){
	if(str==undefined||str==""||str==null){
		return true;
	}
	return false;
};

/**
 * Checks if a String is not empty ("") and not null.
 * param str
 */
StringUtils.isNotEmpty=function(str){
	return !StringUtils.isEmpty(str);
};

/**
 * Checks if a String is whitespace, empty ("") or null.
 * param str
 */
StringUtils.isBlank=function(str){
	if(str==undefined||str==""||str==null||/^\s*/.test(str)){
		return true;
	}
	return false;
};

/**
 * Checks if a String is not empty (""), not null and not whitespace only.
 * param str
 */
StringUtils.isNotBlank=function(str){
	return !StringUtils.isBlank(str);
};

/**
 * Checks if the String contains only unicode letters.
 * param str
 */
StringUtils.isAlpha=function(str){
	return /^[A-Za-z]+$/.test(str);
};

/**
 * Checks if the String contains only unicode letters or digits.
 * param str
 */
StringUtils.isAlphanumeric=function(str){
	return /^[A-Za-z0-9]+$/.test(str);
};

/**
 * Checks if the String contains only unicode letters, digits or space (' ').
 * param str
 */
StringUtils.isAlphanumericSpace=function(str){
	if(str==""){
		return true;
	}
	return /^[A-Za-z0-9\s]+$/.test(str);
};

/**
 * Checks if the String contains only unicode letters and space (' ').
 * param str
 */
StringUtils.isAlphaSpace=function(str){
	if(str==""){
		return true;
	}
	return /^[A-Za-z\s]+$/.test(str);
};

/**
 * Checks if the string contains only ASCII printable characters.
 * param str
 */
StringUtils.isAsciiPrintable=function(str){
	if (str == null) {
        return false;
    }
    var length = str.length();
    for (var i = 0; i < length; i++) {
        var ch=str.charAt(i);
        ch=ch.charCodeAt(0);
        if(ch < 32 && ch >= 127){
        	return false;
        }
    }
    return true;
};

/**
 * Checks if the String contains only unicode digits.
 * param str
 */
StringUtils.isNumeric=function(str){
	return /^[0-9]+$/.test(str);
};

/**
 * Checks if the String contains only unicode digits or space (' ').
 * param str
 */
StringUtils.isNumericSpace=function(str){
	return /^[0-9\s]+$/.test(str);
};

/**
 * Checks if the String contains only whitespace.
 * param str
 */
StringUtils.isWhitespace=function(str){
	return /^[\s]+$/.test(str);
};

/**
 * Joins the elements of the provided array into a single String containing the provided list of elements.
 * param arr
 * param separtor
 */
StringUtils.joinArray=function(arr,separator){
	if(StringUtils.isEmpty(separator)){
		return arr.join("");
	}
	return arr.join(separator);
};

/**
 * Joins the elements of the provided list into a single String containing the provided list of elements.
 * param list
 * param separator
 */
StringUtils.joinList=function(list,separator){
	if(!list||!list.jsjava_class||list.jsjava_class!="jsjava.util.List"){
		return null;
	}
	if(StringUtils.isEmpty(separator)){
		separator="";
	}
	var arr=list.toArray();
	return arr.join(separator);
};

/**
 * Joins the elements of the provided iterator into a single String containing the provided list of elements.
 * param iterator
 * param separator
 */
StringUtils.joinIterator=function(iterator,separator){
	if(!iterator||!iterator.jsjava_class||iterator.jsjava_class!="jsjava.util.Iterator"){
		return null;
	}
	if(StringUtils.isEmpty(separator)){
		separator="";
	}
	iterator.moveTo(0);
	var list=new List();
	while(iterator.hasNext()){
		list.add(iterator.next());
	}
	var arr=list.toArray();
	return arr.join(separator);
};

/**
 * Removes control characters (char <= 32) from both ends of this String, handling null by returning null.
 * param str
 */
StringUtils.trim=function(str){
	if(StringUtils.isEmpty(str)){
		return str;
	}
	return str.replace(/(^\s*)|(\s*$)/g, ""); 
};
