Here are some documentations about JsJava.
1)JsJava apidoc
2)JsJava user guide (author:zhangbo email:freeeob@gmail.com)