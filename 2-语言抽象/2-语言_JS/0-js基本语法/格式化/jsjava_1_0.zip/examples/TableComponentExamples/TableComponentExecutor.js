/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**  The TableComponentExecutor class not references to any class of J2SE1.4 
 *  This is a executor to deal with table application event,such as add a new
 *  item and so on
 */
 
/**
 * constructor
 */
function TableComponentExecutor(){
   	this.jsjava_class="jsorg.eob.component.table.TableComponentExecutor";
}
TableComponentExecutor.us_en_exceptions=["Please do edit operation after row selected","Only one item can be edited at one time","Please do config operation after row selected","Only one item can be configed at one time","Please do delete operation after row selected","Please do move operation after row selected","Command status error,scripts failed"];
TableComponentExecutor.zh_cn_exceptions=["\u8bf7\u9009\u62e9\u540e\u518d\u8fdb\u884c\u7f16\u8f91\uff01","\u53ea\u80fd\u9009\u53d6\u4e00\u9879\u8fdb\u884c\u7f16\u8f91\uff01","\u8bf7\u9009\u62e9\u540e\u518d\u8fdb\u884c\u914d\u7f6e\uff01","\u53ea\u80fd\u9009\u53d6\u4e00\u9879\u8fdb\u884c\u914d\u7f6e\uff01","\u8bf7\u9009\u62e9\u540e\u518d\u8fdb\u884c\u5220\u9664\uff01","\u8bf7\u9009\u62e9\u540e\u518d\u79fb\u52a8\uff01","\u547d\u4ee4\u72b6\u6001\u9519\u8bef\uff0c\u62d2\u7edd\u6267\u884c\u811a\u672c"];
TableComponentExecutor.language=navigator.userLanguage==undefined?navigator.language:navigator.userLanguage;

/**
 * format exception info to i18n info
 * param index the index of exception info returned
 */
TableComponentExecutor.formatExceptions=function(index){
   var lang=TableComponentExecutor.language.replace("-","_").toLowerCase();
   var langExceptions=eval("TableComponentExecutor."+lang+"_exceptions");
   return langExceptions[index];	
};

/**
 * set the executor current command such as create eidt delete and so on
 * param command
 */
TableComponentExecutor.prototype.setCommand=function(command){
   this.command=command;
};

/**
 * set the id of the table row which needs changing the color
 * param id
 */
TableComponentExecutor.prototype.setNeedChangeRowTableId=function(id){
   this.needChangeRowTableId=id;
};

/**
 * return the id of the table row which needs changing the color
 */
TableComponentExecutor.prototype.getNeedChangeRowTableId=function(){
   return this.needChangeRowTableId;
};

/**
 * return the executor current command
 */
TableComponentExecutor.prototype.getCommand=function(){
   return this.command;
};

/**
 * set the submission form if the executor needs execute a submit operation
 * param form the form name
 */
TableComponentExecutor.prototype.setForm=function(form){
   this.form=form;
};

/**
 * return the submission form name
 */
TableComponentExecutor.prototype.getForm=function(){
   return this.form;
};

/**
 * set checkbox name of the table rows
 * param checkbox
 */
TableComponentExecutor.prototype.setCheckbox=function(checkbox){
   this.checkbox=checkbox;
};

/**
 * return the checkbox name of the table rows
 */
TableComponentExecutor.prototype.getCheckbox=function(){
   return this.checkbox;
};

/**
 * set the name of the checkbox used to select all rows
 * param selectAllCheckbox
 */
TableComponentExecutor.prototype.setSelectAllCheckbox=function(selectAllCheckbox){
   this.selectAllCheckbox=selectAllCheckbox;
};

/**
 * return the name of the checkbox used to select all rows 
 */
TableComponentExecutor.prototype.getSelectAllCheckbox=function(){
   return this.selectAllCheckbox;
};

/**
 * set the name of sort collum
 * param sortName
 */
TableComponentExecutor.prototype.setSortName=function(sortName){
   this.sortName=sortName;
};

/**
 * return the name of sort collum
 */
TableComponentExecutor.prototype.getSortName=function(){
   return this.sortName;
};

/**
 * set the sort type
 * param sortType either ASC or DESC
 */
TableComponentExecutor.prototype.setSortType=function(sortType){
   this.sortType=sortType;
};

/**
 * return the sort type
 */
TableComponentExecutor.prototype.getSortType=function(){
   return this.sortType;
};

/**
 * set the name of input field used to record the sort name
 * param sortNameField
 */
TableComponentExecutor.prototype.setSortNameField=function(sortNameField){
   this.sortNameField=sortNameField;
};

/**
 * return the name of input field used to record the sort name
 */
TableComponentExecutor.prototype.getSortNameField=function(){
   return this.sortNameField;
};

/**
 * set the name of input field used to record the sort type
 * param sortTypeField
 */
TableComponentExecutor.prototype.setSortTypeField=function(sortTypeField){
   this.sortTypeField=sortTypeField;
};

/**
 * return the name of input field used to record the sort type
 */
TableComponentExecutor.prototype.getSortTypeField=function(){
   return this.sortTypeField;
};

/**
 * set the name of input field used to record the command
 * param commandField
 */
TableComponentExecutor.prototype.setCommandField=function(commandField){
   this.commandField=commandField;
};

/**
 * return the name of input field used to record the command
 */
TableComponentExecutor.prototype.getCommandField=function(){
   return this.commandField;
};

/**
 * set the window event source object
 * param eventSource
 */
TableComponentExecutor.prototype.setEventSource=function(eventSource){
   this.evnetSource=eventSource;	
};

/**
 * get the window event source object
 */
TableComponentExecutor.prototype.getEventSource=function(){
   return this.evnetSource;	
};

/**
 * set the action of the submission form
 * param formAction
 */
TableComponentExecutor.prototype.setFormAction=function(formAction){
   this.formAction=formAction;	
};

/**
 * return the action of the submission form
 */
TableComponentExecutor.prototype.getFormAction=function(){
   return this.formAction;	
};

/**
 * set the action target of the submission form
 * param formTarget
 */
TableComponentExecutor.prototype.setFormTarget=function(formTarget){
   this.formTarget = formTarget;
};

/**
 * return the action target of the submission form
 */
TableComponentExecutor.prototype.getFormTarget=function() {
   return this.formTarget;
};

/**
 * set the boolean value whether the form need submiting
 * param isSubmit
 */
TableComponentExecutor.prototype.setIsSubmit=function(isSubmit){
   this.isSubmit=isSubmit;
};

/**
 * return the boolean value whether the form need submitting
 */
TableComponentExecutor.prototype.getIsSubmit=function(){
   return this.isSubmit;
};

/**
 * set the command prefix
 * param commandPrefix such as the prefix do in doDelete 
 */
TableComponentExecutor.prototype.setCommandPrefix=function(commandPrefix){
   this.commandPrefix=commandPrefix;	
};

/**
 * return the command prefix
 */
TableComponentExecutor.prototype.getCommandPrefix=function(){
   return this.commandPrefix;
};

/**
 * set the boolean value whether the form may be submit directly
 * param directSubmit
 */
TableComponentExecutor.prototype.setDirectSubmit=function(directSubmit){
   this.directSubmit=directSubmit;	
};

/**
 * return the boolean value whether the form may be submit directly
 */
TableComponentExecutor.prototype.getDirectSubmit=function(){
   return this.directSubmit;	
};

/**
 * execute the command
 * param command 
 */
TableComponentExecutor.prototype.execute=function(command){

	var formName=this.getForm();
	var checkboxObj=this.getCheckbox();
	var selectAllCheckboxObj=this.getSelectAllCheckbox();
	var sortName=this.getSortName();
	var sortType=this.getSortType();
	var sortNameFieldName=this.getSortNameField();
	var sortTypeFieldName=this.getSortTypeField();
	var formObj=document.forms[formName];
	var isSubmit=this.getIsSubmit();
	var commandPrefix=this.getCommandPrefix();
	if(!this.getDirectSubmit()){
		if(command=="create"||command=="save"){
		    
		}else if(command=="edit" || command.indexOf('Radio') > -1){ 
		    if(!this.eidtEventTrigger(formObj,checkboxObj)){
		    	this.setIsSubmit(true);
			return false;
		    }	    
		}else if(command=="config"){ 
		    if(!this.configEventTrigger(formObj,checkboxObj)){
		    	this.setIsSubmit(true);
			return false;
		    }	    
		}else if(command=="delete"||command=="remove"){	
		    if(!this.deleteEventTrigger(formObj,checkboxObj)){
		    	this.setIsSubmit(true);
			return false;
		    } 
		}else if(command=="SelectAllCheckBox"){
		    if(!this.selectAllEventTrigger(formObj,checkboxObj,selectAllCheckboxObj)){
		    	this.setIsSubmit(true);
			return false;
		    }
		}else if(command=="sort"){
		    if(!this.sortEventTrigger(formObj,sortName,sortType,sortNameFieldName,sortTypeFieldName)){
		    	this.setIsSubmit(true);
			return false;
		    }
		}else if(command=="search"){
		    
		}else if(command=="restore"){
		    
		}else if(command=="move"){
		    if(!this.moveEventTrigger(formObj)){
		    	this.setIsSubmit(true);
			return false;
		    }
		}else if(command=="moveUp"){
		    if(!this.moveUpEventTrigger(formObj,checkboxObj)){
		    	this.setIsSubmit(true);
			return false;
		    }
		}else if(command=="moveDown"){

		    if(!this.moveDownEventTrigger(formObj,checkboxObj)){

		    	this.setIsSubmit(true);
			return false;
		    }
		}else if(command=="InitSequence"){
		
		}else if(command=="RowCheckStateChanged"){
		    if(!this.rowCheckStateChanged()){
		    	this.setIsSubmit(true);
			return false;
		    }	    
		}else{
		    ;
		}
	}
	if(command!=null&&commandPrefix!=null){
	    var c1=command.substring(0,1);
	    var c2=command.substring(1);
	    c1=c1.toUpperCase();
	    command=commandPrefix+c1+c2;
	}
	if(this.getCommandField()!=null||formObj.operation!=null){
	    formObj.operation.value=command;
	}	
	if(this.getFormAction()!=null){
	    formObj.action=this.getFormAction();	
	}
	if(this.getFormTarget()!=null){
		formObj.target=this.getFormTarget();
		this.formTarget=null;
	} else {
		formObj.target="_self";
	}
	if(this.getFormTarget()!=null){
		formObj.target=this.getFormTarget();
	}
	if(this.getIsSubmit()){
	    formObj.submit();
	}else{
	    return true;	    
	}	
    };

/**
 * execute when user triggers table row edit event
 * param formObj
 * param checkboxName
 */
TableComponentExecutor.prototype.eidtEventTrigger=function(formObj,checkboxName){
    
    var	checkboxObj=formObj.elements[checkboxName];
    if(!checkboxObj){
	return false;
    } 
    var	counter=0;
    if(!checkboxObj.length){
	if(checkboxObj.checked!=true){
	    alert(TableComponentExecutor.formatExceptions(0));
	    return false;
	}
    }else{ 
	for(var	i=0;i<checkboxObj.length;i++){
	    if(checkboxObj[i].checked){
		  counter++;
	    }
	}
	if(counter==0){
	    alert(TableComponentExecutor.formatExceptions(0));
	    return false;
	}  
	if(counter>1){
	    alert(TableComponentExecutor.formatExceptions(1));
	    return false;
	}
    }
    return true;
};

/**
 * execute when user triggers table row config event
 * param formObj
 * param checkboxName
 */
TableComponentExecutor.prototype.configEventTrigger=function(formObj,checkboxName){
    
    var	checkboxObj=formObj.elements[checkboxName];
    if(!checkboxObj){
	return false;
    } 
    var	counter=0;
    if(!checkboxObj.length){
	if(checkboxObj.checked!=true){
	    alert(TableComponentExecutor.formatExceptions(2));
	    return false;
	}
    }else{ 
	for(var	i=0;i<checkboxObj.length;i++){
	    if(checkboxObj[i].checked){
		  counter++;
	    }
	}
	if(counter==0){
	    alert(TableComponentExecutor.formatExceptions(2));
	    return false;
	}  
	if(counter>1){
	    alert(TableComponentExecutor.formatExceptions(3));
	    return false;
	}
    }
    return true;
};

/**
 * execute when user triggers table row delete event
 * param formObj
 * param checkboxName
 */
TableComponentExecutor.prototype.deleteEventTrigger=function(formObj,checkboxName){
    
    var	checkboxObj=formObj.elements[checkboxName];
    if(!checkboxObj){
	return false;
    } 
    var	counter=0;
    if(!checkboxObj.length){
	if(checkboxObj.checked!=true){
	    alert(TableComponentExecutor.formatExceptions(4));
	    return false;
	}
    }else{ 
	for(var	i=0;i<checkboxObj.length;i++){
	    if(checkboxObj[i].checked){
		  counter++;
	    }
	}
	if(counter==0){
	    alert(TableComponentExecutor.formatExceptions(4));
	    return false;
	}  
    }
    return true;
};

/**
 * execute when user triggers table select all event
 * param formObj
 * param checkboxName
 * param eventSourceName
 */
TableComponentExecutor.prototype.selectAllEventTrigger=function(formObj,checkboxName,eventSourceName){
    
    var	checkboxObj=formObj.elements[checkboxName];
    if(!checkboxObj){
	return false;
    } 
    var	eventSource=formObj.elements[eventSourceName];
    if(!eventSource){
	alert(TableComponentExecutor.formatExceptions(6));
	return false;
    } 
    if(!checkboxObj.length){
	if(eventSource.checked){
	    checkboxObj.checked=true;
	    checkboxObj.parentNode.parentNode.className='evenrow';
	}else{
	    checkboxObj.checked=false;
	    checkboxObj.parentNode.parentNode.className='';
	}
    }else{ 
	if(eventSource.checked){
	    for(var i=0;i<checkboxObj.length;i++){
		checkboxObj[i].checked=true;
		checkboxObj[i].parentNode.parentNode.className='evenrow';
	    }
	}else{
	    for(var i=0;i<checkboxObj.length;i++){
		checkboxObj[i].checked=false;
		checkboxObj[i].parentNode.parentNode.className='';
	    }
	}
    }  
    return false;
};

/**
 * execute when user triggers table sort
 * param formObj
 * param sortName
 * param sortType
 * param sortNameFieldName
 * param sortTypeFieldName
 */
TableComponentExecutor.prototype.sortEventTrigger=function(formObj,sortName,sortType,sortNameFieldName,sortTypeFieldName){    
    formObj.elements(sortNameFieldName).value=sortName;
    formObj.elements(sortTypeFieldName).value=sortType;
    return true;
};


/**
 * execute when user triggers table row move event
 * param formObj
 */
TableComponentExecutor.prototype.moveEventTrigger=function(formObj){    
    formObj.InitSequence.click();
    return false;
};

/**
 * execute when user triggers table row select state change event
 */
TableComponentExecutor.prototype.rowCheckStateChanged=function(){
    var eventSource=executor.getEventSource();	
    if(eventSource.checked){
	eventSource.checked=true;
	eventSource.parentNode.parentNode.className='evenrow';
    }else{
	eventSource.checked=false;
	eventSource.parentNode.parentNode.className='';
    }
};

/**
 * execute when user triggers table row move up event
 * param formObj
 * param checkboxName
 */
TableComponentExecutor.prototype.moveUpEventTrigger=function(formObj,checkboxName){
    var checkboxObj=formObj.elements[checkboxName];
    var length = checkboxObj.length;
    if(length>0)
    {
    	var isSelected=false;
	for(var i=0;i<length;++i)
	{
	   if (checkboxObj[i] && checkboxObj[i].checked)
	   {
	   	isSelected=true;
	        if(i>0&&!checkboxObj[(i-1)].checked)
	        {
	           var tableElement = document.getElementById(getNeedChangeRowTableId());
	            if(i>0){
	            	tableElement.moveRow(i+1,i);	            
	        	    checkboxObj[i-1].checked=true;
	        	}
	        }
	   }
	}
	if(!isSelected){
	   alert(TableComponentExecutor.formatExceptions(5));
	}
    }	
};

/**
 * execute when user triggers table row move down event
 * param formObj
 * param checkboxName
 */
TableComponentExecutor.prototype.moveDownEventTrigger=function(formObj,checkboxName){
    var checkboxObj=formObj.elements[checkboxName];
    var length = checkboxObj.length;
    if(length>0)
    {
    	var isSelected=false;
	for(var i=length;i>=0;--i)
	{
	   if (checkboxObj[i] && checkboxObj[i].checked)
	   {
	   	isSelected=true;
	        if((i+1)<length&&!checkboxObj[(i+1)].checked)
	        {
         
	            var tableElement = document.getElementById(getNeedChangeRowTableId());
	            tableElement.moveRow(i+1,i+2);	            
	            checkboxObj[i+1].checked=true;
	        }
	   }
	}
	if(!isSelected){
	   alert(TableComponentExecutor.formatExceptions(5));
	}
    }
    
};
