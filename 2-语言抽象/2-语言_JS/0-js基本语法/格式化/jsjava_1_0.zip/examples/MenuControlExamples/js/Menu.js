/*
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/*  The Menu class does not references to java.awt.Menu of J2SE1.4 */
 
/*
 * constructor
 * param id
 * param capacity the number of the menu being able to contain menutiems 
 */
function Menu(id,capacity){
      this.id=id;                        
      this.capacity=capacity;            
      this.children=new Array(capacity); 
      this.size=0;                       
      this.isLeaf=false;
      if(capacity==0)
      {
         this.isLeaf=true;
      }  
      this.parent=null;
      this._isURLForbid=false;
      this._isScriptForbid=false;
      this._isPassURLScriptArgsOnly=false;
   }
   
   /*
    * set menu title
    * param title
    */
   Menu.prototype.setTitle=function (title){
      this.title=title;
   };  
   
   /*
    * get menu title
    */
   Menu.prototype.getTitle=function(){
      return this.title;
   };  
   
   /*
    * add a menuitem
    * param childNode a menu object
    */
   Menu.prototype.addChild=function (childNode){
      this.children[this.size]=childNode;
      this.size=this.size+1;
      childNode.parent=this;
   };   
   
   /*
    * get all child menuitems
    */     
   Menu.prototype.getChildren=function (){
      var children=new Array(this.size);
      for(var i=0;i<children.length;i++)
      {
         children[i]=this.children[i];
      }
      return children;
   };    
   
   /*
    * get menu's parent menu
    */  
   Menu.prototype.getParent=function (){
      return this.parent;
   };   
   
   /*
    * set menu display icon
    * param icon a image url string
    */
   Menu.prototype.setIcon=function (icon){
      this.icon=icon;
   };    
   
   /*
    * return menu icon
    */
   Menu.prototype.getIcon=function (){
      return this.icon;
   };  
   
   /*
    * set menu default icon
    * param defaultIcon
    */            
   Menu.prototype.setDefaultIcon=function (defaultIcon){
      this.defaultIcon=defaultIcon;
   };
   
   /*
    * return menu default icon
    */
   Menu.prototype.getDefaultIcon=function (){
      return this.defaultIcon;
   };
   
   /*
    * set menu link
    * param url a url string 
    */
   Menu.prototype.setLink=function (url){
      this.url=url;
   };    
   
   /*
    * return menu link
    */  
   Menu.prototype.getLink=function (){
      return this.url;
   };      
   
   /*
    * set menu link target such as _blank _top and so on
    * param target
    */  
   Menu.prototype.setTarget=function (target){
      this.target=target;	
   };   
   
   /*
    * get menu link target
    */
   Menu.prototype.getTarget=function (){
      return this.target;	
   };    
   
   /*
    * set features of the window of the linked page such as menubar=no status=no and so on
    * param title
    */      
   Menu.prototype.setFeature=function (feature){
      this.feature=feature;	
   };
   
   /*
    * get features of the window of the linked page
    */
   Menu.prototype.getFeature=function (){
      return this.feature;	
   };
   
   /*
    * set menu script function name on clicking the menu
    * param scriptName javascript function name of the page
    */
   Menu.prototype.setScriptName=function (scriptName){
      this.scriptName=scriptName;	
   };  
   
   /*
    * get menu script function name
    */
   Menu.prototype.getScriptName=function (){
      return this.scriptName;	
   };  
   
   /*
    * set menu script function arguments
    * param scriptArgs 
    */
   Menu.prototype.setScriptArgs=function (scriptArgs){
      this.scriptArgs=scriptArgs;	
   };  
   
   /*
    * get menu script function arguments
    */
   Menu.prototype.getScriptArgs=function (){
      return this.scriptArgs;	
   };  	
   
   /*
    * set script function on mouse over the menu
    * param mouseover
    */
   Menu.prototype.setMouseover=function (mouseover){
      this.mouseover=mouseover;	
   };
   
   /*
    * get script function on mouse over the menu
    */
   Menu.prototype.getMouseover=function (){
      return this.mouseover;
   };	
   
   /*
    * set script function on mouse out of he menu
    * param mouseout
    */
   Menu.prototype.setMouseout=function (mouseout){
      this.mouseout=mouseout;	
   };
   
   /*
    * get script function on mouse out of the menu
    */
   Menu.prototype.getMouseout=function (){
      return this.mouseout;
   };
   
   /*
    * set menu background color
    * param background a color
    */
   Menu.prototype.setBackground=function (background){
      this.background=background;	
   };
   
   /*
    * get menu background color
    */
   Menu.prototype.getBackground=function (){
      return this.background;	
   };
   
   /*
    * set the boolean value whether rendering the menu display on mouse over the menu
    * param isRender a boolean value
    */
   Menu.prototype.setMouseRender=function (isRender){
      this.mouseRender=isRender;	
   };
   
   /*
    * get the boolean value whether rendering the menu display on mouse over the menu
    */
   Menu.prototype.isMouseRender=function(){
      return this.mouseRender;	
   };
   
   /*
    * return the display HTML content
    */
   Menu.prototype.getContent=function (){
   	var topNode=this.getTop();
        var content="<table width='100%' cellpadding='3' cellspacing='0' borderColor='#316AC5' class='WindowMenu' background='"+this.getBackground(this)+"'>";
    	for(var i=0;i<this.size;i++){
    	    var child=this.children[i];
    	    var linkUrl=child.getLink();
    	    var linkTarget=child.getTarget();
    	    var clickStr=child.getScriptName();
    	    var scriptArgs=child.getScriptArgs();
    	    if(clickStr==null||clickStr==""){
    	        clickStr=topNode.getScriptName();	
    	        scriptArgs=topNode.getScriptArgs();
    	    }
    	    var cursor="default";
    	    if(clickStr==null||clickStr==undefined){
    	    	clickStr="";
    	    }else{    	        
    	        if(topNode.isPassURLScriptArgsOnly()){
    	            clickStr+="(\""+linkUrl+"\","+"\""+linkTarget+"\")";	
    	        }else{
    	            clickStr+="("+scriptArgs+")";
    	        }
    	        cursor="hand";
    	    }
    	    var linkLeftStr="";
    	    var linkRightStr="";
    	    
    	    var isURLForbid=topNode.isURLForbid();
    	    if(linkUrl!=null&&linkUrl!=undefined&&!isURLForbid){
    	    	if(linkTarget==null||linkTarget==undefined){
    	    	    linkTarget="_self";	
    	    	}
    	    	var openStr="\""+linkUrl+"\",\""+linkTarget+"\","+"\"\"";
    	        linkLeftStr="<span style='text-decoration:none;cursor:hand' onclick='window.open("+openStr+")'>";
    	        linkRightStr="</span>";
    	    }
    	    var icon=child.getIcon();
    	    if(icon==null||icon==undefined){
    	        icon=topNode.getDefaultIcon();
    	    }
    	    content+="<tr>";
    	    content+="<td id='node_0_"+this.id+"' width='1'>";
    	    content+="<img id='node_0_1"+this.id+"' src='"+icon+"' nowrap/>";
    	    content+="</td>";
    	    content+="<td id='node_1_"+this.id+"' nowrap valign='middle' style='cursor:"+cursor+"' onclick='"+clickStr+"'";
    	    if(this.isMouseRender()){
    	    	content+=" onmouseover='parentElement.className=\"WindowMenuMouseOver\"' onmouseout='parentElement.className=\"WindowMenuMouseOut\"'";
    	    }
    	    content+=">";
    	    content+=linkLeftStr+child.getTitle()+linkRightStr;
    	    content+="</td>";
    	    content+="</tr>";
    	}    
    	content+="</table>";
    	return content;
   };
   
   /*
    * get menu's root menu
    */
   Menu.prototype.getTop=function (){
      var parentNode=this.getParent();
      if(parentNode==null||parentNode==undefined){
      	 return this;
      }
      return parentNode.getTop();
   };
   
   /*
    * forbid url link operation
    */
   Menu.prototype.forbidURL=function(){
       this._isURLForbid=true;	
   };
   
   /*
    * allow url link operation
    */
   Menu.prototype.enableURL=function(){
       this._isURLForbid=false;	
   };
   
   /*
    * return the boolean value whether forbidding url link operation
    */
   Menu.prototype.isURLForbid=function(){
       return this._isURLForbid;
   };
   
   /*
    * forbid script event operation
    */
   Menu.prototype.forbidScript=function(){
       this._isScriptForbid=true;	
   };
   
   /*
    * allow script event operation
    */
   Menu.prototype.enableScript=function(){
       this._isScriptForbid=false;	
   };
   
   /*
    * return the boolean value whether allowing script event operation
    */
   Menu.prototype.isScriptForbid=function(){
       return this._isScriptForbid;	
   };
   
   /*
    *  only allow pass url link and target args to the javascript function
    */
   Menu.prototype.passURLScriptArgsOnly=function(){
       this._isPassURLScriptArgsOnly=true;
   };
   
   /*
    * return the boolean value whether only allowing pass url link and target 
    * args to the javascript function
    */
   Menu.prototype.isPassURLScriptArgsOnly=function(){
       return this._isPassURLScriptArgsOnly;
   };
   
   /*
    *  init the menu capacity
    */
   Menu.prototype.init=function (capacity){
      this.capacity=capacity;
   };        
   