/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function AnimationFrameModel(){
	this.jsjava_class="jsorg.eob.animation.AnimationFrameModel";
	this.id=null;
    this.name=null;
    this.title=null;
    this.type=null;
};

/**
 * set frame model id
 * @param id
 */
AnimationFrameModel.prototype.setId=function(id){
    this.id=id;	
};

/**
 * return frame model id
 */
AnimationFrameModel.prototype.getId=function(){
    return this.id;	
};

/**
 * set frame model name
 * @param id
 */
AnimationFrameModel.prototype.setName=function(name){
    this.name=name;	
};

/**
 * return frame model name
 */
AnimationFrameModel.prototype.getName=function(){
    return this.name;	
};

/**
 * set frame model title
 * @param title
 */
AnimationFrameModel.prototype.setTitle=function(title){
    this.title=title;	
};

/**
 * set frame model title
 */
AnimationFrameModel.prototype.getTitle=function(){
    return this.title;	
};

/**
 * set frame model type
 * @param type
 */
AnimationFrameModel.prototype.setType=function(type){
    this.type=type;	
};

/**
 * set frame model type
 */
AnimationFrameModel.prototype.getType=function(){
    return this.type;	
};