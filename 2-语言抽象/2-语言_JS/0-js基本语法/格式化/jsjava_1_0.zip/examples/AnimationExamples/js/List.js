/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

 /**  The List class references to java.util.List of J2SE1.4 */
 
/**
 * constructor
 */
function List(){
	this.jsjava_class="jsjava.util.List";
    this.capacity=50;
    this.size=0;
    this.span=10;
    this.elements=new Array(this.capacity);
}

/**
 * Increases the capacity of and internally reorganizes this 
 * list, in order to accommodate and access its entries 
 * more efficiently.
 */
List.prototype.recapacity=function (){
    if(this.capacity-this.size<10){
     this.capacity+=this.span;
     var oldElements=this.elements;
        this.elements=new Array(this.capacity); 
        for(var i=0;i<this.size;i++){
            this.elements[i]=oldElements[i]; 
        }
    }
};

/**
 * Appends the specified element to the end of this list
 * param pvalue
 */
List.prototype.add=function (pvalue){
    this.recapacity();
    this.elements[this.size++]=pvalue; 
};

/**
 * Inserts the specified element at the specified position in this list
 * param index
 * param pvalue
 */
List.prototype.addIndexOf=function (index,pvalue){
    this.recapacity();
    if(index>=this.size){
        this.elements[this.size]=pvalue;
        return; 
    }
    this.size++;      
    for(var i=this.size-1;i>index;i--){
     this.elements[i]=this.elements[i-1];
    } 
    this.elements[index]=pvalue;
};

/**
 * Removes all of the elements from this list
 */
List.prototype.clear=function (){
    this.elements=new Array(this.capacity); 
};

/**
 * Returns true if this list contains the specified element.
 * param pvalue
 */
List.prototype.contains=function (pvalue){
    for(var i=0;i<this.size;i++){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return true; 
        } 
    } 
    return false;
};

/**
 * Returns the element at the specified position in this list.
 * param index
 */
List.prototype.get=function (index){
    return this.elements[index];
};

/**
 * Returns the index in this list of the first occurrence of the 
 * specified element, or -1 if this list does not contain this element.
 * param pvalue
 */
List.prototype.indexOf=function (pvalue){
    for(var i=0;i<this.size;i++){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return i; 
        } 
    } 
    return -1;
};

/**
 * Returns true if this list contains no elements.
 */
List.prototype.isEmpty=function (){
    return this.size==0;
};

/**
 * Returns an iterator over the elements in this list in proper sequence.
 */
List.prototype.iterator=function (){
    return new Iterator(this);
};

/**
 * Returns the index in this list of the last occurrence of the specified 
 * element, or -1 if this list does not contain this
 */
List.prototype.lastIndexOf=function (pvalue){
    for(var i=this.size-1;i>=0;i--){
     var elem=this.elements[i];
        if(elem.equals(pvalue)){
            return i; 
        } 
    } 
    return -1;
};

/**
 * Removes the element at the specified position in this list
 * param index
 */
List.prototype.removeIndexOf=function (index){
    if(index>-1&&index<this.size){
     var oldElems=this.elements;
     this.elements=new Array(this.capacity);
     this.size--;
     for(var i=0;i<this.size;i++){
         if(i<index){
             this.elements[i]=oldElems[i]; 
         }else{
             this.elements[i]=oldElems[i+1];
         } 
        
     }
    }
};

/**
 * Removes the first occurrence in this list of the specified element
 * param pvalue
 */
List.prototype.remove=function (pvalue){
    this.removeIndexOf(this.indexOf(pvalue));
};

/**
 * Replaces the element at the specified position in this list with the 
 * specified element
 * param index
 * param pvalue
 */
List.prototype.set=function (index,pvalue){
    this.elements[index]=pvalue;
};

/**
 * Returns a view of the portion of this list between the specified 
 * fromIndex, inclusive, and toIndex, exclusive.
 * param index1
 * param index2
 */
List.prototype.subList=function (index1,index2){
    var l=new List();
    for(var i=index1;i<index2;i++){
        l.add(this.elements[i]); 
    }
    return l;
};

/**
 * Appends all of the elements in the specified array to the end of 
 * this list
 * param arr
 */
List.prototype.addArray=function (arr){
    if(arr==undefined||arr.length==undefined){
        return; 
    } 
    for(var i=0;i<arr.length;i++){
        this.add(arr[i]); 
    }
};

/**
 * Appends all of the elements in the specified list to the end of 
 * this list
 * param list
 */
List.prototype.addList=function (list){
    if(list==undefined||list.size<=0){
        return; 
    }
    this.addArray(list.elements);
};

/**
 * Returns the number of elements in this list. 
 */
List.prototype.getSize=function (){
    return this.size;
};

/**
 * Returns an array containing all of the elements 
 * in this list in proper sequence. 
 */
List.prototype.toArray=function (){
    var arr=new Array(this.size);
    for(var i=0;i<this.size;i++){
        arr[i]=this.elements[i]; 
    } 
    return arr;
};

/**
 * Returns a string representation of this List object
 */
List.prototype.toString=function (){
    return this.toArray().toString(); 
};
