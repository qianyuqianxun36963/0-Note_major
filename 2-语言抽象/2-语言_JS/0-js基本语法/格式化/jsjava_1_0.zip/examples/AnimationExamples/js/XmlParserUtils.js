/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/**
 * Constrcutor
 */ 
function XmlParserUtils(){
	this.jsjava_class="jsorg.eob.xml.XmlParserUtils";
}

/**
 * Get xml parser object of IE
 */
XmlParserUtils.toIEXmlParser=function(){
	return new ActiveXObject("Microsoft.XMLDOM");
};

/**
 * Get xml parser object of Mozilla
 */
XmlParserUtils.toMozillaXmlParser=function(){
	return new DOMParser();
};

/**
 * Get xml document object object of Mozilla
 */
XmlParserUtils.toMozillaXmlDocument=function(){
	return document.implementation.createDocument("","",null);
};

/**
 * Get xml parser object
 */
XmlParserUtils.toXmlParser=function(){
	if (window.ActiveXObject){
		return new ActiveXObject("Microsoft.XMLDOM");
	}else if (document.implementation &&document.implementation.createDocument){
		return document.implementation.createDocument("","",null);
	}else{
		return;
	}
};