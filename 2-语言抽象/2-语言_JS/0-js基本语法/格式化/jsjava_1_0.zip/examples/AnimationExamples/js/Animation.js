/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function Animation(){
	this.jsjava_class="jsorg.eob.animation.Animation";
	this.scenes=new List();
};

/**
 * add scene to animation
 * @param scene
 */
Animation.prototype.addScene=function(scene){
    this.scenes.add(scene);
};

/**
 * return animation scenes
 */
Animation.prototype.getScenes=function(){
    return this.scenes.toArray();
};

/**
 * return the indexed scene
 * @param index
 */
Animation.prototype.getScene=function(index){
    return this.scenes.get(index);
};

/**
 * return the max number of scene
 */
Animation.prototype.getMaxSceneNumber=function(){
    return this.scenes.toArray().length;
};

/**
 * clone a new animation object
 */
Animation.prototype.clone=function(){
	var animation=new Animation();
	animation.scenes=this.scenes;
	return animation;
};