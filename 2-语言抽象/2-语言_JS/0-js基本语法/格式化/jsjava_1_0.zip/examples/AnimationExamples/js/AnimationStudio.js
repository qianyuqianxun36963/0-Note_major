/**
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */
 
function AnimationStudio(){
	this.jsjava_class="jsorg.eob.animation.AnimationStudio";
	this.animation=null;
	this.timer=null;
	this.sceneNumber=0;
	this.maxSceneNumber=0;
	this.instanceName=null;
};

/**
 * set the instance of current processing animation studio object
 * @param instanceName
 */
AnimationStudio.prototype.setInstanceName=function(instanceName){
    this.instanceName=instanceName;
};

/**
 * load animation into studio from xml string
 * @param aXml
 */
AnimationStudio.prototype.loadFromXml=function(aXml){
	var parser=new XmlBrowserParser();
	parser.loadXml(aXml);
	var xmldom=parser.toDocument();
    var rootElem=xmldom.documentElement;
    var sceneElems=rootElem.getElementsByTagName("graph-scene");
    var scenesSize=sceneElems.length;
    this.maxSceneNumber=scenesSize;
    var animation=new Animation();
    for(var i=0;i<scenesSize;i++){
        var sceneElem=sceneElems[i];
        var scene=new AnimationScene();
        var sceneSequenceElem=sceneElem.getElementsByTagName("graph-scene-sequence")[0];
        var sceneSequence=sceneSequenceElem.firstChild.nodeValue;
        scene.setSequence(sceneSequence);
        var frameElems=sceneElem.getElementsByTagName("graph-frame");
        var framesSize=frameElems.length;
        for(var j=0;j<framesSize;j++){
            var frameElem=frameElems[j];
            var frame=new AnimationFrame();
            var statusElem=frameElem.getElementsByTagName("graph-frame-status")[0];
            var status=statusElem.firstChild.nodeValue;
            frame.setStatus(status);
            var model=new AnimationFrameModel();
            var modelElem=frameElem.getElementsByTagName("graph-object")[0];
            var typeElem=modelElem.getElementsByTagName("graph-type")[0];
            var type=typeElem.firstChild.nodeValue;
            var metaElem=modelElem.getElementsByTagName("graph-meta-info")[0];
            var id=metaElem.getElementsByTagName("graph-object-id")[0].firstChild.nodeValue;
            var name=metaElem.getElementsByTagName("graph-object-name")[0].firstChild.nodeValue;
            var title=metaElem.getElementsByTagName("graph-object-label")[0].firstChild.nodeValue;
            model.setId(id);
            model.setName(name);
            model.setTitle(title);
            model.setType(type);
            frame.setModel(model);
            scene.addFrame(frame);
        }
        animation.addScene(scene);
    }
    this.animation=animation;
};

/**
 * load animation into studio from animation object
 * @param animation
 */
AnimationStudio.prototype.load=function(animation){
	this.animation=animation;
};

/**
 * set the interval between the frames
 * @param interval
 */
AnimationStudio.prototype.setInterval=function(interval){
	this.interval=interval;
};

/**
 * return the interval between the frames
 */
AnimationStudio.prototype.getInterval=function(){
	return this.interval;
};

/**
 * set the user-defined function for animation
 * @param action
 */
AnimationStudio.prototype.setAction=function(action){
	this.action=action;
};

/**
 * return the user-defined function for animation
 */
AnimationStudio.prototype.getAction=function(){
	return this.action;
};

/**
 * set the user-defined start function for animation
 * @param action
 */
AnimationStudio.prototype.setStartAction=function(action){
	this.startAction=action;
};

/**
 * return the user-defined start function for animation
 */
AnimationStudio.prototype.getStartAction=function(){
	return this.startAction;
};

/**
 * set the user-defined render function for animation
 * @param render
 */
AnimationStudio.prototype.setRender=function(render){
	this.render=render;
};

/**
 * return the user-defined render function for animation
 */
AnimationStudio.prototype.getRender=function(){
	return this.render;
};

/**
 * set the user-defined end function for animation
 * @param action
 */
AnimationStudio.prototype.setEndAction=function(action){
	this.endAction=action;
};

/**
 * return the user-defined end function for animation
 */
AnimationStudio.prototype.getEndAction=function(){
	return this.endAction;
};

/**
 * start to play animation
 */
AnimationStudio.prototype.play=function(){
	var action=this.getAction();
	var startAction=this.getStartAction();
	if(typeof(startAction)=="function"){
		startAction();
	}else{
		eval("window."+startAction+"()");
	}
	if(action){
		if(typeof(action)=="function"){
	    	this.timer=setInterval(action(),this.getInterval());  
	    }else{
	    	this.timer=setInterval(action+"()",this.getInterval()); 
	    }
	}else{
	    this.timer=setInterval("jsjava_play_animation('"+this.instanceName+"')",this.getInterval()); 
	}
};

/**
 * suspend to play animation
 */
AnimationStudio.prototype.suspend=function(){
	clearInterval(this.timer);
};

/**
 * restore to play animation
 */
AnimationStudio.prototype.restore=function(){
	this.play();
};

/**
 * stop to play animation
 */
AnimationStudio.prototype.stop=function(){	
	var endAction=studio.getEndAction();
    if(endAction){
    	if(typeof(endAction)=="function"){
    		endAction();
    	}else{
    		eval("window."+endAction+"()");
    	}
    }
    if(this.timer&&this.timer!=null){
    	clearInterval(this.timer);
    }
    this.sceneNumber=0;
};

/**
 * the execution action if no user-defined action
 */
function jsjava_play_animation(studioInstanceName){
    var studio=eval("window."+studioInstanceName);
    studio.sceneNumber++;
	if(studio.sceneNumber>=studio.maxSceneNumber-1){
	    studio.stop();
	    return;
	}	
	var render=studio.getRender();
	var currentScene=studio.animation.getScene(studio.sceneNumber);	
    var frames=currentScene.getFrames();
    for(var i=0;i<frames.length;i++){
        var frame=frames[i];
        var status=frame.getStatus();
        var model=frame.getModel();
        var type=model.getType();
        var id=model.getId();
        var title=model.getTitle(); 
        eval("window."+render+"('"+id+"','"+type+"','"+status+"','"+title+"')");
    }
};
