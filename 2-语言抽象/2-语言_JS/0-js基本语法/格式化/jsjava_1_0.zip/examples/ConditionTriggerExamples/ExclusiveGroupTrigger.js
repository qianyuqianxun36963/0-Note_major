/*
 *  Copyright (C) 2006 zhangbo (freeeob@gmail.com)
 *
 *  This product is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation; either version 2.1 of the License, or
 *  (at your option) any later version.
 * 
 *  This product is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 * 
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 *
 *  author:zhangbo
 *  Email:jsjava@gmail.com
 */

/*  The ExclusiveGroupTrigger class not references to any class of J2SE1.4 
 *  This class is a trigger instance scene that two groups of objects are 
 *  exclusive each other.the one is named positive,and the other is named 
 *  minus.
 */
 
/*
 * constructor
 */ 
function ExclusiveGroupTrigger(){
    
}

/*
 * set the form
 * param formName
 */ 
ExclusiveGroupTrigger.prototype.setExclusiveGroupForm=function(formName){
	this.formName=formName;
};

/*
 * return the form
 */ 
ExclusiveGroupTrigger.prototype.getExclusiveGroupForm=function(){
    return this.formName;	
};

/*
 * set name of the checkboxes of one group
 * param pc the name of positive checkbox
 */ 
ExclusiveGroupTrigger.prototype.setExclusiveGroupPositiveCheckbox=function(pc){
	this.pc=pc;
};

/*
 * get name of the checkboxes of one group
 */ 
ExclusiveGroupTrigger.prototype.getExclusiveGroupPositiveCheckbox=function(){
    return this.pc;	
};

/*
 * set name of the checkboxes of the other group
 * param mc the name of minus checkbox
 */  
ExclusiveGroupTrigger.prototype.setExclusiveGroupMinusCheckbox=function(mc){
	this.mc=mc;
};

/*
 * get name of the checkboxes of the other group
 */
ExclusiveGroupTrigger.prototype.getExclusiveGroupMinusCheckbox=function(){
    return this.mc;	
};

/*
 * set name of the select all checkbox of one group
 * param pac the name of positive all checkbox
 */
ExclusiveGroupTrigger.prototype.setExclusiveGroupPositiveAllCheckbox=function(pac){
	this.pac=pac;
};

/*
 * get name of the select all checkbox of one group
 */
ExclusiveGroupTrigger.prototype.getExclusiveGroupPositiveAllCheckbox=function(){
    return this.pac;	
};

/*
 * set name of the select all checkbox of the other group
 * param mac the name of the minus all checkbox
 */
ExclusiveGroupTrigger.prototype.setExclusiveGroupMinusAllCheckbox=function(mac){
	this.mac=mac;
};

/*
 * get name of the select all checkbox of the other group
 */
ExclusiveGroupTrigger.prototype.getExclusiveGroupMinusAllCheckbox=function(){
    return this.mac;	
};

/*
 * set the event source object
 * param eventSource
 */
ExclusiveGroupTrigger.prototype.setExclusiveGroupEventSource=function(eventSource){
	this.eventSource=eventSource;
};

/*
 * get the event source object
 */
ExclusiveGroupTrigger.prototype.getExclusiveGroupEventSource=function(){
    return this.eventSource;	
};

/*
 * execute exclusive trigger
 * param command
 */
ExclusiveGroupTrigger.prototype.exclusiveGrouptrigger=function(command){
    if(command=="positive"){
    	this.positiveEventTrigger();
    }else if(command=="minus"){
    	this.minusEventTrigger();
    }else if(command=="positiveAll"){
    	this.positiveAllEventTrigger();
    }else if(command=="minusAll"){
    	this.minusAllEventTrigger();
    }	
};

/*
 * execute positive event trigger
 */
ExclusiveGroupTrigger.prototype.positiveEventTrigger=function(){
	    var eventSource=this.getEventSource();
	    var formName=this.getForm();
	    var pcName=this.getPositiveCheckbox();
	    var mcName=this.getMinusCheckbox();
	    var pacName=this.getPositiveAllCheckbox();
	    var macName=this.getMinusAllCheckbox();
	    var formObj=document.forms(formName);
	    var pcObj=formObj.elements(pcName);
	    var mcObj=formObj.elements(mcName);
	    var pacObj=formObj.elements(pacName);
	    var macObj=formObj.elements(macName);
	    
	    if(eventSource.checked==false){
            pacObj.checked=false;
        }else{
            var isAllSelected=true;
            for(var i=0;i<pcObj.length;i++){
                if(!pcObj[i].checked){
                    isAllSelected=false;
                }
            }
            if(isAllSelected){
                pacObj.checked=true;
            }
        }
        macObj.checked=false;
        var value=eventSource.value;
        if(mcObj.length){
            for(var i=0;i<mcObj.length;i++){
                if(mcObj[i].value==value){
                    mcObj[i].checked=false;
                }
            }
        }else{
            mcObj.checked=false;
        }
        return false;
};

/*
 * execute minus event trigger
 */
ExclusiveGroupTrigger.prototype.minusEventTrigger=function(){
	    var eventSource=trigger.getEventSource();
	    var formName=this.getForm();
	    var pcName=this.getPositiveCheckbox();
	    var mcName=this.getMinusCheckbox();
	    var pacName=this.getPositiveAllCheckbox();
	    var macName=this.getMinusAllCheckbox();
	    var formObj=document.forms(formName);
	    var pcObj=formObj.elements(pcName);
	    var mcObj=formObj.elements(mcName);
	    var pacObj=formObj.elements(pacName);
	    var macObj=formObj.elements(macName);
	    
	    if(eventSource.checked==false){
            macObj.checked=false;
        }else{
            var isAllSelected=true;
            for(var i=0;i<mcObj.length;i++){
                if(!mcObj[i].checked){
                    isAllSelected=false;
                }
            }
            if(isAllSelected){
                macObj.checked=true;
            }
        }
        pacObj.checked=false;
        var value=eventSource.value;
        if(formObj.allow.length){
            for(var i=0;i<pcObj.length;i++){
                if(pcObj[i].value==value){
                    pcObj[i].checked=false;
                }
            }
        }else{
            pcObj.checked=false;
        }
        return false;
};

/*
 * execute positive all event trigger
 */
ExclusiveGroupTrigger.prototype.positiveAllEventTrigger=function(){
	    var eventSource=this.getEventSource();
	    if(eventSource.checked){
            this.changeAllPositiveState(true);
        }else{
            this.changeAllPositiveState(false);
        }
        return false;
};

/*
 * execute minus all event trigger
 */
ExclusiveGroupTrigger.prototype.minusAllEventTrigger=function(){
	    var eventSource=this.getEventSource();
	    if(eventSource.checked){
            this.changeAllMinusState(true);
        }else{
            this.changeAllMinusState(false);
        }
        return false;
};

/*
 * change all positive state to active
 */
ExclusiveGroupTrigger.prototype.changeAllPositiveState=function(isChecked){
	var eventSource=this.getEventSource();
	    var formName=this.getForm();
	    var pcName=this.getPositiveCheckbox();
	    var mcName=this.getMinusCheckbox();
	    var pacName=this.getPositiveAllCheckbox();
	    var macName=this.getMinusAllCheckbox();
	    var formObj=document.forms(formName);
	    var pcObj=formObj.elements(pcName);
	    var mcObj=formObj.elements(mcName);
	    var pacObj=formObj.elements(pacName);
	    var macObj=formObj.elements(macName);
	    
	if(isChecked){
        macObj.checked=false;
        if(pcObj.length){
            for(var i=0;i<pcObj.length;i++){
                pcObj[i].checked=true;
                mcObj[i].checked=false;
            }
        }else{
            pcObj.checked=true;
            mcObj.checked=false;
        }
    }else{
        pacObj.checked=false;
    }
};

/*
 * change all minus state to active
 */
ExclusiveGroupTrigger.prototype.changeAllMinusState=function(isChecked){
	var eventSource=this.getEventSource();
	    var formName=this.getForm();
	    var pcName=this.getPositiveCheckbox();
	    var mcName=this.getMinusCheckbox();
	    var pacName=this.getPositiveAllCheckbox();
	    var macName=this.getMinusAllCheckbox();
	    var formObj=document.forms(formName);
	    var pcObj=formObj.elements(pcName);
	    var mcObj=formObj.elements(mcName);
	    var pacObj=formObj.elements(pacName);
	    var macObj=formObj.elements(macName);
	    
	    if(isChecked){
        pacObj.checked=false;
        if(mcObj.length){
            for(var i=0;i<mcObj.length;i++){
                mcObj[i].checked=true;
                pcObj[i].checked=false;
            }
        }else{
            pcObj.checked=false;
            mcObj.checked=true;
        }
    }else{
        macObj.checked=false;
    }
};